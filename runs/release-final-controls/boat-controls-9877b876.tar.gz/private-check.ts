import {isDeepStrictEqual} from 'node:util'
const [root, input] = process.argv.slice(2)
const {extract}=await import(root+'/core/extract.ts')
const units=[['first.ts',['decideStart','decideApproval','decideRedemption']],['second.ts',['redirectAdmitted']]] as const
let ordinal=0
for(const [file,entries] of units){
  const module=await import(input+'/'+file)
  for(const entry of entries){
    const x=extract(input+'/'+file,{entry,mode:'standalone'})
    if(!x.ok||!x.evidence||x.evidence.requests<1)throw Error('default source replay did not pass')
    const m=x.model,r=x.rule,run=r.interpreter(),p=r.encodeParams({}),result=m.results[entry]
    if(m.params.length)throw Error('unexpected decision parameters')
    const fields=m.inputs.map((v:any)=>[v.name,v.sort.k==='bool'?[false,true]:v.sort.k==='choice'?v.sort.values:m.standaloneDomains?.[v.name]])
    if(fields.some(([,values]:any)=>!Array.isArray(values)))throw Error('unbounded decision domain')
    let rows:Record<string,unknown>[]=[{}]
    for(const [name,values] of fields as [string,unknown[]][]){rows=rows.flatMap(row=>values.map(value=>({...row,[name]:value})));if(rows.length>4096)throw Error('domain cap')}
    const arg=(a:any,row:Record<string,unknown>):unknown=>a.k==='input'?row[a.name]:a.k==='lit'?a.value:a.k==='rec'?Object.fromEntries(a.fields.map(([k,v]:any)=>[k,arg(v,row)])):a.k==='maybe-bool'?row[a.missing]?undefined:row[a.name]:(()=>{throw Error('unsupported argument shape')})()
    for(const row of rows){
      const event=m.events[0],theirs=module[entry](...event.args.map((a:any)=>arg(a,row)))
      const decoded=r.decode(run.step(p,run.init(p),r.encodeInput(row)))
      const ours=result.k==='rec'?Object.fromEntries(result.fields.map(([k,n]:any)=>[k,decoded[n]])):result.k==='maybe'&&decoded[result.missing]?(result.null?null:undefined):decoded[result.name]
      if(!isDeepStrictEqual(ours,theirs))throw Error('exhaustive extracted/plain mismatch')
    }
    console.log('REPLAY_EXHAUSTIVE '+JSON.stringify({decision:++ordinal,cases:rows.length,requests:x.evidence.requests,fromStates:x.evidence.fromStates,probes:x.evidence.probes,coverage:x.evidence.coverage,matched:true}))
  }
}
let lost = false
for(const [file,expected] of [['first.ts',13],['second.ts',7]] as const){
  const p=Bun.spawnSync(['bun',root+'/core/cli.ts','check',input+'/'+file,'--mode','standalone','--no-propose','--ms','30000','--json'],{stdout:'pipe',stderr:'pipe'})
  if(p.exitCode===null || !p.stdout.length)throw Error('plain-file CLI replay did not produce a receipt')
  const data=JSON.parse(p.stdout.toString()),laws=data.rules.flatMap((r:any)=>r.laws)
  const rows=laws.map((l:any)=>({id:String(l.name).match(/(?:CLI-A|MCP-B)\d+/)?.[0],verdict:l.verdict}))
  console.log('REPLAY_LAWS '+JSON.stringify({expected,exit:data.exit,checks:data.rules.map((r:any)=>r.checked),rows}))
  if(data.exit||laws.length!==expected||rows.some((r:any)=>!r.id||r.verdict!=='proven'))lost=true
}
if(lost)throw Error('law replay changed: see REPLAY_LAWS for names')
