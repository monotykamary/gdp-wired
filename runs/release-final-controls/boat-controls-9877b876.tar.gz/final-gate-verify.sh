#!/usr/bin/env bash
set -euo pipefail
control=$PWD; d=$(mktemp -d /tmp/gdp-final-verify.XXXXXX); trap 'rm -rf "$d"' EXIT
bash setup-b11.sh final-meta "$d/tree"
cd "$d/tree"; bun install --frozen-lockfile
bun "$control/gate-b11-verify.ts" "$PWD" "$control/final-receipts" "$(<"$control/final-meta/main.sha")" "$control/baseline-verified/verify-new-census-baseline.log" "$d/verified.json" "$control/retry-receipts"
printf 'FINAL_GATE_JSON '; /usr/bin/python3 -c 'import json,sys;print(json.dumps(json.load(open(sys.argv[1])),separators=(",",":")))' "$d/verified.json"
