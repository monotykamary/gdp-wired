"""Boat-only transport for the unchanged bar: serial native workers, no nested scheduler."""
import argparse
import importlib.util
import inspect
import json
import math
import os
import pathlib
import re
import runpy
import subprocess
import sys
import time
import types

if os.environ.get('GDP_BAR_ON_BOAT') != '1':
    raise RuntimeError('this adapter must run inside the Boat job')
CONTROL = pathlib.Path(os.environ['GDP_BAR_CONTROL'])
spec = importlib.util.spec_from_file_location('bar_boat_agent', CONTROL / 'boat-agent.py')
agent = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = agent
spec.loader.exec_module(agent)
sys.modules['agent'] = agent
sys.modules['modal'] = agent.modal_stub()
_original = runpy.run_path
_paths = {}

def remap(value):
    if isinstance(value, str):
        for before, after in sorted(_paths.items(), key=lambda p: -len(p[0])):
            value = value.replace(before + '/', after + '/')
            if value == before:
                value = after
        return value
    if isinstance(value, list):
        return [remap(v) for v in value]
    if isinstance(value, tuple):
        return tuple(remap(v) for v in value)
    if isinstance(value, dict):
        return {k: remap(v) for k, v in value.items()}
    return value

class LocalEx:
    backend = 'boat'
    def __init__(self, *_a, **_kw):
        pass
    def remote(self, fn, *args):
        return fn(*remap(args))
    def starmap(self, fn, args):
        for values in args:
            try:
                yield fn(*remap(values))
            except Exception as error:
                yield error
    def close(self):
        pass

def cli(fn, _file, description=''):
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument('--backend', default='boat')
    for name, parameter in list(inspect.signature(fn).parameters.items())[1:]:
        kwargs = {}
        if parameter.default is inspect.Parameter.empty:
            kwargs['required'] = True
        else:
            kwargs['default'] = parameter.default
        if isinstance(parameter.default, bool):
            kwargs['action'] = 'store_true'
        else:
            kwargs['type'] = parameter.annotation if parameter.annotation in (str, int, float) else type(parameter.default) if parameter.default is not inspect.Parameter.empty else str
        parser.add_argument('--' + name.replace('_', '-'), **kwargs)
    values = vars(parser.parse_args())
    if values.pop('backend') != 'boat':
        raise RuntimeError('remote bar transport refuses a mislabeled Modal fallback')
    return fn(LocalEx(), **values)

def run_jobs(_app, jobs, out, pre='', command=lambda c: c, *_a, **_kw):
    destination = pathlib.Path(out)
    destination.mkdir(parents=True, exist_ok=True)
    rows = []
    available = os.environ['GDP_BAR_CPUS'].split(',')
    for job in jobs:
        cpus = available[:max(1, math.ceil(float(job.get('cpu', 2))))]
        if len(cpus) < math.ceil(float(job.get('cpu', 2))):
            raise RuntimeError('insufficient CPUs for a native bar job')
        started = time.monotonic()
        result = subprocess.run(['taskset', '-c', ','.join(cpus), 'timeout', '-s', 'KILL', str(job.get('timeout', 900)), 'bash', '-c', pre + command(remap(job['cmd']))], cwd=pathlib.Path.cwd() / job.get('cwd', '.'), capture_output=True, text=True)
        elapsed = time.monotonic() - started
        (destination / (job['name'] + '.log')).write_text(result.stdout + '\n--- stderr ---\n' + result.stderr)
        rows.append((job['name'], result.returncode, elapsed))
    (destination / 'summary.tsv').write_text(''.join(f'{name}\t{code}\t{elapsed}\tboat\n' for name, code, elapsed in rows))
    (destination / 'backends.json').write_text(json.dumps({'where': {'boat': len(rows)}, 'transport': 'serial native execution inside the outer Boat job'}))
    return {name: {'code': code, 'seconds': elapsed} for name, code, elapsed in rows}

fanout = types.ModuleType('fanout')
fanout.ModalEx = LocalEx
fanout.BoatEx = LocalEx
fanout.cli = cli
fanout.run_jobs = run_jobs
fanout.reexec_with_modal = lambda: None
sys.modules['fanout'] = fanout

def transported(path, init_globals=None, run_name=None):
    global _paths
    path = pathlib.Path(path).resolve()
    root = str(pathlib.Path.cwd())
    _paths = {'/work/gdp-wired': root, '/src/gdp-wired': root, '/chc': '/opt/gdpw/chc/bench', '/its': '/opt/gdpw/term/bench', '/goals': os.environ['GDP_BAR_GOALS']}
    if path.name == 'boat.py':
        return {}
    if path.name == 'modal_chc.py':
        _paths['/bench'] = '/opt/gdpw/chc/bench'
    elif path.name == 'modal_term.py':
        _paths['/bench'] = '/opt/gdpw/term/bench'
    elif path.name == 'modal_tip.py':
        _paths['/bench'] = '/opt/gdpw/tip/bench'
        os.environ['PATH'] = '/opt/bun-1.4.4/bin:' + os.environ['PATH']
    source = path.read_text()
    for before, after in _paths.items():
        for quote in ('"', "'"):
            source = source.replace(quote + before + quote, quote + after + quote).replace(quote + before + '/', quote + after + '/')
    namespace = {'__name__': run_name or '<run_path>', '__file__': str(path), '__package__': None, '__spec__': None, '__cached__': None}
    namespace.update(init_globals or {})
    sys.path.insert(0, str(path.parent))
    exec(compile(source, str(path), 'exec'), namespace)
    return namespace

runpy.run_path = transported
