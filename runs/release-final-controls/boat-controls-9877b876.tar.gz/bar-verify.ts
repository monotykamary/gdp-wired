import {readFileSync} from 'node:fs'
import {createHash} from 'node:crypto'
import {join} from 'node:path'
const [root,folder,expected]=process.argv.slice(2)
if(!root||!folder||!expected)throw Error('bar verify ROOT FOLDER EXPECTED')
const {VIEWS,testTimes,goals,goalSig}=await import(join(root,'gates/bar-lib.ts'))
const report=JSON.parse(readFileSync(join(folder,'bar/runs/combined-quick/report.json'),'utf8'))
const required=['chc','its','its-scc','sv','sv-scc','tip','f1','f2','rw','g332','lean']
const expectedBase='b11e1f651618b3d3fcaf6cec66b4a8b0203cdcd3'
if(report.trees.cand.sha!==expected||report.trees.base.sha!==expectedBase||report.coverageErrors.length)throw Error('bar identity or coverage')
if(report.results.length!==10||required.some(v=>!report[v]))throw Error('missing result group or view')
const views:Record<string,unknown>={}
for(const key of required){const view=report[key];if(!view.candidate)throw Error('empty view '+key);if((view.candidate.wrong??0)!==0||(view.candidate.error??0)!==0)throw Error('wrong/error in '+key);if((view.tasks??[]).some((t:any)=>t.kind==='wrong'||t.kind==='lost'&&t.solid))throw Error('wrong or solid loss in '+key);views[key]={candidate:view.candidate,base:view.base??[],gained:(view.tasks??[]).filter((t:any)=>t.kind==='gained'&&t.solid).length,lost:(view.tasks??[]).filter((t:any)=>t.kind==='lost'&&t.solid).length}}
for(const result of report.results){if(result.error||result.metas.some((m:any)=>m.code!==0))throw Error('failed launch '+result.group);if(!result.quick)continue;const names=result.group==='its'?['its','its-scc']:result.group==='sv'?['sv','sv-scc']:result.group==='onecpu'?[]:[result.group];for(const key of names){const reader=VIEWS[key];const candidate=reader.parse(result.cand,report.trees.cand.path);if(result.quick.some((k:string)=>!candidate.has(k)))throw Error('missing candidate task '+key);for(const base of result.base){const rows=reader.parse(base,report.trees.base.path);if(result.quick.some((k:string)=>!rows.has(k)))throw Error('missing baseline task '+key)}}}
if(report.g332.candidate.proven!==332||report.g332.candidate.goals!==332||report.g332.base.some((b:any)=>b.proven!==332||b.goals!==332))throw Error('g332 is not 332/332 on both sides')
if(report.lean.candidate.checked!==6||report.lean.candidate.sampled!==6)throw Error('Lean did not check all six')
const cpu=report.results.find((r:any)=>r.group==='onecpu'),a=testTimes(cpu.cand),b=testTimes(cpu.base[0])
if(a.failed.length||b.failed.length||!a.tests.size||a.tests.size!==b.tests.size||[...a.tests].some(([key,times]:any)=>times.length!==3||b.tests.get(key)?.length!==3))throw Error('onecpu tests failed or incomplete')
const query=report.results.find((r:any)=>r.group==='g332'),q1=goals(query.cand),q2=goals(query.base[0])
const equal=[...q1].filter(([key,value]:any)=>q2.has(key)&&goalSig(value)===goalSig(q2.get(key))).length
const hashes:Record<string,string>={}
for(const file of ['gates/bar.ts','gates/bar-lib.ts','gates/bar-dev.json']){const hash=(path:string)=>createHash('sha256').update(readFileSync(path)).digest('hex');const x=hash(join(report.trees.cand.path,file)),y=hash(join(report.trees.base.path,file));if(x!==y)throw Error('benchmark/scoring source changed '+file);hashes[file]=x}
const evidence=JSON.parse(readFileSync(join(folder,'transport-proof.json'),'utf8'))
const summary={candidate:expected,baseline:expectedBase,groups:10,views,onecpu:{failed:0,tests:a.tests.size,runsPerTest:3},g332SameSearch:equal,benchmarkHashes:hashes,transport:evidence}
console.log('BAR_FINAL_VERIFIED '+JSON.stringify(summary))
console.log('BAR_FINAL_REPORT64 '+Buffer.from(readFileSync(join(folder,'bar/runs/combined-quick/REPORT.md'))).toString('base64'))
console.log('BAR_FINAL_JSON64 '+Buffer.from(JSON.stringify(report,null,2)+'\n').toString('base64'))
