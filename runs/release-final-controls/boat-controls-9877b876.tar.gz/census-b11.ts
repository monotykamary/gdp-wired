import {readFileSync} from 'node:fs'
import {join} from 'node:path'
const index=Number(process.argv[2]), count=Number(process.argv[3]);
const baselineText=readFileSync(join(process.argv[4]!, 'verify-new-census-baseline.log'),'utf8');
const line=baselineText.split('\n').find(l=>l.startsWith('BASELINE_CENSUS_VERIFIED '));
if(!line)throw Error('missing verified baseline');
const baseline=JSON.parse(line.slice('BASELINE_CENSUS_VERIFIED '.length));
if(baseline.commit!=='b11e1f651618b3d3fcaf6cec66b4a8b0203cdcd3')throw Error('wrong baseline');
const expected=new Map<string,string>(baseline.rows.map((r:{id:string,verdict:string})=>[r.id,r.verdict]));
const {protocols}=await import(process.cwd()+'/research/protocols/ic3syn/models.ts');
const ids=protocols.filter((_:unknown,k:number)=>k%count===index).map((p:{id:string})=>p.id);
if(protocols.length!==29||expected.size!==29)throw Error('census roster changed');
console.log('CENSUS_ROSTER '+JSON.stringify({index,count,total:protocols.length,ids,baseline:baseline.commit}));
const result=Bun.spawnSync(['bun','research/protocols/ic3syn/run.ts','--only',ids.join(','),'--ms','60000','--skip','broken'],{stdout:'pipe',stderr:'pipe'});
process.stdout.write(result.stdout);process.stderr.write(result.stderr);
const rows=result.stdout.toString().split('\n').filter(l=>l.startsWith('{')).map(l=>JSON.parse(l));
if(result.exitCode||rows.length!==ids.length||new Set(rows.map(r=>r.id)).size!==ids.length||rows.some(r=>r.error||!ids.includes(r.id)||r.search?.verdict!==expected.get(r.id)))throw Error('incomplete or changed census');
console.log('CENSUS_COMPLETE '+JSON.stringify({index,count,rows:rows.length,unchanged:true,baseline:baseline.commit,verdicts:rows.map(r=>[r.id,r.search.verdict])}));
