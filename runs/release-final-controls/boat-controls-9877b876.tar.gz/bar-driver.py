import fcntl
import importlib.util
import json
import time
import os
import pathlib
import runpy
import sys

# Only the bar's orchestration entrypoints use this adapter. Python helpers
# launched by a benchmark keep ordinary interpreter semantics.
entry = pathlib.Path(sys.argv[1]).name if len(sys.argv) > 1 else ''
if entry not in {'run.py', 'modal_chc.py', 'modal_term.py', 'modal_tip.py', 'modal_sv.py', 'modal_query.py', 'boat-pass.py'}:
    os.execv('/usr/bin/python3', ['/usr/bin/python3', *sys.argv[1:]])
control = pathlib.Path(os.environ['GDP_BAR_CONTROL'])
spec = importlib.util.spec_from_file_location('bar_direct_transport', control / 'bar-direct.py')
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
cpus = [int(x) for x in os.environ.get('GDP_BAR_LEASED_CPUS', os.environ['GDP_BAR_CPUS']).split(',')]
locks = []
lease_root = os.environ.get('GDP_BAR_CPU_LEASES')
inherited_lease = bool(os.environ.get('GDP_BAR_LEASED_CPUS'))
if lease_root and not os.environ.get('GDP_BAR_LEASED_CPUS'):
    # Whole benchmark drivers get disjoint two-CPU leases. The dependent Lean
    # pass needs four CPUs, after its ITS producers have all completed.
    wide = any('/lean/' in arg or '/lean.' in arg for arg in sys.argv[1:])
    slots = [open(pathlib.Path(lease_root) / f'{i}.lock', 'a') for i in range(len(cpus) // 2)]
    if wide:
        for slot in slots:
            fcntl.flock(slot, fcntl.LOCK_EX)
        locks = slots
    else:
        chosen = None
        for i, slot in enumerate(slots):
            try:
                fcntl.flock(slot, fcntl.LOCK_EX | fcntl.LOCK_NB)
                chosen = i
                break
            except BlockingIOError:
                pass
        if chosen is None:
            chosen = 0
            fcntl.flock(slots[chosen], fcntl.LOCK_EX)
        locks = [slots[chosen]]
        cpus = cpus[chosen * 2:chosen * 2 + 2]
        for i, slot in enumerate(slots):
            if i != chosen: slot.close()
elif not os.environ.get('GDP_BAR_LEASED_CPUS'):
    cpus = cpus[:2]
os.sched_setaffinity(0, cpus)
os.environ['GDP_BAR_CPUS'] = ','.join(map(str, cpus))
os.environ['GDP_BAR_LEASED_CPUS'] = os.environ['GDP_BAR_CPUS']
sys.argv = sys.argv[1:]
receipt = {'pid': os.getpid(), 'cpus': sorted(os.sched_getaffinity(0)), 'inherited': inherited_lease}
print('BAR_CPU_LEASE ' + json.dumps({**receipt, 'event': 'start', 'time': time.monotonic()}), flush=True)
try:
    runpy.run_path(sys.argv[0], run_name='__main__')
finally:
    print('BAR_CPU_LEASE ' + json.dumps({**receipt, 'event': 'end', 'time': time.monotonic()}), flush=True)
    for slot in locks: slot.close()
