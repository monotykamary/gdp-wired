import base64
import gzip
import hashlib
import json
import pathlib
import sys

receipt_dir, output_dir, metadata_dir = map(pathlib.Path, sys.argv[1:4])
expected_base = 'b11e1f651618b3d3fcaf6cec66b4a8b0203cdcd3'
expected_candidate = (metadata_dir / 'main.sha').read_text().strip()
groups = ['chc', 'its', 'sv', 'tip', 'f1', 'f2', 'rw', 'g332', 'onecpu']
output_dir.mkdir(parents=True, exist_ok=True)
results = []
proof = []
started = []
wall = 0

def replace_tree(value, old_root, group):
    if isinstance(value, str):
        shared = str(output_dir / 'bar' / 'trees')
        local = str(output_dir / 'groups' / group)
        return value.replace(old_root + '/bar/trees', shared).replace(old_root, local)
    if isinstance(value, list):
        return [replace_tree(x, old_root, group) for x in value]
    if isinstance(value, dict):
        return {k: replace_tree(v, old_root, group) for k, v in value.items()}
    return value

for group in groups:
    log = receipt_dir / ('quick-bar-' + group + '.log')
    lines = log.read_text().splitlines()
    exports = [json.loads(x.removeprefix('BAR_EXPORT ')) for x in lines if x.startswith('BAR_EXPORT ')]
    bundles = [x.removeprefix('BAR_BUNDLE ') for x in lines if x.startswith('BAR_BUNDLE ')]
    assert len(exports) == 1 and len(bundles) <= 1, (group, 'missing or duplicated export')
    export = exports[0]
    if export['inline']:
        assert len(bundles) == 1, (group, 'missing inline bundle')
        compressed = base64.b64decode(bundles[0], validate=True)
    else:
        assert not bundles, (group, 'unexpected inline bundle')
        compressed = (receipt_dir / 'external' / (group + '.json.gz')).read_bytes()
    assert hashlib.sha256(compressed).hexdigest() == export['sha256'], (group, 'bundle hash')
    bundle = json.loads(gzip.decompress(compressed))
    assert bundle['group'] == group and bundle['mode'] == 'quick', group
    assert bundle['status'] == export['status'] == 0, (group, 'bar did not exit zero')
    assert bundle['candidate'] == export['candidate'] == expected_candidate, (group, 'candidate')
    assert bundle['base'] == export['base'] == expected_base, (group, 'baseline')
    report_key = 'bar/runs/quick-' + group + '/report.json'
    assert report_key in bundle['files'], (group, 'missing canonical report')
    report = json.loads(base64.b64decode(bundle['files'][report_key]))
    assert not report['coverageErrors'], (group, report['coverageErrors'])
    assert report['trees']['cand']['sha'] == expected_candidate and report['trees']['cand']['clean'], group
    assert report['trees']['base']['sha'] == expected_base and report['trees']['base']['clean'], group
    old_root = report['trees']['cand']['path'].split('/bar/trees/')[0]
    assert bundle['root'] == old_root, (group, 'root identity')
    events = []
    for name, encoded in bundle['files'].items():
        relative = pathlib.PurePosixPath(name)
        assert not relative.is_absolute() and '..' not in relative.parts, (group, name)
        data = base64.b64decode(encoded, validate=True)
        if name.endswith('.log'):
            for line in data.decode(errors='replace').splitlines():
                if line.startswith('BAR_CPU_LEASE '):
                    events.append(json.loads(line.removeprefix('BAR_CPU_LEASE ')))
        if name.endswith('.json'):
            obj = json.loads(data)
            data = (json.dumps(replace_tree(obj, old_root, group), indent=1) + '\n').encode()
        target = output_dir / 'groups' / group / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    leases = {}
    spans = []
    for event in events:
        if event['inherited']:
            continue
        assert len(event['cpus']) in (2, 4) and len(set(event['cpus'])) == len(event['cpus']), (group, event)
        if event['event'] == 'start':
            assert event['pid'] not in leases, (group, 'overlapping pid', event)
            leases[event['pid']] = event
        else:
            assert event['event'] == 'end' and event['pid'] in leases, (group, 'unpaired lease', event)
            begin = leases.pop(event['pid'])
            assert begin['cpus'] == event['cpus'] and begin['time'] <= event['time'], group
            spans.append({'pid': event['pid'], 'cpus': event['cpus'], 'start': begin['time'], 'end': event['time']})
    assert not leases and spans, (group, 'missing or unfinished CPU leases', leases)
    for i, a in enumerate(spans):
        for b in spans[i + 1:]:
            if a['start'] < b['end'] and b['start'] < a['end']:
                assert not set(a['cpus']).intersection(b['cpus']), (group, 'overlapping CPU leases', a, b)
    assert {r['group'] for r in report['results']} == ({'its', 'lean'} if group == 'its' else {group}), group
    for target_result in report['results']:
        assert not target_result.get('error'), (group, target_result.get('error'))
        assert all(meta['code'] == 0 for meta in target_result['metas']), (group, 'failed launch')
        assert target_result.get('cand') and (target_result['base'] or target_result['group'] == 'lean'), (group, 'empty sides')
        results.append(replace_tree(target_result, old_root, group))
    proof.append({'group': group, 'sha256': export['sha256'], 'files': len(bundle['files']), 'cpuLeases': spans, 'report': report_key})
    started.append(report['started'])
    wall += report['wall_s']
    print('BAR_COLLECTED ' + json.dumps({'group': group, 'files': len(bundle['files']), 'cpuLeases': len(spans)}))

assert len(results) == len(groups) + 1 and {r['group'] for r in results} == set(groups) | {'lean'}
def tree(sha):
    return {'path': str(output_dir / 'bar' / 'trees' / sha[:12]), 'sha': sha, 'key': sha[:12], 'clean': True, 'label': sha[:12]}
combined = {'results': results, 'trees': {'cand': tree(expected_candidate), 'base': tree(expected_base)}, 'started': min(started), 'wall_s': wall}
run_dir = output_dir / 'bar' / 'runs' / 'combined-quick'
run_dir.mkdir(parents=True, exist_ok=True)
(run_dir / 'report.json').write_text(json.dumps(combined, indent=2) + '\n')
(output_dir / 'transport-proof.json').write_text(json.dumps({'candidate': expected_candidate, 'base': expected_base, 'groups': proof, 'timing': 'Paired canonical quick mode (--quick --together): one initial baseline and candidate pass, three reruns per side of each difference. Exclusive xlarge Boat VMs; unchanged benchmark/prover/scoring code; native two-CPU workers with disjoint leases, four CPUs for the dependent Lean pass. Native jobs serialized inside each driver; do not compare wall time to a normal distributed bar.'}, indent=2) + '\n')
