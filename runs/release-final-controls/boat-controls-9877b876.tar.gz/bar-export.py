import base64,gzip,hashlib,json,pathlib,sys
root=pathlib.Path(sys.argv[1]); base,candidate,group,status,mode=sys.argv[2:]
report=root/'bar'/'runs'/(mode+'-'+group)/'report.json'
if not report.exists(): raise RuntimeError('bar has no final report')
files={}
for path in (root/'bar').rglob('*'):
 if not path.is_file() or any(part in {'trees','bench'} for part in path.relative_to(root/'bar').parts): continue
 files[str(path.relative_to(root))]=base64.b64encode(path.read_bytes()).decode()
manifest={'root':str(root),'base':base,'candidate':candidate,'group':group,'mode':mode,'status':int(status),'files':files}
packed=gzip.compress(json.dumps(manifest,separators=(',',':')).encode(),mtime=0)
archive=pathlib.Path.home()/'.cache'/'gdp-wired-bar-artifacts'/candidate/(mode+'-'+group+'.json.gz')
archive.parent.mkdir(parents=True,exist_ok=True)
archive.write_bytes(packed)
print('BAR_REMOTE_REPORT '+json.dumps(json.loads(report.read_text()),separators=(',',':')))
print('BAR_EXPORT '+json.dumps({'base':base,'candidate':candidate,'group':group,'status':int(status),'files':len(files),'compressedBytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'archive':str(archive),'inline':len(packed)<=250000}))
if len(packed)<=250000: print('BAR_BUNDLE '+base64.b64encode(packed).decode())
