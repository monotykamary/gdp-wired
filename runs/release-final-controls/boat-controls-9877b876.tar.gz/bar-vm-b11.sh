#!/usr/bin/env bash
set -euo pipefail
group=$1; mode=${2:-quick}; control=$PWD; d=$(mktemp -d /tmp/gdp-bar-b11.XXXXXX); trap 'rm -rf "$d"' EXIT
bash setup-b11.sh baseline-meta "$d/base"
bash setup-b11.sh law-meta "$d/candidate"
base=$(<baseline-meta/main.sha); candidate=$(<law-meta/main.sha)
git -C "$d/candidate" hash-object -t commit -w --stdin < baseline-meta/main.commit >/dev/null
mkdir -p "$d/control/bin" "$d/bar/trees"
cp bar-direct.py bar-driver.py boat-agent.py "$d/control/"
ln -s "$d/base" "$d/bar/trees/${base:0:12}"
ln -s "$d/candidate" "$d/bar/trees/${candidate:0:12}"
for tree in "$d/base" "$d/candidate"; do
 printf '.bar-ready\n' >> "$tree/.git/info/exclude"; touch "$tree/.bar-ready"
 mkdir -p "$tree/runs/modal/dag"; ln -s "$control/bar-goals" "$tree/runs/modal/dag/goals"
 (cd "$tree"; bun install --frozen-lockfile)
done
export GDP_BAR_ON_BOAT=1 GDP_BAR_CONTROL="$d/control" GDP_BAR_GOALS="$control/bar-goals"
export GDP_BAR_CPUS=$(/usr/bin/python3 -c 'import os; print(",".join(map(str, sorted(os.sched_getaffinity(0))[:4])))')
export GDP_BAR_CPU_LEASES="$d/control/cpu-leases"
mkdir -p "$GDP_BAR_CPU_LEASES"
printf '#!/bin/sh\nexec /usr/bin/python3 "$GDP_BAR_CONTROL/bar-driver.py" "$@"\n' > "$d/control/bin/python3"
printf '#!/bin/sh\n[ "$1" = reap ] && exit 0\nexit 64\n' > "$d/control/bin/supercomputer"
chmod +x "$d/control/bin/python3" "$d/control/bin/supercomputer"
export PATH="$d/control/bin:$PATH" SUPERCOMPUTER_CLASS=submission GDPW_BAR_DIR="$d/bar" GDP_CYCLIC_LOG=0
cd "$d/candidate"
only=$group; [ "$group" != its ] || only=its,lean
mode_args=(--quick); [ "$mode" != smoke ] || mode_args=(--smoke)
set +e
bun gates/bar.ts --cand "$candidate" --base "$base" "${mode_args[@]}" --together --only "$only" --backend boat --procs 2 --name "$mode-$group"
status=$?
set -e
for tree in "$d/base" "$d/candidate"; do test -z "$(git -C "$tree" status --porcelain --untracked-files=all)"; done
/usr/bin/python3 "$control/bar-export.py" "$d" "$base" "$candidate" "$group" "$status" "$mode"
exit "$status"
