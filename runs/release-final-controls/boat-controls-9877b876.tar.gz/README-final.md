# Final Boat verification controls

Candidate: 9877b8762d516506cda2b222282447235ae6fd5b
Baseline: b11e1f651618b3d3fcaf6cec66b4a8b0203cdcd3

`setup-b11.sh` reconstructs exact clean Git commits from the cached baseline archive, vendor archives, a binary Git diff, raw commit objects and expected tree hashes. It refuses content mismatches. The metadata can be regenerated from these two Git commits; the private application files are deliberately not included.

`gate-b11.jobs.json` / `gate-b11.sh` run the unchanged per-unit full-suite sharding, default four-seed differential sweep (1,664 cases), all mutation suites, build/exports, private replay and 29-model census. Correct data mounts include `runs/b11-census-baseline-verified` as `baseline-verified` and the previously prepared annotated two-file private fixture as `ci-private`. The first final submission mistakenly referenced nonexistent directories for these two mounts. Only its eight affected jobs were retried (`gate-final-data-retry.jobs.json`); all original failures remain recorded. `gate-b11-verify.ts` accepts exactly those eight setup-only replacements and refuses any other failing job.

`bar-b11.jobs.json` / `bar-vm-b11.sh` run all nine canonical quick-bar jobs (ten result groups, including dependent Lean). They use `--quick --together`, one initial baseline/candidate pass, and the canonical three reruns per side of each difference. These are paired dev-set comparisons, not new full-corpus cached baseline runs. The initial uncached full-baseline attempts were cancelled and are not passes.

`bar-direct.py` and the pinned `boat-agent.py` replace transport only: the original benchmark, solver commands, budgets and scoring source remain unchanged. Native worker jobs are serial inside each driver. `bar-driver.py` grants disjoint two-CPU leases to baseline and candidate drivers, and four CPUs to the subsequent Lean pass. Nested Python helpers keep ordinary interpreter semantics; nested drivers inherit the lease. All work runs inside submission-class Boat jobs with exclusive xlarge placement. Do not compare these wall times to a normal distributed bar.

`bar-export.py` preserves all score/replay artifacts except re-downloadable static `bar/bench` inputs and source tree links. It writes a hash-addressed compressed manifest; small manifests are inline, large ones are retained under the VM user's `~/.cache/gdp-wired-bar-artifacts/<candidate>/` for exact-VM `boat scp` retrieval. `bar-collect.py` checks hashes, exact source identities, launch status and CPU-lease intervals. `bar-final-collect.sh` restores both source trees and invokes the unmodified canonical reporter; `bar-verify.ts` additionally requires complete views, no wrong/solid-lost verdicts, all 332 goals, all six Lean samples and complete one-CPU repetitions.

No application source, credentials or proof budgets are embedded in this control archive. Metadata paths in the controller invocation are workspace-local mounts, not published services.
