#!/usr/bin/env bash
set -euo pipefail
control=$PWD; mode=$1; d=$(mktemp -d /tmp/gdp-final-b11.XXXXXX); trap 'rm -rf "$d"' EXIT
bash setup-b11.sh final-meta "$d/tree"
cd "$d/tree"; export NODE_OPTIONS=--max-old-space-size=8192 GDP_CYCLIC_LOG=0
run_checked() {
 local phase=$1; shift
 if "$@" > "$d/$phase.log" 2>&1; then
  echo "PASS $phase"
  grep -E '^ *[0-9]+ (pass|fail)|Ran [0-9]+|Found [0-9]+|^TRANSLATION_SMOKE |^ *[0-9]+[.][0-9]+ s ' "$d/$phase.log" | tail -n 200 || true
 else
  local status=$?; echo "FAIL $phase exit=$status"; grep -E '^FAILED' "$d/$phase.log" || true; tail -n 260 "$d/$phase.log"; exit "$status"
 fi
}
run_checked install bun install --frozen-lockfile
case "$mode" in
 check)
  run_checked check bun run check
  run_checked build bun run build
  run_checked treadmill python3 research/translation-fuzz/treadmill_test.py
  run_checked exports bun test core/exports.test.ts core/runtime-default.test.ts --timeout 60000
  for message in "$control"/final-meta/messages/*.txt; do bunx @commitlint/cli --config research/egraph/historical/commitlint.config.cjs < "$message"; done
  echo 'PASS commitlint';;
 test) run_checked tests bun scripts/test-shards.ts --measure "$d/unit-times.json" --shard "$2";;
 runtime) run_checked runtime bun test core/runtime.test.ts --timeout 600000;;
 census) bun "$control/census-b11.ts" "$2" 7 "$control/baseline-verified";;
 mutants) bun research/verify-all/optional-choice-mutants.ts; bun research/verify-all/ci-audit-mutants.ts; bun research/verify-all/law-crosscheck-mutants.ts; bun research/verify-all/ci-sibling-mutants.ts; git diff --exit-code;;
 replay) bun "$control/final-control/private-check.ts" "$PWD" "$control/ci-private";;
 fuzz) bun research/translation-fuzz/run.ts --api "$PWD" --seed "$2" --count 208 --shard "$3" --shards 2 --case-ms 15000 --expect-clean --emit-cases --out "$d/fuzz";;
 *) exit 2;;
esac
