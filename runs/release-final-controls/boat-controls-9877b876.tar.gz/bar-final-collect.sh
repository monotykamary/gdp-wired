#!/usr/bin/env bash
set -euo pipefail
control=$PWD; d=$(mktemp -d /tmp/gdp-bar-collect.XXXXXX); trap 'rm -rf "$d"' EXIT
base=$(<baseline-meta/main.sha); cand=$(<law-meta/main.sha)
bash setup-b11.sh baseline-meta "$d/bar/trees/${base:0:12}"
bash setup-b11.sh law-meta "$d/bar/trees/${cand:0:12}"
/usr/bin/python3 bar-collect.py bar-receipts "$d" law-meta
cd "$d/bar/trees/${cand:0:12}"; bun install --frozen-lockfile
mkdir -p "$d/bin"; printf '#!/bin/sh\nprintf "[]\\n"\n' > "$d/bin/modal"; chmod +x "$d/bin/modal"
PATH="$d/bin:$PATH" GDPW_BAR_DIR="$d/bar" bun gates/bar.ts report "$d/bar/runs/combined-quick" --quick --together --backend boat
bun "$control/bar-verify.ts" "$PWD" "$d" "$cand"
