// @bun
// research/track-m/section18-run.ts
import { readFileSync, writeFileSync, mkdirSync } from "fs";
import { join as join2 } from "path";

// core/check.ts
var vars = (lin) => Object.keys(lin).filter((key) => key !== "1");
var exact = (lin) => Object.values(lin).every((c) => Number.isSafeInteger(c));
function checkRefutation(constraints, steps, integral = true) {
  const rows = [], strict = [];
  for (const [i, s] of steps.entries()) {
    if (s.kind === "input") {
      if (!(Number.isInteger(s.index) && s.index >= 0 && s.index < constraints.length))
        return false;
      const c = constraints[s.index];
      if (!exact(c.lin))
        return false;
      rows.push(c.lin);
      strict.push(!integral && c.strict === true);
    } else if (s.kind === "combine") {
      if (!(s.a < i && s.b < i && Number.isSafeInteger(s.ma) && Number.isSafeInteger(s.mb) && s.ma > 0 && s.mb > 0))
        return false;
      if (!integral && !(Number.isInteger(s.a) && Number.isInteger(s.b) && s.a >= 0 && s.b >= 0))
        return false;
      const out = Object.create(null);
      for (const [lin, m] of [[rows[s.a], s.ma], [rows[s.b], s.mb]])
        for (const [key, c] of Object.entries(lin)) {
          if (!Number.isSafeInteger(m * c))
            return false;
          out[key] = (out[key] ?? 0) + m * c;
        }
      if (!exact(out))
        return false;
      rows.push(out);
      strict.push(strict[s.a] || strict[s.b]);
    } else {
      if (!integral)
        return false;
      const row = rows[s.of];
      if (!(row !== undefined && s.of < i && Number.isSafeInteger(s.g) && s.g > 0 && vars(row).every((key) => row[key] % s.g === 0)))
        return false;
      rows.push({ ...Object.fromEntries(vars(row).map((key) => [key, row[key] / s.g])), 1: Math.ceil((row["1"] ?? 0) / s.g) });
      strict.push(false);
    }
  }
  const last = rows.at(-1), constant = last?.["1"] ?? 0;
  return last !== undefined && vars(last).every((key) => last[key] === 0) && (constant > 0 || strict.at(-1) && constant >= 0);
}

// core/q.ts
var bgcd = (a, b) => {
  a = a < 0n ? -a : a;
  b = b < 0n ? -b : b;
  while (b)
    [a, b] = [b, a % b];
  return a;
};
var q = (num, den = 1n) => {
  let n = BigInt(num), d = BigInt(den);
  if (d === 0n)
    throw new RangeError("a rational with denominator 0");
  if (d < 0n) {
    n = -n;
    d = -d;
  }
  const g = bgcd(n, d) || 1n;
  return { num: n / g, den: d / g };
};
var Q0 = q(0);
var Q1 = q(1);
var qadd = (a, b) => q(a.num * b.den + b.num * a.den, a.den * b.den);
var qsub = (a, b) => q(a.num * b.den - b.num * a.den, a.den * b.den);
var qmul = (a, b) => q(a.num * b.num, a.den * b.den);
var qdiv = (a, b) => q(a.num * b.den, a.den * b.num);
var qneg = (a) => ({ num: -a.num, den: a.den });
var qcmp = (a, b) => {
  const d = a.num * b.den - b.num * a.den;
  return d < 0n ? -1 : d > 0n ? 1 : 0;
};
var qnum = (a) => Number(a.num) / Number(a.den);
var qrow = (lin, at) => {
  let out = Q0;
  for (const [key, c] of Object.entries(lin))
    out = qadd(out, qmul(q(c), key === "1" ? Q1 : at[key] ?? Q0));
  return out;
};

// core/solver.ts
var env = globalThis.process?.env ?? {};
var v = (name) => ({ [name]: 1 });
var k = (value) => value === 0 ? {} : { 1: value };
function add(...xs) {
  const out = Object.create(null);
  for (const x of xs)
    for (const key in x)
      out[key] = (out[key] ?? 0) + x[key];
  for (const key in out)
    if (out[key] === 0)
      delete out[key];
  return out;
}
var scale = (x, f) => {
  const out = Object.create(null);
  for (const key in x) {
    const value = x[key] * f;
    if (value !== 0)
      out[key] = value;
  }
  return out;
};
var sub = (a, b) => {
  const out = Object.create(null);
  for (const key in a)
    out[key] = a[key];
  for (const key in b)
    out[key] = (out[key] ?? 0) - b[key];
  for (const key in out)
    if (out[key] === 0)
      delete out[key];
  return out;
};
var gcd = (a, b) => b === 0 ? Math.abs(a) : gcd(b, a % b);
var vars2 = (lin) => Object.keys(lin).filter((key) => key !== "1");
var plus = (a, b, f = 1) => {
  const o = { ...a };
  for (const x in b) {
    o[x] = (o[x] ?? 0) + f * b[x];
    if (!o[x])
      delete o[x];
  }
  return o;
};
var times = (a, f) => {
  const o = {};
  if (f)
    for (const x in a)
      o[x] = a[x] * f;
  return o;
};
var konst = (c) => c ? { 1: c } : {};
var work = { n: 0 };
var costs = {
  solves: 0,
  solveRows: 0,
  fm: 0,
  fpivots: 0,
  fcells: 0,
  cdclNodes: 0,
  cdclRows: 0,
  scan: 0,
  pivots: 0,
  pivotRows: 0,
  plainNodes: 0,
  plainRows: 0,
  values: 0,
  copies: 0,
  edges: 0,
  unitRows: 0,
  unfoldRows: 0,
  goalNodes: 0,
  translateRows: 0
};
function solve(constraints, maxRows = 20000, integral = true) {
  work.n += constraints.length;
  costs.solves++;
  costs.solveRows += constraints.length;
  const steps = [];
  const lins = [], stricts = [];
  const push = (step, lin, strict = false) => (steps.push(step), lins.push(lin), stricts.push(strict), lins.length - 1);
  const tighten = (index) => {
    if (!integral)
      return index;
    const lin = lins[index];
    let g = 0;
    for (const key in lin)
      if (key !== "1") {
        g = gcd(g, lin[key]);
        if (g === 1)
          return index;
      }
    if (g <= 1)
      return index;
    const cut = {};
    for (const key in lin)
      if (key !== "1")
        cut[key] = lin[key] / g;
    const constant = Math.ceil((lin["1"] ?? 0) / g);
    return push({ kind: "cut", of: index, g }, add(cut, k(constant)));
  };
  let rows = constraints.map((c, index) => tighten(push({ kind: "input", index }, c.lin, !integral && c.strict === true)));
  const contra = [];
  const isContra = (r) => contra[r] ??= ((lins[r]["1"] ?? 0) > 0 || stricts[r] && (lins[r]["1"] ?? 0) >= 0) && Object.keys(lins[r]).every((key) => key === "1");
  let inexact = false;
  const pushExact = (step, lin, strict) => {
    if (!integral && !Object.values(lin).every((c) => Number.isSafeInteger(c)))
      inexact = true;
    return push(step, lin, strict);
  };
  const contradiction = () => rows.find(isContra);
  const eliminated = [];
  let exact = true;
  const keyOf = (lin) => JSON.stringify(Object.entries(lin).sort((a, b) => a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0));
  const keys = [], negKeys = [];
  const key = (r) => keys[r] ??= keyOf(lins[r]), negKey = (r) => negKeys[r] ??= keyOf(scale(lins[r], -1));
  for (let changed = true;changed && contradiction() === undefined; ) {
    changed = false;
    const byKey = new Map(rows.map((r) => [key(r), r]));
    for (const r of rows) {
      const neg = byKey.get(negKey(r));
      if (neg === undefined || neg === r || stricts[r] || stricts[neg])
        continue;
      let x;
      for (const name in lins[r])
        if (name !== "1" && Math.abs(lins[r][name]) === 1) {
          x = name;
          break;
        }
      if (x === undefined)
        continue;
      const [up, down] = lins[r][x] === 1 ? [r, neg] : [neg, r];
      const next = [];
      for (const o of rows) {
        if (o === up || o === down)
          continue;
        const c = lins[o][x] ?? 0;
        if (c === 0)
          next.push(o);
        else
          next.push(tighten(pushExact({ kind: "combine", a: o, b: c > 0 ? down : up, ma: 1, mb: Math.abs(c) }, add(lins[o], scale(lins[c > 0 ? down : up], Math.abs(c))), stricts[o])));
      }
      eliminated.push({ x, rows: [up, down] });
      rows = next;
      changed = true;
      break;
    }
  }
  const sigs = [];
  const sigOf = (r) => {
    let sig = sigs[r];
    if (sig === undefined) {
      const lin = lins[r], keys = [];
      for (const key in lin)
        if (key !== "1")
          keys.push(key);
      keys.sort();
      sig = JSON.stringify(keys.map((key) => [key, lin[key]]));
      sigs[r] = sig;
    }
    return sig;
  };
  for (let found = contradiction();found === undefined; found = contradiction()) {
    const index = new Map;
    for (const r of rows)
      for (const x in lins[r]) {
        if (x === "1")
          continue;
        const c = lins[r][x];
        let e = index.get(x);
        if (!e)
          index.set(x, e = { pos: [], neg: [], posUnit: true, negUnit: true });
        if (c > 0) {
          e.pos.push(r);
          e.posUnit &&= c === 1;
        } else if (c < 0) {
          e.neg.push(r);
          e.negUnit &&= c === -1;
        }
      }
    if (index.size === 0)
      break;
    let choice;
    for (const [x, e] of index) {
      const c = { x, pos: e.pos, neg: e.neg, isExact: e.posUnit || e.negUnit, size: e.pos.length * e.neg.length - e.pos.length - e.neg.length };
      if (!choice || c.isExact && !choice.isExact || c.isExact === choice.isExact && c.size < choice.size)
        choice = c;
    }
    if (!choice)
      break;
    if (choice.pos.length * choice.neg.length > 5 * maxRows)
      return { kind: "unknown" };
    work.n += choice.pos.length * choice.neg.length;
    costs.fm += choice.pos.length * choice.neg.length;
    exact &&= choice.isExact;
    eliminated.push({ x: choice.x, rows: [...choice.pos, ...choice.neg] });
    const next = rows.filter((r) => (lins[r][choice.x] ?? 0) === 0);
    for (const p of choice.pos)
      for (const n of choice.neg) {
        const a = lins[p][choice.x], b = -lins[n][choice.x];
        const combined = pushExact({ kind: "combine", a: p, b: n, ma: b / gcd(a, b), mb: a / gcd(a, b) }, add(scale(lins[p], b / gcd(a, b)), scale(lins[n], a / gcd(a, b))), stricts[p] || stricts[n]);
        next.push(tighten(combined));
      }
    const best = new Map;
    for (const r of next) {
      const lin = lins[r], sig = sigOf(r);
      if (sig === "[]" && !isContra(r))
        continue;
      const seen = best.get(sig);
      if (seen === undefined || (lins[seen]["1"] ?? 0) < (lin["1"] ?? 0) || stricts[r] && !stricts[seen] && (lins[seen]["1"] ?? 0) === (lin["1"] ?? 0))
        best.set(sig, r);
    }
    rows = [...best.values()];
    if (rows.length > maxRows || inexact)
      return { kind: "unknown" };
  }
  const found = contradiction();
  if (found !== undefined)
    return inexact ? { kind: "unknown" } : { kind: "refuted", steps: prune(steps, found) };
  if (!integral)
    return inexact ? { kind: "unknown" } : satOverQ(constraints, eliminated, lins, stricts);
  const rational = {};
  for (const { x, rows: bounds } of [...eliminated].reverse()) {
    let { NEGATIVE_INFINITY: lower, POSITIVE_INFINITY: upper } = Number;
    for (const r of bounds) {
      const lin = lins[r], a = lin[x];
      const rest = Object.entries(lin).reduce((sum, [key, c]) => key === x ? sum : sum + c * (key === "1" ? 1 : rational[key] ?? 0), 0);
      if (a > 0)
        upper = Math.min(upper, -rest / a);
      else
        lower = Math.max(lower, -rest / a);
    }
    rational[x] = lower === Number.NEGATIVE_INFINITY ? Math.min(0, upper) : lower;
  }
  const point = {};
  for (const { x, rows: bounds } of eliminated.reverse()) {
    let { NEGATIVE_INFINITY: lower, POSITIVE_INFINITY: upper } = Number;
    for (const r of bounds) {
      const lin = lins[r], a = lin[x];
      const rest = Object.entries(lin).reduce((sum, [key, c]) => key === x ? sum : sum + c * (key === "1" ? 1 : point[key] ?? 0), 0);
      if (a > 0)
        upper = Math.min(upper, Math.floor(-rest / a));
      else
        lower = Math.max(lower, Math.ceil(-rest / a));
    }
    point[x] = lower === Number.NEGATIVE_INFINITY ? Math.min(0, upper) : lower;
  }
  for (const c of constraints)
    for (const key of vars2(c.lin))
      point[key] ??= 0;
  const holds = constraints.every((c) => Object.entries(c.lin).reduce((sum, [key, a]) => sum + a * (key === "1" ? 1 : point[key]), 0) <= 0);
  return holds ? { kind: "sat", witness: point } : { kind: "unknown", point: rational };
}
function satOverQ(constraints, eliminated, lins, stricts) {
  const at = {};
  for (const { x, rows: bounds } of [...eliminated].reverse()) {
    let lo, hi;
    for (const r of bounds) {
      const lin = lins[r], a = lin[x];
      const rest = qrow(Object.fromEntries(Object.entries(lin).filter(([key]) => key !== x)), at), b = qdiv(qneg(rest), q(a)), strict = stricts[r];
      if (a > 0) {
        if (!hi || qcmp(b, hi.v) < 0 || qcmp(b, hi.v) === 0 && strict)
          hi = { v: b, strict };
      } else if (!lo || qcmp(b, lo.v) > 0 || qcmp(b, lo.v) === 0 && strict)
        lo = { v: b, strict };
    }
    const fits = (v) => (!lo || qcmp(v, lo.v) > 0 || !lo.strict && qcmp(v, lo.v) === 0) && (!hi || qcmp(v, hi.v) < 0 || !hi.strict && qcmp(v, hi.v) === 0);
    const floor = (v) => q(v.num >= 0n ? v.num / v.den : -((-v.num + v.den - 1n) / v.den));
    const tries = [Q0, ...lo ? [floor(lo.v), qadd(floor(lo.v), Q1)] : [], ...hi ? [floor(hi.v), qsub(floor(hi.v), Q1)] : []];
    at[x] = tries.find(fits) ?? (lo && hi ? qdiv(qadd(lo.v, hi.v), q(2)) : lo ? qadd(lo.v, Q1) : qsub(hi.v, Q1));
  }
  for (const c of constraints)
    for (const key of vars2(c.lin))
      at[key] ??= Q0;
  const holds = constraints.every((c) => {
    const s = qcmp(qrow(c.lin, at), Q0);
    return c.strict ? s < 0 : s <= 0;
  });
  return holds ? { kind: "sat", witness: Object.fromEntries(Object.entries(at).map(([key, v]) => [key, qnum(v)])), rational: at } : { kind: "unknown" };
}
function prune(steps, last) {
  const keep = new Set;
  const visit = (i) => {
    if (keep.has(i))
      return;
    keep.add(i);
    const s = steps[i];
    if (s.kind === "combine")
      visit(s.a), visit(s.b);
    if (s.kind === "cut")
      visit(s.of);
  };
  visit(last);
  const order = [...keep].sort((a, b) => a - b);
  const at = new Map(order.map((old, i) => [old, i]));
  return order.map((i) => {
    const s = steps[i];
    return s.kind === "combine" ? { ...s, a: at.get(s.a), b: at.get(s.b) } : s.kind === "cut" ? { ...s, of: at.get(s.of) } : s;
  });
}
var ratioRow = (T, basis, enter, cols, eps) => {
  let leave = -1, best = Infinity;
  for (let r = 0;r < T.length; r++) {
    const a = T[r][enter];
    if (a > eps) {
      const ratio = T[r][cols] / a;
      if (ratio < best - eps || Math.abs(ratio - best) <= eps && basis[r] < basis[leave]) {
        best = ratio;
        leave = r;
      }
    }
  }
  return [leave, best];
};
function pivot(T, z, basis, leave, enter, cols) {
  const p = T[leave], pv = p[enter];
  for (let j = 0;j <= cols; j++)
    p[j] /= pv;
  for (let r = 0;r < T.length; r++)
    if (r !== leave) {
      const f = T[r][enter];
      if (f !== 0) {
        const row = T[r];
        for (let j = 0;j <= cols; j++)
          row[j] -= f * p[j];
      }
    }
  const f = z ? z[enter] : 0;
  if (f !== 0)
    for (let j = 0;j <= cols; j++)
      z[j] -= f * p[j];
  basis[leave] = enter;
}
function refuteFast(constraints, maxRows = 2000, integral = true) {
  const m = constraints.length;
  if (m === 0)
    return;
  const names = [...new Set(constraints.flatMap((c) => vars2(c.lin)))], n = names.length;
  if (m > maxRows || n > maxRows)
    return;
  const R = n + 1, cols = m + R;
  const T = Array.from({ length: R }, () => new Float64Array(cols + 1));
  const col = new Map(names.map((x, j) => [x, j]));
  constraints.forEach((c, i) => {
    for (const [key, a] of Object.entries(c.lin)) {
      if (key === "1")
        T[n][i] = a;
      else
        T[col.get(key)][i] = a;
    }
  });
  T[n][cols] = 1;
  for (let r = 0;r < R; r++)
    T[r][m + r] = 1;
  const basis = Array.from({ length: R }, (_, r) => m + r);
  const z = new Float64Array(cols + 1);
  for (let r = 0;r < R; r++)
    for (let j = 0;j <= cols; j++)
      if (j < m || j === cols)
        z[j] -= T[r][j];
  const eps = 0.000000001;
  for (let iter = 0;iter < 50 * (R + m); iter++) {
    work.n += 1 + (R * cols >> 8);
    costs.fpivots++;
    costs.fcells += R * cols >> 8;
    let enter = -1;
    for (let j = 0;j < cols; j++)
      if (z[j] < -eps) {
        enter = j;
        break;
      }
    if (enter < 0)
      break;
    const [leave] = ratioRow(T, basis, enter, cols, eps);
    if (leave < 0)
      return;
    pivot(T, z, basis, leave, enter, cols);
  }
  if (-z[cols] > 0.0000001)
    return;
  const support = [];
  for (let r = 0;r < R; r++)
    if (basis[r] < m && T[r][cols] > eps)
      support.push(basis[r]);
  if (!support.length)
    return;
  const sub = solve(support.sort((a, b) => a - b).map((i) => constraints[i]), 20000, integral);
  if (sub.kind !== "refuted")
    return;
  return { kind: "refuted", steps: sub.steps.map((st) => st.kind === "input" ? { ...st, index: support[st.index] } : st) };
}

// kernel/kernel.ts
function unreachable(value) {
  throw new Error(`unhandled case: ${JSON.stringify(value)}`);
}
var tuple = (parts) => parts.slice(0, -1).reduceRight((b, a) => ({ op: "tup", a, b }), parts.at(-1));
var tupleParts = (e) => e.op === "tup" ? [e.a, ...tupleParts(e.b)] : [e];
var canonMemo = new WeakMap;
var flipMemo = new WeakMap;
var canon = (lin) => {
  let out = canonMemo.get(lin);
  if (out === undefined)
    canonMemo.set(lin, out = Object.keys(lin).sort().map((key) => `${key}:${lin[key]}`).join(","));
  return out;
};
var canonFlip = (lin) => {
  let out = flipMemo.get(lin);
  if (out !== undefined)
    return out;
  const keys = Object.keys(lin);
  if (!("1" in lin))
    keys.push("1");
  const parts = [];
  for (const key of keys.sort()) {
    const c = key === "1" ? 1 - (lin["1"] ?? 0) : -lin[key];
    if (c !== 0)
      parts.push(`${key}:${c}`);
  }
  flipMemo.set(lin, out = parts.join(","));
  return out;
};
var atomOf = (lin, holds) => ({ lin: holds ? lin : add(k(1), scale(lin, -1)), label: "" });
function decide(lin, path) {
  let constant = true;
  for (const key in lin) {
    if (!Number.isSafeInteger(lin[key]))
      return;
    if (key !== "1")
      constant = false;
  }
  if (constant)
    return (lin["1"] ?? 0) <= 0;
  const direct = look(path, canon(lin));
  if (direct !== undefined)
    return direct;
  const flipped = look(path, canonFlip(lin));
  return flipped === undefined ? undefined : !flipped;
}
var recording;
var look = (path, key) => {
  const out = path.get(key)?.holds;
  if (recording)
    recording.set(key, out);
  return out;
};
var linearMemo = new WeakMap;
var freeMemo = new WeakMap;
var freeLinear = new WeakMap;
var choiceFree = (e) => {
  let out = freeMemo.get(e);
  if (out !== undefined)
    return out;
  switch (e.op) {
    case "var":
    case "const":
      out = true;
      break;
    case "mul":
      out = choiceFree(e.a);
      break;
    case "get":
      out = choiceFree(e.key);
      break;
    case "add":
    case "prod":
    case "tup":
      out = choiceFree(e.a) && choiceFree(e.b);
      break;
    case "proj":
      out = choiceFree(e.a);
      break;
    case "sub":
    case "min":
    case "max":
    case "if":
      out = false;
      break;
  }
  freeMemo.set(e, out);
  return out;
};
function linear(e, path) {
  if (choiceFree(e)) {
    if (freeLinear.has(e))
      return freeLinear.get(e);
    const out = linearOf(e, path);
    freeLinear.set(e, out);
    return out;
  }
  if (reuse)
    return reusing(seenOf(linearSeen, e), path, (p) => linearOf(e, p));
  let memo = linearMemo.get(path);
  if (!memo)
    linearMemo.set(path, memo = new WeakMap);
  if (memo.has(e))
    return memo.get(e);
  const out = linearOf(e, path);
  memo.set(e, out);
  return out;
}
function linearOf(e, path) {
  const out = linearOp(e, path);
  return out && safe(out) ? out : undefined;
}
var safe = (lin) => Object.values(lin).every((c) => Number.isSafeInteger(c));
function linearOp(e, path) {
  switch (e.op) {
    case "var":
      return e.name === "1" || /[*[\],:\u27E6\u27E8\u27E9|]/.test(e.name) ? undefined : v(e.name);
    case "const":
      return k(e.value);
    case "mul": {
      const a = linear(e.a, path);
      return a && Number.isSafeInteger(e.k) ? scale(a, e.k) : undefined;
    }
    case "prod": {
      const a = linear(e.a, path), b = linear(e.b, path);
      return a && b && times2(a, b);
    }
    case "add": {
      const a = linear(e.a, path), b = linear(e.b, path);
      return a && b && add(a, b);
    }
    case "sub":
    case "min":
    case "max": {
      const a = linear(e.a, path), b = linear(e.b, path);
      if (!a || !b)
        return;
      const aLeB = decide(sub(a, b), path), bLeA = decide(sub(b, a), path);
      if (e.op === "sub")
        return bLeA === true ? sub(a, b) : bLeA === false ? k(0) : v(termColumn(e));
      if (aLeB === undefined)
        return v(termColumn(e));
      return e.op === "min" === aLeB ? a : b;
    }
    case "if": {
      const c = truth(e.c, path);
      return c === undefined ? v(termColumn(e)) : linear(c ? e.then : e.else, path);
    }
    case "get": {
      if (!plainMap(e.map))
        return;
      if (e.key.op === "tup" || e.key.op === "proj") {
        const keys = keyParts(e.key, path);
        if (keys)
          return v(`${e.map}[\u27E8${keys.map(canon).join("|")}\u27E9]`);
        if (e.key.op === "tup")
          return;
      }
      const key = linear(e.key, path);
      return key && v(`${e.map}[${canon(key)}]`);
    }
    case "tup":
      return;
    case "proj": {
      const ps = keyParts(e.a, path);
      return !ps ? undefined : e.k === 0 ? ps[0] : ps.length === 2 ? ps[1] : undefined;
    }
  }
}
var plainMaps = new Map;
var plainMap = (name) => {
  let ok = plainMaps.get(name);
  if (ok === undefined)
    plainMaps.set(name, ok = name !== "1" && !/[*[\],:\u27E6\u27E7\u27E8\u27E9|]/.test(name));
  return ok;
};
function keyParts(e, path) {
  if (e.op === "proj") {
    const ps = e.k === 0 ? undefined : keyParts(e.a, path);
    return ps && ps.length >= 3 ? ps.slice(1) : undefined;
  }
  if (e.op !== "tup")
    return;
  const a = linear(e.a, path);
  if (!a)
    return;
  if (e.b.op !== "tup") {
    const b = linear(e.b, path);
    return b && [a, b];
  }
  const rest = keyParts(e.b, path);
  return rest && [a, ...rest];
}
var termIds = new Map;
var termTable = [];
var memo = new WeakMap;
function termId(t) {
  const had = memo.get(t);
  if (had !== undefined)
    return had;
  const parts = Object.entries(t).sort(([x], [y]) => x < y ? -1 : x > y ? 1 : 0).map(([key, val]) => Array.isArray(val) ? `${key}=[${val.map((x) => termId(x)).join(",")}]` : typeof val === "object" && val !== null ? `${key}=#${termId(val)}` : `${key}=${JSON.stringify(val)}`);
  const key = parts.join(";");
  let id = termIds.get(key);
  if (id === undefined) {
    id = termTable.length;
    termIds.set(key, id);
    termTable.push(t);
  }
  memo.set(t, id);
  return id;
}
var termColumn = (e) => `\u27E6${termId(e)}\u27E7`;
var columnTerm = (name) => {
  const m = /^\u27E6(\d+)\u27E7$/.exec(name);
  return m ? termTable[Number(m[1])] : undefined;
};
function decided(e, path) {
  if (e.op === "if")
    return truth(e.c, path) !== undefined;
  if (e.op !== "sub" && e.op !== "min" && e.op !== "max")
    return true;
  const a = linear(e.a, path), b = linear(e.b, path);
  return !!a && !!b && decide(e.op === "sub" ? sub(b, a) : sub(a, b), path) !== undefined;
}
function termRows(name, path) {
  const e = columnTerm(name), col = v(name), out = [];
  if (e.op === "min" || e.op === "max" || e.op === "sub") {
    const a = linear(e.a, path), b = linear(e.b, path);
    if (a && b) {
      if (e.op === "min")
        out.push(sub(col, a), sub(col, b));
      if (e.op === "max")
        out.push(sub(a, col), sub(b, col));
      if (e.op === "sub")
        out.push(sub(sub(a, b), col), sub(col, a));
    }
  }
  if (e.op === "if") {
    const a = linear(e.then, path), b = linear(e.else, path), constant = (l) => Object.entries(l).every(([key, c]) => key === "1" || c === 0);
    if (a && b && constant(a) && constant(b))
      out.push(sub(col, add(a, b)));
  }
  if (decided(e, path)) {
    const r = linear(e, path);
    if (r)
      out.push(sub(col, r), sub(r, col));
  }
  return out;
}
function times2(a, b) {
  const out = Object.create(null);
  for (const [p, cp] of Object.entries(a))
    for (const [q, cq] of Object.entries(b)) {
      if (p.includes("\u27E6") || q.includes("\u27E6"))
        return;
      const fs = [...p === "1" ? [] : factorsOf(p), ...q === "1" ? [] : factorsOf(q)].sort(), key = fs.length ? fs.join("*") : "1", c = (out[key] ?? 0) + cp * cq;
      if (!(Number.isSafeInteger(cp) && Number.isSafeInteger(cq) && Number.isSafeInteger(cp * cq) && Number.isSafeInteger(c)))
        return;
      out[key] = c;
    }
  for (const key in out)
    if (out[key] === 0)
      delete out[key];
  return out;
}
var factorMemo = new Map;
function factorsOf(name) {
  let out = factorMemo.get(name);
  if (out)
    return out;
  out = [];
  let depth = 0, start = 0;
  for (let i = 0;i <= name.length; i++) {
    const ch = name[i];
    if (ch === "[")
      depth++;
    else if (ch === "]")
      depth--;
    else if (ch === "*" && depth === 0 || i === name.length) {
      out.push(name.slice(start, i));
      start = i + 1;
    }
  }
  factorMemo.set(name, out);
  return out;
}
var isMonomial = (name) => factorsOf(name).length > 1;
var isCell = (name) => name.includes("[") && !isMonomial(name);
var comparisonMemo = new WeakMap;
var freeComparison = new WeakMap;
function comparison(c, path) {
  const free = choiceFree(c.a) && choiceFree(c.b);
  if (free && freeComparison.has(c))
    return freeComparison.get(c);
  if (!free && reuse)
    return reusing(seenOf(comparisonSeen, c), path, (p) => comparisonOf(c, p));
  let memo = comparisonMemo.get(path);
  if (!free) {
    if (!memo)
      comparisonMemo.set(path, memo = new WeakMap);
    if (memo.has(c))
      return memo.get(c);
  }
  const out = comparisonOf(c, path);
  if (free)
    freeComparison.set(c, out);
  else
    memo.set(c, out);
  return out;
}
function comparisonOf(c, path) {
  const a = linear(c.a, path), b = linear(c.b, path);
  if (!a || !b)
    return;
  const ab = sub(a, b), ba = sub(b, a);
  if (!safe(ab))
    return;
  if (c.op === "<=")
    return { when: [ab], unless: [[add(ba, k(1))]] };
  if (c.op === "<")
    return { when: [add(ab, k(1))], unless: [[ba]] };
  return { when: [ab, ba], unless: [[add(ab, k(1))], [add(ba, k(1))]] };
}
var truthMemo = new WeakMap;
function truth(c, path) {
  if (reuse)
    return reusing(seenOf(truthSeen, c), path, (p) => truthOf(c, p));
  let memo = truthMemo.get(path);
  if (!memo)
    truthMemo.set(path, memo = new WeakMap);
  if (memo.has(c))
    return memo.get(c);
  const out = truthOf(c, path);
  memo.set(c, out);
  return out;
}
function truthOf(c, path) {
  switch (c.op) {
    case "flag":
      throw new Error("flags are inlined before the kernel sees them");
    case "all":
      return;
    case "not": {
      const t = truth(c.x, path);
      return t === undefined ? undefined : !t;
    }
    case "and":
    case "or": {
      const ts = c.xs.map((y) => truth(y, path)), dominant = c.op === "or";
      return ts.includes(dominant) ? dominant : ts.every((t) => t === !dominant) ? !dominant : undefined;
    }
    case "<":
    case "<=":
    case "=": {
      const parts = tupleEq(c);
      if (parts) {
        const a = truth(parts[0], path), b = truth(parts[1], path);
        return a === false || b === false ? false : a === true && b === true ? true : undefined;
      }
      const cmp = comparison(c, path);
      if (!cmp)
        return;
      const ts = cmp.when.map((lin) => decide(lin, path));
      return ts.includes(false) ? false : ts.every((t) => t === true) ? true : undefined;
    }
    default:
      return unreachable(c);
  }
}
var tupleEqMemo = new WeakMap;
var tupleAndMemo = new WeakMap;
function tupleAnd(c) {
  const parts = tupleEq(c);
  if (!parts)
    return;
  let out = tupleAndMemo.get(c);
  if (!out)
    tupleAndMemo.set(c, out = { op: "and", xs: parts });
  return out;
}
function tupleEq(c) {
  if (c.op !== "=" || c.a.op !== "tup" || c.b.op !== "tup")
    return;
  let out = tupleEqMemo.get(c);
  if (out === undefined)
    tupleEqMemo.set(c, out = [{ op: "=", a: c.a.a, b: c.b.a }, { op: "=", a: c.a.b, b: c.b.b }]);
  return out ?? undefined;
}
function facts(c, path, positive = true) {
  switch (c.op) {
    case "flag":
      throw new Error("flags are inlined before the kernel sees them");
    case "all":
      return [];
    case "not":
      return facts(c.x, path, !positive);
    case "and":
    case "or": {
      if (c.op === "and" === positive)
        return c.xs.flatMap((y) => facts(y, path, positive));
      const open = c.xs.filter((y) => truth(y, path) !== !positive);
      return open.length === 0 ? [k(1)] : open.length === 1 ? facts(open[0], path, positive) : [];
    }
    case "<":
    case "<=":
    case "=": {
      const parts = tupleEq(c);
      if (parts) {
        if (positive)
          return [...facts(parts[0], path, true), ...facts(parts[1], path, true)];
        const open = parts.filter((y) => truth(y, path) !== true);
        return open.length === 0 ? [k(1)] : open.length === 1 ? facts(open[0], path, false) : [];
      }
      const cmp = comparison(c, path);
      if (!cmp)
        return [];
      if (positive)
        return cmp.when;
      const open = cmp.unless.filter((atoms) => !atoms.some((lin) => decide(lin, path) === false));
      return open.length === 0 ? [k(1)] : open.length === 1 ? open[0] : [];
    }
    default:
      return unreachable(c);
  }
}
function leafConstraints(goal, path) {
  return leafRows(goal, path, (h) => facts(h, path));
}
var factsSeen = new WeakMap;
function leafConstraintsReusing(goal, path) {
  let byHyp = factsSeen.get(goal);
  if (!byHyp)
    factsSeen.set(goal, byHyp = new Map);
  return leafRows(goal, path, (h) => {
    let seen = byHyp.get(h);
    if (!seen)
      byHyp.set(h, seen = {});
    return reusing(seen, path, (p) => facts(h, p));
  });
}
var reuseKeep = 16;
function remember(seen, reads, out) {
  if ((seen.size = (seen.size ?? 0) + 1) > reuseKeep) {
    seen.root = undefined;
    seen.size = 1;
  }
  const leaf = { reads, out };
  let node = seen.root, parent, via;
  while (node && "key" in node) {
    if (reads[node.at]?.[0] !== node.key)
      return;
    parent = node;
    via = reads[node.at][1];
    node = node.next.get(via);
  }
  const put = (n) => {
    if (parent)
      parent.next.set(via, n);
    else
      seen.root = n;
  };
  if (!node) {
    put(leaf);
    return;
  }
  const i = node.reads.findIndex((d, j) => reads[j]?.[0] !== d[0] || reads[j][1] !== d[1]);
  if (i < 0 || reads[i]?.[0] !== node.reads[i][0])
    return;
  put({ at: i, key: node.reads[i][0], next: new Map([[node.reads[i][1], node], [reads[i][1], leaf]]) });
}
function reusing(seen, path, f) {
  let node = seen.root;
  while (node && "key" in node)
    node = node.next.get(path.get(node.key)?.holds);
  if (node && node.reads.every(([key, holds]) => path.get(key)?.holds === holds)) {
    if (recording)
      for (const [key, holds] of node.reads)
        recording.set(key, holds);
    return node.out;
  }
  const outer = recording, mode = reuse;
  recording = new Map;
  reuse = true;
  try {
    const out = f(new Map(path));
    remember(seen, [...recording], out);
    return out;
  } finally {
    if (outer)
      for (const [key, holds] of recording)
        outer.set(key, holds);
    recording = outer;
    reuse = mode;
  }
}
var reuse = false;
var linearSeen = new WeakMap;
var comparisonSeen = new WeakMap;
var truthSeen = new WeakMap;
var seenOf = (m, k) => {
  let s = m.get(k);
  if (!s)
    m.set(k, s = {});
  return s;
};
function leafRows(goal, path, factsOf) {
  const rows = [...path.values()].map((a, i) => ({ ...atomOf(a.lin, a.holds), src: { atom: i } }));
  for (const [i, h] of goal.hyps.entries())
    for (const lin of factsOf(h))
      rows.push({ lin, label: "", src: { fact: i } });
  const names = new Set(rows.flatMap((r) => Object.keys(r.lin).filter((key) => key !== "1")));
  const cells = [...names].filter(isCell).map((name) => ({ name, ...cellParts(name) }));
  for (const [i, p] of cells.entries())
    for (const q of cells.slice(i + 1)) {
      if (p.map !== q.map)
        continue;
      if (!sameKey(p, q, path))
        continue;
      rows.push({ lin: sub(v(p.name), v(q.name)), label: "", src: { pair: [p.name, q.name] } }, { lin: sub(v(q.name), v(p.name)), label: "", src: { pair: [p.name, q.name] } });
    }
  const seen = new Set, todo = [...names].filter((n) => n.startsWith("\u27E6"));
  while (todo.length) {
    const name = todo.pop();
    if (seen.has(name))
      continue;
    seen.add(name);
    for (const lin of termRows(name, path)) {
      rows.push({ lin, label: "", src: { term: name } });
      for (const key of Object.keys(lin))
        if (key !== "1") {
          names.add(key);
          if (key.startsWith("\u27E6") && !seen.has(key))
            todo.push(key);
        }
    }
  }
  for (const name of names)
    rows.push({ lin: { [name]: -1 }, label: "", src: { nat: name } });
  return rows;
}
var cellMemo = new Map;
function cellParts(cell) {
  let out = cellMemo.get(cell);
  if (!out) {
    if (cellMemo.size > 200000)
      cellMemo.clear();
    cellMemo.set(cell, out = cellParts0(cell));
  }
  return out;
}
function cellParts0(cell) {
  const map = cell.slice(0, cell.indexOf("[")), inner = cell.slice(cell.indexOf("[") + 1, -1);
  if (inner.startsWith("\u27E8") && inner.endsWith("\u27E9"))
    return { map, keys: splitOuter(inner.slice(1, -1), "|").map(linOf) };
  return { map, key: linOf(inner) };
}
var splitOuter = (text, sep) => {
  const parts = [];
  let depth = 0, start = 0;
  for (let i = 0;i <= text.length; i++) {
    const ch = text[i];
    if (ch === "[" || ch === "\u27E8")
      depth++;
    else if (ch === "]" || ch === "\u27E9")
      depth--;
    else if (ch === sep && depth === 0 || i === text.length) {
      parts.push(text.slice(start, i));
      start = i + 1;
    }
  }
  return parts;
};
var linOf = (text) => {
  const out = Object.create(null);
  for (const part of splitOuter(text, ","))
    if (part) {
      const at = part.lastIndexOf(":");
      out[part.slice(0, at)] = Number(part.slice(at + 1));
    }
  return out;
};
function sameKey(p, q, path) {
  const zero = (a, b) => {
    const d = sub(a, b);
    return decide(d, path) === true && decide(scale(d, -1), path) === true;
  };
  if (p.key && q.key)
    return zero(p.key, q.key);
  return !!p.keys && !!q.keys && p.keys.length === q.keys.length && p.keys.every((a, i) => zero(a, q.keys[i]));
}
function withProducts(rows, pairs, squares = []) {
  const out = [...rows];
  for (const t of squares) {
    const tt = times2(t, t);
    out.push(tt ? { lin: scale(tt, -1), label: "" } : { lin: {}, label: "" });
  }
  for (const [i, j] of pairs) {
    const p = out[i], q = out[j], pq = p && q ? times2(p.lin, q.lin) : undefined;
    out.push(pq ? { lin: scale(pq, -1), label: "" } : { lin: {}, label: "" });
  }
  return out;
}
function check(goal, tree, path = new Map) {
  if ("leaf" in tree)
    return checkRefutation(withProducts(leafConstraints(goal, path), tree.products ?? [], tree.squares), tree.leaf);
  const id = canon(tree.split);
  if (path.has(id) || Object.keys(tree.split).every((key) => key === "1"))
    return false;
  const yes = new Map(path).set(id, { lin: tree.split, holds: true }), no = new Map(path).set(id, { lin: tree.split, holds: false });
  return check(goal, tree.yes, yes) && check(goal, tree.no, no);
}
var lemmaLin = (lin) => !!lin && typeof lin === "object" && !Array.isArray(lin) && (Object.getPrototypeOf(lin) === Object.prototype || Object.getPrototypeOf(lin) === null) && Object.values(lin).every(Number.isSafeInteger);
function prependAtoms(front, path) {
  const out = new Map;
  let duplicate = 0;
  for (const atom of [...front, ...path.values()]) {
    const id = canon(atom.lin);
    out.set(out.has(id) ? `@${duplicate++}` : id, atom);
  }
  return out;
}
function lemmaPath(lemmas, path) {
  lemmas = lemmas.map((l) => ({ ...l, when: l.when.map((w) => Object.keys(w).every((key) => key === "1" || w[key] === 0) ? k(w["1"] ?? 0) : w) }));
  const active = lemmas.filter((l) => l.when.every((w) => decide(w, path) === true));
  return active.length ? prependAtoms(active.map((l) => ({ lin: l.cut, holds: true })), path) : path;
}
function checkGoalLemmas(goal, tree, lemmas = []) {
  if (!Array.isArray(lemmas))
    return false;
  if (!lemmas.length)
    return check(goal, tree);
  try {
    if (!Array.from(lemmas).every((l) => !!l && typeof l === "object" && Array.isArray(l.when) && Array.from(l.when).every(lemmaLin) && lemmaLin(l.cut) && !!l.tree && typeof l.tree === "object" && (l.slice === undefined || Array.isArray(l.slice) && Array.from(l.slice).every((i) => Number.isSafeInteger(i) && i >= 0 && i < goal.hyps.length))))
      return false;
    for (const l of lemmas) {
      const hyps = l.slice === undefined ? goal.hyps : l.slice.map((i) => goal.hyps[i]);
      const path = prependAtoms([{ lin: l.cut, holds: false }, ...l.when.map((lin) => ({ lin, holds: true }))], new Map);
      if (!check({ ...goal, hyps }, l.tree, path))
        return false;
    }
    const visit = (t, path) => {
      if ("leaf" in t)
        return check(goal, t, lemmaPath(lemmas, path));
      const id = canon(t.split);
      if (path.has(id) || Object.keys(t.split).every((key) => key === "1"))
        return false;
      return visit(t.yes, new Map(path).set(id, { lin: t.split, holds: true })) && visit(t.no, new Map(path).set(id, { lin: t.split, holds: false }));
    };
    return visit(tree, new Map);
  } catch {
    return false;
  }
}
function natural(e) {
  switch (e.op) {
    case "var":
      return true;
    case "const":
      return Number.isInteger(e.value) && e.value >= 0;
    case "mul":
      return Number.isInteger(e.k) && e.k >= 0 && natural(e.a);
    case "prod":
      return natural(e.a) && natural(e.b);
    case "if":
      return naturalC(e.c) && natural(e.then) && natural(e.else);
    case "get":
      return natural(e.key);
    case "add":
    case "sub":
    case "min":
    case "max":
    case "tup":
      return natural(e.a) && natural(e.b);
    case "proj":
      return (e.k === 0 || e.k === 1) && natural(e.a);
    default:
      return unreachable(e);
  }
}
var naturalC = (c) => c.op === "flag" ? true : c.op === "all" ? naturalC(c.c) : c.op === "not" ? naturalC(c.x) : c.op === "and" || c.op === "or" ? c.xs.every(naturalC) : natural(c.a) && natural(c.b);
var own = (r, k) => Object.hasOwn(r, k) ? r[k] : undefined;
function substE(e, s) {
  switch (e.op) {
    case "var":
      return own(s.vars, e.name) ?? e;
    case "const":
      return e;
    case "mul":
      return { ...e, a: substE(e.a, s) };
    case "prod":
      return { ...e, a: substE(e.a, s), b: substE(e.b, s) };
    case "if":
      return { op: "if", c: substC(e.c, s), then: substE(e.then, s), else: substE(e.else, s) };
    case "get": {
      const key = substE(e.key, s), f = own(s.maps, e.map);
      return f ? f(key) : { op: "get", map: e.map, key };
    }
    case "add":
    case "sub":
    case "min":
    case "max":
    case "tup":
      return { ...e, a: substE(e.a, s), b: substE(e.b, s) };
    case "proj":
      return { ...e, a: substE(e.a, s) };
    default:
      return unreachable(e);
  }
}
function substC(c, s) {
  if (c.op === "flag") {
    const f = own(s.flags, c.name);
    if (!f)
      throw new Error(`unknown flag ${c.name}`);
    return f;
  }
  if (c.op === "not")
    return { op: "not", x: substC(c.x, s) };
  if (c.op === "all") {
    const keys = boundOf(c), vars = Object.fromEntries(Object.entries(s.vars).filter(([n]) => !keys.includes(n)));
    return { ...c, c: substC(c.c, { ...s, vars }) };
  }
  if (c.op === "and" || c.op === "or")
    return { op: c.op, xs: c.xs.map((y) => substC(y, s)) };
  return { ...c, a: substE(c.a, s), b: substE(c.b, s) };
}
var mentions = (c, names) => JSON.stringify(c).match(/"name":"([^"]+)"/g)?.some((m) => names.includes(m.slice(8, -1))) ?? false;
var aboutParams = (c, params) => !JSON.stringify(c).includes('"op":"get"') && (JSON.stringify(c).match(/"name":"([^"]+)"/g) ?? []).every((m) => params.includes(m.slice(8, -1)));
var preOf = (o) => {
  if (o.pre && !(aboutParams(o.pre, o.params) && naturalC(o.pre)))
    throw new Error("a precondition reads only the params");
  return o.pre ? [o.pre] : [];
};
var identity = { vars: {}, maps: {}, flags: {} };
var from = (at = identity) => ({ hyps: [], at });
var holds = (r, cs) => ({ hyps: [...r.hyps, ...cs.map((c) => substC(c, r.at))], at: r.at });
var step = (r, u) => {
  const at = r.at, before = (map, key) => {
    const f = own(at.maps, map);
    return f ? f(key) : { op: "get", map, key };
  };
  return { hyps: r.hyps, at: {
    vars: { ...at.vars, ...Object.fromEntries(Object.entries(u.vars).map(([n, e]) => [n, substE(e, at)])) },
    maps: { ...at.maps, ...Object.fromEntries(Object.entries(u.maps).map(([map, w]) => [map, "each" in w ? (key) => substE(w.value, { ...at, vars: { ...at.vars, [w.each]: key } }) : (key) => ({ op: "if", c: { op: "=", a: key, b: substE(w.key, at) }, then: substE(w.value, at), else: before(map, key) })])) },
    flags: at.flags
  } };
};
var atEnd = (r, c) => substC(c, r.at);
var goal = (name, r, conclusion) => ({ name, hyps: [...r.hyps, { op: "not", x: conclusion }] });
var flagsOf = (m) => {
  const out = Object.create(null);
  for (const [f, c] of Object.entries(m.step.flags ?? {}))
    out[f] = c.op === "all" ? { op: "=", a: { op: "var", name: `?${f}` }, b: { op: "const", value: 1 } } : substC(c, { vars: {}, maps: {}, flags: out });
  return out;
};
var quantified = (m) => Object.entries(m.step.flags ?? {}).filter((e) => e[1].op === "all");
var boundOf = (c) => [c.key, ...c.keys ?? []];
var witnessesOf = (f, q) => boundOf(q).map((_, i) => i ? `w${i + 1}?${f}` : `w?${f}`);
var crossing = (c, keys) => (c.op === "<" || c.op === "<=" || c.op === "=") && c.a.op === "var" && c.b.op === "var" && c.a.name !== c.b.name && keys.includes(c.a.name) && keys.includes(c.b.name);
var crossCache = new WeakMap;
var crossFree = (c, keys) => {
  const id = keys.join(","), hit = crossCache.get(c)?.get(id);
  if (hit)
    return hit;
  const zero = { op: "const", value: 0 };
  const e = (t) => t.op === "if" ? { ...t, c: crossFree(t.c, keys), then: e(t.then), else: e(t.else) } : t.op === "get" ? { ...t, key: e(t.key) } : t.op === "mul" || t.op === "proj" ? { ...t, a: e(t.a) } : t.op === "add" || t.op === "sub" || t.op === "min" || t.op === "max" || t.op === "prod" || t.op === "tup" ? { ...t, a: e(t.a), b: e(t.b) } : t;
  const out = crossing(c, keys) ? { op: "<=", a: zero, b: zero } : c.op === "not" ? { op: "not", x: crossFree(c.x, keys) } : c.op === "and" || c.op === "or" ? { op: c.op, xs: c.xs.map((y) => crossFree(y, keys)) } : c.op === "all" ? { ...c, c: crossFree(c.c, keys) } : c.op === "flag" ? c : { ...c, a: e(c.a), b: e(c.b) };
  if (!crossCache.has(c))
    crossCache.set(c, new Map);
  crossCache.get(c).set(id, out);
  return out;
};
var updateOf = (m) => {
  const flags = { vars: {}, maps: {}, flags: flagsOf(m) };
  return {
    vars: Object.fromEntries(Object.entries(m.step.state ?? {}).map(([n, e]) => [n, substE(e, flags)])),
    maps: Object.fromEntries(Object.entries(m.step.maps ?? {}).map(([map, w]) => [map, "each" in w ? { each: w.each, value: substE(w.value, flags) } : { key: substE(w.key, flags), value: substE(w.value, flags) }]))
  };
};
var inlineFlags = (m, c) => substC(c, { vars: {}, maps: {}, flags: flagsOf(m) });
var closing = (m, instances) => quantified(m).flatMap(([f, q]) => {
  const v = { op: "var", name: `?${f}` }, zero = { op: "const", value: 0 }, one = { op: "const", value: 1 }, names = boundOf(q), n = names.length;
  const body = (keys) => substC(q.c, { vars: Object.fromEntries(names.map((key, i) => [key, keys[i]])), maps: {}, flags: flagsOf(m) });
  const inst = instances[`?${f}`] ?? [];
  return [
    { op: "<=", a: v, b: one },
    ...Array.from({ length: Math.floor(inst.length / n) }, (_, t) => ({ op: "or", xs: [{ op: "=", a: v, b: zero }, body(inst.slice(t * n, (t + 1) * n))] })),
    { op: "or", xs: [{ op: "=", a: v, b: one }, { op: "not", x: body(witnessesOf(f, q).map((name) => ({ op: "var", name }))) }] }
  ];
});
var assumed = (laws, instances) => laws.flatMap((l) => {
  const keys = own(instances, l.name) ?? [];
  if (l.keys?.length) {
    const names = [l.forall, ...l.keys], n = names.length;
    return Array.from({ length: Math.floor(keys.length / n) }, (_, t) => substC(l.holds, { vars: Object.fromEntries(names.map((name, i) => [name, keys[t * n + i]])), maps: {}, flags: {} }));
  }
  return l.forall ? keys.map((key) => substC(l.holds, { vars: { [l.forall]: key }, maps: {}, flags: {} })) : [l.holds];
});
var given = (m, r, instances) => ({ hyps: [...r.hyps, ...assumed(m.facts ?? [], instances)], at: r.at });
var startOf = (m) => ({ vars: { ...m.state }, maps: Object.fromEntries(Object.entries(m.maps ?? {}).map(([map, c]) => [map, () => ({ op: "const", value: c })])), flags: {} });
function reads(t, out = { vars: new Set, maps: new Set, flags: new Set }) {
  switch (t.op) {
    case "var":
      out.vars.add(t.name);
      break;
    case "const":
      break;
    case "get":
      out.maps.add(t.map);
      reads(t.key, out);
      break;
    case "flag":
      out.flags.add(t.name);
      break;
    case "all": {
      const inner = reads(t.c);
      for (const key of boundOf(t))
        inner.vars.delete(key);
      for (const k of ["vars", "maps", "flags"])
        for (const name of inner[k])
          out[k].add(name);
      break;
    }
    case "not":
      reads(t.x, out);
      break;
    case "and":
    case "or":
      for (const y of t.xs)
        reads(y, out);
      break;
    case "mul":
    case "proj":
      reads(t.a, out);
      break;
    case "if":
      reads(t.c, out);
      reads(t.then, out);
      reads(t.else, out);
      break;
    case "add":
    case "sub":
    case "min":
    case "max":
    case "prod":
    case "tup":
    case "<":
    case "<=":
    case "=":
      reads(t.a, out);
      reads(t.b, out);
      break;
    default:
      unreachable(t);
  }
  return out;
}
function inScope(what, ts, vars, maps = [], flags = []) {
  for (const t of ts) {
    const r = reads(t);
    for (const name of r.vars)
      if (!vars.includes(name))
        throw new Error(`${what} reads ${name}, which it doesn't declare`);
    for (const map of r.maps)
      if (!maps.includes(map))
        throw new Error(`${what} reads the map ${map}, which it doesn't declare`);
    for (const flag of r.flags)
      if (!flags.includes(flag))
        throw new Error(`${what} reads the flag ${flag}, which it doesn't declare`);
  }
}
var plainName = (what, name) => {
  if (name === "1" || /[*[\],:#?~'\u27E6\u27E7\u27E8\u27E9|]/.test(name))
    throw new Error(`${what}: the name ${name} is reserved (1, or * [ ] , : # ? ~ ' \u27E6 \u27E7 \u27E8 \u27E9 |)`);
};
var distinct = (what, names) => {
  const seen = new Set;
  for (const name of names) {
    if (seen.has(name))
      throw new Error(`${what} declares ${name} twice`);
    seen.add(name);
  }
};
function scope(m, laws = []) {
  const state = Object.keys(m.state), maps = Object.keys(m.maps ?? {}), flags = Object.keys(m.step.flags ?? {}), fns = Object.keys(m.fns ?? {});
  const counts = Object.keys(m.counts ?? {}), carried = [...m.inputMaps ?? [], ...counts];
  const names = [...m.params, ...m.inputs, ...state];
  distinct(m.name, [...names, ...maps, ...carried, ...fns]);
  for (const name of [...names, ...maps, ...carried, ...fns, ...flags])
    plainName(m.name, name);
  for (const name of Object.keys(m.step.state ?? {}))
    if (!state.includes(name))
      throw new Error(`${m.name}'s step sets ${name}, which isn't in its state`);
  for (const map of Object.keys(m.step.maps ?? {}))
    if (!maps.includes(map))
      throw new Error(`${m.name}'s step writes the map ${map}, which it doesn't declare`);
  const readable = [...maps, ...carried, ...fns];
  const bound = (what, key, t) => {
    plainName(what, key);
    if ([...names, ...readable, ...flags].includes(key))
      throw new Error(`${what}: the key ${key} is already a name of ${m.name}`);
    keyOnly(what, t, key, [...fns, ...counts]);
  };
  inScope(`${m.name}'s start`, Object.values(m.state), m.params);
  flags.forEach((f, i) => {
    const c = m.step.flags[f], what = `${m.name}'s flag ${f}`;
    if (c.op === "all") {
      const keys = boundOf(c), body = crossFree(c.c, keys);
      distinct(what, keys);
      for (const key of keys) {
        bound(what, key, body);
        apart(what, body, key, keys);
      }
      unquantified(what, c.c);
      inScope(what, [c.c], [...names, ...keys], readable, []);
    } else {
      unquantified(what, c);
      inScope(what, [c], names, readable, flags.slice(0, i));
    }
  });
  const arity = mapArities(m, laws);
  for (const [map, w] of Object.entries(m.step.maps ?? {})) {
    const what = `${m.name}'s write to ${map}`;
    if ("each" in w && (own(arity, map) ?? 1) > 1) {
      const t = eachParts(w, arity[map]);
      plainName(what, w.each);
      if (readsKey(t.value, w.each))
        throw new Error(`${what}: the key ${w.each} is read as its ${arity[map]} parts (or whole, as the key of a map of ${arity[map]}), nothing else`);
      for (const key of t.names) {
        bound(what, key, t.value);
        apart(what, crossFree({ op: "=", a: t.value, b: { op: "const", value: 0 } }, t.names), key, t.names);
      }
      unquantified(what, w.value);
      inScope(what, [t.value], [...names, ...t.names], readable, flags);
    } else if ("each" in w) {
      bound(what, w.each, w.value);
      unquantified(what, w.value);
      inScope(what, [w.value], [...names, w.each], readable, flags);
    } else {
      unquantified(what, w.key);
      unquantified(what, w.value);
      inScope(what, [w.key, w.value], names, readable, flags);
    }
  }
  for (const e of Object.values(m.step.state ?? {}))
    unquantified(`${m.name}'s step`, e);
  inScope(`${m.name}'s step`, Object.values(m.step.state ?? {}), names, readable, flags);
  if (m.assume) {
    unquantified(`${m.name}'s assumption`, m.assume);
    inScope(`${m.name}'s assumption`, [m.assume], names, readable, flags);
  }
  if (m.pre)
    inScope(`${m.name}'s precondition`, [m.pre], m.params);
  const facts = m.facts ?? [];
  distinct(`${m.name}'s laws and facts`, [...laws, ...facts].map((l) => l.name));
  for (const law of [...laws, ...facts]) {
    const what = facts.includes(law) ? `fact ${law.name}` : `law ${law.name}`;
    for (const key of [law.forall, ...law.keys ?? []])
      if (key) {
        plainName(what, key);
        if ([...names, ...maps, ...carried, ...fns].includes(key))
          throw new Error(`${what}'s key ${key} is already a name of ${m.name}`);
      }
    if (law.keys?.length && (!law.forall || new Set([law.forall, ...law.keys]).size !== law.keys.length + 1))
      throw new Error(`${what}: further keys come with a first, each a different name`);
    if (law.name.startsWith("?"))
      throw new Error(`${what}: a name starting with ? is a flag's (its instances)`);
    unquantified(what, law.holds);
  }
  const keysOf = (l) => [...l.forall ? [l.forall] : [], ...l.keys ?? []];
  for (const law of laws)
    inScope(`law ${law.name}`, [law.holds], [...m.params, ...state, ...keysOf(law)], [...maps, ...fns, ...stateCounts(m)]);
  countsScope(m, laws);
  for (const fact of facts)
    inScope(`fact ${fact.name}`, [fact.holds], [...m.params, ...keysOf(fact)], fns);
}
var keyArity = (key) => keyParts(key, new Map)?.length ?? tupleParts(key).length;
function mapArities(m, laws = []) {
  const out = Object.create(null);
  const plainOnly = new Set([...Object.keys(m.fns ?? {}), ...Object.keys(m.counts ?? {}), ...m.inputMaps ?? []]);
  const note = (map, key) => {
    const n = keyArity(key), had = own(out, map);
    if (had !== undefined && had !== n)
      throw new Error(`${m.name}: the map ${map} is read at keys of ${had} and of ${n} parts`);
    if (n > 1 && plainOnly.has(map))
      throw new Error(`${m.name}: ${map} is a function, a count or a carried map, read at plain keys only`);
    out[map] = n;
  };
  walkTerms([...machineTermsOf(m), ...laws.map((l) => l.holds)], (o) => {
    if (o.op === "get" && typeof o.map === "string" && o.key)
      note(o.map, o.key);
  });
  for (const [map, w] of Object.entries(m.step.maps ?? {}))
    if (!("each" in w))
      note(map, w.key);
  return out;
}
var walkTerms = (ts, f) => {
  const go = (t) => {
    if (Array.isArray(t)) {
      t.forEach(go);
      return;
    }
    if (!t || typeof t !== "object")
      return;
    f(t);
    for (const x of Object.values(t))
      go(x);
  };
  ts.forEach(go);
};
var machineTermsOf = (m) => [m.state, m.step, m.pre, m.assume, m.facts, m.history, m.sums, m.counts, m.leasts];
function eachParts(w, n) {
  const names = Array.from({ length: n }, (_, i) => `${w.each}$${i + 1}`);
  const flags = Object.fromEntries([...JSON.stringify(w.value).matchAll(/"op":"flag","name":"((?:[^"\\]|\\.)*)"/g)].map((m) => [JSON.parse(`"${m[1]}"`), { op: "flag", name: JSON.parse(`"${m[1]}"`) }]));
  const at = substE(w.value, { vars: { [w.each]: tuple(names.map((name) => ({ op: "var", name }))) }, maps: {}, flags });
  return { names, value: projected(at) };
}
function projected(e) {
  switch (e.op) {
    case "var":
    case "const":
      return e;
    case "proj": {
      const a = projected(e.a);
      return a.op === "tup" ? e.k === 0 ? a.a : a.b : { op: "proj", k: e.k, a };
    }
    case "mul":
      return { ...e, a: projected(e.a) };
    case "get":
      return { ...e, key: projected(e.key) };
    case "if":
      return { op: "if", c: projectedC(e.c), then: projected(e.then), else: projected(e.else) };
    case "add":
    case "sub":
    case "min":
    case "max":
    case "prod":
    case "tup":
      return { ...e, a: projected(e.a), b: projected(e.b) };
    default:
      return unreachable(e);
  }
}
var projectedC = (c) => c.op === "not" ? { op: "not", x: projectedC(c.x) } : c.op === "and" || c.op === "or" ? { op: c.op, xs: c.xs.map(projectedC) } : c.op === "all" ? { ...c, c: projectedC(c.c) } : c.op === "flag" ? c : { ...c, a: projected(c.a), b: projected(c.b) };
var readsKey = (t, key) => JSON.stringify(t).includes(`"op":"var","name":${JSON.stringify(key)}`);
var tupleSides = (u) => {
  if (u.op !== "=" || u.a.op !== "tup" || u.b.op !== "tup")
    return;
  const as = tupleParts(u.a), bs = tupleParts(u.b);
  return as.length === bs.length ? as.map((a, i) => [a, bs[i]]) : undefined;
};
var keyTerm = (e, key) => e.op === "var" ? e.name === key : e.op === "add" ? e.a.op === "var" && e.a.name === key && !readsKey(e.b, key) || e.b.op === "var" && e.b.name === key && !readsKey(e.a, key) : e.op === "sub" && e.a.op === "var" && e.a.name === key && !readsKey(e.b, key);
function keyOnly(what, t, key, fns = []) {
  const bad = () => {
    throw new Error(`${what}: the key ${key} is read only in a map's key or a comparison, alone or plus or less a term that doesn't read it`);
  };
  const walk = (u) => {
    switch (u.op) {
      case "var":
        if (u.name === key)
          bad();
        break;
      case "get":
        if (u.key.op === "tup" && !fns.includes(u.map)) {
          for (const part of tupleParts(u.key))
            if (!keyTerm(part, key))
              walk(part);
        } else if (!(keyTerm(u.key, key) && !fns.includes(u.map)))
          walk(u.key);
        break;
      case "const":
      case "flag":
        break;
      case "not":
        walk(u.x);
        break;
      case "all":
        walk(u.c);
        break;
      case "and":
      case "or":
        u.xs.forEach(walk);
        break;
      case "mul":
      case "proj":
        walk(u.a);
        break;
      case "if":
        walk(u.c);
        walk(u.then);
        walk(u.else);
        break;
      case "<":
      case "<=":
      case "=": {
        const side = (a, b) => {
          if (keyTerm(a, key) && !readsKey(b, key))
            walk(b);
          else if (keyTerm(b, key) && !readsKey(a, key))
            walk(a);
          else {
            walk(a);
            walk(b);
          }
        };
        const pairs = tupleSides(u);
        if (pairs)
          for (const [a, b] of pairs)
            side(a, b);
        else
          side(u.a, u.b);
        break;
      }
      case "add":
      case "sub":
      case "min":
      case "max":
      case "prod":
      case "tup":
        walk(u.a);
        walk(u.b);
        break;
      default:
        unreachable(u);
    }
  };
  walk(t);
}
function apart(what, t, key, keys) {
  const others = keys.filter((k) => k !== key), other = (e) => others.some((k) => readsKey(e, k));
  const cmp = (a, b) => keyTerm(a, key) && (other(a) || other(b)) || keyTerm(b, key) && (other(a) || other(b));
  const walk = (u) => {
    if (u.op === "get" && (u.key.op === "tup" ? tupleParts(u.key).some((p) => keyTerm(p, key) && other(p)) : keyTerm(u.key, key) && other(u.key)) || (u.op === "<" || u.op === "<=" || u.op === "=") && (tupleSides(u)?.some(([a, b]) => cmp(a, b)) ?? cmp(u.a, u.b)))
      throw new Error(`${what}: the keys ${keys.join(", ")} are each read on their own, and compared with one another only plainly (i < j, i <= j, i = j)`);
    for (const x of Object.values(u))
      if (x && typeof x === "object")
        (Array.isArray(x) ? x : [x]).forEach((y) => walk(y));
  };
  walk(t);
}
var plainKey = (t, key) => {
  const walk = (u) => {
    switch (u.op) {
      case "var":
        return u.name !== key;
      case "get":
        return u.key.op === "var" && u.key.name === key || walk(u.key);
      case "const":
      case "flag":
        return true;
      case "not":
        return walk(u.x);
      case "all":
        return walk(u.c);
      case "and":
      case "or":
        return u.xs.every(walk);
      case "mul":
      case "proj":
        return walk(u.a);
      case "if":
        return walk(u.c) && walk(u.then) && walk(u.else);
      case "add":
      case "sub":
      case "min":
      case "max":
      case "prod":
      case "tup":
      case "<":
      case "<=":
      case "=":
        return walk(u.a) && walk(u.b);
      default:
        return unreachable(u);
    }
  };
  return walk(t);
};
function unquantified(what, t) {
  if (JSON.stringify(t).includes('"op":"all"'))
    throw new Error(`${what}: a condition at every key is a flag of its own (flags: {name: all(...)})`);
}
var readsOnly = (t, names) => !JSON.stringify(t).includes('"op":"get"') && !JSON.stringify(t).includes('"op":"flag"') && (JSON.stringify(t).match(/"name":"([^"]+)"/g) ?? []).every((m) => names.includes(m.slice(8, -1)));
var homogeneous = (e, names) => e.op === "var" ? names.includes(e.name) : e.op === "add" ? homogeneous(e.a, names) && homogeneous(e.b, names) : e.op === "mul" ? Number.isInteger(e.k) && e.k >= 0 && homogeneous(e.a, names) : false;
function historyMachine(m) {
  const h = m.history;
  if (!h)
    return { machine: m, goals: [] };
  const queries = Object.keys(h.queries), sums = Object.keys(h.sums), plainInputs = m.inputs.filter((i) => !queries.includes(i));
  const fields = h.record.map((f) => `r.${f}`);
  const taken = [...m.params, ...m.inputs, ...Object.keys(m.state), ...Object.keys(m.step.state ?? {})];
  const ok = [...taken, ...sums].every((name) => !name.startsWith("r.")) && queries.every((q) => m.inputs.includes(q)) && h.record.every((f) => plainInputs.includes(f)) && sums.every((s) => !taken.includes(s)) && Object.values(h.sums).every((g) => natural(g) && readsOnly(g, [...fields, ...m.params])) && Object.values(h.queries).every((g) => natural(g) && readsOnly(g, [...fields, ...m.params, ...plainInputs])) && naturalC(h.keep) && (h.relations ?? []).every((r) => naturalC(r.when) && readsOnly(r.when, [...m.params, ...plainInputs]) && r.holds.op === "<=" && homogeneous(r.holds.a, [...sums, ...queries]) && homogeneous(r.holds.b, [...sums, ...queries]));
  if (!ok)
    throw new Error("a history: sums read the record and params, queries also the request's other inputs, relations are homogeneous a <= b under a condition on the params and the request");
  inScope(`${m.name}'s keep`, [h.keep], [...m.params, ...m.inputs, ...Object.keys(m.state), ...sums], Object.keys(m.maps ?? {}), Object.keys(m.step.flags ?? {}));
  if (h.prune && !(h.record.includes(h.prune.order) && natural(h.prune.after) && readsOnly(h.prune.after, m.params)))
    throw new Error("a history is pruned by a recorded input and a term over the params");
  const atRequest = { vars: Object.fromEntries(h.record.map((f) => [`r.${f}`, { op: "var", name: f }])), maps: {}, flags: {} };
  const TRUE = { op: "<=", a: { op: "const", value: 0 }, b: { op: "const", value: 0 } };
  const relations = (h.relations ?? []).map((r) => ({ op: "or", xs: [{ op: "not", x: r.when }, r.holds] })).reduceRight((acc, r) => ({ op: "and", xs: [r, acc] }), TRUE);
  const machine = {
    ...m,
    history: undefined,
    state: { ...m.state, ...Object.fromEntries(sums.map((s) => [s, { op: "const", value: 0 }])) },
    step: { ...m.step, state: { ...m.step.state, ...Object.fromEntries(sums.map((s) => [s, { op: "add", a: { op: "var", name: s }, b: { op: "if", c: h.keep, then: substE(h.sums[s], atRequest), else: { op: "const", value: 0 } } }])) } },
    assume: { op: "and", xs: [m.assume ?? TRUE, relations] }
  };
  const perRecord = { vars: { ...h.sums, ...h.queries }, maps: {}, flags: {} };
  const goals = (h.relations ?? []).map((r, i) => ({ name: `relation ${i + 1} @record`, hyps: [...preOf(m), r.when, { op: "not", x: substC(r.holds, perRecord) }] }));
  if (h.prune) {
    const { order, after } = h.prune;
    const gone = { op: "<=", a: { op: "add", a: { op: "var", name: `r.${order}` }, b: after }, b: { op: "var", name: order } };
    for (const [q, g] of Object.entries(h.queries))
      goals.push({ name: `prune @query ${q}`, hyps: [...preOf(m), gone, { op: "not", x: { op: "<=", a: g, b: { op: "const", value: 0 } } }] });
  }
  return { machine, goals };
}
var ZERO = { op: "const", value: 0 };
var TRUE_C = { op: "<=", a: ZERO, b: ZERO };
var dTerm = (G, cs) => cs.length ? { op: "add", a: G(cs[0]), b: dTerm((t) => ({ op: "if", c: { op: "=", a: t, b: cs[0] }, then: ZERO, else: G(t) }), cs.slice(1)) } : ZERO;
var sumTermOk = (e, key) => {
  switch (e.op) {
    case "var":
      return false;
    case "const":
      return true;
    case "get":
      return e.key.op === "var" && e.key.name === key;
    case "mul":
      return sumTermOk(e.a, key);
    case "if":
      return sumCondOk(e.c, key) && sumTermOk(e.then, key) && sumTermOk(e.else, key);
    case "add":
    case "sub":
    case "min":
    case "max":
    case "prod":
      return sumTermOk(e.a, key) && sumTermOk(e.b, key);
    case "tup":
    case "proj":
      return false;
    default:
      return unreachable(e);
  }
};
var sumCondOk = (c, key) => c.op === "flag" || c.op === "all" ? false : c.op === "not" ? sumCondOk(c.x, key) : c.op === "and" || c.op === "or" ? c.xs.every((y) => sumCondOk(y, key)) : sumTermOk(c.a, key) && sumTermOk(c.b, key);
var sumParts = (s) => ({ flag: `cells$${s}`, x: `x$${s}` });
function comparedKeys(t, key, out) {
  if (t.op === "=" && t.a.op === "var" && t.a.name === key && !readsKey(t.b, key))
    out.set(JSON.stringify(t.b), t.b);
  else if (t.op === "=" && t.b.op === "var" && t.b.name === key && !readsKey(t.a, key))
    out.set(JSON.stringify(t.a), t.a);
  for (const x of Object.values(t))
    if (x && typeof x === "object")
      (Array.isArray(x) ? x : [x]).forEach((y) => comparedKeys(y, key, out));
}
function sumCovers(m) {
  return Object.fromEntries(Object.entries(m.sums ?? {}).map(([s, sum]) => {
    const out = new Map;
    for (const map of [...new Set([...JSON.stringify(sum.term).matchAll(/"op":"get","map":"([^"]+)"/g)].map((x2) => x2[1]))]) {
      const w = own(m.step.maps ?? {}, map);
      if (!w)
        continue;
      if ("each" in w)
        comparedKeys(w.value, w.each, out);
      else
        out.set(JSON.stringify(w.key), w.key);
    }
    return [s, [...out.values()]];
  }));
}
var cellLaws = (laws, read, x) => laws.flatMap((l) => l.forall && !l.keys?.length && sumCondOk(l.holds, l.forall) && [...JSON.stringify(l.holds).matchAll(/"op":"get","map":"([^"]+)"/g)].every((y) => read.includes(y[1])) ? [substC(l.holds, { vars: { [l.forall]: x }, maps: {}, flags: {} })] : []);
function sumMachine(m, given, laws = []) {
  const sums = Object.entries(m.sums ?? {});
  if (!sums.length)
    return { machine: m, goals: [] };
  if (m.history)
    throw new Error(`${m.name}: sums over a map's keys go on a machine without a history`);
  const covers = given ?? sumCovers(m), flags = m.step.flags ?? {};
  const same = Object.fromEntries(Object.keys(flags).map((f) => [f, { op: "flag", name: f }]));
  for (const [s] of sums)
    if (Object.hasOwn(m.state, s) && JSON.stringify(m.state[s]) !== JSON.stringify(ZERO) || Object.hasOwn(m.step.state ?? {}, s))
      throw new Error(`${m.name}: the sum ${s} starts at 0 and no step sets it`);
  const names = [
    ...m.params,
    ...m.inputs,
    ...Object.keys(m.state).filter((n) => !Object.hasOwn(m.sums, n)),
    ...Object.keys(m.maps ?? {}),
    ...m.inputMaps ?? [],
    ...Object.keys(m.fns ?? {}),
    ...Object.keys(flags),
    ...Object.keys(flags).map((f) => `?${f}`),
    ...Object.entries(flags).flatMap(([f, c]) => c.op === "all" ? [...witnessesOf(f, c), ...boundOf(c)] : []),
    ...Object.values(m.step.maps ?? {}).flatMap((w) => ("each" in w) ? [w.each] : [])
  ];
  const steps = Object.create(null), qflags = Object.create(null), facts = [], goals = [];
  for (const [s, sum] of sums) {
    const { term, key } = sum, { flag, x } = sumParts(s), cs = own(covers, s);
    const read = [...new Set([...JSON.stringify(term).matchAll(/"op":"get","map":"([^"]+)"/g)].map((x2) => x2[1]))];
    const bad = (why) => {
      throw new Error(`${m.name}: the sum ${s}: ${why}`);
    };
    for (const name of [s, key, flag, x]) {
      plainName(m.name, name);
      if (names.includes(name) || Object.hasOwn(m.sums ?? {}, name) && name !== s)
        bad(`${name} is already a name of the machine`);
    }
    if (new Set([s, key, flag, x, `?${flag}`, `w?${flag}`]).size !== 6 || names.includes(`?${flag}`) || names.includes(`w?${flag}`))
      bad("its names collide");
    if (!natural(term) || !sumTermOk(term, key))
      bad(`its term reads the maps at ${key} alone, and no other name`);
    for (const map of read) {
      if ((m.inputMaps ?? []).includes(map) || Object.hasOwn(m.fns ?? {}, map) || !Object.hasOwn(m.maps ?? {}, map))
        bad(`${map} is not a map of the machine's state`);
    }
    const atStart = substE(term, { vars: {}, maps: Object.fromEntries(read.map((map) => [map, () => ({ op: "const", value: m.maps[map] })])), flags: same });
    if (natE(atStart, {}) !== 0n)
      bad("its term is not 0 at the start");
    for (const c of cs)
      if (JSON.stringify(c).includes('"op":"flag"') || readsKey(c, key) || readsKey(c, x))
        bad("a key a step writes it at reads a flag");
    for (const map of read) {
      const w = own(m.step.maps ?? {}, map);
      if (w && !("each" in w) && !cs.some((c) => JSON.stringify(c) === JSON.stringify(w.key)))
        bad(`the key ${map} is written at is no cover key`);
    }
    const here = (t) => substE(term, { vars: { [key]: t }, maps: {}, flags: same });
    const post = (map) => (k2) => {
      const w = own(m.step.maps ?? {}, map);
      if (!w)
        return { op: "get", map, key: k2 };
      if ("each" in w)
        return substE(w.value, { vars: { [w.each]: k2 }, maps: {}, flags: same });
      return { op: "if", c: { op: "=", a: k2, b: w.key }, then: w.value, else: { op: "get", map, key: k2 } };
    };
    const after = (t) => substE(term, { vars: { [key]: t }, maps: Object.fromEntries(read.map((map) => [map, post(map)])), flags: same });
    const S = { op: "var", name: s };
    steps[s] = { op: "sub", a: { op: "add", a: S, b: dTerm(after, cs) }, b: dTerm(here, cs) };
    qflags[flag] = { op: "all", key, c: { op: "<=", a: dTerm(here, [{ op: "var", name: key }, ...cs]), b: S } };
    facts.push({ op: "and", xs: [{ op: "<=", a: dTerm(here, cs), b: S }, { op: "flag", name: flag }] });
    const lean = { vars: {}, maps: {}, flags: Object.fromEntries(Object.entries(flagsOf(m)).map(([f, c]) => [f, flags[f].op === "all" ? c : { op: "=", a: { op: "if", c, then: { op: "const", value: 1 }, else: ZERO }, b: { op: "const", value: 1 } }])) };
    for (const [map, w] of Object.entries(m.step.maps ?? {})) {
      if (!("each" in w) || !read.includes(map))
        continue;
      const X = { op: "var", name: x };
      goals.push({ name: `${s} @cover ${map}`, hyps: [
        substC(m.assume ?? TRUE_C, lean),
        ...cellLaws(laws, read, X),
        ...cs.map((c) => ({ op: "not", x: { op: "=", a: X, b: c } })),
        { op: "not", x: { op: "=", a: substE(substE(w.value, lean), { vars: { [w.each]: X }, maps: {}, flags: {} }), b: { op: "get", map, key: X } } }
      ] });
    }
  }
  const assumed = facts.reduceRight((acc, f) => ({ op: "and", xs: [f, acc] }), TRUE_C);
  const machine = {
    ...m,
    sums: undefined,
    state: { ...m.state, ...Object.fromEntries(sums.map(([s]) => [s, ZERO])) },
    step: { ...m.step, flags: { ...flags, ...qflags }, state: { ...m.step.state, ...steps } },
    assume: { op: "and", xs: [m.assume ?? TRUE_C, assumed] }
  };
  return { machine, goals };
}
var plainOf = (m) => m.history ? historyMachine(m).machine : m.sums && Object.keys(m.sums).length ? sumMachine(m).machine : m;
var natE = (e, env) => {
  switch (e.op) {
    case "var":
      return own(env, e.name) ?? 0n;
    case "const":
      return BigInt(e.value);
    case "add":
      return natE(e.a, env) + natE(e.b, env);
    case "sub": {
      const d = natE(e.a, env) - natE(e.b, env);
      return d > 0n ? d : 0n;
    }
    case "mul":
      return BigInt(e.k) * natE(e.a, env);
    case "prod":
      return natE(e.a, env) * natE(e.b, env);
    case "min": {
      const a = natE(e.a, env), b = natE(e.b, env);
      return a < b ? a : b;
    }
    case "max": {
      const a = natE(e.a, env), b = natE(e.b, env);
      return a > b ? a : b;
    }
    case "if":
      return natC(e.c, env) ? natE(e.then, env) : natE(e.else, env);
    case "get":
      return 0n;
    case "tup":
    case "proj":
      throw new Error("a loop's run is read over no tuple");
    default:
      return unreachable(e);
  }
};
var natC = (c, env) => {
  switch (c.op) {
    case "<=":
      return natE(c.a, env) <= natE(c.b, env);
    case "<":
      return natE(c.a, env) < natE(c.b, env);
    case "=":
      return natE(c.a, env) === natE(c.b, env);
    case "and":
      return c.xs.every((x) => natC(x, env));
    case "or":
      return c.xs.some((x) => natC(x, env));
    case "not":
      return !natC(c.x, env);
    case "flag":
    case "all":
      throw new Error("a loop reads no flag");
    default:
      return unreachable(c);
  }
};
var zero = { op: "const", value: 0 };
var trueC = { op: "<=", a: zero, b: zero };
var stable = (t) => JSON.stringify(t, (_, x) => x && typeof x === "object" && !Array.isArray(x) ? Object.fromEntries(Object.keys(x).sort().map((key) => [key, x[key]])) : x);
var sameE = (a, b) => stable(a) === stable(b);
var findCount = (cs, v) => cs.find((c) => c.v === v);
function resolve(cs, B, ts) {
  const out = [];
  for (const [z, v] of ts) {
    const c = findCount(cs, v);
    if (!c || !sameE(c.below, B))
      return;
    out.push([z, c]);
  }
  return out;
}
var sumE = (es) => es.reduceRight((acc, e) => ({ op: "add", a: e, b: acc }), { op: "const", value: 0 });
var posP = (z) => Math.max(z, 0);
var negP = (z) => Math.max(-z, 0);
var side = (part, rd, one, u, rs) => ({ op: "add", a: sumE(rs.map(([z, c]) => ({ op: "mul", k: part(z), a: rd(c) }))), b: { op: "mul", k: part(u), a: one } });
var atCount = (c) => ({ op: "var", name: c.v });
var atWit = (w) => (c) => substE(c.body, { vars: { [c.key]: { op: "var", name: w } }, maps: {}, flags: {} });
function countHyp(cs, i) {
  const rs = resolve(cs, i.below, i.terms);
  if (!rs)
    return;
  const one = { op: "const", value: 1 }, w = atWit(i.wit);
  return { op: "or", xs: [
    { op: "<=", a: side(posP, atCount, i.below, i.unit, rs), b: side(negP, atCount, i.below, i.unit, rs) },
    { op: "and", xs: [{ op: "<", a: { op: "var", name: i.wit }, b: i.below }, { op: "<", a: side(negP, w, one, i.unit, rs), b: side(posP, w, one, i.unit, rs) }] }
  ] };
}
function countHyps(cs, is) {
  const out = [];
  for (const i of is) {
    const h = countHyp(cs, i);
    if (!h)
      return;
    out.push(h);
  }
  return out;
}
var readsVar = (t, w) => reads(t).vars.has(w);
var typed = (is) => is.every((i) => typeof i.wit === "string" && Number.isSafeInteger(i.unit) && i.terms.every(([z]) => Number.isSafeInteger(z)));
function countedGoal(g, insts) {
  const hs = countHyps(g.counts, insts);
  return hs && { name: g.name, hyps: [...g.hyps, ...hs] };
}
var postName = (map) => `${map}#`;
var declsOf = (m) => Object.entries(m.counts ?? {}).map(([map, c]) => ({ map, j: c.j, key: c.key, below: c.below, body: c.body, ...c.base ? { lo: c.lo, base: c.base } : {} }));
var loOf = (d) => d.lo ?? d.j;
var baseOf = (d) => d.base ?? 0;
var stateOnly = (m, d) => [d.below, d.body].every((t) => {
  const r = reads(t);
  return m.inputs.every((i) => !r.vars.has(i)) && [...m.inputMaps ?? [], ...Object.keys(m.counts ?? {})].every((mp) => !r.maps.has(mp));
});
var stateCounts = (m) => Object.entries(m.counts ?? {}).filter(([, d]) => stateOnly(m, d)).map(([c]) => c);
function countsScope(m, laws) {
  const counts = m.counts ?? {};
  if (!Object.keys(counts).length)
    return;
  const state = Object.keys(m.state), maps = Object.keys(m.maps ?? {}), carried = m.inputMaps ?? [], fns = Object.keys(m.fns ?? {});
  const names = [...m.params, ...m.inputs, ...state], declared = [...names, ...maps, ...carried, ...fns, ...Object.keys(counts), ...Object.keys(m.step.flags ?? {})];
  const bound = [...quantified(m).flatMap(([f, q]) => [`?${f}`, ...witnessesOf(f, q), ...boundOf(q)]), ...Object.values(m.step.maps ?? {}).flatMap((w) => ("each" in w) ? [w.each] : [])];
  const lawNames = [...laws, ...m.facts ?? []].flatMap((l) => [l.forall, ...l.keys ?? []].flatMap((k) => k ? [k, `${k}#`] : []));
  for (const [c, d] of Object.entries(counts)) {
    const what = `${m.name}'s count ${c}`;
    if (declared.includes(postName(c)))
      throw new Error(`${what}: its post name ${postName(c)} is already a name of ${m.name}`);
    if (d.lo === undefined !== (d.base === undefined) || d.base !== undefined && !(Number.isSafeInteger(d.base) && d.base > 0))
      throw new Error(`${what}: lo and base go together, base a positive integer`);
    const ps = d.lo === undefined ? [d.j] : [d.j, d.lo];
    for (const x of [...ps, d.key])
      plainName(what, x);
    if (new Set([...ps, d.key]).size !== ps.length + 1)
      throw new Error(`${what}: j, lo and key are one name`);
    for (const x of [...ps, d.key])
      if ([...declared, ...bound, ...lawNames].includes(x))
        throw new Error(`${what}: ${x} is already a name of ${m.name} or a law`);
    unquantified(what, d.below);
    unquantified(what, d.body);
    inScope(`${what}'s bound`, [d.below], [...names, ...ps], [...maps, ...carried, ...fns]);
    inScope(`${what}'s body`, [d.body], [...names, ...ps, d.key], [...maps, ...carried, ...fns]);
    if (!natural(d.below) || !natural(d.body))
      throw new Error(`${what}: a negative constant or factor is outside the kernel`);
  }
}
var countKeyParts = (d, e) => !baseOf(d) ? [{ op: "const", value: 0 }, e] : e.op === "add" && e.a.op === "mul" && e.a.k === baseOf(d) ? [e.a.a, e.b] : undefined;
var toCount = (ds, r) => {
  const d = ds.find((x) => x.map === r[1]), p = d && countKeyParts(d, r[2]);
  if (!d || !p)
    return;
  const at = { vars: { [d.j]: p[0], [loOf(d)]: p[1] }, maps: {}, flags: {} };
  return { v: r[0], key: d.key, below: substE(d.below, at), body: substE(d.body, at) };
};
function toCounts(ds, rs) {
  const out = [];
  for (const r of rs) {
    const c = toCount(ds, r);
    if (!c)
      return;
    out.push(c);
  }
  return out;
}
var readHyp = (ds, r) => {
  const eq = { op: "=", a: { op: "var", name: r[0] }, b: { op: "get", map: r[1], key: r[2] } }, d = ds.find((x) => x.map === r[1]), p = d && baseOf(d) ? countKeyParts(d, r[2]) : undefined;
  return p ? { op: "or", xs: [{ op: "<=", a: { op: "const", value: baseOf(d) }, b: p[1] }, eq] } : eq;
};
var allNe = (k, ks) => ks.length ? { op: "and", xs: [{ op: "not", x: { op: "=", a: k, b: ks[0] } }, allNe(k, ks.slice(1))] } : trueC;
var distinctBelow = (b, ks) => ks.length ? { op: "and", xs: [{ op: "<", a: ks[0], b }, { op: "and", xs: [allNe(ks[0], ks.slice(1)), distinctBelow(b, ks.slice(1))] }] } : trueC;
var pickHyp = (c, ks) => ({ op: "or", xs: [
  { op: "not", x: distinctBelow(c.below, ks) },
  { op: "<=", a: sumE(ks.map((k) => substE(c.body, { vars: { [c.key]: k }, maps: {}, flags: {} }))), b: { op: "var", name: c.v } }
] });
var pickHyps = (ds, rs, ps) => ps.flatMap(([v, ks]) => {
  const r = rs.find((x) => x[0] === v), c = r && toCount(ds, r);
  return c ? [pickHyp(c, ks)] : [];
});
var picksTyped = (ps) => ps === undefined || Array.isArray(ps) && ps.every((p) => Array.isArray(p) && p.length === 2 && typeof p[0] === "string" && Array.isArray(p[1]) && p[1].every(safeTerm));
var readFresh = (hyps, ds, rs, v) => hyps.every((h) => !readsVar(h, v)) && ds.every((d) => !readsVar(d.below, v) && !readsVar(d.body, v) && d.j !== v && loOf(d) !== v && d.key !== v) && rs.every((r) => !readsVar(r[2], v));
var readsOk = (hyps, ds, rs) => new Set(rs.map((r) => r[0])).size === rs.length && rs.every((r) => readFresh(hyps, ds, rs, r[0]) && ds.every((d) => !readsVar(r[2], d.key)));
var safeTerm = (t) => {
  if (!t || typeof t !== "object")
    return false;
  const e = t;
  switch (e.op) {
    case "var":
      return typeof e.name === "string";
    case "const":
      return Number.isSafeInteger(e.value) && e.value >= 0;
    case "mul":
      return Number.isSafeInteger(e.k) && e.k >= 0 && safeTerm(e.a);
    case "get":
      return typeof e.map === "string" && safeTerm(e.key);
    case "add":
    case "sub":
    case "min":
    case "max":
    case "prod":
      return safeTerm(e.a) && safeTerm(e.b);
    case "if":
      return safeCond(e.c) && safeTerm(e.then) && safeTerm(e.else);
    case "tup":
    case "proj":
      return false;
    default:
      return false;
  }
};
var safeCond = (c) => !!c && typeof c === "object" && (c.op === "<" || c.op === "<=" || c.op === "=" ? safeTerm(c.a) && safeTerm(c.b) : c.op === "not" ? safeCond(c.x) : (c.op === "and" || c.op === "or") && Array.isArray(c.xs) && c.xs.every(safeCond));
var readsTyped = (rs) => Array.isArray(rs) && rs.every((r) => Array.isArray(r) && r.length === 3 && typeof r[0] === "string" && typeof r[1] === "string" && safeTerm(r[2]));
var witFreshW = (cs, is, w) => cs.every((c) => c.v !== w && !readsVar(c.below, w) && !readsVar(c.body, w)) && is.every((j) => !readsVar(j.below, w));
var countedOkW = (cs, is) => {
  const ws = is.map((i) => i.wit);
  return new Set(ws).size === ws.length && is.every((i) => witFreshW(cs, is, i.wit));
};
function checkCountedW(hyps, cs, cert) {
  if (!(countedOkW(cs, cert.insts) && typed(cert.insts)))
    return false;
  const hs = countHyps(cs, cert.insts);
  return hs !== undefined && checkGoalLemmas({ name: "counted", hyps: [...hyps, ...hs] }, cert.tree, cert.lemmas);
}
function checkMC(hyps, ds, k) {
  if (!(ds.every((d) => d.j !== d.key && loOf(d) !== d.key) && picksTyped(k.picks) && readsTyped(k.reads) && Array.isArray(k.insts) && k.insts.every((i) => !!i && safeTerm(i.below)) && readsOk(hyps, ds, k.reads)))
    return false;
  if (!k.reads.every((r) => k.insts.every((i) => i.wit !== r[0] && !readsVar(r[2], i.wit))))
    return false;
  const cs = toCounts(ds, k.reads);
  return cs !== undefined && checkCountedW([...hyps, ...k.reads.map((r) => readHyp(ds, r)), ...pickHyps(ds, k.reads, k.picks ?? [])], cs, { insts: k.insts, tree: k.tree, lemmas: k.lemmas });
}
function mcGoal(hyps, ds, k) {
  const cs = toCounts(ds, k.reads);
  return cs && countedGoal({ name: "counted", hyps: [...hyps, ...k.reads.map((r) => readHyp(ds, r)), ...pickHyps(ds, k.reads, k.picks ?? [])], counts: cs }, k.insts);
}
function countedObligations(m, laws, instances = {}, only) {
  if (m.history || m.sums && Object.keys(m.sums).length)
    throw new Error(`${m.name}: counts go with no history and no sums`);
  scope(m, laws);
  const ok = [...Object.values(m.state), ...Object.values(m.step.state ?? {}), ...Object.values(m.step.maps ?? {}).flatMap((w) => ("each" in w) ? [w.value] : [w.key, w.value])].every(natural) && Object.values(m.step.flags ?? {}).every(naturalC) && laws.every((l) => naturalC(l.holds)) && Object.values(m.maps ?? {}).every((c) => Number.isInteger(c) && c >= 0);
  if (!ok || !(m.facts ?? []).every((l) => naturalC(l.holds)) || laws.some((l) => mentions(l.holds, m.inputs)))
    throw new Error("a negative constant or factor, or a law about a request, is outside the kernel");
  const ren = { vars: {}, maps: Object.fromEntries(Object.keys(m.counts ?? {}).map((c) => [c, (key) => ({ op: "get", map: postName(c), key })])), flags: {} };
  const proven = (law) => {
    const h = substC(law.holds, ren);
    return law.forall ? substC(h, { vars: { [law.forall]: { op: "var", name: `${law.forall}#` } }, maps: {}, flags: {} }) : h;
  };
  const all = declsOf(m), st = all.filter((d) => stateOnly(m, d));
  const after = (at) => st.map((d) => ({ ...d, map: postName(d.map), below: substE(d.below, at), body: substE(d.body, at) }));
  const pre = preOf(m), u = updateOf(m), assume = m.assume ? [inlineFlags(m, m.assume)] : [];
  return laws.flatMap((law, i) => {
    if (only !== undefined && i !== only)
      return [];
    const inst = own(instances, law.name) ?? {};
    const start = given(m, holds(from(startOf(m)), pre), inst);
    const turn = step(holds(given(m, from(), inst), [...pre, ...assume, ...assumed(laws, inst), ...closing(m, inst)]), u);
    return [
      { goal: goal(`${law.name} @start`, start, atEnd(start, proven(law))), decls: after(start.at) },
      { goal: goal(`${law.name} @step`, turn, atEnd(turn, proven(law))), decls: [...all, ...after(turn.at)] }
    ];
  });
}
// core/machine.ts
var walkOnce = (t, f) => {
  const seen = new Set;
  const go = (x) => {
    if (!x || typeof x !== "object" || seen.has(x))
      return;
    seen.add(x);
    f(x);
    for (const y of Object.values(x))
      go(y);
  };
  go(t);
};
var x = (name) => ({ op: "var", name });
var n = (value) => ({ op: "const", value });
var plus2 = (a, b) => ({ op: "add", a, b });
var cpair = (a, b) => {
  const s = a + b;
  return exactPair(s % 2 === 0 ? s / 2 * (s + 1) + b : s * ((s + 1) / 2) + b);
};
var exactPair = (v) => {
  if (!Number.isSafeInteger(v))
    throw new RangeError("a tuple key passed 2^53 - 1, past which the proofs over the naturals no longer describe the run");
  return v;
};
var cunpair = (z) => {
  let s = Math.floor((Math.sqrt(8 * z + 1) - 1) / 2);
  while (s > 0 && tri(s) > z)
    s--;
  while (tri(s + 1) <= z)
    s++;
  const b = z - tri(s);
  return [s - b, b];
};
var tri = (s) => s % 2 === 0 ? s / 2 * (s + 1) : s * ((s + 1) / 2);
var same = (a, b) => ({ op: "=", a, b });
var any = (...xs) => ({ op: "or", xs });
var mapsIn = (t) => [...new Set([...JSON.stringify(t).matchAll(/"op":"get","map":"([^"]+)"/g)].map((x) => x[1]))];
function keysAt(st, maps) {
  const keys = new Set;
  let past = 0;
  for (const cells of Object.values(st.maps))
    for (const key of cells.keys())
      past = Math.max(past, key + 1);
  for (const map of maps)
    for (const key of st.maps[map]?.keys() ?? [])
      keys.add(key);
  return [...keys, past];
}
var breaksCache = new WeakMap;
function breaksOf(t, key) {
  const hit = breaksCache.get(t)?.get(key);
  if (hit)
    return hit;
  const out = { reads: [], cmps: [] };
  const termOf = (e) => e.op === "var" ? { minus: false } : e.op === "add" ? { off: e.a.op === "var" && e.a.name === key ? e.b : e.a, minus: false } : { off: e.b, minus: true };
  const cmp = (a, b) => {
    if (!keyTerm(a, key) && !keyTerm(b, key))
      return false;
    const [kt, other] = keyTerm(a, key) ? [a, b] : [b, a];
    out.cmps.push({ value: other, ...termOf(kt) });
    walk(other);
    return true;
  };
  const walk = (u) => {
    if (u.op === "get" && keyTerm(u.key, key)) {
      out.reads.push({ map: u.map, ...termOf(u.key) });
      return;
    }
    if (u.op === "get" && u.key.op === "tup") {
      const parts = tupleParts(u.key);
      parts.forEach((p, i) => {
        if (keyTerm(p, key))
          out.reads.push({ map: u.map, ...termOf(p), part: [i, parts.length] });
        else
          walk(p);
      });
      return;
    }
    if (u.op === "=" && u.a.op === "tup" && u.b.op === "tup") {
      const as = tupleParts(u.a), bs = tupleParts(u.b);
      if (as.length === bs.length) {
        as.forEach((a, i) => {
          if (!cmp(a, bs[i])) {
            walk(a);
            walk(bs[i]);
          }
        });
        return;
      }
    }
    if ((u.op === "<" || u.op === "<=" || u.op === "=") && cmp(u.a, u.b))
      return;
    for (const v of Object.values(u))
      if (v && typeof v === "object")
        (Array.isArray(v) ? v : [v]).forEach((y) => walk(y));
  };
  walk(t);
  if (!breaksCache.has(t))
    breaksCache.set(t, new Map);
  breaksCache.get(t).set(key, out);
  return out;
}
function breakKeys(b, env2, st, m) {
  const points = new Set([0]);
  for (const r of b.reads) {
    const d = r.off ? evalE(r.off, env2, st, m) : 0;
    for (const s0 of st.maps[r.map]?.keys() ?? []) {
      const s = r.part ? partsOf(s0, r.part[1])[r.part[0]] : s0;
      if (r.minus)
        points.add(s + d);
      else if (s >= d)
        points.add(s - d);
    }
    if (r.minus)
      points.add(d);
  }
  for (const c of b.cmps) {
    const v = evalE(c.value, env2, st, m), d = c.off ? evalE(c.off, env2, st, m) : 0;
    if (c.minus) {
      points.add(v + d);
      points.add(d);
    } else if (v >= d)
      points.add(v - d);
  }
  const keys = new Set;
  for (const p of points)
    for (let i = -1;i <= 2; i++)
      if (p + i >= 0)
        keys.add(p + i);
  const sorted = [...keys].sort((a, b) => a - b);
  return [...sorted, sorted.at(-1) + 1];
}
function tupleKeys(c, env2, st, m) {
  const names = boundOf(c);
  if (names.every((n) => plainKey(c.c, n)))
    return keysAt(st, mapsIn(c.c));
  if (names.length === 1)
    return breakKeys(breaksOf(c.c, c.key), env2, st, m);
  const body = crossFree(c.c, names);
  if (names.every((n) => plainKey(body, n)))
    return spread([0, ...keysAt(st, mapsIn(c.c))], names.length + 1);
  const parts = names.map((n) => breaksOf(body, n));
  return spread(breakKeys({ reads: parts.flatMap((b) => b.reads), cmps: parts.flatMap((b) => b.cmps) }, env2, st, m), names.length);
}
var partsOf = (z, n) => {
  const out = [];
  for (let i = 0;i + 1 < n; i++) {
    const [a, b] = cunpair(z);
    out.push(a);
    z = b;
  }
  out.push(z);
  return out;
};
var spread = (keys, n) => [...new Set(keys.flatMap((k) => Array.from({ length: n }, (_, i) => k + i)))].sort((a, b) => a - b);
var naturalIn = (v, what) => {
  if (typeof v !== "number" || !Number.isSafeInteger(v) || v < 0)
    throw new RangeError(`${what} must be a natural below 2^53, not ${String(v)}`);
  return v;
};
var exact2 = (v) => {
  if (v > Number.MAX_SAFE_INTEGER)
    throw new RangeError("a value passed 2^53 - 1, past which the proofs over the naturals no longer describe the run");
  return v;
};
var num = (x) => typeof x === "number" ? x : undefined;
function evalE(e, env2, st, m) {
  switch (e.op) {
    case "var": {
      const v = num(env2[e.name]) ?? num(st.scalars[e.name]);
      if (v === undefined)
        throw new Error(`no value for ${e.name}`);
      return v;
    }
    case "const":
      return e.value;
    case "add":
      return exact2(evalE(e.a, env2, st, m) + evalE(e.b, env2, st, m));
    case "sub":
      return Math.max(0, evalE(e.a, env2, st, m) - evalE(e.b, env2, st, m));
    case "mul":
      return exact2(e.k * evalE(e.a, env2, st, m));
    case "prod":
      return exact2(evalE(e.a, env2, st, m) * evalE(e.b, env2, st, m));
    case "min":
      return Math.min(evalE(e.a, env2, st, m), evalE(e.b, env2, st, m));
    case "max":
      return Math.max(evalE(e.a, env2, st, m), evalE(e.b, env2, st, m));
    case "if":
      return evalC(e.c, env2, st, m) ? evalE(e.then, env2, st, m) : evalE(e.else, env2, st, m);
    case "tup":
      return cpair(evalE(e.a, env2, st, m), evalE(e.b, env2, st, m));
    case "proj":
      return cunpair(evalE(e.a, env2, st, m))[e.k];
    case "get": {
      const fn = m.fns && Object.hasOwn(m.fns, e.map) ? m.fns[e.map] : undefined, args = fn?.call ? pairedArgs(e.key, fn.arity) : undefined;
      if (args) {
        const xs = args.map((a) => evalE(a, env2, st, m));
        return naturalIn(callOf(fn)(...xs), `${e.map}(${xs.join(", ")})`);
      }
      const key = evalE(e.key, env2, st, m);
      return fn ? naturalIn(fnOf(fn)(key), `${e.map}(${key})`) : st.maps[e.map].get(key) ?? (st.defaults && Object.hasOwn(st.defaults, e.map) ? st.defaults[e.map] : undefined) ?? m.maps[e.map];
    }
  }
}
var compiledFns = new WeakMap;
var fnOf = (fn) => {
  let f = compiledFns.get(fn);
  if (!f) {
    f = compileFunction(["k"], `return (${fn.js})(k)`);
    compiledFns.set(fn, f);
  }
  return f;
};
var compiledCalls = new WeakMap;
var callOf = (fn) => {
  let f = compiledCalls.get(fn);
  if (!f) {
    f = compileFunction([], `return (${fn.call})`)();
    compiledCalls.set(fn, f);
  }
  return f;
};
var paired = new WeakMap;
function pairedArgs(key, n) {
  let byN = paired.get(key);
  if (!byN)
    paired.set(key, byN = new Map);
  if (byN.has(n))
    return byN.get(n);
  let out;
  if (n === 1)
    out = [key];
  else if (key.op === "add" && key.a.op === "prod" && key.a.a.op === "add" && alike(key.a.a, key.a.b) && alike(key.a.a.b, key.b)) {
    const first = pairedArgs(key.a.a.a, n - 1);
    out = first && [...first, key.b];
  }
  byN.set(n, out);
  return out;
}
var alike = (a, b) => a === b || JSON.stringify(a) === JSON.stringify(b);
function evalC(c, env2, st, m) {
  switch (c.op) {
    case "<":
      return evalE(c.a, env2, st, m) < evalE(c.b, env2, st, m);
    case "<=":
      return evalE(c.a, env2, st, m) <= evalE(c.b, env2, st, m);
    case "=":
      return evalE(c.a, env2, st, m) === evalE(c.b, env2, st, m);
    case "and":
      return c.xs.every((y) => evalC(y, env2, st, m));
    case "or":
      return c.xs.some((y) => evalC(y, env2, st, m));
    case "not":
      return !evalC(c.x, env2, st, m);
    case "flag":
      return env2[`?${c.name}`] === 1;
    case "all": {
      const names = boundOf(c), keys = tupleKeys(c, env2, st, m);
      const go = (i, at) => i === names.length ? evalC(c.c, at, st, m) : keys.every((key) => go(i + 1, { ...at, [names[i]]: key }));
      return go(0, env2);
    }
  }
}
function compileFunction(params, body) {
  return new Function(...params, body);
}
var proveDebug = !!env.PROVE_DEBUG;

// kernel/share.ts
function shareTerms() {
  const memo = new WeakMap, ids = new WeakMap, table = new Map;
  let next = 0;
  const share = (term) => {
    const had = memo.get(term);
    if (had)
      return had;
    const entries = Object.entries(term).map(([k, value]) => [k, value !== null && typeof value === "object" ? share(value) : value]);
    const key = JSON.stringify([Array.isArray(term) ? ["array", term.length] : ["object"], entries.map(([k, value]) => [
      k,
      value !== null && typeof value === "object" ? ["ref", ids.get(value)] : [typeof value, typeof value === "number" && Object.is(value, -0) ? "-0" : String(value)]
    ]).sort(([a], [b]) => String(a).localeCompare(String(b)))]);
    let out = table.get(key);
    if (!out) {
      out = entries.every(([k, value]) => term[k] === value) ? term : Object.assign(Array.isArray(term) ? new Array(term.length) : {}, Object.fromEntries(entries));
      table.set(key, out);
      ids.set(out, next++);
    }
    memo.set(term, out);
    memo.set(out, out);
    return out;
  };
  return share;
}

// kernel/reader.ts
var none = new Set;
var join = (a, b) => {
  if (!a.size || a === b)
    return b;
  if (!b.size)
    return a;
  const [s, l] = a.size <= b.size ? [a, b] : [b, a];
  let inside = true;
  for (const x of s)
    if (!l.has(x)) {
      inside = false;
      break;
    }
  if (inside)
    return l;
  const out = new Set(a);
  for (const x of b)
    out.add(x);
  return out;
};
var R0 = { w: none, pos: -1, fin: true };
var R1 = { w: none, pos: -1, fin: false };
var unfin = (r) => r.fin ? { w: r.w, pos: r.pos, fin: false } : r;
var both = (a, b) => ({ w: join(a.w, b.w), pos: Math.max(a.pos, b.pos), fin: a.fin && b.fin });
function times3(a, b) {
  const out = [];
  for (const [p, cp] of Object.entries(a))
    for (const [q, cq] of Object.entries(b)) {
      if (p.includes("\u27E6") || q.includes("\u27E6"))
        return;
      const fs = [...p === "1" ? [] : factorsOf(p), ...q === "1" ? [] : factorsOf(q)].sort();
      out.push({ [fs.length ? fs.join("*") : "1"]: cp * cq });
    }
  return add(...out);
}
var one = k(1);
var namePair = new WeakMap;
var constantLin = (l) => Object.entries(l).every(([key, c]) => key === "1" || c === 0);
var lasts = Array.from({ length: 8 }, () => new WeakMap);
function same2(site, owner, a, b, c, make) {
  const m = lasts[site], had = m.get(owner);
  if (had && had.a === a && had.b === b && had.c === c)
    return had.out;
  const out = make();
  m.set(owner, { a, b, c, out });
  return out;
}
var keepClean = env.GDP_READER_CLEAN !== "0";

class Seg {
  kind;
  i;
  j;
  constructor(kind, i, j = -1) {
    this.kind = kind;
    this.i = i;
    this.j = j;
  }
}

class Reader {
  goal;
  trail;
  node = 0;
  share = shareTerms();
  natRows = new Map;
  atomRows = new Map;
  leafAtomRows = new WeakMap;
  ls = new Map;
  ts = new Map;
  fs = [];
  os = [];
  constructor(goal, trail) {
    this.goal = goal;
    this.trail = trail;
  }
  begin() {
    this.node++;
  }
  up = new Map;
  byAtom = new Map;
  found = new Map;
  lastUp = new WeakMap;
  clean = new Set;
  factKeys = [];
  openKeys = [];
  finding;
  read(key) {
    const f = this.finding;
    if (!f || this.lastUp.get(key) === f)
      return;
    this.lastUp.set(key, f);
    let s = this.up.get(key);
    if (!s)
      this.up.set(key, s = new Map);
    s.set(f.key, f);
  }
  readAtom(name) {
    const f = this.finding;
    if (!f)
      return;
    let s = this.byAtom.get(name);
    if (!s)
      this.byAtom.set(name, s = new Map);
    s.set(f.key, f);
  }
  within(key, f) {
    const was = this.finding, now = { key };
    costs.values++;
    this.found.set(key, now);
    this.finding = now;
    try {
      return f();
    } finally {
      this.finding = was;
    }
  }
  touch(name) {
    const todo = [], seen = new Set, found = this.found;
    const walk = (edges) => {
      if (edges) {
        costs.edges += edges.size;
        for (const [k, f] of edges) {
          if (found.get(k) === f)
            todo.push(k);
          else
            edges.delete(k);
        }
      }
    };
    walk(this.byAtom.get(name));
    while (todo.length) {
      const key = todo.pop();
      if (seen.has(key))
        continue;
      seen.add(key);
      this.clean.delete(key);
      if (key instanceof Seg && this.syncing)
        this.dirty.add(key);
      walk(this.up.get(key));
    }
  }
  ok(x, key) {
    if (keepClean && this.clean.has(key) || x.node === this.node)
      return true;
    if (x.fin && (x.pos < 0 || x.pos < this.trail.size() && this.trail.stamp(x.pos) === x.stamp)) {
      this.clean.add(key);
      return true;
    }
    return false;
  }
  units = new Map;
  unit(name) {
    let w = this.units.get(name);
    if (!w)
      this.units.set(name, w = new Set([name]));
    return w;
  }
  dec(lin) {
    let constant = true;
    for (const key in lin)
      if (key !== "1") {
        constant = false;
        break;
      }
    if (constant)
      return { w: none, pos: -1, fin: true, t: (lin["1"] ?? 0) <= 0 };
    let names = namePair.get(lin);
    if (!names)
      namePair.set(lin, names = [canon(lin), canonFlip(lin)]);
    const [a, f] = names;
    this.readAtom(a);
    this.readAtom(f);
    const x = this.trail.get(a);
    if (x && x.val !== undefined)
      return { t: x.val, w: this.unit(a), pos: x.at, fin: true };
    const y = this.trail.get(f);
    if (y && y.val !== undefined)
      return { t: !y.val, w: this.unit(f), pos: y.at, fin: true };
    return { t: undefined, w: none, pos: -1, fin: false };
  }
  linear(e) {
    e = this.share(e);
    this.read(e);
    const had = this.ls.get(e);
    if (had && this.ok(had, e))
      return had;
    return this.within(e, () => this.linear0(e));
  }
  linear0(e) {
    let lin, r = R0;
    switch (e.op) {
      case "var":
        lin = e.name === "1" || /[*[\],:\u27E6\u27E8\u27E9|]/.test(e.name) ? undefined : same2(0, e, 0, 0, 0, () => v(e.name));
        break;
      case "const":
        lin = same2(0, e, 0, 0, 0, () => k(e.value));
        break;
      case "mul": {
        const a = this.linear(e.a);
        lin = a.lin && same2(0, e, a.lin, 0, 0, () => scale(a.lin, e.k));
        r = a;
        break;
      }
      case "prod": {
        const a = this.linear(e.a), b = this.linear(e.b);
        lin = a.lin && b.lin && same2(0, e, a.lin, b.lin, 0, () => times3(a.lin, b.lin));
        r = both(a, b);
        break;
      }
      case "add": {
        const a = this.linear(e.a), b = this.linear(e.b);
        lin = a.lin && b.lin && same2(0, e, a.lin, b.lin, 0, () => add(a.lin, b.lin));
        r = both(a, b);
        break;
      }
      case "sub":
      case "min":
      case "max": {
        const a = this.linear(e.a), b = this.linear(e.b);
        if (!a.lin || !b.lin) {
          lin = undefined;
          r = both(a, b);
          break;
        }
        const d = this.dec(same2(1, e, a.lin, b.lin, 0, () => e.op === "sub" ? sub(b.lin, a.lin) : sub(a.lin, b.lin)));
        if (d.t === undefined) {
          lin = same2(2, e, 0, 0, 0, () => v(termColumn(e)));
          r = { w: none, pos: -1, fin: false };
          break;
        }
        r = both(both(a, b), d);
        lin = e.op === "sub" ? same2(0, e, a.lin, b.lin, d.t, () => d.t ? sub(a.lin, b.lin) : k(0)) : e.op === "min" === d.t ? a.lin : b.lin;
        break;
      }
      case "if": {
        const c = this.truth(e.c);
        if (c.t === undefined) {
          lin = same2(2, e, 0, 0, 0, () => v(termColumn(e)));
          r = { w: none, pos: -1, fin: false };
          break;
        }
        const x = this.linear(c.t ? e.then : e.else);
        lin = x.lin;
        r = both(c, x);
        break;
      }
      case "get": {
        if (!plainMap(e.map)) {
          lin = undefined;
          break;
        }
        if (e.key.op === "tup" || e.key.op === "proj") {
          const ps = this.tparts(e.key);
          if (ps.lins) {
            r = ps.r;
            const name = `${e.map}[\u27E8${ps.lins.map(canon).join("|")}\u27E9]`;
            lin = same2(0, e, name, 0, 0, () => v(name));
            break;
          }
          if (e.key.op === "tup") {
            lin = undefined;
            r = ps.r;
            break;
          }
        }
        const key = this.linear(e.key);
        lin = key.lin && same2(0, e, key.lin, 0, 0, () => v(`${e.map}[${canon(key.lin)}]`));
        r = key;
        break;
      }
      case "tup":
        lin = undefined;
        break;
      case "proj": {
        const ps = this.tparts(e.a);
        r = ps.r;
        lin = !ps.lins ? undefined : e.k === 0 ? ps.lins[0] : ps.lins.length === 2 ? ps.lins[1] : undefined;
        break;
      }
    }
    const out = { lin, w: r.w, fin: r.fin, pos: r.pos, stamp: r.pos < 0 ? 0 : this.trail.stamp(r.pos), node: this.node };
    this.ls.set(e, out);
    this.clean.add(e);
    return out;
  }
  tparts(e) {
    if (e.op === "proj") {
      if (e.k === 0)
        return { r: R0 };
      const ps = this.tparts(e.a);
      return ps.lins && ps.lins.length >= 3 ? { lins: ps.lins.slice(1), r: ps.r } : { r: ps.r };
    }
    if (e.op !== "tup")
      return { r: R0 };
    const a = this.linear(e.a);
    if (!a.lin)
      return { r: a };
    if (e.b.op !== "tup") {
      const b = this.linear(e.b);
      return b.lin ? { lins: [a.lin, b.lin], r: both(a, b) } : { r: both(a, b) };
    }
    const rest = this.tparts(e.b);
    return rest.lins ? { lins: [a.lin, ...rest.lins], r: both(a, rest.r) } : { r: both(a, rest.r) };
  }
  atoms(c) {
    if (c.a.op === "tup" || c.b.op === "tup")
      return;
    const a = this.linear(c.a), b = this.linear(c.b);
    if (!a.lin || !b.lin)
      return;
    const r = both(a, b), x = a.lin, y = b.lin;
    const atoms = same2(3, c, x, y, 0, () => {
      const ab = sub(x, y), ba = sub(y, x);
      if (c.op === "<=")
        return { when: [ab], unless: [[add(ba, k(1))]] };
      if (c.op === "<")
        return { when: [add(ab, k(1))], unless: [[ba]] };
      return { when: [ab, ba], unless: [[add(ab, k(1))], [add(ba, k(1))]] };
    });
    return { when: atoms.when, unless: atoms.unless, r };
  }
  truth(c) {
    c = this.share(c);
    this.read(c);
    const had = this.ts.get(c);
    if (had && this.ok(had, c))
      return had;
    return this.within(c, () => this.truth0(c));
  }
  truth0(c) {
    let t, r;
    switch (c.op) {
      case "flag":
        throw new Error("flags are inlined before the kernel sees them");
      case "all":
        t = undefined;
        r = R1;
        break;
      case "not": {
        const x = this.truth(c.x);
        t = x.t === undefined ? undefined : !x.t;
        r = x;
        break;
      }
      case "and":
      case "or": {
        const dominant = c.op === "or", xs = c.xs.map((y) => this.truth(y));
        let best;
        for (const x of xs)
          if (x.t === dominant && (!best || x.w.size < best.w.size || x.w.size === best.w.size && x.fin && !best.fin))
            best = x;
        if (best) {
          t = dominant;
          r = best;
        } else if (xs.every((x) => x.t === !dominant)) {
          t = !dominant;
          r = xs.reduce(both, R0);
        } else {
          t = undefined;
          r = R1;
        }
        break;
      }
      case "<":
      case "<=":
      case "=": {
        const and = tupleAnd(c);
        if (and) {
          const x = this.truth(and);
          t = x.t;
          r = x;
          break;
        }
        const cmp = this.atoms(c);
        if (!cmp) {
          t = undefined;
          r = R1;
          break;
        }
        const ds = cmp.when.map((lin) => this.dec(lin));
        let best;
        for (const d of ds)
          if (d.t === false && (!best || d.w.size < best.w.size))
            best = d;
        if (best) {
          t = false;
          const x = both(cmp.r, best);
          r = { w: x.w, pos: x.pos, fin: cmp.r.fin };
        } else if (ds.every((d) => d.t === true)) {
          t = true;
          r = ds.reduce(both, cmp.r);
        } else {
          t = undefined;
          r = unfin(cmp.r);
        }
        break;
      }
    }
    const out = { t, w: r.w, fin: t !== undefined && r.fin, pos: r.pos, stamp: r.pos < 0 ? 0 : this.trail.stamp(r.pos), node: this.node };
    this.ts.set(c, out);
    this.clean.add(c);
    return out;
  }
  factsOf(c, positive, out) {
    switch (c.op) {
      case "flag":
        throw new Error("flags are inlined before the kernel sees them");
      case "all":
        return R0;
      case "not":
        return this.factsOf(c.x, !positive, out);
      case "and":
      case "or": {
        if (c.op === "and" === positive)
          return c.xs.reduce((acc, y) => both(acc, this.factsOf(y, positive, out)), R0);
        let closed = R0;
        const open = [];
        for (const y of c.xs) {
          const t = this.truth(y);
          if (t.t === !positive)
            closed = both(closed, t);
          else
            open.push(y);
        }
        if (open.length === 0) {
          out.push({ lin: one, w: closed.w, label: "" });
          return closed;
        }
        if (open.length > 1)
          return unfin(closed);
        const inner = [], r = this.factsOf(open[0], positive, inner);
        for (const row of inner)
          out.push({ lin: row.lin, w: join(row.w, closed.w), label: "" });
        const last = this.truth(open[0]);
        const x = both(both(closed, r), last);
        return { w: x.w, pos: x.pos, fin: x.fin && last.t !== undefined };
      }
      case "<":
      case "<=":
      case "=": {
        const and = tupleAnd(c);
        if (and)
          return this.factsOf(and, positive, out);
        const cmp = this.atoms(c);
        if (!cmp)
          return R1;
        if (positive) {
          for (const lin of cmp.when)
            out.push({ lin, w: cmp.r.w, label: "" });
          return cmp.r;
        }
        let closed = cmp.r;
        const open = [];
        for (const atoms of cmp.unless) {
          let shut;
          for (const lin of atoms) {
            const d = this.dec(lin);
            if (d.t === false) {
              shut = d;
              break;
            }
          }
          if (shut)
            closed = both(closed, shut);
          else
            open.push(atoms);
        }
        if (open.length === 0) {
          out.push({ lin: one, w: closed.w, label: "" });
          return closed;
        }
        if (open.length > 1)
          return unfin(closed);
        for (const lin of open[0])
          out.push({ lin, w: closed.w, label: "" });
        return unfin(closed);
      }
    }
  }
  facts(i) {
    const key = this.factKeys[i] ??= new Seg(0, i);
    this.read(key);
    const had = this.fs[i];
    if (had && this.ok(had, key))
      return had;
    return this.within(key, () => {
      const parts = this.parts(i);
      let rows = [], pos = -1, fin = true;
      if (parts.length === 1) {
        const f = this.part(parts[0]);
        rows = f.rows;
        pos = f.pos;
        fin = f.fin;
      } else
        for (const p of parts) {
          const f = this.part(p);
          for (const r of f.rows)
            rows.push(r);
          if (f.pos > pos)
            pos = f.pos;
          fin &&= f.fin;
        }
      const out = { rows, fin, pos, stamp: pos < 0 ? 0 : this.trail.stamp(pos), node: this.node };
      this.fs[i] = out;
      this.clean.add(key);
      return out;
    });
  }
  factsFin(i) {
    for (const p of this.parts(i))
      if (!this.part(p).fin)
        return false;
    return true;
  }
  partsOf = [];
  ps = new Map;
  parts(i) {
    let out = this.partsOf[i];
    if (out)
      return out;
    const mine = [];
    const flat = (c, positive) => {
      if (c.op === "not")
        return flat(c.x, !positive);
      if (c.op === "and" && positive || c.op === "or" && !positive) {
        for (const y of c.xs)
          flat(y, positive);
        return;
      }
      mine.push({ c, positive, key: new Seg(3, i, mine.length) });
    };
    flat(this.goal.hyps[i], true);
    return this.partsOf[i] = out = mine;
  }
  part(p) {
    this.read(p.key);
    const had = this.ps.get(p.key);
    if (had && this.ok(had, p.key))
      return had;
    return this.within(p.key, () => {
      const rows = [], r = this.factsOf(p.c, p.positive, rows);
      const out = { rows, fin: r.fin, pos: r.pos, stamp: r.pos < 0 ? 0 : this.trail.stamp(r.pos), node: this.node };
      this.ps.set(p.key, out);
      this.clean.add(p.key);
      return out;
    });
  }
  termRows(name) {
    const e = columnTerm(name), col = same2(4, e, 0, 0, 0, () => v(name)), out = [];
    if (e.op === "min" || e.op === "max" || e.op === "sub") {
      const a = this.linear(e.a), b = this.linear(e.b), w = join(a.w, b.w);
      if (a.lin && b.lin) {
        const x = a.lin, y = b.lin, lins = same2(5, e, x, y, 0, () => e.op === "min" ? [sub(col, x), sub(col, y)] : e.op === "max" ? [sub(x, col), sub(y, col)] : [sub(sub(x, y), col), sub(col, x)]);
        for (const lin of lins)
          out.push({ lin, w, label: "" });
      }
    }
    if (e.op === "if") {
      const a = this.linear(e.then), b = this.linear(e.else);
      if (a.lin && b.lin && constantLin(a.lin) && constantLin(b.lin)) {
        const x = a.lin, y = b.lin;
        out.push({ lin: same2(5, e, x, y, 0, () => sub(col, add(x, y))), w: join(a.w, b.w), label: "" });
      }
    }
    if (this.decided(e)) {
      const r = this.linear(e);
      if (r.lin) {
        const x = r.lin, [p, q] = same2(6, e, x, 0, 0, () => [sub(col, x), sub(x, col)]);
        out.push({ lin: p, w: r.w, label: "" }, { lin: q, w: r.w, label: "" });
      }
    }
    return out;
  }
  decided(e) {
    if (e.op === "if")
      return this.truth(e.c).t !== undefined;
    if (e.op !== "sub" && e.op !== "min" && e.op !== "max")
      return true;
    const a = this.linear(e.a).lin, b = this.linear(e.b).lin;
    return !!a && !!b && this.dec(same2(1, e, a, b, 0, () => e.op === "sub" ? sub(b, a) : sub(a, b))).t !== undefined;
  }
  rows() {
    const out = [], g = ++this.gen;
    for (const r of this.leafRows()) {
      const id = this.form(r.lin).id;
      if (this.formSeen[id] !== g) {
        this.formSeen[id] = g;
        this.formAt[id] = out.length;
        out.push(r);
      } else {
        const j = this.formAt[id];
        if (r.w.size < out[j].w.size)
          out[j] = r;
      }
    }
    return out;
  }
  forms = new WeakMap;
  formIds = new Map;
  nameIds = new Map;
  nameText = [];
  nameKind = [];
  formSeen = [];
  formAt = [];
  nameSeen = [];
  termSeen = [];
  gen = 0;
  form(lin) {
    let f = this.forms.get(lin);
    if (f)
      return f;
    const text = canon(lin);
    let id = this.formIds.get(text);
    if (id === undefined) {
      id = this.formIds.size;
      this.formIds.set(text, id);
      this.formSeen.push(0);
      this.formAt.push(0);
    }
    const names = namesOf(lin).map((n) => {
      let j = this.nameIds.get(n);
      if (j === undefined) {
        j = this.nameText.length;
        this.nameIds.set(n, j);
        this.nameText.push(n);
        this.nameKind.push(n.startsWith("\u27E6") ? 1 : isCell(n) ? 2 : 0);
        this.nameSeen.push(0);
        this.termSeen.push(0);
      }
      return j;
    });
    this.forms.set(lin, f = { id, names });
    return f;
  }
  readsColumn(lin) {
    for (const j of this.form(lin).names)
      if (this.nameKind[j] === 1)
        return true;
    return false;
  }
  trailRows = [];
  trailStamps = [];
  pairs = new Map;
  leafRows(src) {
    const rows = [];
    for (let i = 0;i < this.trail.size(); i++) {
      if (this.trail.quiet?.(i))
        continue;
      const s = this.trail.stamp(i);
      let r = this.trailStamps[i] === s ? this.trailRows[i] : undefined;
      if (!r) {
        const a = this.trail.lin(i), own = this.leafAtomRows.get(a.lin) ?? this.leafAtomRows.set(a.lin, []).get(a.lin), k = a.holds ? 1 : 0;
        r = own[k] ?? (own[k] = { lin: atomOf(a.lin, a.holds).lin, w: new Set([a.name]), label: "" });
        this.trailRows[i] = r;
        this.trailStamps[i] = s;
      }
      rows.push(r);
      src?.push(-1);
    }
    for (let i = 0;i < this.goal.hyps.length; i++)
      for (const r of this.facts(i).rows) {
        rows.push(r);
        src?.push(i);
      }
    const g = ++this.gen, names = [], seen = this.nameSeen, kind = this.nameKind;
    for (const r of rows)
      for (const j of this.form(r.lin).names)
        if (seen[j] !== g) {
          seen[j] = g;
          names.push(j);
        }
    const cells = names.filter((j) => kind[j] === 2).map((j) => cellOf(this.nameText[j]));
    for (const [i, p] of cells.entries())
      for (const q of cells.slice(i + 1)) {
        if (p.map !== q.map)
          continue;
        const f = this.pair(p, q), w = this.equal(f);
        if (w) {
          rows.push({ lin: f.pq, w, label: "" }, { lin: f.qp, w, label: "" });
          src?.push([p.name, q.name], [p.name, q.name]);
        }
      }
    const done = this.termSeen, todo = names.filter((j) => kind[j] === 1);
    while (todo.length) {
      const j = todo.pop();
      if (done[j] === g)
        continue;
      done[j] = g;
      for (const r of this.termRows(this.nameText[j])) {
        rows.push(r);
        src?.push(-1);
        for (const n of this.form(r.lin).names) {
          if (seen[n] !== g) {
            seen[n] = g;
            names.push(n);
          }
          if (kind[n] === 1 && done[n] !== g)
            todo.push(n);
        }
      }
    }
    for (const j of names) {
      const name = this.nameText[j];
      let r = this.natRows.get(name);
      if (!r)
        this.natRows.set(name, r = { lin: { [name]: -1 }, w: none, label: "" });
      rows.push(r);
      src?.push(-1);
    }
    return rows;
  }
  live = [];
  entered = [];
  left = [];
  syncing = false;
  dirty = new Set;
  slot = [];
  copies = [];
  c12 = [];
  cT = [];
  inTrail = [];
  inParts = new Map;
  hypsIn = 0;
  src = new WeakMap;
  hypsOf(rows) {
    const out = new Set;
    for (const r of rows) {
      const i = this.src.get(r);
      if (i !== undefined)
        out.add(i);
    }
    return [...out];
  }
  srcOf(r) {
    return this.src.get(r);
  }
  inSeg = new Map;
  cached = new Map;
  termKeys = [];
  pairKeys = new Map;
  liveCells = new Map;
  inNat = [];
  syncN = 0;
  markN = [];
  wasLive = [];
  changed = [];
  slotOf(id) {
    return this.slot[id];
  }
  hasCells() {
    return this.cellsOn > 0;
  }
  cellsOn = 0;
  cells = new Map;
  cellsChanged = 0;
  sync(from = 0) {
    this.syncing = true;
    this.syncN++;
    this.changed = [];
    const n = this.trail.size();
    for (let i = from;i < Math.max(n, this.inTrail.length); i++) {
      const r = i < n && !this.trail.quiet?.(i) ? this.trailRow(i) : undefined, had = this.inTrail[i];
      if (r === had)
        continue;
      if (r)
        this.addCopy(r, 1);
      if (had)
        this.removeCopy(had, 1);
      this.inTrail[i] = r;
    }
    this.inTrail.length = n;
    for (;this.hypsIn < this.goal.hyps.length; this.hypsIn++)
      for (const p of this.parts(this.hypsIn))
        this.dirty.add(p.key);
    for (const key of [...this.dirty]) {
      if (key.kind === 0)
        continue;
      if (key.kind === 3) {
        const fv = this.part(this.partsOf[key.i][key.j]), had = this.inParts.get(key);
        if (fv === had)
          continue;
        for (const r of fv.rows) {
          this.src.set(r, key.i);
          this.addCopy(r, 1);
        }
        if (had)
          for (const r of had.rows)
            this.removeCopy(r, 1);
        this.inParts.set(key, fv);
      } else if (this.inSeg.has(key)) {
        const had = this.inSeg.get(key), now = this.segRows(key);
        if (now === had)
          continue;
        this.inSeg.set(key, now);
        for (const r of now)
          this.addCopy(r, key.kind === 1 ? 2 : 0, key.kind === 1 ? key.i : -1);
        for (const r of had)
          this.removeCopy(r, key.kind === 1 ? 2 : 0, key.kind === 1 ? key.i : -1);
      }
    }
    this.dirty.clear();
    this.entered = [];
    this.left = [];
    for (const id of this.changed) {
      const now = this.copies[id].length > 0;
      if (now && !this.wasLive[id])
        this.entered.push(id);
      else if (!now && this.wasLive[id])
        this.left.push(id);
    }
  }
  trailRow(i) {
    const s = this.trail.stamp(i);
    let r = this.trailStamps[i] === s ? this.trailRows[i] : undefined;
    if (!r) {
      const a = this.trail.lin(i), key = `${a.name}=${a.holds}`;
      r = this.atomRows.get(key);
      if (!r)
        this.atomRows.set(key, r = { lin: atomOf(a.lin, a.holds).lin, w: new Set([a.name]), label: "" });
      this.trailRows[i] = r;
      this.trailStamps[i] = s;
    }
    return r;
  }
  segRows(key) {
    const had = this.cached.get(key);
    if (had && this.clean.has(key))
      return had;
    const rows = this.within(key, () => {
      if (key.kind === 1)
        return this.termRows(this.nameText[key.i]);
      const p = cellOf(this.nameText[key.i]), q = cellOf(this.nameText[key.j]), f = this.pair(p, q), w = this.equal(f);
      if (!w)
        return [];
      return [{ lin: f.pq, w, label: "" }, { lin: f.qp, w, label: "" }];
    });
    this.cached.set(key, rows);
    this.clean.add(key);
    return rows;
  }
  pair(p, q) {
    const key = `${p.name}\x00${q.name}`;
    let f = this.pairs.get(key);
    if (!f) {
      if (this.pairs.size > 200000)
        this.pairs.clear();
      const ds = p.key && q.key ? [sub(p.key, q.key)] : p.keys && q.keys && p.keys.length === q.keys.length ? p.keys.map((x, i) => sub(x, q.keys[i])) : undefined;
      this.pairs.set(key, f = { parts: ds?.map((d) => [d, scale(d, -1)]), pq: sub(v(p.name), v(q.name)), qp: sub(v(q.name), v(p.name)) });
    }
    return f;
  }
  equal(f) {
    if (!f.parts)
      return;
    let w = none;
    for (const [d, neg] of f.parts) {
      const x = this.dec(d), y = this.dec(neg);
      if (x.t !== true || y.t !== true)
        return;
      w = join(w, join(x.w, y.w));
    }
    return w;
  }
  mark(id, live) {
    if (this.markN[id] === this.syncN)
      return;
    this.markN[id] = this.syncN;
    this.wasLive[id] = live;
    this.changed.push(id);
  }
  addCopy(r, kind, self = -1) {
    const f = this.form(r.lin), id = f.id, cs = this.copies[id] ??= [];
    costs.copies++;
    if (!cs.length) {
      this.mark(id, false);
      this.slot[id] = this.live.length;
      this.live.push(r);
    } else {
      const at = this.slot[id];
      if (r.w.size < this.live[at].w.size)
        this.live[at] = r;
    }
    cs.push(r);
    if (kind) {
      for (const j of f.names)
        if (j !== self)
          this.countUp(j, kind);
    }
  }
  removeCopy(r, kind, self = -1) {
    const f = this.form(r.lin), id = f.id, cs = this.copies[id];
    costs.copies++;
    cs.splice(cs.indexOf(r), 1);
    const at = this.slot[id];
    if (!cs.length) {
      this.mark(id, true);
      const last = this.live.pop();
      if (at < this.live.length) {
        this.live[at] = last;
        this.slot[this.form(last.lin).id] = at;
      }
      this.slot[id] = -1;
    } else if (this.live[at] === r) {
      let best = cs[0];
      for (const c of cs)
        if (c.w.size < best.w.size)
          best = c;
      this.live[at] = best;
    }
    if (kind) {
      for (const j of f.names)
        if (j !== self)
          this.countDown(j, kind);
    }
  }
  countUp(j, kind) {
    const before = (this.c12[j] ?? 0) + (this.cT[j] ?? 0);
    if (kind === 1)
      this.c12[j] = (this.c12[j] ?? 0) + 1;
    else
      this.cT[j] = (this.cT[j] ?? 0) + 1;
    if (before === 0)
      this.nameOn(j);
    if (kind === 1 && this.c12[j] === 1 && this.nameKind[j] === 2)
      this.cellOn(j);
  }
  countDown(j, kind) {
    if (kind === 1)
      this.c12[j]--;
    else
      this.cT[j]--;
    if (kind === 1 && this.c12[j] === 0 && this.nameKind[j] === 2)
      this.cellOff(j);
    if ((this.c12[j] ?? 0) + (this.cT[j] ?? 0) === 0)
      this.nameOff(j);
  }
  nameOn(j) {
    const name = this.nameText[j];
    let r = this.natRows.get(name);
    if (!r)
      this.natRows.set(name, r = { lin: { [name]: -1 }, w: none, label: "" });
    this.inNat[j] = r;
    this.addCopy(r, 0);
    if (this.nameKind[j] === 2) {
      this.cellsOn++;
      this.cellsChanged++;
      const c = cellOf(name);
      let same = this.cells.get(c.map);
      if (!same)
        this.cells.set(c.map, same = new Set);
      same.add(name);
    }
    if (this.nameKind[j] === 1)
      this.segOn(this.termKeys[j] ??= new Seg(1, j));
  }
  nameOff(j) {
    this.removeCopy(this.inNat[j], 0);
    this.inNat[j] = undefined;
    if (this.nameKind[j] === 2) {
      this.cellsOn--;
      this.cellsChanged++;
      this.cells.get(cellOf(this.nameText[j]).map).delete(this.nameText[j]);
    }
    if (this.nameKind[j] === 1)
      this.segOff(this.termKeys[j]);
  }
  segOn(key) {
    const rows = this.segRows(key);
    this.inSeg.set(key, rows);
    for (const r of rows)
      this.addCopy(r, key.kind === 1 ? 2 : 0, key.kind === 1 ? key.i : -1);
  }
  segOff(key) {
    const rows = this.inSeg.get(key);
    this.inSeg.delete(key);
    for (const r of rows)
      this.removeCopy(r, key.kind === 1 ? 2 : 0, key.kind === 1 ? key.i : -1);
  }
  pairKey(a, b) {
    const [p, q] = a < b ? [a, b] : [b, a];
    let m = this.pairKeys.get(p);
    if (!m)
      this.pairKeys.set(p, m = new Map);
    let key = m.get(q);
    if (!key)
      m.set(q, key = new Seg(2, p, q));
    return key;
  }
  cellOn(j) {
    const c = cellOf(this.nameText[j]);
    let same = this.liveCells.get(c.map);
    if (!same)
      this.liveCells.set(c.map, same = new Set);
    for (const q of same)
      this.segOn(this.pairKey(j, q));
    same.add(j);
  }
  cellOff(j) {
    const same = this.liveCells.get(cellOf(this.nameText[j]).map);
    same.delete(j);
    for (const q of same)
      this.segOff(this.pairKey(j, q));
  }
  openList(i) {
    const key = this.openKeys[i] ??= {}, had = this.os[i];
    if (had && (keepClean && this.clean.has(key) || had.node === this.node))
      return had.lins;
    const lins = this.within(key, () => {
      const mine = [];
      if (!this.factsFin(i))
        this.openH(this.goal.hyps[i], mine, true);
      return mine;
    });
    this.os[i] = { lins, node: this.node };
    this.clean.add(key);
    return lins;
  }
  openE(e, out) {
    switch (e.op) {
      case "var":
      case "const":
        return;
      case "mul":
        return this.openE(e.a, out);
      case "prod":
        return this.openE(e.a, out), this.openE(e.b, out);
      case "get":
        return this.openE(e.key, out);
      case "tup":
        return this.openE(e.a, out), this.openE(e.b, out);
      case "proj":
        return this.openE(e.a.op === "tup" ? e.k === 0 ? e.a.a : e.a.b : e.a, out);
      case "if": {
        const t = this.truth(e.c);
        if (t.t === undefined)
          this.openC(e.c, out);
        else
          this.openE(t.t ? e.then : e.else, out);
        return;
      }
      case "add":
      case "sub":
      case "min":
      case "max": {
        if (this.linear(e).fin)
          return;
        this.openE(e.a, out), this.openE(e.b, out);
        const a = this.linear(e.a).lin, b = this.linear(e.b).lin;
        if (a && b && !this.decided(e))
          out.push(same2(1, e, a, b, 0, () => e.op === "sub" ? sub(b, a) : sub(a, b)));
        return;
      }
    }
  }
  openC(c, out) {
    if (this.truth(c).t !== undefined)
      return;
    if (c.op === "flag" || c.op === "all")
      return;
    if (c.op === "not")
      return this.openC(c.x, out);
    if (c.op === "and" || c.op === "or")
      return c.xs.forEach((y) => this.openC(y, out));
    const and = tupleAnd(c);
    if (and)
      return this.openC(and, out);
    const a = this.linear(c.a).lin, b = this.linear(c.b).lin;
    const own = a && b ? same2(7, c, a, b, 0, () => {
      const d = sub(a, b);
      return c.op === "<=" ? [d] : c.op === "<" ? [add(d, k(1))] : [d, scale(d, -1)];
    }) : [];
    this.openE(c.a, out), this.openE(c.b, out);
    for (const x of own)
      out.push(x);
  }
  openH(c, out, positive) {
    if (c.op === "not")
      return this.openH(c.x, out, !positive);
    if (c.op === "and" && positive || c.op === "or" && !positive)
      return c.xs.forEach((y) => this.openH(y, out, positive));
    if (c.op === "and" || c.op === "or") {
      if (this.truth(c).t !== undefined)
        return;
      const open = c.xs.filter((y) => this.truth(y).t !== !positive);
      if (open.length === 1)
        this.openH(open[0], out, positive);
      else
        this.openC(c, out);
      return;
    }
    if (c.op === "flag" || c.op === "all")
      return;
    const and = tupleAnd(c);
    if (and)
      return this.openH(and, out, positive);
    const before = out.length;
    this.openE(c.a, out), this.openE(c.b, out);
    if (out.length === before && !positive && c.op === "=" && this.truth(c).t === undefined)
      this.openC(c, out);
  }
}
var nameMemo = new WeakMap;
var namesOf = (lin) => {
  let out = nameMemo.get(lin);
  if (!out)
    nameMemo.set(lin, out = Object.keys(lin).filter((key) => key !== "1"));
  return out;
};
var cellMemo2 = new Map;
var cellOf = (name) => {
  let out = cellMemo2.get(name);
  if (!out) {
    if (cellMemo2.size > 1e5)
      cellMemo2.clear();
    cellMemo2.set(name, out = { name, ...cellParts(name) });
  }
  return out;
};
var notLit = (l) => ({ lin: l.lin, holds: !l.holds });
var litIds = new WeakMap;
var litVar = (l) => {
  let x = litIds.get(l.lin);
  if (!x) {
    const a = canon(l.lin), f = canonFlip(l.lin);
    litIds.set(l.lin, x = f < a ? [f, false] : [a, true]);
  }
  return [x[0], x[1] === l.holds];
};
var isConst = (lin) => {
  for (const key in lin)
    if (key !== "1" && lin[key] !== 0)
      return false;
  return true;
};

class Unread extends Error {
}

class Clausal {
  sideOf;
  maxCases;
  made = [];
  n = 0;
  hyp = 0;
  gm = new Map;
  cm = new Map;
  constructor(sideOf = () => 0, maxCases = 16) {
    this.sideOf = sideOf;
    this.maxCases = maxCases;
  }
  add(c, hyp) {
    this.hyp = hyp;
    try {
      this.top(c, true);
      return true;
    } catch (e) {
      if (e instanceof Unread)
        return false;
      throw e;
    }
  }
  memo(m) {
    const s = this.sideOf(this.hyp);
    let out = m.get(s);
    if (!out)
      m.set(s, out = new Map);
    return out;
  }
  fresh(kind) {
    return `${kind}${this.hyp}_${this.n++}`;
  }
  clause(lits, own = false, last = false) {
    const seen = new Map, out = [];
    for (const l of lits) {
      const [x, val] = litVar(l), had = seen.get(x);
      if (had === undefined) {
        seen.set(x, val);
        out.push(l);
      } else if (had !== val)
        return;
    }
    this.made.push({ lits: out, hyp: this.hyp, own, out: last && out.at(-1) === lits.at(-1) });
  }
  top(c, positive) {
    switch (c.op) {
      case "not":
        return this.top(c.x, !positive);
      case "and":
      case "or": {
        if (c.op === "and" === positive) {
          for (const y of c.xs)
            this.top(y, positive);
          return;
        }
        const lits = [];
        for (const y of c.xs) {
          const l = this.lit(y, positive ? 1 : 2), m = typeof l === "boolean" ? l === positive : positive ? l : notLit(l);
          if (m === true)
            return;
          if (m !== false)
            lits.push(m);
        }
        return this.clause(lits);
      }
      case "<":
      case "<=":
      case "=":
        for (const cs of this.cmpCases(c)) {
          const not = cs.g.map(notLit);
          if (positive) {
            if (cs.atoms === false)
              this.clause(not);
            else if (cs.atoms !== true)
              for (const a of cs.atoms)
                this.clause([...not, a], false, true);
          } else if (cs.atoms === true)
            this.clause(not);
          else if (cs.atoms !== false)
            this.clause([...not, ...cs.atoms.map(notLit)]);
        }
        return;
      case "flag":
      case "all":
        throw new Unread;
    }
  }
  lit(c, pol) {
    switch (c.op) {
      case "not": {
        const x = this.lit(c.x, (pol & 1) << 1 | (pol & 2) >> 1);
        return typeof x === "boolean" ? !x : notLit(x);
      }
      case "and":
      case "or":
      case "<":
      case "<=":
      case "=":
        break;
      case "flag":
      case "all":
        throw new Unread;
    }
    const m = this.memo(this.gm), had = m.get(c);
    if (had && (typeof had.l === "boolean" || !(pol & ~had.done)))
      return had.l;
    const need = had ? pol & ~had.done : pol;
    let g = had?.l, out;
    const gate = () => g ??= { lin: v(this.fresh("\u03C4")), holds: true };
    if (c.op === "and" || c.op === "or") {
      const dominant = c.op === "or", kids = [];
      let fold;
      for (const y of c.xs) {
        const l = this.lit(y, need);
        if (typeof l === "boolean") {
          if (l === dominant) {
            fold = dominant;
            break;
          }
        } else
          kids.push(l);
      }
      if (fold !== undefined || !kids.length)
        out = fold ?? !dominant;
      else if (kids.length === 1)
        out = kids[0];
      else {
        const t = gate();
        if (need & 1) {
          if (dominant)
            this.clause([notLit(t), ...kids], true);
          else
            for (const x of kids)
              this.clause([notLit(t), x], true);
        }
        if (need & 2) {
          if (dominant)
            for (const x of kids)
              this.clause([t, notLit(x)], true);
          else
            this.clause([t, ...kids.map(notLit)], true);
        }
        out = t;
      }
    } else {
      const cases = this.cmpCases(c);
      if (cases.length === 1 && !cases[0].g.length && (typeof cases[0].atoms === "boolean" || cases[0].atoms.length === 1))
        out = typeof cases[0].atoms === "boolean" ? cases[0].atoms : cases[0].atoms[0];
      else {
        const t = gate();
        for (const cs of cases) {
          const not = cs.g.map(notLit);
          if (need & 1) {
            if (cs.atoms === false)
              this.clause([notLit(t), ...not], true);
            else if (cs.atoms !== true)
              for (const a of cs.atoms)
                this.clause([notLit(t), ...not, a], true, true);
          }
          if (need & 2) {
            if (cs.atoms === true)
              this.clause([t, ...not], true);
            else if (cs.atoms !== false)
              this.clause([t, ...not, ...cs.atoms.map(notLit)], true);
          }
        }
        out = t;
      }
    }
    m.set(c, { l: out, done: (had?.done ?? 0) | need });
    return out;
  }
  cmpCases(c) {
    return this.cross(this.cases(c.a), this.cases(c.b), sub).map(({ g, lin: d }) => {
      const lins = c.op === "<=" ? [d] : c.op === "<" ? [add(d, k(1))] : [d, scale(d, -1)], atoms = [];
      for (const lin of lins) {
        if (!isConst(lin))
          atoms.push({ lin, holds: true });
        else if ((lin["1"] ?? 0) > 0)
          return { g, atoms: false };
      }
      return { g, atoms: atoms.length ? atoms : true };
    });
  }
  join(g, more) {
    if (!more.length)
      return g;
    if (!g.length)
      return more;
    const out = [...g], ids = new Map(g.map((l) => litVar(l)));
    for (const l of more) {
      const [x, val] = litVar(l), had = ids.get(x);
      if (had === undefined) {
        ids.set(x, val);
        out.push(l);
      } else if (had !== val)
        return;
    }
    return out;
  }
  cross(xs, ys, f) {
    const out = [];
    for (const x of xs)
      for (const y of ys) {
        const g = this.join(x.g, y.g);
        if (g)
          out.push({ g, lin: f(x.lin, y.lin) });
      }
    return out;
  }
  split(c, l, yes, no) {
    if (typeof l === "boolean")
      return [{ g: c.g, lin: l ? yes : no }];
    const out = [];
    for (const [m, lin] of [[l, yes], [notLit(l), no]]) {
      const g = this.join(c.g, [m]);
      if (g)
        out.push({ g, lin });
    }
    return out;
  }
  cases(e) {
    const m = this.memo(this.cm), had = m.get(e);
    if (had)
      return had;
    let out;
    switch (e.op) {
      case "var":
        if (e.name === "1" || /[*[\],:\u27E6\u27E8\u27E9|]/.test(e.name))
          throw new Unread;
        out = [{ g: [], lin: v(e.name) }];
        break;
      case "const":
        out = [{ g: [], lin: k(e.value) }];
        break;
      case "add":
        out = this.cross(this.cases(e.a), this.cases(e.b), add);
        break;
      case "mul":
        out = this.cases(e.a).map((c) => ({ g: c.g, lin: scale(c.lin, e.k) }));
        break;
      case "sub":
      case "min":
      case "max": {
        out = [];
        for (const x of this.cases(e.a))
          for (const y of this.cases(e.b)) {
            const g = this.join(x.g, y.g);
            if (!g)
              continue;
            const a = x.lin, b = y.lin, d = e.op === "sub" ? sub(b, a) : sub(a, b);
            out.push(...this.split({ g, lin: a }, isConst(d) ? (d["1"] ?? 0) <= 0 : { lin: d, holds: true }, e.op === "sub" ? sub(a, b) : e.op === "min" ? a : b, e.op === "sub" ? {} : e.op === "min" ? b : a));
          }
        break;
      }
      case "get": {
        const f = /^(div|mod)\$(\d+)$/.exec(e.map);
        if (!f)
          throw new Unread;
        const c = Number(f[2]);
        out = [];
        for (const x of this.cases(e.key)) {
          const q = v(this.fresh("\u03F0")), cq = scale(q, c), not = x.g.map(notLit);
          for (const lin of [sub(cq, x.lin), add(sub(x.lin, cq), k(1 - c))])
            this.clause([...not, { lin, holds: true }]);
          out.push({ g: x.g, lin: f[1] === "div" ? q : sub(x.lin, cq) });
        }
        break;
      }
      case "if": {
        const l = this.lit(e.c, 3);
        if (typeof l === "boolean") {
          out = this.cases(l ? e.then : e.else);
          break;
        }
        out = [];
        for (const [m2, x] of [[l, e.then], [notLit(l), e.else]])
          for (const c of this.cases(x)) {
            const g = this.join(c.g, [m2]);
            if (g)
              out.push({ g, lin: c.lin });
          }
        break;
      }
      case "prod":
      case "tup":
      case "proj":
        throw new Unread;
    }
    if (out.length > this.maxCases) {
      const col = v(this.fresh("\u03F0"));
      for (const c of out) {
        const not = c.g.map(notLit);
        for (const lin of [sub(col, c.lin), sub(c.lin, col)])
          if (!isConst(lin))
            this.clause([...not, { lin, holds: true }], false, true);
          else if ((lin["1"] ?? 0) > 0)
            this.clause(not);
      }
      out = [{ g: [], lin: col }];
    }
    m.set(e, out);
    return out;
  }
}

// kernel/simplex.ts
var eps = 0.000000001;
var tol = (b) => 0.0000001 * Math.max(1, Math.abs(b));
var formMemo = new WeakMap;
function formOf(lin) {
  let out = formMemo.get(lin);
  if (out !== undefined)
    return out;
  const keys = Object.keys(lin).filter((key) => key !== "1" && lin[key] !== 0).sort();
  if (!keys.length)
    out = null;
  else if (keys.length === 1)
    out = { single: keys[0], c: lin[keys[0]] };
  else {
    let g = 0;
    for (const key of keys)
      g = gcd(g, lin[key]);
    if (lin[keys[0]] < 0)
      g = -g;
    const terms = keys.map((key) => [key, lin[key] / g]);
    out = { slack: `\u03C3(${terms.map(([key, c]) => `${key}:${c}`).join(",")})`, g, terms };
  }
  formMemo.set(lin, out);
  return out;
}

class Simplex {
  integral;
  boundsOnly;
  constructor(integral = true, boundsOnly = false) {
    this.integral = integral;
    this.boundsOnly = boundsOnly;
  }
  index = new Map;
  lo = [];
  hi = [];
  loWhy = [];
  hiWhy = [];
  val = [];
  rowOf = [];
  rows = [];
  colOf = [];
  pivots = 0;
  nnzN = 0;
  at = new WeakMap;
  place(lin) {
    let at = this.at.get(lin);
    if (at === undefined) {
      const f = formOf(lin);
      at = f === null ? null : ("single" in f) ? { j: this.varOf(f.single), c: f.c } : { j: this.slackOf(f), c: f.g };
      this.at.set(lin, at);
    }
    return at;
  }
  varOf(name) {
    let j = this.index.get(name);
    if (j !== undefined)
      return j;
    j = this.val.length;
    this.index.set(name, j);
    this.lo.push(-Infinity);
    this.hi.push(Infinity);
    this.loWhy.push(-1);
    this.hiWhy.push(-1);
    this.val.push(0);
    this.rowOf.push(-1);
    this.colOf.push(new Set);
    return j;
  }
  slackOf(f) {
    const had = this.index.get(f.slack);
    if (had !== undefined)
      return had;
    const coef = new Map;
    const addTo = (j, c) => {
      const x = (coef.get(j) ?? 0) + c;
      if (Math.abs(x) < eps)
        coef.delete(j);
      else
        coef.set(j, x);
    };
    for (const [name, c] of f.terms) {
      const j = this.varOf(name), r = this.rowOf[j];
      if (r < 0)
        addTo(j, c);
      else
        for (const [k, a] of this.rows[r].coef)
          addTo(k, c * a);
    }
    const s = this.varOf(f.slack), r = this.rows.length;
    this.rows.push({ basic: s, coef });
    this.nnzN += coef.size;
    this.rowOf[s] = r;
    for (const j of coef.keys())
      this.colOf[j].add(r);
    let value = 0;
    for (const [j, c] of coef)
      value += c * this.val[j];
    this.val[s] = value;
    return s;
  }
  load(rows) {
    for (let j = 0;j < this.val.length; j++) {
      this.lo[j] = -Infinity;
      this.hi[j] = Infinity;
      this.loWhy[j] = -1;
      this.hiWhy[j] = -1;
    }
    const tighten = (j, upper, b, why) => {
      if (upper) {
        if (b < this.hi[j]) {
          this.hi[j] = b;
          this.hiWhy[j] = why;
        }
      } else if (b > this.lo[j]) {
        this.lo[j] = b;
        this.loWhy[j] = why;
      }
    };
    const integral = this.integral;
    const bound = (c, j, k, i, strict) => {
      const b = c > 0 ? -k / c : k / -c;
      if (integral) {
        if (c > 0)
          tighten(j, true, Math.floor(b + eps), i);
        else
          tighten(j, false, Math.ceil(b - eps), i);
        return;
      }
      const d = strict ? 0.0000001 * Math.max(1, Math.abs(b)) : 0;
      if (c > 0)
        tighten(j, true, b - d, i);
      else
        tighten(j, false, b + d, i);
    };
    for (let i = 0;i < rows.length; i++) {
      const r = rows[i], k = r.lin["1"] ?? 0;
      const at = this.place(r.lin);
      if (at === null) {
        if (k > 0 || !integral && r.strict && k >= 0)
          return { kind: "conflict", rows: [i] };
        continue;
      }
      bound(at.c, at.j, k, i, !integral && r.strict);
    }
    for (let j = 0;j < this.val.length; j++)
      if (this.lo[j] > this.hi[j] + eps)
        return { kind: "conflict", rows: [this.loWhy[j], this.hiWhy[j]].filter((x) => x >= 0) };
    for (let j = 0;j < this.val.length; j++) {
      if (this.rowOf[j] >= 0)
        continue;
      const x = this.val[j];
      this.val[j] = x < this.lo[j] ? this.lo[j] : x > this.hi[j] ? this.hi[j] : x;
    }
    for (const row of this.rows) {
      let value = 0;
      for (const [j, c] of row.coef)
        value += c * this.val[j];
      this.val[row.basic] = value;
    }
    return { kind: "sat" };
  }
  ins = new Map;
  inLo = [];
  inHi = [];
  falseIn = new Set;
  crossing = new Set;
  moved = [];
  movedAt = [];
  settles = 0;
  assert(id, lin, strict) {
    const at = this.place(lin), k = lin["1"] ?? 0;
    if (at === null) {
      this.ins.set(id, null);
      if (k > 0 || !this.integral && strict && k >= 0)
        this.falseIn.add(id);
      return;
    }
    const { j, c } = at, b0 = c > 0 ? -k / c : k / -c, upper = c > 0, d = !this.integral && strict ? 0.0000001 * Math.max(1, Math.abs(b0)) : 0;
    const b = this.integral ? upper ? Math.floor(b0 + eps) : Math.ceil(b0 - eps) : upper ? b0 - d : b0 + d;
    this.ins.set(id, { j, upper, b });
    ((upper ? this.inHi : this.inLo)[j] ??= []).push([b, id]);
    if (upper ? b < this.hi[j] : b > this.lo[j]) {
      if (upper) {
        this.hi[j] = b;
        this.hiWhy[j] = id;
      } else {
        this.lo[j] = b;
        this.loWhy[j] = id;
      }
      this.move(j);
    }
  }
  retract(id) {
    const a = this.ins.get(id);
    this.ins.delete(id);
    if (a === undefined)
      return;
    if (a === null) {
      this.falseIn.delete(id);
      return;
    }
    const { j, upper } = a, list = (upper ? this.inHi : this.inLo)[j];
    list.splice(list.findIndex((x) => x[1] === id), 1);
    if ((upper ? this.hiWhy : this.loWhy)[j] !== id)
      return;
    let b = upper ? Infinity : -Infinity, why = -1;
    for (const [x, i] of list)
      if (upper ? x < b : x > b) {
        b = x;
        why = i;
      }
    if (upper) {
      this.hi[j] = b;
      this.hiWhy[j] = why;
    } else {
      this.lo[j] = b;
      this.loWhy[j] = why;
    }
    this.move(j);
  }
  changes = 0;
  move(j) {
    this.vers[j] = (this.vers[j] ?? 0) + 1;
    this.changes++;
    if (!this.boundsOnly && this.movedAt[j] !== this.settles + 1) {
      this.movedAt[j] = this.settles + 1;
      this.moved.push(j);
    }
  }
  vers = [];
  version(j) {
    return this.vers[j] ?? 0;
  }
  value(j) {
    return this.val[j];
  }
  settle() {
    for (const id of this.falseIn)
      return { kind: "conflict", rows: [id] };
    for (const j of this.moved) {
      if (this.lo[j] > this.hi[j] + eps)
        this.crossing.add(j);
      else
        this.crossing.delete(j);
    }
    if (this.crossing.size) {
      let j = Infinity;
      for (const x of this.crossing)
        if (x < j)
          j = x;
      return { kind: "conflict", rows: [this.loWhy[j], this.hiWhy[j]].filter((x) => x >= 0) };
    }
    for (const j of this.moved) {
      if (this.rowOf[j] >= 0)
        continue;
      const x = this.val[j], to = x < this.lo[j] ? this.lo[j] : x > this.hi[j] ? this.hi[j] : x;
      if (to !== x)
        this.shift(j, to - x);
    }
    this.moved = [];
    if (++this.settles % 16 === 0)
      for (const row of this.rows) {
        let value = 0;
        for (const [j, c] of row.coef)
          value += c * this.val[j];
        this.val[row.basic] = value;
      }
    return { kind: "sat" };
  }
  indexOf(name) {
    return this.index.get(name);
  }
  low(j) {
    return this.lo[j];
  }
  high(j) {
    return this.hi[j];
  }
  lowWhy(j) {
    return this.loWhy[j];
  }
  highWhy(j) {
    return this.hiWhy[j];
  }
  shift(j, d) {
    this.val[j] += d;
    for (const r of this.colOf[j]) {
      const row = this.rows[r];
      this.val[row.basic] += row.coef.get(j) * d;
    }
  }
  greedy = 0;
  check(maxPivots = 5000) {
    if (this.greedy)
      return this.checkGreedy(maxPivots);
    for (let n = 0;n < maxPivots; n++) {
      let b = -1;
      for (const row of this.rows) {
        const j = row.basic, x = this.val[j];
        if ((x < this.lo[j] - tol(this.lo[j]) || x > this.hi[j] + tol(this.hi[j])) && (b < 0 || j < b))
          b = j;
      }
      if (b < 0)
        return { kind: "sat" };
      const row = this.rows[this.rowOf[b]], below = this.val[b] < this.lo[b];
      let e = -1;
      for (const [j, a] of row.coef) {
        if (e >= 0 && j > e)
          continue;
        const up = below === a > 0;
        if (up ? this.val[j] < this.hi[j] - eps : this.val[j] > this.lo[j] + eps)
          e = j;
      }
      if (e < 0)
        return this.conflict(b, row, below);
      const target = below ? this.lo[b] : this.hi[b];
      this.pivot(b, e, target);
      this.pivots++;
    }
    return { kind: "unknown" };
  }
  checkGreedy(maxPivots) {
    for (let n = 0;n < maxPivots; n++) {
      const g = n < this.greedy;
      let b = -1, worst = 0;
      for (const row of this.rows) {
        const j = row.basic, x = this.val[j], lo = this.lo[j], hi = this.hi[j];
        if (x < lo - tol(lo) || x > hi + tol(hi)) {
          if (g) {
            const d = x < lo ? lo - x : x - hi;
            if (d > worst) {
              worst = d;
              b = j;
            }
          } else if (b < 0 || j < b)
            b = j;
        }
      }
      if (b < 0)
        return { kind: "sat" };
      const row = this.rows[this.rowOf[b]], below = this.val[b] < this.lo[b];
      let e = -1;
      for (const [j, a] of row.coef) {
        if (!g && e >= 0 && j > e)
          continue;
        const up = below === a > 0;
        if (up ? this.val[j] < this.hi[j] - eps : this.val[j] > this.lo[j] + eps) {
          if (!g || e < 0 || this.colOf[j].size < this.colOf[e].size || this.colOf[j].size === this.colOf[e].size && j < e)
            e = j;
        }
      }
      if (e < 0)
        return this.conflict(b, row, below);
      this.pivot(b, e, below ? this.lo[b] : this.hi[b]);
      this.pivots++;
    }
    return { kind: "unknown" };
  }
  conflict(b, row, below) {
    const why = [below ? this.loWhy[b] : this.hiWhy[b]];
    for (const [j, a] of row.coef)
      why.push(below === a > 0 ? this.hiWhy[j] : this.loWhy[j]);
    return { kind: "conflict", rows: [...new Set(why)].filter((x) => x >= 0) };
  }
  pivot(b, e, target) {
    const r = this.rowOf[b], row = this.rows[r], a = row.coef.get(e);
    const theta = (target - this.val[b]) / a;
    this.shift(e, theta);
    const ecoef = new Map;
    for (const [j, c] of row.coef)
      if (j !== e)
        ecoef.set(j, -c / a);
    ecoef.set(b, 1 / a);
    for (const j of row.coef.keys())
      this.colOf[j].delete(r);
    this.nnzN += ecoef.size - row.coef.size;
    row.basic = e;
    row.coef = ecoef;
    this.rowOf[e] = r;
    this.rowOf[b] = -1;
    for (const j of ecoef.keys())
      this.colOf[j].add(r);
    costs.pivotRows += this.colOf[e].size;
    for (const q of [...this.colOf[e]]) {
      if (q === r)
        continue;
      const other = this.rows[q], c = other.coef.get(e), before = other.coef.size;
      other.coef.delete(e);
      this.colOf[e].delete(q);
      for (const [j, d] of ecoef) {
        const x = (other.coef.get(j) ?? 0) + c * d;
        if (Math.abs(x) < eps) {
          if (other.coef.delete(j))
            this.colOf[j].delete(q);
        } else {
          if (!other.coef.has(j))
            this.colOf[j].add(q);
          other.coef.set(j, x);
        }
      }
      this.nnzN += other.coef.size - before;
    }
    this.colOf[e].delete(r);
    for (const j of ecoef.keys())
      this.colOf[j].add(r);
  }
  holds(lin) {
    let x = lin["1"] ?? 0;
    for (const key in lin) {
      if (key === "1")
        continue;
      const j = this.index.get(key);
      if (j === undefined)
        return;
      x += lin[key] * this.val[j];
    }
    return x <= tol(x);
  }
  get size() {
    return this.rows.length;
  }
  get nnz() {
    return this.nnzN;
  }
  get vars() {
    return this.val.length;
  }
}

// kernel/cdcl.ts
function localize(rows, steps) {
  const inputs = [], at = new Map, from = [];
  const out = steps.map((st) => {
    if (st.kind !== "input")
      return st;
    let j = at.get(st.index);
    if (j === undefined) {
      j = inputs.length;
      at.set(st.index, j);
      inputs.push(rows[st.index].lin);
      from.push(st.index);
    }
    return { ...st, index: j };
  });
  return { inputs, steps: out, from };
}
var keyMemo = new WeakMap;
var keyOf = (lin) => {
  let key = keyMemo.get(lin);
  if (key === undefined) {
    const a = canon(lin), b = canonFlip(lin);
    keyMemo.set(lin, key = b < a ? b : a);
  }
  return key;
};
var pointLeaf = env.GDP_CDCL_POINT !== "0";
var lpFill = Number(env.GDP_CDCL_FILL ?? 8);
var lpGrow = Number(env.GDP_CDCL_GROW ?? 4);
var lpBase = Number(env.GDP_CDCL_BASE ?? 500);
var lpGreedy = Number(env.GDP_CDCL_GREEDY ?? 200);
var useLp = env.GDP_CDCL_LP !== "0";
var verify = env.GDP_CDCL_VERIFY === "1";
var cdclStats = { on: false, runs: 0, proven: 0, conflicts: 0, decisions: 0, setupMs: 0, propagationMs: 0, firstDecisionMs: 0, firstDecisions: 0, solveMs: 0, rowsMs: 0, coreMs: 0, unfoldMs: 0, leaves: 0, resolved: 0, coreSize: 0, pathSize: 0, lpMisses: 0, resolved2: 0, unfoldWhy: "", orderMs: 0, boundMs: 0, openMisses: 0, lpMs: 0, lpUnknown: 0, fmCalls: 0, pivots: 0, lpRebuilds: 0, lpRows: 0, lpNnz: 0, lpVars: 0, lpLoad: 0, nodes: 0, boundRounds: 0, fmLeafMs: 0, fmOpenMs: 0, fastMs: 0, missMs: 0 };
var REFUTED = "refuted, not unfolded";
function growCdcl(goal, root, budget, opts = {}) {
  if (opts.model && !opts.dag && !opts.clausal && !root.size && wideFor(goal)) {
    const out = growWide(goal, budget, (g, until) => growCdcl(g, root, { nodes: 0, until }, opts));
    if (out)
      return out;
  }
  const go = () => cdclSession(goal, root, opts).run(budget, opts.wall);
  return queryHook.on && !queryHook.depth ? logged(opts.model ? "model" : "cdcl", goal, go) : go();
}
function cdclSession(goal, root, opts = {}) {
  let until = Infinity, budget = { nodes: 0 }, wall, assumed = [], listed = false;
  let aq = 0, aqOf = new Map, aqVars = [];
  const st = cdclStats, timing = st.on, setupStarted = timing ? performance.now() : 0;
  let runStarted = 0, sawDecision = false;
  const noteDecision = () => {
    st.decisions++;
    if (timing && !sawDecision) {
      sawDecision = true;
      st.firstDecisions++;
      st.firstDecisionMs += performance.now() - runStarted;
    }
  };
  const t = (f, add) => {
    if (!timing)
      return f();
    const t0 = performance.now();
    try {
      return f();
    } finally {
      add(performance.now() - t0);
    }
  };
  st.runs++;
  const vars = new Map, trail = [], tv = [], levels = [];
  let clausal = !!(opts.clausal && opts.model), enc = clausal ? new Clausal(opts.sideOf) : undefined, fed = 0, dead = -1, unread = false, lowAt = 0;
  if (enc) {
    for (;fed < goal.hyps.length; fed++)
      if (!enc.add(goal.hyps[fed], fed)) {
        clausal = false;
        enc = undefined;
        fed = 0;
        break;
      }
  }
  const heap = [], byId = [], vals = [];
  const rel = [], relStack = [];
  const wl = [], ownBy = [], cls = [], oc = [];
  const byHyp = [], retired = [];
  const holds = (c) => vals[c >> 1] === 2 - (c & 1), opposed = (c) => vals[c >> 1] === 1 + (c & 1);
  const heapUp = (i) => {
    const x = heap[i];
    while (i > 0) {
      const p = i - 1 >> 1, y = heap[p];
      if (y.act >= x.act)
        break;
      heap[i] = y;
      y.hp = i;
      i = p;
    }
    heap[i] = x;
    x.hp = i;
  };
  const heapDown = (i) => {
    const x = heap[i], n = heap.length;
    for (;; ) {
      let c = 2 * i + 1;
      if (c >= n)
        break;
      if (c + 1 < n && heap[c + 1].act > heap[c].act)
        c++;
      if (heap[c].act <= x.act)
        break;
      heap[i] = heap[c];
      heap[i].hp = i;
      i = c;
    }
    heap[i] = x;
    x.hp = i;
  };
  const heapIn = (x) => {
    if (!x.cond || rel[x.id] < 0 || x.hp !== undefined && x.hp >= 0)
      return;
    x.hp = heap.length;
    heap.push(x);
    heapUp(x.hp);
  };
  const heapPop = () => {
    const top = heap[0], end = heap.pop();
    top.hp = -1;
    if (heap.length) {
      heap[0] = end;
      end.hp = 0;
      heapDown(0);
    }
  };
  let sx = useLp ? new Simplex : undefined;
  if (sx && clausal)
    sx.greedy = lpGreedy;
  const nodes = [], clauses = [], occ = new Map;
  const leafHyps = new Map, wantCore = !!(opts.core && opts.model), wantDag = !!(opts.dag && opts.model);
  const hypsOf = (rs) => {
    return reader.hypsOf(rs);
  };
  let inc = 1;
  const ensure = (lin) => {
    const key = keyOf(lin);
    if (!vars.has(key)) {
      const flip = key !== canon(lin), stored = flip ? atomOf(lin, false).lin : lin, terms = Object.entries(stored).filter(([x0]) => x0 !== "1");
      const x = {
        name: key,
        lin: stored,
        terms,
        col: terms.some(([x0]) => x0.startsWith("\u27E6")),
        quiet: undefined,
        id: byId.length,
        hp: undefined,
        cond: undefined,
        val: undefined,
        level: -1,
        reason: undefined,
        at: -1,
        act: 0,
        phase: !flip,
        bj: undefined,
        bjAt: undefined,
        bsig: undefined,
        bver: undefined,
        sj: undefined,
        sx: undefined,
        pair: undefined,
        fs: undefined,
        aq: undefined,
        an: undefined
      };
      byId.push(x);
      vals.push(0);
      rel.push(-1);
      if (opts.model && terms.length === 1 && (opts.quiet?.(terms[0][0]) || clausal && terms[0][0].startsWith("\u03C4")))
        x.quiet = true;
      vars.set(key, x);
      if (clausal)
        heapIn(x);
    }
    return key;
  };
  const recs = new WeakMap;
  const recOf = (lin) => {
    let r = recs.get(lin);
    if (!r)
      recs.set(lin, r = { x: namesOf(lin).length > 0 ? vars.get(ensure(lin)) : undefined, seen: 0 });
    return r;
  };
  let candGen = 0, colsOn = 0, pairsChanged = 0;
  let cellsAt = [-1, -1], cellsOpen = [];
  const pairRecs = new Map;
  let flat = [], flatAt = -1;
  const valOf = (x, same) => x?.val === undefined ? undefined : same ? x.val : !x.val;
  const openCellsLive = () => {
    if (cellsAt[0] === reader.cellsChanged && cellsAt[1] === pairsChanged)
      return cellsOpen;
    if (flatAt !== reader.cellsChanged) {
      flat = [];
      for (const names of reader.cells.values()) {
        const ns = [...names];
        for (let i = 0;i < ns.length; i++) {
          let row = pairRecs.get(ns[i]);
          if (!row)
            pairRecs.set(ns[i], row = new Map);
          for (let j = i + 1;j < ns.length; j++) {
            let r = row.get(ns[j]);
            if (!r) {
              const parts = tupleCellPairs(ns[i], ns[j]);
              if (parts)
                r = parts.map(([d, neg]) => ({ d, neg, mono: false }));
              else {
                const pair = cellPair(ns[i], ns[j]);
                r = { d: pair.d, neg: pair.neg, mono: Object.keys(pair.d).some(isMonomial) };
              }
              row.set(ns[j], r);
            }
            if (Array.isArray(r))
              flat.push(...r);
            else
              flat.push(r);
          }
        }
      }
      flatAt = reader.cellsChanged;
    }
    const out = [];
    for (const r of flat) {
      if (pairedKeys.skip && r.mono)
        continue;
      if (!r.read) {
        for (const lin of [r.d, r.neg]) {
          const x = recOf(lin).x;
          if (x)
            x.pair = true;
        }
        r.xd = recOf(r.d).x;
        r.sd = r.xd?.name === canon(r.d);
        r.xn = recOf(r.neg).x;
        r.sn = r.xn?.name === canon(r.neg);
        r.read = true;
      }
      const a = valOf(r.xd, r.sd), b = valOf(r.xn, r.sn);
      if (a === undefined)
        out.push(r.d);
      else if (a === true && b === undefined)
        out.push(r.neg);
    }
    cellsAt = [reader.cellsChanged, pairsChanged];
    return cellsOpen = out;
  };
  const listRecs = new WeakMap;
  const bx = new Simplex(true, true), bxIn = new Set, toAssert = new Set, toRetract = new Set;
  const rootNames = new Set, stamps = [];
  let stampN = 0;
  for (const [key, a] of root) {
    const name = ensure(a.lin), x = vars.get(name), val = name === key ? a.holds : !a.holds;
    x.val = val;
    x.level = 0;
    x.at = trail.length;
    stamps[x.at] = ++stampN;
    trail.push(name);
    tv.push(x);
    rootNames.add(name);
    if (x.col)
      colsOn++;
  }
  const reader = new Reader(clausal ? { name: goal.name, hyps: [] } : goal, {
    get: (name) => vars.get(name),
    stamp: (at) => stamps[at],
    size: () => trail.length,
    lin: (at) => {
      const name = trail[at], x = vars.get(name);
      return { name, lin: x.lin, holds: x.val };
    },
    ...clausal || opts.quiet ? { quiet: (at) => !!tv[at].quiet } : {}
  });
  let last = goal.hyps.length - 1;
  const near = nearOf(goal);
  const decidedLin = (lin) => vars.get(keyOf(lin))?.val !== undefined;
  const fixed = trail.length;
  const level = () => levels.length;
  const pathOf = () => new Map(trail.map((name) => {
    const x = vars.get(name);
    return [name, { lin: x.lin, holds: x.val }];
  }));
  const assignKernel = (x, val, reason) => {
    const name = x.name;
    lowAt = Math.min(lowAt, trail.length);
    x.val = val;
    x.level = level();
    x.at = trail.length;
    x.phase = val;
    stamps[x.at] = ++stampN;
    x.reason = reason;
    trail.push(name);
    tv.push(x);
    if (x.col)
      colsOn++;
    if (x.pair)
      pairsChanged++;
    reader.touch(name);
  };
  const assignClausal = (x, val, reason) => {
    lowAt = Math.min(lowAt, trail.length);
    x.val = val;
    x.level = level();
    x.at = trail.length;
    x.phase = val;
    stamps[x.at] = ++stampN;
    x.reason = reason;
    trail.push(x.name);
    tv.push(x);
    vals[x.id] = val ? 1 : 2;
    if (rel[x.id] >= 0)
      activate(x.id);
  };
  const assignVar = clausal ? assignClausal : assignKernel;
  const assign = (name, val, reason) => assignVar(vars.get(name), val, reason);
  const relevant = (id) => {
    if (rel[id] >= 0)
      return;
    rel[id] = levels.length;
    relStack.push(id);
    heapIn(byId[id]);
    if (vals[id])
      activate(id);
  };
  const todo = [];
  const activate = (id0) => {
    for (todo.push(id0);todo.length; ) {
      const id = todo.pop(), own = ownBy[2 * id + (vals[id] === 1 ? 1 : 0)];
      if (!own)
        continue;
      for (let i = 0;i < own.length; i++) {
        const ci = own[i];
        if (retired[ci])
          continue;
        const c = cls[ci];
        costs.scan += 1 + (c.length >> 2);
        for (let j = 0;j < c.length; j++) {
          const y = c[j] >> 1;
          if (rel[y] < 0) {
            rel[y] = levels.length;
            relStack.push(y);
            heapIn(byId[y]);
            if (vals[y])
              todo.push(y);
          }
        }
      }
    }
  };
  const undoKernel = (l) => {
    const keep = levels[l] ?? trail.length;
    while (trail.length > Math.max(keep, fixed)) {
      const name = trail.pop(), x = tv.pop(), q = x.aq;
      x.val = undefined;
      x.level = -1;
      x.reason = undefined;
      if (x.col)
        colsOn--;
      if (x.pair)
        pairsChanged++;
      reader.touch(name);
      if (q !== undefined && q < aq)
        aq = q;
    }
    lowAt = Math.min(lowAt, trail.length);
    levels.length = l;
  };
  const undone = [];
  const undoClausal = (l) => {
    const keep = levels[l] ?? trail.length;
    undone.length = 0;
    while (trail.length > keep) {
      trail.pop();
      const x = tv.pop(), q = x.aq;
      vals[x.id] = 0;
      undone.push(x);
      x.val = undefined;
      x.level = -1;
      x.reason = undefined;
      if (q !== undefined && q < aq)
        aq = q;
    }
    lowAt = Math.min(lowAt, trail.length);
    levels.length = l;
    while (relStack.length && rel[relStack.at(-1)] > l)
      rel[relStack.pop()] = -1;
    for (const x of undone)
      heapIn(x);
  };
  const undoTo = clausal ? undoClausal : undoKernel;
  const addClause = (lits, node) => {
    clauses.push({ lits, node });
    const i = clauses.length - 1;
    if (clausal) {
      watches(i);
      return i;
    }
    for (const [name, pos] of lits) {
      const key = `${name}=${pos}`;
      let xs = occ.get(key);
      if (!xs)
        occ.set(key, xs = []);
      xs.push(i);
    }
    return i;
  };
  const watches = (ci) => {
    const c = Int32Array.from([...clauses[ci].lits].map(([name, pos]) => 2 * vars.get(name).id + (pos ? 1 : 0)));
    cls[ci] = c;
    oc[ci] = -1;
    if (c.length < 2)
      return;
    const rank = (z) => holds(z) ? byId[z >> 1].at : Infinity;
    for (const j of [0, 1]) {
      let b = j;
      for (let q = j + 1;q < c.length; q++)
        if (rank(c[q]) > rank(c[b]))
          b = q;
      const t0 = c[j];
      c[j] = c[b];
      c[b] = t0;
    }
    for (const j of [0, 1])
      (wl[c[j]] ??= []).push(ci, c[1 - j]);
  };
  const take = () => {
    if (!enc)
      return;
    for (;fed < goal.hyps.length; fed++)
      if (!enc.add(goal.hyps[fed], fed)) {
        unread = true;
        break;
      }
    if (!enc.made.length)
      return;
    for (const { lits, hyp, own, out } of enc.made) {
      const m = new Map;
      for (const l of lits) {
        const name = ensure(l.lin);
        m.set(name, !(name === canon(l.lin) ? l.holds : !l.holds));
      }
      nodes.push({ hyp, lits: [...m].map(([name, pos]) => [vars.get(name).lin, pos]) });
      let j = 0;
      for (const name of m.keys()) {
        const x = vars.get(name);
        if (!x.cond && !(out && j === m.size - 1)) {
          x.cond = true;
          heapIn(x);
        }
        j++;
      }
      const ci = addClause(m, nodes.length - 1);
      clauses[ci].input = true;
      (byHyp[hyp] ??= []).push(ci);
      if (own && m.size) {
        const [name, pos] = m.entries().next().value, z = 2 * vars.get(name).id + (pos ? 1 : 0);
        oc[ci] = z;
        (ownBy[z] ??= []).push(ci);
      }
      let open;
      for (const name of m.keys())
        if (vars.get(name).val === undefined)
          open = name;
      if (!m.size)
        dead = nodes.length - 1;
      else if (m.size === 1 && open !== undefined)
        assign(open, !m.get(open), ci);
      else if (m.size === 1 && dead < 0) {
        let c = clauses[ci];
        while (c.lits.size) {
          let best;
          for (const name of c.lits.keys()) {
            const y = vars.get(name);
            if (y.val === c.lits.get(name) && (!best || y.at > best.at))
              best = y;
          }
          if (!best || best.reason === undefined)
            break;
          c = resolveOn(c, best.name);
        }
        if (!c.lits.size)
          dead = c.node;
      }
      if (oc[ci] < 0 || rel[oc[ci] >> 1] >= 0 && holds(oc[ci]))
        for (const name of m.keys())
          relevant(vars.get(name).id);
    }
    enc.made = [];
    qhead = 0;
  };
  const needed = (ci) => !retired[ci] && (oc[ci] < 0 || rel[oc[ci] >> 1] >= 0 && holds(oc[ci]));
  const satisfied = (ci) => {
    const c = cls[ci];
    costs.scan += 1 + (c.length >> 2);
    for (let j = 0;j < c.length; j++)
      if (opposed(c[j]))
        return true;
    return false;
  };
  const pickOpen = () => {
    while (heap.length) {
      const x = heap[0];
      if (x.val !== undefined || rel[x.id] < 0) {
        heapPop();
        continue;
      }
      return x;
    }
    if (verify) {
      for (let ci = 0;ci < clauses.length; ci++)
        if (clauses[ci].input && needed(ci) && !satisfied(ci))
          throw new Error("clausal: a needed clause unsatisfied with no open variable");
    }
    return;
  };
  const pointOf = (lp, rows) => {
    const w = {};
    for (const r of rows)
      for (const n of namesOf(r.lin))
        if (!(n in w)) {
          const j = lp.indexOf(n);
          if (j === undefined)
            return;
          const x = lp.value(j), y = Math.round(x);
          if (Math.abs(x - y) > 0.000000001)
            return;
          w[n] = y;
        }
    for (const r of rows) {
      let x = r.lin["1"] ?? 0;
      for (const n of namesOf(r.lin))
        x += r.lin[n] * w[n];
      if (x > 0)
        return;
    }
    return w;
  };
  const roundless = (lp, rows) => {
    const w = {};
    for (const r of rows)
      for (const n of namesOf(r.lin))
        if (!(n in w)) {
          const j = lp.indexOf(n);
          if (j === undefined)
            return;
          w[n] = lp.value(j);
        }
    return w;
  };
  const roundedOf = (lp, rows) => {
    const w = {};
    for (const r of rows)
      for (const n of namesOf(r.lin))
        if (!(n in w)) {
          const j = lp.indexOf(n);
          if (j === undefined)
            return;
          w[n] = Math.max(0, Math.round(lp.value(j)));
        }
    return w;
  };
  let qhead = 0;
  const propagateKernel = () => {
    while (qhead < trail.length) {
      const name = trail[qhead++], x = vars.get(name), os = occ.get(`${name}=${x.val}`);
      if (!os)
        continue;
      for (const ci of os) {
        const c = clauses[ci];
        let open, nOpen = 0, dead = false;
        for (const [w, p] of c.lits) {
          const y = vars.get(w);
          if (y.val === undefined) {
            nOpen++;
            open = w;
            if (nOpen > 1)
              break;
          } else if (y.val !== p) {
            dead = true;
            break;
          }
        }
        if (dead || nOpen > 1)
          continue;
        if (nOpen === 0)
          return ci;
        assign(open, !c.lits.get(open), ci);
      }
    }
    return;
  };
  const propagateClausal = () => {
    while (qhead < trail.length) {
      const x = tv[qhead++], code = 2 * x.id + (x.val ? 1 : 0), ws = wl[code];
      if (!ws)
        continue;
      let n = 0;
      for (let i = 0;i < ws.length; ) {
        const blocker = ws[i + 1];
        if (vals[blocker >> 1] === 1 + (blocker & 1)) {
          i += 2;
          continue;
        }
        const ci = ws[i], c = cls[ci];
        n++;
        if (retired[ci]) {
          ws[i] = ws[ws.length - 2];
          ws[i + 1] = ws[ws.length - 1];
          ws.length -= 2;
          continue;
        }
        if (c[0] === code) {
          c[0] = c[1];
          c[1] = code;
        }
        const o = c[0];
        if (vals[o >> 1] === 1 + (o & 1)) {
          ws[i + 1] = o;
          i += 2;
          continue;
        }
        let j = 2;
        const len = c.length;
        while (j < len) {
          const z = c[j];
          if (vals[z >> 1] !== 2 - (z & 1))
            break;
          j++;
        }
        if (j < len) {
          const z = c[j];
          c[j] = code;
          c[1] = z;
          (wl[z] ??= []).push(ci, o);
          ws[i] = ws[ws.length - 2];
          ws[i + 1] = ws[ws.length - 1];
          ws.length -= 2;
          continue;
        }
        if (!vals[o >> 1]) {
          assignClausal(byId[o >> 1], !(o & 1), ci);
          i += 2;
          continue;
        }
        costs.scan += n;
        return ci;
      }
      costs.scan += n;
    }
    return;
  };
  const propagate = clausal ? propagateClausal : propagateKernel;
  const bump = (lits) => {
    for (const name of lits.keys()) {
      const x = vars.get(name);
      x.act += inc;
      if (x.act > 10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) {
        for (const y of vars.values())
          y.act *= 0.0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001;
        inc *= 0.0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001;
      }
      if (clausal && x.hp !== undefined && x.hp >= 0)
        heapUp(x.hp);
    }
    inc /= 0.95;
  };
  const resolveOn = (c, name) => {
    const x = vars.get(name), r = clauses[x.reason];
    if (r.node < 0)
      materialize(x.reason);
    const lits = new Map(c.lits);
    lits.delete(name);
    for (const [w, p] of r.lits)
      if (w !== name)
        lits.set(w, p);
    nodes.push({ res: c.lits.get(name) ? [c.node, r.node] : [r.node, c.node], on: x.lin });
    st.resolved++;
    return { lits, node: nodes.length - 1 };
  };
  const leafNode = (w, inputs, steps, extra, hyps, src) => {
    nodes.push(src ? { inputs, steps, src } : { inputs, steps });
    if (hyps)
      leafHyps.set(nodes.length - 1, hyps);
    st.leaves++;
    const lits = new Map;
    for (const name of w)
      if (!rootNames.has(name))
        lits.set(name, vars.get(name).val);
    if (extra)
      lits.set(extra[0], extra[1]);
    if (src)
      nodes.at(-1).lits = [...lits].map(([name, val]) => [vars.get(name).lin, val]);
    st.coreSize += lits.size;
    return { lits, node: nodes.length - 1 };
  };
  const leafAt = (rows, steps) => t(() => {
    const w = new Set;
    for (const s of steps)
      if (s.kind === "input")
        for (const name of rows[s.index].w)
          w.add(name);
    st.pathSize += trail.length - fixed;
    const local = localize(rows, steps);
    return leafNode(w, local.inputs, local.steps, undefined, wantCore ? hypsOf(steps.flatMap((s) => s.kind === "input" ? [rows[s.index]] : [])) : undefined, wantDag ? local.from.map((i) => reader.srcOf(rows[i]) ?? -1) : undefined);
  }, (ms) => {
    st.coreMs += ms;
  });
  const pending = new Map;
  const materialize = (ci) => t(() => {
    const b = pending.get(ci), x = vars.get(b.name), c = clauses[ci];
    pending.delete(ci);
    const local = [...b.used.map((lin) => ({ lin, label: "" })), { lin: atomOf(x.lin, !b.val).lin, label: "" }];
    const s = solve(local);
    if (s.kind !== "refuted")
      throw new Error("a bound propagation its bounds do not refute");
    const loc = localize(local, s.steps), made = leafNode(b.w, loc.inputs, loc.steps, [b.name, !b.val], b.hyps, b.src && loc.from.map((i) => b.src[i] ?? -1));
    c.lits = made.lits;
    c.node = made.node;
  }, (ms) => {
    st.coreMs += ms;
  });
  let anN = 0;
  const analyzeClausal = (c) => {
    const lits = new Map(c.lits), an = ++anN;
    for (const name of lits.keys())
      vars.get(name).an = an;
    let node = c.node, { top, here } = levelsOf(c), p = trail.length - 1;
    if (top < level()) {
      undoTo(top);
      qhead = trail.length;
      p = trail.length - 1;
    }
    while (lits.size && !(top > 0 && here === 1)) {
      while (p >= 0 && !(tv[p].an === an && tv[p].level === top))
        p--;
      const name = trail[p], x = tv[p];
      if (top > 0 && x.reason === undefined)
        break;
      const r = clauses[x.reason];
      if (r.node < 0)
        materialize(x.reason);
      nodes.push({ res: lits.get(name) ? [node, r.node] : [r.node, node], on: x.lin });
      st.resolved++;
      node = nodes.length - 1;
      lits.delete(name);
      x.an = 0;
      here--;
      for (const [w, q] of r.lits)
        if (w !== name && !lits.has(w)) {
          const y = vars.get(w);
          lits.set(w, q);
          y.an = an;
          if (y.level === top)
            here++;
        }
    }
    return { lits, node };
  };
  const decideFree = () => {
    const x = pickOpen();
    if (!x)
      return false;
    free--;
    if (!x.quiet && sx)
      phaseAtPoint(x, sx);
    levels.push(trail.length);
    noteDecision();
    assignVar(x, x.phase);
    return true;
  };
  const levelsOf = (c) => {
    let top = -1, here = 0, latest, at = -1;
    for (const name of c.lits.keys()) {
      const x = vars.get(name);
      if (x.level > top) {
        top = x.level;
        here = 1;
        latest = name;
        at = x.at;
      } else if (x.level === top) {
        here++;
        if (x.at > at) {
          latest = name;
          at = x.at;
        }
      }
    }
    let below = 0;
    for (const name of c.lits.keys()) {
      const l = vars.get(name).level;
      if (name !== latest && l > below)
        below = l;
    }
    return { top, here, latest, below };
  };
  const luby = (i) => {
    let n = 1;
    while ((1 << n) - 1 < i + 1)
      n++;
    return (1 << n) - 1 === i + 1 ? 1 << n - 1 : luby(i + 1 - (1 << n - 1));
  };
  const phaseAtPoint = (x, lp) => {
    if (x.val !== undefined || x.col)
      return;
    if (x.sx !== lp) {
      x.sx = lp;
      x.sj = x.terms.map(([x0]) => lp.indexOf(x0));
    }
    let v = x.lin["1"] ?? 0, known = true;
    for (let q = 0;q < x.sj.length && known; q++) {
      const j = x.sj[q];
      if (j === undefined)
        known = false;
      else
        v += x.terms[q][1] * lp.value(j);
    }
    if (!known) {
      const at = lp.holds(x.lin);
      if (at !== undefined)
        x.phase = at;
      x.sx = undefined;
      return;
    }
    x.phase = v <= 0.0000001 * Math.max(1, Math.abs(v));
  };
  let restartAt = 32, nRestart = 0, sinceRestart = 0, free = 0;
  const batch = Number(env.GDP_CDCL_BATCH ?? 16);
  const stuck = (kind, why, extra = {}) => ({ stuck: kind, path: clausal ? new Map : pathOf(), why, ...extra });
  const run = (b, w, assume) => {
    budget = b;
    until = b.until ?? Infinity;
    wall = w;
    last = goal.hyps.length - 1;
    if (timing) {
      runStarted = performance.now();
      sawDecision = false;
    }
    restartAt = 32;
    nRestart = 0;
    sinceRestart = 0;
    listed = Array.isArray(assume);
    assumed = (assume === undefined ? [] : Array.isArray(assume) ? assume : [assume]).map((lin) => {
      const name = ensure(lin);
      return [name, name === canon(lin)];
    });
    let keep = 0;
    if (listed && !(enc && fed < goal.hyps.length))
      for (let l = 0, q = 0;l < levels.length; l++) {
        const d = trail[levels[l]];
        for (let y = q < assumed.length ? vars.get(assumed[q][0]) : undefined;y && y.val === assumed[q][1] && y.at < levels[l]; y = ++q < assumed.length ? vars.get(assumed[q][0]) : undefined)
          ;
        if (q >= assumed.length || assumed[q][0] !== d || vars.get(d).val !== assumed[q][1])
          break;
        q++;
        keep = l + 1;
      }
    aq = 0;
    aqOf = new Map(assumed.map(([name], q) => [name, q]));
    for (const y of aqVars)
      y.aq = undefined;
    aqVars = assumed.map(([name], q) => {
      const y = vars.get(name);
      y.aq = q;
      return y;
    });
    undoTo(keep);
    qhead = Math.min(qhead, trail.length);
    take();
    if (unread)
      return { stuck: "unknown", path: new Map, why: "a hypothesis the clauses do not read" };
    if (dead >= 0)
      return { stuck: "unknown", path: new Map, why: REFUTED, ...listed ? { assumed: [] } : {}, ...wantDag ? { dag: { nodes, top: dead, clausal } } : {} };
    return queryHook.on && !queryHook.depth ? logged(opts.model ? "model" : "cdcl", goal, search) : search();
  };
  let finalN = 0;
  const final = (q0) => {
    const out = new Set([q0]), todo = [vars.get(assumed[q0][0])], stamp = ++finalN;
    while (todo.length) {
      const x = todo.pop();
      if (x.fs === stamp || x.level <= 0)
        continue;
      x.fs = stamp;
      if (x.reason === undefined) {
        if (x.aq !== undefined)
          out.add(x.aq);
        continue;
      }
      if (clauses[x.reason].node < 0)
        materialize(x.reason);
      const c = clausal ? cls[x.reason] : undefined;
      if (c) {
        for (let j = 0;j < c.length; j++) {
          const y = byId[c[j] >> 1];
          if (y !== x)
            todo.push(y);
        }
      } else
        for (const w of clauses[x.reason].lits.keys())
          if (w !== x.name)
            todo.push(vars.get(w));
    }
    return [...out].sort((a, b) => a - b);
  };
  const finalDag = (q0) => {
    const x0 = vars.get(assumed[q0][0]);
    if (clauses[x0.reason].node < 0)
      materialize(x0.reason);
    let c = clauses[x0.reason];
    for (;; ) {
      let best;
      for (const name of c.lits.keys()) {
        if (aqOf.has(name))
          continue;
        const y = vars.get(name);
        if (!best || y.at > best.at)
          best = y;
      }
      if (!best)
        return c.node;
      c = resolveOn(c, best.name);
    }
  };
  const search = () => {
    for (;; ) {
      if (++budget.nodes > 200000 || late(until) || wall !== undefined && performance.now() > wall)
        return stuck("unknown", budget.nodes > 200000 ? "nodes" : "time");
      let conflict;
      const ci = t(propagate, (ms) => {
        st.propagationMs += ms;
      });
      let open = -1, wrong = -1;
      if (ci === undefined)
        for (;aq < assumed.length; aq++) {
          const val = vars.get(assumed[aq][0]).val;
          if (val === !assumed[aq][1]) {
            wrong = aq;
            break;
          }
          if (val === undefined) {
            open = aq;
            break;
          }
        }
      if (ci !== undefined)
        conflict = clauses[ci];
      else if (wrong >= 0)
        return { stuck: "unknown", path: new Map, why: REFUTED, ...listed ? { assumed: final(wrong) } : {}, ...wantDag ? { dag: { nodes, top: finalDag(wrong), clausal } } : {} };
      else if (open >= 0) {
        levels.push(trail.length);
        assign(assumed[open][0], assumed[open][1]);
        continue;
      } else {
        if (free > 0 && decideFree())
          continue;
        reader.begin();
        st.nodes++;
        const rowsR = t(() => (reader.sync(lowAt), lowAt = trail.length, reader.live), (ms) => {
          st.rowsMs += ms;
        });
        const full = rowsR;
        const single = (id) => reader.form(full[reader.slotOf(id)].lin).names.length === 1;
        for (const id of reader.left) {
          if (bxIn.delete(id))
            bx.retract(id);
          if (sx && !toAssert.delete(id))
            toRetract.add(id);
        }
        for (const id of reader.entered) {
          if (single(id)) {
            bxIn.add(id);
            bx.assert(id, full[reader.slotOf(id)].lin);
          }
          if (sx && !toRetract.delete(id))
            toAssert.add(id);
        }
        if (verify && !clausal) {
          const mine = new Set(rowsR.map((r) => canon(r.lin))), theirs = new Set(leafConstraints(goal, pathOf()).map((r) => canon(r.lin)));
          if (mine.size !== theirs.size || [...mine].some((x) => !theirs.has(x)))
            throw new Error(`reader.ts's rows differ from kernel.ts's at a node of ${goal.name}: reader's alone ${[...mine].filter((x) => !theirs.has(x)).slice(0, 4).join(" ; ")}; kernel's alone ${[...theirs].filter((x) => !mine.has(x)).slice(0, 4).join(" ; ")}; path ${[...pathOf()].map(([k2, a]) => `${a.holds ? "" : "\xAC"}${k2}`).join(" ; ")}`);
        }
        work.n += 1 + full.length;
        costs.cdclNodes++;
        costs.cdclRows += full.length;
        const columns = colsOn > 0;
        let kidx, idx, rows;
        const korder = () => kidx ??= reader.rows().map((r) => reader.slotOf(reader.form(r.lin).id));
        const plain = () => {
          if (rows)
            return rows;
          idx = korder().filter((i) => columns || !reader.readsColumn(full[i].lin));
          return rows = idx.map((i) => full[i]);
        };
        const at = (i) => i < plain().length ? idx[i] : full.length + i - plain().length;
        const cands = t(() => {
          if (clausal) {
            const x = pickOpen();
            return x ? [x] : [];
          }
          const g = ++candGen, keep = [];
          const take = (lins) => {
            let rs = listRecs.get(lins);
            if (!rs)
              listRecs.set(lins, rs = lins.map(recOf));
            costs.scan += rs.length;
            for (const r of rs) {
              if (r.seen === g)
                continue;
              r.seen = g;
              if (r.x && r.x.val === undefined)
                keep.push(r.x);
            }
          };
          take(unitAtoms(goal));
          if (last >= 0)
            take(reader.openList(last));
          for (let i = 0;i < last; i++)
            if (near[i])
              take(reader.openList(i));
          for (let i = 0;i < last; i++)
            if (!near[i])
              take(reader.openList(i));
          if (reader.hasCells())
            take(openCellsLive());
          return keep;
        }, (ms) => {
          st.orderMs += ms;
        });
        const open = cands.length > 0;
        const tb = timing ? performance.now() : 0;
        if (open) {
          let forced = 0;
          for (const x of cands) {
            const name = x.name;
            if (x.val !== undefined || x.col)
              continue;
            if (x.bver === bx.changes)
              continue;
            if (!x.bj) {
              if (x.bjAt === bx.vars)
                continue;
              x.bjAt = bx.vars;
              const bj = x.terms.map(([x0]) => bx.indexOf(x0));
              if (bj.some((j) => j === undefined))
                continue;
              x.bj = bj;
            }
            const bj = x.bj;
            let sig = 0;
            for (const j of bj)
              sig += bx.version(j);
            if (x.bsig === sig) {
              x.bver = bx.changes;
              continue;
            }
            const side = (val) => {
              let sum = x.lin["1"] ?? 0;
              const used = [];
              for (let q = 0;q < bj.length; q++) {
                const c = x.terms[q][1], j = bj[q], up = c > 0 === val, b = up ? bx.high(j) : bx.low(j);
                if (!Number.isFinite(b))
                  return;
                sum += c * b;
                used.push(reader.slotOf(up ? bx.highWhy(j) : bx.lowWhy(j)));
              }
              return (val ? sum <= 0 : sum >= 1) ? used : undefined;
            };
            let hit = false;
            for (const val of [true, false]) {
              const used = side(val);
              if (!used)
                continue;
              hit = true;
              const w = new Set;
              for (const i of used)
                for (const n of rowsR[i].w)
                  w.add(n);
              clauses.push({ lits: new Map([[name, !val]]), node: -1 });
              pending.set(clauses.length - 1, { w, used: used.map((i) => full[i].lin), name, val, ...wantCore ? { hyps: hypsOf(used.map((i) => rowsR[i])) } : {}, ...wantDag ? { src: used.map((i) => reader.srcOf(rowsR[i]) ?? -1) } : {} });
              assign(name, val, clauses.length - 1);
              forced++;
              break;
            }
            x.bsig = hit ? undefined : sig;
            x.bver = hit ? undefined : bx.changes;
          }
          if (timing)
            st.boundMs += performance.now() - tb;
          if (forced) {
            st.boundRounds++;
            continue;
          }
        }
        let steps, lpSat = false, judged = false;
        let verdict;
        t(() => {
          if (sx) {
            const t0 = timing ? performance.now() : 0;
            const over = sx.size > (clausal ? lpGrow : 4) * full.length + (clausal ? lpBase : 500) || sx.nnz > lpFill * full.length;
            if (over) {
              sx = new Simplex;
              if (clausal)
                sx.greedy = lpGreedy;
              st.lpRebuilds++;
            }
            if (over || !sx.vars)
              for (const r of reader.rows())
                sx.assert(reader.form(r.lin).id, r.lin);
            else {
              for (const id of toRetract)
                sx.retract(id);
              for (const id of toAssert)
                sx.assert(id, full[reader.slotOf(id)].lin);
            }
            toAssert.clear();
            toRetract.clear();
            const p0 = sx.pivots;
            let lp = sx.settle();
            if (lp.kind === "sat")
              lp = sx.check();
            if (lp.kind === "conflict")
              lp = { kind: "conflict", rows: lp.rows.map((id) => reader.slotOf(id)) };
            costs.pivots += sx.pivots - p0;
            if (timing) {
              st.lpMs += performance.now() - t0;
              st.pivots += sx.pivots - p0;
              st.lpRows = sx.size;
              st.lpNnz = sx.nnz;
              st.lpVars = sx.vars;
              st.lpLoad = full.length;
              if (lp.kind === "unknown")
                st.lpUnknown++;
            }
            if (lp.kind === "conflict") {
              const tm = timing ? performance.now() : 0, support = lp.rows.sort((x, y) => x - y), out = solve(support.map((i) => full[i]));
              if (timing)
                st.missMs += performance.now() - tm;
              if (out.kind === "refuted")
                steps = out.steps.map((s) => s.kind === "input" ? { ...s, index: support[s.index] } : s);
              else
                st.lpMisses++;
            }
            lpSat = lp.kind === "sat";
            if (open && lpSat && wideScope.judge) {
              const w = roundedOf(sx, rowsR);
              if (w && wideScope.judge(w)) {
                verdict = { kind: "sat", witness: w };
                judged = true;
                return;
              }
            }
            if (steps || open && lp.kind === "sat")
              return;
            const byPoint = pointLeaf && !!opts.point && !!opts.model;
            if ((clausal || byPoint) && !open && lpSat) {
              const w = pointOf(sx, rowsR);
              if (w) {
                verdict = { kind: "sat", witness: w };
                return;
              }
            }
            if (byPoint && !clausal && !open && lpSat) {
              const point = roundless(sx, rowsR);
              if (point && Object.entries(point).some(([x0, value]) => Math.abs(value - Math.round(value)) >= 0.000000001 && !isMonomial(x0) && !decidedLin(Math.floor(value) === 0 ? { [x0]: 1 } : { [x0]: 1, 1: -Math.floor(value) }))) {
                verdict = { kind: "unknown", point };
                return;
              }
            }
          }
          st.fmCalls++;
          const rows = plain(), tf = timing ? performance.now() : 0;
          if (open && rows.length > 60) {
            const fast = refuteFast(rows);
            if (fast?.kind === "refuted")
              steps = fast.steps.map((s) => s.kind === "input" ? { ...s, index: at(s.index) } : s);
          }
          const tf2 = timing ? performance.now() : 0;
          if (timing)
            st.fastMs += tf2 - tf;
          if (!steps) {
            verdict = open && rows.length > 60 ? solve(rows, 2 * rows.length) : solve(rows);
            if (verdict.kind === "refuted")
              steps = verdict.steps.map((s) => s.kind === "input" ? { ...s, index: at(s.index) } : s);
          }
          if (timing) {
            if (open)
              st.fmOpenMs += performance.now() - tf2;
            else
              st.fmLeafMs += performance.now() - tf2;
          }
          if (!steps && open && !columns && full.length > rows.length) {
            const k = korder(), fast = refuteFast(k.map((i) => full[i]));
            if (fast?.kind === "refuted")
              steps = fast.steps.map((s) => s.kind === "input" ? { ...s, index: k[s.index] } : s);
          }
        }, (ms) => {
          st.solveMs += ms;
        });
        if (judged && verdict?.kind === "sat")
          return stuck("sat", "a model", { witness: verdict.witness });
        if (steps)
          conflict = leafAt(rowsR, steps);
        else {
          let pick, best = -1, px;
          for (const x of cands)
            if (x.val === undefined && x.act > best) {
              best = x.act;
              pick = x.name;
              px = x;
            }
          if ((opts.model || atPoint.on) && lpSat && sx && open && px)
            phaseAtPoint(px, sx);
          if (!pick && verdict?.kind === "unknown") {
            for (const [x0, value] of Object.entries(verdict.point ?? {})) {
              if (Math.abs(value - Math.round(value)) < 0.000000001 || isMonomial(x0))
                continue;
              const c = Math.floor(value), lin = c === 0 ? { [x0]: 1 } : { [x0]: 1, 1: -c };
              if (!decidedLin(lin)) {
                pick = ensure(lin);
                break;
              }
            }
          }
          if (!pick && !clausal) {
            const p = pathOf(), more = openAt(goal, p, rowsAt(goal, p)).find((lin) => Object.keys(lin).some((key) => key !== "1") && !decidedLin(lin));
            if (more) {
              st.openMisses++;
              pick = ensure(more);
            }
          }
          if (!pick)
            return verdict?.kind === "sat" ? stuck("sat", "a model", { witness: verdict.witness }) : stuck("unknown", "no split");
          levels.push(trail.length);
          noteDecision();
          assign(pick, vars.get(pick).phase);
          if (clausal && lpSat)
            free = batch;
          continue;
        }
      }
      st.conflicts++;
      sinceRestart++;
      free = 0;
      let c = conflict;
      if (clausal)
        c = analyzeClausal(c);
      for (;; ) {
        if (!c.lits.size) {
          if (opts.model) {
            if (wantDag)
              return { stuck: "unknown", path: new Map, why: REFUTED, dag: { nodes, top: c.node, clausal } };
            if (!wantCore)
              return { stuck: "unknown", path: new Map, why: REFUTED };
            const core = new Set, seen = new Set, todo = [c.node];
            let whole = true;
            while (todo.length) {
              const i = todo.pop();
              if (i < 0) {
                whole = false;
                break;
              }
              if (seen.has(i))
                continue;
              seen.add(i);
              const nd = nodes[i];
              if ("res" in nd)
                todo.push(...nd.res);
              else
                for (const h of leafHyps.get(i) ?? [])
                  core.add(h);
            }
            return { stuck: "unknown", path: new Map, why: REFUTED, ...whole ? { core: [...core].sort((a, b) => a - b) } : {} };
          }
          const tree = t(() => unfold(goal, nodes, c.node, root, opts.maxLeaves ?? 20000, until), (ms) => {
            st.unfoldMs += ms;
          });
          if (!tree)
            return stuck("unknown", "unfold");
          st.proven++;
          return { tree, nodes: budget.nodes };
        }
        const { top, here, latest } = levelsOf(c);
        if (top < level()) {
          undoTo(top);
          qhead = trail.length;
        }
        if (top === 0) {
          c = resolveOn(c, latest);
          continue;
        }
        if (here === 1)
          break;
        if (vars.get(latest).reason === undefined)
          break;
        c = resolveOn(c, latest);
      }
      const { top, here, latest: uip, below } = levelsOf(c);
      bump(c.lits);
      const learned = addClause(c.lits, c.node);
      if (here !== 1) {
        undoTo(Math.max(0, top - 1));
        qhead = Math.min(qhead, trail.length);
        continue;
      }
      undoTo(below);
      qhead = trail.length;
      assign(uip, !c.lits.get(uip), learned);
      if (sinceRestart >= restartAt) {
        sinceRestart = 0;
        restartAt = 32 * luby(++nRestart);
        undoTo(0);
        qhead = Math.min(qhead, trail.length);
      }
    }
  };
  const retire = (hyp) => {
    for (const ci of byHyp[hyp] ?? [])
      retired[ci] = true;
  };
  if (timing)
    st.setupMs += performance.now() - setupStarted;
  return { run, retire };
}
function unfold(goal, nodes, top, root, maxLeaves, until) {
  const stack = [], on = new Map, stamps = [];
  let stampN = 0, leaves = 0;
  const reader = new Reader(goal, { get: (name) => on.get(name), stamp: (at) => stamps[at], size: () => stack.length, lin: (at) => stack[at] });
  const push = (name, lin, holds) => {
    on.set(name, { val: holds, at: stack.length });
    stamps[stack.length] = ++stampN;
    stack.push({ name, lin, holds });
    reader.touch(name);
  };
  const pop = () => {
    const name = stack.pop().name;
    on.delete(name);
    reader.touch(name);
  };
  for (const [key, a] of root)
    push(key, a.lin, a.holds);
  const go = (i) => {
    const n = nodes[i];
    if ("res" in n) {
      const key = canon(n.on), d = on.get(key);
      if (d)
        return go(d.val ? n.res[0] : n.res[1]);
      push(key, n.on, true);
      const yes = go(n.res[0]);
      pop();
      if (!yes)
        return;
      push(key, n.on, false);
      const no = go(n.res[1]);
      pop();
      return no && { split: n.on, yes, no };
    }
    if ("hyp" in n)
      return;
    if (++leaves > maxLeaves || late(until)) {
      cdclStats.unfoldWhy = leaves > maxLeaves ? "leaves" : "time";
      return;
    }
    reader.begin();
    const src = [], rows = reader.leafRows(src);
    costs.unfoldRows += rows.length;
    const noted = (leaf) => {
      const t = { leaf }, at = new Map;
      for (const st of leaf)
        if (st.kind === "input" && st.index < rows.length)
          at.set(st.index, { lin: rows[st.index].lin, src: src[st.index] });
      leafRowsOf.set(t, { n: rows.length, at });
      return t;
    };
    if (verify) {
      const path = new Map(stack.map((x) => [x.name, { lin: x.lin, holds: x.holds }])), kr = leafConstraints(goal, path);
      if (kr.length !== rows.length || kr.some((r, j) => canon(r.lin) !== canon(rows[j].lin))) {
        const j = kr.findIndex((r, j2) => canon(r.lin) !== canon(rows[j2]?.lin ?? {}));
        throw new Error(`reader.ts's rows differ from kernel.ts's at a leaf of ${goal.name}: ${kr.length} vs ${rows.length}, at ${j}: ${JSON.stringify(kr[j])} vs ${JSON.stringify(rows[j]?.lin)}; next ${JSON.stringify(kr.slice(j + 1, j + 3).map((r) => r.lin))} vs ${JSON.stringify(rows.slice(j + 1, j + 3).map((r) => r.lin))}`);
      }
    }
    const at = new Map;
    rows.forEach((r, j) => {
      const key = canon(r.lin);
      if (!at.has(key))
        at.set(key, j);
    });
    const steps = [];
    for (const s of n.steps) {
      if (s.kind !== "input") {
        steps.push(s);
        continue;
      }
      const j = at.get(canon(n.inputs[s.index]));
      if (j === undefined)
        break;
      steps.push({ ...s, index: j });
    }
    if (steps.length === n.steps.length && checkRefutation(rows, steps))
      return noted(steps);
    cdclStats.resolved2++;
    work.n += 1 + rows.length;
    costs.unfoldRows += rows.length;
    const fast = rows.length > 60 ? refuteFast(rows) : undefined;
    if (fast?.kind === "refuted")
      return noted(fast.steps);
    const out = solve(rows);
    if (out.kind === "refuted")
      return noted(out.steps);
    cdclStats.unfoldWhy = "refute";
    return;
  };
  return go(top);
}

// kernel/epr.ts
var textsOf = new WeakMap;
var textOfE = (o) => {
  let s = textsOf.get(o);
  if (s === undefined)
    textsOf.set(o, s = JSON.stringify(o));
  return s;
};
function patternsOf(m, laws) {
  const out = Object.create(null);
  const each = new Set(Object.values(m.step.maps ?? {}).flatMap((w) => ("each" in w) ? [w.each] : []));
  const scan = (o) => {
    if (!o || typeof o !== "object")
      return;
    const x = o;
    if (x.op === "get" && !x.args && !(x.key.op === "var" && each.has(x.key.name)) && !(m.fns && Object.hasOwn(m.fns, x.map))) {
      const t = tupleOf(x.key);
      if (t && t.coefs.length > (out[x.map]?.length ?? 0))
        out[x.map] = t.coefs;
    }
    for (const y of Object.values(o))
      scan(y);
  };
  scan(m.step);
  scan(m.assume);
  for (const f of Object.keys(m.fns ?? {}))
    out[f] = [0];
  for (const l of laws)
    if (!(l.name.startsWith("every ") && l.name.endsWith("of its kind")))
      scan(l.holds);
  const inKey = (o, under) => {
    if (!o || typeof o !== "object")
      return;
    const x = o;
    if (x.op === "get" && !x.args && under && !(m.fns && Object.hasOwn(m.fns, x.map)))
      out[x.map] = [0];
    if (x.op === "get" && !x.args) {
      inKey(x.key, true);
      return;
    }
    for (const y of Object.values(o))
      inKey(y, under);
  };
  inKey(m.step, false);
  inKey(m.assume, false);
  for (const l of laws)
    inKey(l.holds, false);
  return out;
}
var T = { k: "c", b: true };
var Fa = { k: "c", b: false };
var and = (xs) => {
  const ys = xs.filter((x) => !(x.k === "c" && x.b));
  return ys.some((x) => x.k === "c" && !x.b) ? Fa : ys.length === 0 ? T : ys.length === 1 ? ys[0] : { k: "and", xs: ys };
};
var or = (xs) => {
  const ys = xs.filter((x) => !(x.k === "c" && !x.b));
  return ys.some((x) => x.k === "c" && x.b) ? T : ys.length === 0 ? Fa : ys.length === 1 ? ys[0] : { k: "or", xs: ys };
};
var not = (x) => x.k === "c" ? { k: "c", b: !x.b } : x.k === "not" ? x.x : { k: "not", x };
var fnMaps = new Set;
var fnSignature = "";
var partName = (e) => e.op === "var" ? e.name : e.op === "get" && fnMaps.has(e.map) && !e.args ? ((n) => n === undefined ? undefined : `${e.map}(${n})`)(partName(e.key)) : undefined;
var linTerms = (e, k, out, d) => e.op === "var" || e.op === "get" ? ((n) => n !== undefined && (out.push([n, k]), true))(partName(e)) : e.op === "const" ? (d.c += k * e.value, true) : e.op === "mul" ? linTerms(e.a, k * e.k, out, d) : e.op === "add" ? linTerms(e.a, k, out, d) && linTerms(e.b, k, out, d) : false;
var tupleMemo = new WeakMap;
function tupleOf(e) {
  let memo = tupleMemo.get(e);
  if (!memo)
    tupleMemo.set(e, memo = new Map);
  let t = memo.get(fnSignature);
  if (t === undefined)
    memo.set(fnSignature, t = tupleOf0(e) ?? null);
  return t ?? undefined;
}
function tupleOf0(e) {
  if (e.op === "tup") {
    const ps = tupleParts(e).map(partName);
    return ps.every((p) => p !== undefined) ? { coefs: ps.map(() => 0), parts: ps, bounds: ps.map(() => {
      return;
    }) } : undefined;
  }
  const ts = [], d = { c: 0 };
  if (!linTerms(e, 1, ts, d) || d.c !== 0 || !ts.length)
    return;
  ts.sort((a, b) => b[1] - a[1]);
  const coefs = ts.map((t) => t[1]);
  if (coefs.at(-1) !== 1 || coefs.some((c, i) => i + 1 < coefs.length && (c % coefs[i + 1] !== 0 || c / coefs[i + 1] < 2)))
    return;
  return { coefs, parts: ts.map((t) => t[0]), bounds: coefs.map((c, i) => i === 0 ? undefined : coefs[i - 1] / c) };
}
var sameCoefs = (a, b) => a.length === b.length && a.every((c, i) => c === b[i]);
var decideHook = {};
var lastShaped;
var projectedMemo = new WeakMap;
var projectedOf = (g) => {
  let o = projectedMemo.get(g);
  if (!o)
    projectedMemo.set(g, o = { ...g, hyps: g.hyps.map(projectedC) });
  return o;
};
function decide2(goal, patterns, opts = {}) {
  if (!decideHook.on)
    return decide1(goal, patterns, opts);
  const t0 = performance.now(), d = decide1(goal, patterns, opts);
  decideHook.on(goal, d, performance.now() - t0, lastShaped);
  return d;
}
function decide1(goal0, patterns, opts = {}) {
  const previous = fnMaps, previousSignature = fnSignature;
  fnMaps = new Set(Object.entries(patterns).filter(([, c]) => c.length === 1 && c[0] === 0).map(([f]) => f));
  fnSignature = JSON.stringify([...fnMaps].sort());
  const goal = JSON.stringify(goal0.hyps).includes('"op":"proj"') ? projectedOf(goal0) : goal0;
  try {
    const d = decide0(goal, patterns, opts), d2 = "unknown" in d && d.unknown === noRoom ? decide0(goal, patterns, { ...opts, fill: true }) : d;
    return "unknown" in d2 && d2.unknown.startsWith(breaks) && lemmaCache.size ? decide0(goal, patterns, { ...opts, fresh: true }) : d2;
  } catch (e) {
    if (e === pastEnd)
      return { unknown: "past the deadline" };
    throw e;
  } finally {
    fnMaps = previous;
    fnSignature = previousSignature;
  }
}
var liftMemo = new WeakMap;
var ifMemo = new WeakMap;
var hasIf = (o) => {
  if (!o || typeof o !== "object")
    return false;
  let b = ifMemo.get(o);
  if (b === undefined)
    ifMemo.set(o, b = o.op === "if" || Object.values(o).some(hasIf));
  return b;
};
var underMemo = new WeakMap;
var underGuard = (e, guard, yes) => {
  if (!hasIf(e))
    return e;
  const id = textOfE(guard), key = `${yes}:${id}`, memo = underMemo.get(e) ?? new Map;
  if (!underMemo.has(e))
    underMemo.set(e, memo);
  const was = memo.get(key);
  if (was)
    return was;
  const visit = (o) => {
    if (!o || typeof o !== "object" || !hasIf(o))
      return o;
    if (Array.isArray(o)) {
      const xs = o.map(visit);
      return xs.every((x, i) => x === o[i]) ? o : xs;
    }
    const t = o;
    if (t.op === "if" && textOfE(t.c) === id)
      return visit(yes ? t.then : t.else);
    let changed = false;
    const entries = Object.entries(o).map(([k, v]) => {
      const next = visit(v);
      if (next !== v)
        changed = true;
      return [k, next];
    });
    return changed ? Object.fromEntries(entries) : o;
  };
  const out = visit(e);
  memo.set(key, out);
  return out;
};
var hoistMemo = new WeakMap;
var hoisted = (e) => {
  const was = hoistMemo.get(e);
  if (was)
    return was;
  const out = hoisted0(e);
  hoistMemo.set(e, out);
  return out;
};
var hoisted0 = (e) => {
  if (e.op === "if")
    return { ...e, then: hoisted(underGuard(e.then, e.c, true)), else: hoisted(underGuard(e.else, e.c, false)) };
  if (e.op === "add" || e.op === "tup") {
    const a = hoisted(e.a), b = hoisted(e.b);
    return a.op === "if" ? { op: "if", c: a.c, then: hoisted({ ...e, a: a.then, b: underGuard(b, a.c, true) }), else: hoisted({ ...e, a: a.else, b: underGuard(b, a.c, false) }) } : b.op === "if" ? { op: "if", c: b.c, then: hoisted({ ...e, a: underGuard(a, b.c, true), b: b.then }), else: hoisted({ ...e, a: underGuard(a, b.c, false), b: b.else }) } : a === e.a && b === e.b ? e : { ...e, a, b };
  }
  if (e.op === "mul" || e.op === "proj") {
    const a = hoisted(e.a);
    return a.op === "if" ? { op: "if", c: a.c, then: hoisted({ ...e, a: a.then }), else: hoisted({ ...e, a: a.else }) } : a === e.a ? e : { ...e, a };
  }
  return e;
};
var keysOf = (e) => e.op === "if" ? keysOf(e.then) + keysOf(e.else) : 1;
var liftE = (e) => {
  if (!hasIf(e))
    return e;
  if (e.op === "get" && !e.args) {
    const key = hoisted(liftE(e.key));
    if (key.op !== "if" || keysOf(key) > 8)
      return key === e.key ? e : { ...e, key };
    const at = (k) => k.op === "if" ? { op: "if", c: k.c, then: at(k.then), else: at(k.else) } : { ...e, key: k };
    return at(key);
  }
  const out = {};
  let changed = false;
  for (const [k, x] of Object.entries(e)) {
    const y = x && typeof x === "object" && "op" in x ? k === "c" ? liftC(x) : liftE(x) : x;
    out[k] = y;
    if (y !== x)
      changed = true;
  }
  return changed ? out : e;
};
var liftC = (c) => {
  if (!hasIf(c))
    return c;
  if (c.op === "and" || c.op === "or") {
    const xs = c.xs.map(liftC);
    return xs.every((x, i) => x === c.xs[i]) ? c : { ...c, xs };
  }
  if (c.op === "not") {
    const x = liftC(c.x);
    return x === c.x ? c : { ...c, x };
  }
  if (c.op === "all") {
    const b = liftC(c.c);
    return b === c.c ? c : { ...c, c: b };
  }
  if (c.op === "flag")
    return c;
  const a = liftE(c.a), b = liftE(c.b);
  const guards = new Set, seen = new WeakSet;
  const countGuards = (o) => {
    if (!o || typeof o !== "object" || seen.has(o) || guards.size > 3)
      return;
    seen.add(o);
    const t = o;
    if (t.op === "if")
      guards.add(textOfE(t.c));
    for (const v of Object.values(o))
      countGuards(v);
  };
  if (hasIf(a))
    countGuards(a);
  if (hasIf(b))
    countGuards(b);
  const reads = (e) => textOfE(e).includes('"op":"get"');
  const few = guards.size > 0 && guards.size <= 3, ha = few ? hoisted(a) : a, hb = few ? hoisted(b) : b;
  if (few && (ha.op === "if" && reads(ha) || hb.op === "if" && reads(hb)) && keysOf(ha) * keysOf(hb) <= 8) {
    const split = (x, y) => x.op === "if" ? { op: "or", xs: [{ op: "and", xs: [x.c, split(x.then, y)] }, { op: "and", xs: [{ op: "not", x: x.c }, split(x.else, y)] }] } : y.op === "if" ? { op: "or", xs: [{ op: "and", xs: [y.c, split(x, y.then)] }, { op: "and", xs: [{ op: "not", x: y.c }, split(x, y.else)] }] } : { ...c, a: x, b: y };
    return liftC(split(ha, hb));
  }
  return a === c.a && b === c.b ? c : { ...c, a, b };
};
var liftedKeys = (c) => {
  let x = liftMemo.get(c);
  if (!x)
    liftMemo.set(c, x = liftC(c));
  return x;
};
var pastEnd = new Error("past the deadline");
var eprMeter = { n: 0 };
var eprCap = Infinity;
var pastEprCap = () => eprMeter.n > eprCap;
function withEprCap(units, f) {
  const outer = eprCap;
  eprCap = Math.min(outer, eprMeter.n + units);
  try {
    return f();
  } finally {
    eprCap = outer;
  }
}
var lemmaCache = new Map;
var noRoom = "no values for the model's order";
var breaks = "the abstraction's model breaks";
var factsMemo = new Map;
function factsOf(h0, tick) {
  tick();
  const text = h0 ? JSON.stringify(h0) : "";
  let f = factsMemo.get(text);
  if (f)
    return f;
  const h = h0 && liftedKeys(h0), reads = [], comps = [], bounds = [], seen = new WeakSet;
  const gather = (o) => {
    if (!o || typeof o !== "object" || seen.has(o))
      return;
    seen.add(o);
    tick();
    const x = o;
    if (x.op === "get")
      reads.push(o);
    else if ((x.op === "<" || x.op === "<=" || x.op === "=") && x.a)
      comps.push(o);
    for (const v of Object.values(o))
      gather(v);
  };
  gather(h);
  const unitWalk = (c) => {
    if (!c)
      return;
    if (c.op === "and") {
      c.xs.forEach(unitWalk);
      return;
    }
    if ((c.op === "<=" || c.op === "<") && c.b.op === "const" && (c.a.op === "get" || c.a.op === "var")) {
      const b = c.b.value - (c.op === "<" ? 1 : 0);
      if (b >= 0)
        bounds.push([textOfE(c.a), b]);
    }
  };
  unitWalk(h);
  if (factsMemo.size > 50000)
    factsMemo.clear();
  factsMemo.set(text, f = { h, text, reads, comps, bounds });
  return f;
}
var leavesOf = (e, k, out) => {
  if (e.op === "add") {
    leavesOf(e.a, k, out);
    leavesOf(e.b, k, out);
  } else if (e.op === "mul")
    leavesOf(e.a, k * e.k, out);
  else if (e.op === "if") {
    leavesOf(e.then, k, out);
    leavesOf(e.else, k, out);
  } else if (e.op !== "const")
    out.push([e, k]);
};
var compMemo = new WeakMap;
var compInfo = (c) => {
  let x = compMemo.get(c);
  if (!x) {
    const ts = [], consts = [];
    leavesOf(c.a, 1, ts);
    leavesOf(c.b, -1, ts);
    const k = (e) => {
      if (e.op === "const")
        consts.push(Math.abs(e.value));
      else if (e.op === "add")
        k(e.a), k(e.b);
      else if (e.op === "mul")
        k(e.a);
      else if (e.op === "if")
        k(e.then), k(e.else);
    };
    k(c.a);
    k(c.b);
    compMemo.set(c, x = { ts, top: Math.max(1, ...consts) });
  }
  return { ...x, ta: tupleOf(c.a), tb: tupleOf(c.b) };
};
function stateOf(fs, patterns, tick) {
  const fits = (map, key) => {
    const t = tupleOf(key), p = patterns[map];
    return t && p && sameCoefs(t.coefs, p) ? t : undefined;
  };
  const parts = new Set, fnParts = [], fnSeen = new Set, reads = [];
  for (const f of fs)
    for (const x of f.reads) {
      reads.push(x);
      if (fnMaps.has(x.map)) {
        const n = partName(x), a = partName(x.key);
        if (n && a) {
          if (!fnSeen.has(n))
            fnSeen.add(n), fnParts.push({ f: x.map, n, a });
          parts.add(n);
          parts.add(a);
        }
      } else
        fits(x.map, x.key)?.parts.forEach((p) => parts.add(p));
    }
  const eqs = fs.flatMap((f) => f.comps.flatMap((c) => {
    if (c.op !== "=")
      return [];
    const { ta, tb } = compInfo(c);
    return ta && tb && sameCoefs(ta.coefs, tb.coefs) ? [{ ta, tb }] : [];
  }));
  for (let grew = true;grew; ) {
    grew = false;
    for (const { ta, tb } of eqs)
      if (ta.parts.length > 1 || [...ta.parts, ...tb.parts].some((x) => parts.has(x))) {
        for (const x of [...ta.parts, ...tb.parts])
          if (!parts.has(x)) {
            parts.add(x);
            grew = true;
          }
      }
  }
  const bounded = new Map;
  for (const f of fs)
    for (const [id, b] of f.bounds) {
      const had = bounded.get(id);
      if (had === undefined || b < had)
        bounded.set(id, b);
    }
  const ordMaps = new Set, ordScalars = new Set;
  const exactOf = (e) => e.op === "get" ? !ordMaps.has(e.map) ? bounded.get(textOfE(e)) : undefined : e.op === "var" && !parts.has(e.name) && !ordScalars.has(e.name) ? bounded.get(textOfE(e)) : undefined;
  const caps = new Map;
  const termKey = (e) => e.op === "var" && !parts.has(e.name) ? `s:${e.name}` : e.op === "get" ? `c:${e.map}` : undefined;
  const ofParts = (t) => t?.parts.every((x) => parts.has(x));
  const ordComps = [];
  for (const f of fs)
    for (const c of f.comps) {
      const ci = compInfo(c);
      let ex = 0;
      for (const [e, k] of ci.ts) {
        const x = exactOf(e);
        if (x !== undefined)
          ex += Math.abs(k) * x;
      }
      const top = ci.top + ex + 1;
      for (const [e] of ci.ts) {
        const t = termKey(e);
        if (t)
          caps.set(t, Math.max(caps.get(t) ?? 1, top));
      }
      if (!(ofParts(ci.ta) && ofParts(ci.tb)))
        ordComps.push(ci.ts);
    }
  let grew = true;
  const ordWalk = (ts) => {
    const hasPart = ts.some(([e]) => ((n) => n !== undefined && parts.has(n))(partName(e)));
    const nonPart = ts.filter(([e]) => (hasPart || exactOf(e) === undefined) && (e.op === "get" && !fnMaps.has(e.map) || e.op === "var" && !parts.has(e.name)));
    const tn = ts.filter(([e]) => hasPart || exactOf(e) === undefined), mixed = nonPart.length && tn.length > 1 && tn.some((t) => t[1] > 0) && tn.some((t) => t[1] < 0);
    const beside = nonPart.some(([e]) => e.op === "get" && ordMaps.has(e.map) || e.op === "var" && ordScalars.has(e.name));
    if (mixed || beside)
      for (const [e] of nonPart) {
        if (e.op === "get" && !ordMaps.has(e.map)) {
          ordMaps.add(e.map);
          grew = true;
        } else if (e.op === "var" && !ordScalars.has(e.name)) {
          ordScalars.add(e.name);
          grew = true;
        }
      }
  };
  while (grew) {
    grew = false;
    ordComps.forEach((ts) => (tick(), ordWalk(ts)));
  }
  const sorted = (xs) => [...xs].map((x) => String(x)).sort((a, b) => a < b ? -1 : a > b ? 1 : 0);
  return { parts, fnParts, bounded, caps, ordMaps, ordScalars, reads, sig: JSON.stringify([JSON.stringify(patterns), sorted(parts), sorted(caps), sorted(ordMaps), sorted(ordScalars)]) };
}
var incOn = env.GDP_EPR_INC !== "0";
var pool = new Map;
var other = "another encoder's goal";
function decide0(goal, patterns, opts) {
  let ticks = 0;
  const tick = () => {
    eprMeter.n++;
    if ((++ticks & 4095) === 0 && opts.late?.())
      throw pastEnd;
  };
  const fs = goal.hyps.map((h) => factsOf(h, tick));
  const shapedOf = (f) => f.reads.every((x) => fnMaps.has(x.map) ? partName(x) !== undefined : ((t) => !!t && !!patterns[x.map] && sameCoefs(t.coefs, patterns[x.map]))(x.args ? undefined : tupleOf(x.key)));
  if (decideHook.on)
    lastShaped = fs.map(shapedOf);
  const last = fs.at(-1);
  if (last && !shapedOf(last) && last.reads.some((x) => !fnMaps.has(x.map) && (x.args || !tupleOf(x.key))))
    return { unknown: "the conclusion is not EPR-shaped" };
  const st = stateOf(fs, patterns, tick);
  if (!incOn || opts.fill || opts.fresh)
    return encoder(st, patterns).decide(goal, fs, st, opts);
  let enc = pool.get(st.sig);
  if (enc)
    pool.delete(st.sig);
  else if (pool.size >= 4)
    pool.delete(pool.keys().next().value);
  let d = enc?.decide(goal, fs, st, opts);
  if (!d || "unknown" in d && d.unknown === other)
    d = (enc = encoder(st, patterns)).decide(goal, fs, st, opts);
  if (enc.size() < 20000)
    pool.set(st.sig, enc);
  return d;
}
function encoder(st, patterns) {
  const { parts, bounded, caps, ordMaps, ordScalars } = st;
  const fits = (map, key) => {
    const t = tupleOf(key), p = patterns[map];
    return t && p && sameCoefs(t.coefs, p) ? t : undefined;
  };
  const exactOf = (e) => e.op === "get" ? !ordMaps.has(e.map) ? bounded.get(textOfE(e)) : undefined : e.op === "var" && !parts.has(e.name) && !ordScalars.has(e.name) ? bounded.get(textOfE(e)) : undefined;
  let tick = () => {
    eprMeter.n++;
  };
  let use = { ords: [], fins: [], opq: [], succ: [] };
  const ids = new Map, names = [""], kept = new Set, first = new Set;
  const atom = (key) => {
    let v2 = ids.get(key);
    if (v2 === undefined) {
      v2 = names.length;
      ids.set(key, v2);
      names.push(key);
    }
    return { k: "v", v: v2 };
  };
  const pairAtoms = (tag) => {
    const byA = new Map;
    return (a, b) => {
      let in2 = byA.get(a);
      if (!in2)
        byA.set(a, in2 = new Map);
      let f = in2.get(b);
      if (!f) {
        in2.set(b, f = atom(`${tag} ${a} ${b}`));
        if (tag === "le")
          kept.add(f.v);
      }
      return f;
    };
  };
  const eqAt = pairAtoms("eq"), leAt = pairAtoms("le");
  const eq = (x, y) => x === y ? T : x < y ? eqAt(x, y) : eqAt(y, x);
  const ords = new Set(["k:0", ...[...parts].map((x) => `p:${x}`)]);
  const touch = (id) => {
    ords.add(id);
    use.ords.push(id);
  };
  const le = (a, b) => a === b ? T : leAt(a, b);
  const ltAt = (x, c) => {
    if (c <= 0)
      return Fa;
    touch(`k:${c}`);
    return not(le(`k:${c}`, `p:${x}`));
  };
  const fins = new Map, finsList = [];
  const finAt = (f, v2) => atom(`val ${f.id} ${v2}`);
  const newFin = (id, cap, ex, more, bkey) => {
    const f = { id, cap: ex ?? cap, bkey, ...ex !== undefined ? { exact: true } : {}, ...more };
    fins.set(id, f);
    finsList.push(f);
    const ls = Array.from({ length: f.cap + 1 }, (_, val) => v2(finAt(f, val)));
    first.add(ls[0]);
    if (!f.exact)
      add(ls, -1);
    else {
      exactFins.set(bkey, f);
      for (const b of boundBy.get(bkey) ?? [])
        if (b.b === f.cap)
          add([-b.a, ...ls], b.gid);
    }
    for (let i = 0;i < ls.length; i++)
      for (let j = i + 1;j < ls.length; j++)
        add([-ls[i], -ls[j]], -1);
    return f;
  };
  const finOf = (e) => {
    const f = finOf0(e);
    if (f)
      use.fins.push(f);
    return f;
  };
  const finOf0 = (e) => {
    if (e.op === "get" && (ordMaps.has(e.map) || fnMaps.has(e.map)) || e.op === "var" && ordScalars.has(e.name))
      return;
    const ex = exactOf(e);
    if (e.op === "var" && !parts.has(e.name)) {
      const id = `s:${e.name}`;
      return fins.get(id) ?? newFin(id, caps.get(id) ?? 1, ex, {}, textOfE(e));
    }
    if (e.op === "get" && !e.args && !fits(e.map, e.key)) {
      const id = `c:${e.map}#${textOfE(e.key)}`;
      return fins.get(id) ?? newFin(id, caps.get(`c:${e.map}`) ?? 1, ex, { map: e.map, key: e.key }, textOfE(e));
    }
    if (e.op === "get") {
      const t = tupleOf(e.key), id = `c:${e.map}(${t.parts.join(",")})`;
      return fins.get(id) ?? newFin(id, caps.get(`c:${e.map}`) ?? 1, ex, { map: e.map, parts: t.parts }, textOfE(e));
    }
    return;
  };
  const boundBy = new Map, exactFins = new Map;
  const ordInfo = new Map;
  const ordOf = (e) => {
    if (e.op === "const") {
      const id = `k:${e.value}`;
      touch(id);
      return id;
    }
    const pn = partName(e);
    if (pn !== undefined && parts.has(pn)) {
      touch(`p:${pn}`);
      return `p:${pn}`;
    }
    if (e.op === "var") {
      if (ordScalars.has(e.name)) {
        touch(`s:${e.name}`);
        return `s:${e.name}`;
      }
      return;
    }
    if (e.op === "get" && fnMaps.has(e.map)) {
      const id = `c:${e.map}#${textOfE(e.key)}`;
      touch(id);
      return id;
    }
    if (e.op === "get" && ordMaps.has(e.map) && !e.args) {
      const t = fits(e.map, e.key);
      const id = t ? `c:${e.map}(${t.parts.join(",")})` : `c:${e.map}#${textOfE(e.key)}`;
      if (!ordInfo.has(id))
        ordInfo.set(id, t ? { map: e.map, parts: t.parts } : { map: e.map, key: e.key });
      touch(id);
      return id;
    }
    return;
  };
  const ordCases = (e) => {
    if (e.op === "if") {
      const c = lit(e.c), a = ordCases(e.then), b = ordCases(e.else);
      return a && b ? [...a.map((x) => ({ ...x, g: and([c, x.g]) })), ...b.map((x) => ({ ...x, g: and([not(c), x.g]) }))] : undefined;
    }
    if (e.op === "add" && e.b.op === "const") {
      const a = ordCases(e.a);
      return a?.map((x) => ({ ...x, o: x.o + e.b.value }));
    }
    if (e.op === "add" && e.a.op === "const") {
      const b = ordCases(e.b);
      return b?.map((x) => ({ ...x, o: x.o + e.a.value }));
    }
    const t = ordOf(e);
    return t ? [{ g: T, t, o: 0 }] : undefined;
  };
  const succs = [], succAt = new Map;
  const ordAtom = (t1, t2, d, op) => {
    const num = (x) => x.startsWith("k:") ? Number(x.slice(2)) : undefined, n1 = num(t1), n2 = num(t2);
    if (n1 !== undefined && n2 !== undefined) {
      const x = n1 - n2 + d;
      return { k: "c", b: op === "<" ? x < 0 : op === "<=" ? x <= 0 : x === 0 };
    }
    if (n2 !== undefined && d !== 0) {
      const c = n2 - d;
      if (c < 0)
        return Fa;
      touch(`k:${c}`);
      return ordAtom(t1, `k:${c}`, 0, op);
    }
    if (n1 !== undefined && d !== 0) {
      const c = n1 + d;
      if (c < 0)
        return op === "=" ? Fa : T;
      touch(`k:${c}`);
      return ordAtom(`k:${c}`, t2, 0, op);
    }
    const D = op === "<" ? d + 1 : d;
    if (op === "=") {
      if (d === 0)
        return and([le(t1, t2), le(t2, t1)]);
      if (Math.abs(d) !== 1)
        return;
      const [lo, hi] = d === -1 ? [t2, t1] : [t1, t2], s = atom(`succ ${lo} ${hi}`);
      let si = succAt.get(s.v);
      if (si === undefined) {
        succAt.set(s.v, si = succs.length);
        succs.push({ s: s.v, lo, hi });
      }
      use.succ.push(si);
      return s;
    }
    return D === 0 ? le(t1, t2) : D === 1 ? not(le(t2, t1)) : undefined;
  };
  const ordered = (ts, d, op) => {
    let a, b, dd = d;
    if (ts.length === 2 && ts[0][1] === 1 && ts[1][1] === -1)
      [a, b] = [ts[0][0], ts[1][0]];
    else if (ts.length === 2 && ts[0][1] === -1 && ts[1][1] === 1)
      [a, b] = [ts[1][0], ts[0][0]];
    else if (ts.length === 1 && ts[0][1] === 1) {
      a = ts[0][0];
      if (-d < 0)
        return Fa;
      b = { op: "const", value: -d };
      dd = 0;
    } else if (ts.length === 1 && ts[0][1] === -1) {
      b = ts[0][0];
      if (d < 0)
        return op === "<" || op === "<=" ? T : Fa;
      a = { op: "const", value: d };
      dd = 0;
    } else
      return;
    const ca = ordCases(a), cb = ordCases(b);
    if (!ca || !cb || ca.length * cb.length > 256)
      return;
    const out = [];
    for (const x of ca)
      for (const y of cb) {
        const at = ordAtom(x.t, y.t, dd + x.o - y.o, op);
        if (!at)
          return;
        out.push(and([x.g, y.g, at]));
      }
    return or(out);
  };
  const cases = (e) => {
    if (e.op === "const")
      return [{ g: T, n: e.value }];
    if (e.op === "if") {
      const c = lit(e.c), a = cases(e.then), b = cases(e.else);
      return a && b ? [...a.map((x) => ({ ...x, g: and([c, x.g]) })), ...b.map((x) => ({ ...x, g: and([not(c), x.g]) }))] : undefined;
    }
    const f = finOf(e);
    return f ? [{ g: T, f }] : undefined;
  };
  const exactSub = (e) => {
    const ta = [], tb = [], da = { c: 0 }, db = { c: 0 };
    if (!linTerms(e.a, 1, ta, da) || !linTerms(e.b, 1, tb, db) || db.c > da.c)
      return false;
    const have = new Map;
    for (const [x, c] of ta)
      have.set(x, (have.get(x) ?? 0) + c);
    return tb.every(([x, c]) => (have.get(x) ?? 0) >= c);
  };
  const sum = (e, k, ts, d) => e.op === "const" ? (d.c += k * e.value, true) : e.op === "add" ? sum(e.a, k, ts, d) && sum(e.b, k, ts, d) : e.op === "mul" ? sum(e.a, k * e.k, ts, d) : e.op === "sub" && exactSub(e) ? sum(e.a, k, ts, d) && sum(e.b, -k, ts, d) : (ts.push([e, k]), true);
  const tlin = (e) => {
    if (e.op === "const")
      return konst(e.value);
    if (e.op === "add") {
      const a = tlin(e.a), b = tlin(e.b);
      return a && b ? plus(a, b) : undefined;
    }
    if (e.op === "mul") {
      const a = tlin(e.a);
      return a && times(a, e.k);
    }
    const t = ordOf(e);
    return t === undefined ? undefined : t.startsWith("k:") ? konst(Number(t.slice(2))) : v(t);
  };
  const opqs = new Map;
  const opaque = (c, more) => {
    const a = atom(`op ${textOfE(c)}`);
    let o = opqs.get(a.v);
    if (!o) {
      const outer = use;
      use = { ords: [], fins: [], opq: [], succ: [] };
      let keyOnly = true;
      const wk = (q) => {
        if (!keyOnly || !q || typeof q !== "object")
          return;
        const x = q;
        if (x.op === "get" && !fnMaps.has(x.map) && !ordMaps.has(x.map) || x.op === "var" && !parts.has(x.name) && !ordScalars.has(x.name)) {
          keyOnly = false;
          return;
        }
        for (const y of Object.values(q))
          wk(y);
      };
      wk(c);
      opqs.set(a.v, o = { foreign: !keyOnly, tied: !!more, ords: [] });
      more?.(a.v);
      if (keyOnly && (c.op === "<" || c.op === "<=" || c.op === "=")) {
        const ta = tlin(c.a), tb = tlin(c.b);
        if (ta && tb) {
          o.row = { x: a.v, op: c.op, d: plus(ta, times(tb, -1)) };
          kept.add(a.v);
        }
      }
      o.ords = use.ords;
      outer.fins.push(...use.fins);
      outer.succ.push(...use.succ);
      use = outer;
    }
    use.opq.push(a.v);
    use.ords.push(...o.ords);
    return a;
  };
  const baseOf = (coefs, i) => coefs[i - 1] / coefs[i];
  const pairs = new Map;
  const comparison = (c) => {
    if (c.op === "=") {
      const ta = tupleOf(c.a), tb = tupleOf(c.b);
      if (ta && tb && sameCoefs(ta.coefs, tb.coefs) && [...ta.parts, ...tb.parts].every((p) => parts.has(p))) {
        return opaque(c, (pv) => {
          const es = ta.parts.map((x, i) => eq(x, tb.parts[i]));
          add([...es.map((e) => e.k === "v" ? -e.v : 0).filter(Boolean), pv], -1);
          const bd = ta.bounds.flatMap((b, i) => b === undefined ? [] : [v2(ltAt(ta.parts[i], b)), v2(ltAt(tb.parts[i], b))]);
          for (const e of es)
            if (e.k === "v")
              add([-pv, ...bd.map((l) => -l), e.v], -1);
        });
      }
    }
    const ts = [], d = { c: 0 };
    sum(c.a, 1, ts, d);
    sum(c.b, -1, ts, d);
    if (ts.length === 1 && ts[0][0].op === "var" && parts.has(ts[0][0].name) && Math.abs(ts[0][1]) === 1 && c.op !== "=") {
      const [[x, s]] = ts, k = -d.c * s;
      const strict = c.op === "<";
      return s === 1 ? ltAt(x.name, strict ? k : k + 1) : not(ltAt(x.name, strict ? k + 1 : k));
    }
    if (c.op !== "=" && ts.length && ts.every(([e]) => e.op === "var" && parts.has(e.name))) {
      const merged = new Map;
      for (const [e, k] of ts)
        merged.set(e.name, (merged.get(e.name) ?? 0) + k);
      const pos = [...merged].filter((t) => t[1] > 0).sort((a, b) => b[1] - a[1]), neg = [...merged].filter((t) => t[1] < 0).map(([x, k]) => [x, -k]).sort((a, b) => b[1] - a[1]);
      const k0 = d.c + (c.op === "<" ? 1 : 0);
      const chainOf = (ts2) => ts2.map((t) => t[1]);
      const isChain = (cs) => cs.length > 0 && cs.every((x, i) => i + 1 >= cs.length || x % cs[i + 1] === 0 && x / cs[i + 1] >= 2);
      const prefix = (full, pre) => pre.length < full.length && pre.every((x, i) => x === full[i]);
      const lo = k0 === 0 && chainOf(neg).at(-1) === 1 && isChain(chainOf(neg)) && prefix(chainOf(neg), chainOf(pos));
      const hi = chainOf(pos).at(-1) === 1 && isChain(chainOf(pos)) && prefix(chainOf(pos), chainOf(neg)) && neg.length > 0 && k0 === 1 - neg.at(-1)[1];
      if (lo || hi) {
        const X = (lo ? neg : pos).map((t) => t[0]), L = (lo ? pos : neg).map((t) => t[0]), coefs = chainOf(lo ? neg : pos), kind = lo ? "lo" : "hi";
        return opaque(c, (pv) => {
          const pe = L.map((y, i) => eq(X[i], y));
          const lowBounded = X.flatMap((x, i) => i >= L.length ? [v2(ltAt(x, baseOf(coefs, i)))] : []);
          add([...pe.filter((e) => e.k === "v").map((e) => -e.v), ...kind === "hi" ? lowBounded.map((l) => -l) : [], pv], -1);
          const key = `${X.join(",")}|${L.join(",")}`, pr = pairs.get(key) ?? { X, L, coefs };
          const had = pr.lo !== undefined && pr.hi !== undefined;
          pr[kind] = pv;
          pairs.set(key, pr);
          if (had || pr.lo === undefined || pr.hi === undefined)
            return;
          const bd = [...pr.X.flatMap((x, i) => i ? [v2(ltAt(x, baseOf(pr.coefs, i)))] : []), ...pr.L.flatMap((y, i) => i ? [v2(ltAt(y, baseOf(pr.coefs, i)))] : [])];
          for (const [i, y] of pr.L.entries()) {
            const e = eq(pr.X[i], y);
            if (e.k === "v")
              add([-pr.lo, -pr.hi, ...bd.map((l) => -l), e.v], -1);
          }
        });
      }
    }
    {
      const reads = (e) => e.op === "get" ? ordMaps.has(e.map) || fnMaps.has(e.map) : e.op === "var" ? ordScalars.has(e.name) || parts.has(e.name) : e.op === "if" ? reads(e.then) || reads(e.else) : e.op === "add" ? reads(e.a) || reads(e.b) : false;
      if (ts.some(([e]) => reads(e))) {
        const f = ordered(ts, d.c, c.op);
        if (f)
          return f;
      }
    }
    const cs = ts.length ? ts.map(([e]) => cases(e)) : [], loose = ts.filter((_, i) => !cs[i]?.every((y) => y.n !== undefined || y.f.exact));
    if (ts.length && (loose.every((t) => t[1] > 0) || loose.every((t) => t[1] < 0))) {
      if (cs.every(Boolean)) {
        const holds = (v2) => c.op === "<" ? v2 < 0 : c.op === "<=" ? v2 <= 0 : v2 === 0;
        const out = [];
        let combos = 0;
        const go = (i, acc, g) => {
          if (++combos > 4096)
            return false;
          if (i === ts.length) {
            if (holds(acc + d.c))
              out.push(and(g));
            return true;
          }
          for (const x of cs[i]) {
            if (x.n !== undefined) {
              if (!go(i + 1, acc + ts[i][1] * x.n, [...g, x.g]))
                return false;
              continue;
            }
            for (let v2 = 0;v2 <= x.f.cap; v2++)
              if (!go(i + 1, acc + ts[i][1] * v2, [...g, x.g, finAt(x.f, v2)]))
                return false;
          }
          return true;
        };
        if (go(0, 0, []))
          return or(out);
      }
    }
    if (!ts.length)
      return { k: "c", b: c.op === "<" ? d.c < 0 : c.op === "<=" ? d.c <= 0 : d.c === 0 };
    return opaque(c);
  };
  const lit = (c) => {
    switch (c.op) {
      case "and":
        return and(c.xs.map(lit));
      case "or":
        return or(c.xs.map(lit));
      case "not":
        return not(lit(c.x));
      case "<":
      case "<=":
      case "=":
        return comparison(c);
      case "all":
      case "flag":
        return opaque(c);
    }
  };
  const solver = cdclSolver(first, kept);
  const add = (lits, from) => {
    tick();
    if (lits.length <= 4) {
      const out = [];
      for (const l of lits) {
        if (out.includes(-l))
          return;
        if (!out.includes(l))
          out.push(l);
      }
      solver.add({ lits: out, from });
      return;
    }
    const s = new Set(lits);
    for (const l of s)
      if (s.has(-l))
        return;
    solver.add({ lits: [...s], from });
  };
  let fresh = 0;
  const tseitin = (f) => {
    if (f.k === "v")
      return f.v;
    if (f.k === "not")
      return -tseitin(f.x);
    if (f.k === "c") {
      const g = ++fresh + 1e6;
      add([f.b ? g : -g], -1);
      return g;
    }
    const ls = f.xs.map((x) => tseitin(x)), g = ++fresh + 1e6;
    if (f.k === "and") {
      for (const l of ls)
        add([-g, l], -1);
      add([g, ...ls.map((l) => -l)], -1);
    } else {
      add([-g, ...ls], -1);
      for (const l of ls)
        add([g, -l], -1);
    }
    return g;
  };
  const top = (f, from, ng) => {
    if (f.k === "and") {
      for (const x of f.xs)
        top(x, from, ng);
      return;
    }
    if (f.k === "c") {
      if (!f.b)
        add([ng], from);
      return;
    }
    if (f.k === "or" && f.xs.every((x) => x.k === "v" || x.k === "not" && x.x.k === "v")) {
      add([ng, ...f.xs.map((x) => x.k === "v" ? x.v : -x.x.v)], from);
      return;
    }
    add([ng, tseitin(f)], from);
  };
  const v2 = (f) => f.k === "v" ? f.v : f.k === "not" && f.x.k === "v" ? -f.x.v : undefined;
  const hyps = new Map;
  const encode = (f) => {
    let hp = hyps.get(f.text);
    if (hp)
      return hp;
    const gid = hyps.size, a = ++fresh + 1e6;
    use = { ords: [], fins: [], opq: [], succ: [] };
    for (const [k, b] of f.bounds) {
      let xs = boundBy.get(k);
      if (!xs)
        boundBy.set(k, xs = []);
      xs.push({ a, gid, b });
      const ef = exactFins.get(k);
      if (ef && ef.cap === b)
        add([-a, ...Array.from({ length: b + 1 }, (_, val) => v2(finAt(ef, val)))], gid);
    }
    tick();
    if (f.h)
      top(lit(f.h), gid, -a);
    hp = { a, gid, use };
    hyps.set(f.text, hp);
    return hp;
  };
  const num = (x) => x.startsWith("k:") ? Number(x.slice(2)) : undefined;
  const os = [], cellsBy = new Map, ordCellsBy = new Map, fnAll = [], fnSeen = new Set, discrete = new Set;
  let nFins = 0, nSuccs = 0, nFn = 0, lazy = false;
  const pairsOn = (xs, from, f) => {
    for (let j = from;j < xs.length; j++)
      for (let i = 0;i < j; i++)
        f(xs[i], xs[j]);
  };
  const close = (gst) => {
    for (;nFins < finsList.length; nFins++) {
      const b = finsList[nFins];
      if (!b.map || !b.parts)
        continue;
      let cells = cellsBy.get(b.map);
      if (!cells)
        cellsBy.set(b.map, cells = []);
      cells.push(b);
      for (const a of cells.slice(0, -1)) {
        const es = a.parts.map((x, k) => v2(eq(x, b.parts[k]))), cap = Math.max(a.cap, b.cap);
        const pre = es.filter((e) => e !== undefined).map((e) => -e);
        for (let val = 0;val <= cap; val++) {
          const la = val <= a.cap ? v2(finAt(a, val)) : undefined, lb = val <= b.cap ? v2(finAt(b, val)) : undefined;
          if (la !== undefined)
            add([...pre, -la, ...lb !== undefined ? [lb] : []], -1);
          if (lb !== undefined)
            add([...pre, -lb, ...la !== undefined ? [la] : []], -1);
        }
      }
    }
    const o0 = os.length, all0 = [...ords];
    for (let i = o0;i < all0.length; i++)
      os.push(all0[i]);
    if (os.length > 64)
      lazy = true;
    pairsOn(os, o0, (a, b) => {
      add([v2(le(a, b)), v2(le(b, a))], -1);
      const na = num(a), nb = num(b);
      if (na !== undefined && nb !== undefined) {
        add([na <= nb ? v2(le(a, b)) : -v2(le(a, b))], -1);
        add([nb <= na ? v2(le(b, a)) : -v2(le(b, a))], -1);
      }
      if (a.startsWith("p:") && b.startsWith("p:")) {
        const e = v2(eq(a.slice(2), b.slice(2))), x = v2(le(a, b)), y = v2(le(b, a));
        add([-e, x], -1);
        add([-e, y], -1);
        add([e, -x, -y], -1);
      }
    });
    for (const x of os.slice(o0))
      if (x !== "k:0")
        add([v2(le("k:0", x))], -1);
    for (const c of os.map(num).filter((n) => n !== undefined))
      if (ords.has(`k:${c + 1}`)) {
        for (const x of os)
          if (!x.startsWith("k:") && !discrete.has(`${c}|${x}`)) {
            discrete.add(`${c}|${x}`);
            add([v2(le(x, `k:${c}`)), v2(le(`k:${c + 1}`, x))], -1);
          }
      }
    if (!lazy) {
      for (let m = o0;m < os.length; m++)
        for (let x = 0;x < m; x++)
          for (let y = 0;y < m; y++)
            if (x !== y) {
              const t = os[m], p = os[x], q = os[y];
              add([-v2(le(t, p)), -v2(le(p, q)), v2(le(t, q))], -1);
              add([-v2(le(p, t)), -v2(le(t, q)), v2(le(p, q))], -1);
              add([-v2(le(p, q)), -v2(le(q, t)), v2(le(p, t))], -1);
            }
    }
    for (const fp of gst.fnParts)
      if (!fnSeen.has(fp.n)) {
        fnSeen.add(fp.n);
        fnAll.push(fp);
      }
    for (let j = nFn;j < fnAll.length; j++)
      for (let i = 0;i < j; i++) {
        const x = fnAll[i], y = fnAll[j];
        if (x.f === y.f && x.n !== y.n) {
          const a = v2(eq(x.a, y.a)), b = v2(eq(x.n, y.n));
          if (a !== undefined && b !== undefined)
            add([-a, b], -1);
        }
      }
    nFn = fnAll.length;
    for (let k = 0;k < succs.length; k++) {
      const { s, lo, hi } = succs[k];
      if (k >= nSuccs)
        add([-s, -v2(le(hi, lo))], -1);
      for (const z of k >= nSuccs ? os : os.slice(o0))
        if (z !== lo && z !== hi)
          add([-s, v2(le(z, lo)), v2(le(hi, z))], -1);
    }
    nSuccs = succs.length;
    for (const x of os.slice(o0)) {
      const inf = ordInfo.get(x);
      if (inf?.parts) {
        let cs = ordCellsBy.get(inf.map);
        if (!cs)
          ordCellsBy.set(inf.map, cs = []);
        cs.push(x);
      }
    }
    for (const [, cells] of ordCellsBy) {
      const from = cells.findIndex((x) => os.indexOf(x) >= o0);
      if (from >= 0)
        pairsOn(cells, from, (a, b) => {
          const pa = ordInfo.get(a).parts, pb = ordInfo.get(b).parts, pre = pa.map((x, k) => v2(eq(x, pb[k]))).filter((e) => e !== undefined).map((e) => -e);
          add([...pre, v2(le(a, b))], -1);
          add([...pre, v2(le(b, a))], -1);
        });
    }
  };
  const lemmasIn = new Set;
  let lastGoal = "";
  const seedLemmas = () => {
    for (const [key, l] of lemmaCache) {
      if (lemmasIn.has(key))
        continue;
      const xs = l.map(([k, b]) => {
        const x = ids.get(k);
        return x === undefined ? undefined : b ? x : -x;
      });
      if (xs.every((x) => x !== undefined)) {
        lemmasIn.add(key);
        add(xs, -1);
      }
    }
  };
  const decideGoal = (goal, fs, gst, opts) => {
    tick = () => {
      eprMeter.n++;
      if ((++ticks & 4095) === 0 && opts.late?.())
        throw pastEnd;
    };
    let ticks = 0;
    const hs = fs.map(encode), gOrds = new Set(["k:0", ...[...parts].map((x) => `p:${x}`)]), gFins = new Set, gOpq = new Set, gSuccs = new Set;
    for (const h of hs) {
      for (const x of h.use.ords)
        gOrds.add(x);
      for (const f of h.use.fins)
        gFins.add(f);
      for (const x of h.use.opq)
        gOpq.add(x);
      for (const x of h.use.succ)
        gSuccs.add(x);
    }
    if (opts.fill) {
      const cs = [...gOrds].filter((x) => x.startsWith("k:")).map((x) => Number(x.slice(2))).sort((a, b) => a - b);
      for (let i = 0;i + 1 < cs.length; i++)
        if (cs[i + 1] - cs[i] <= 4)
          for (let c = cs[i] + 1;c < cs[i + 1]; c++) {
            ords.add(`k:${c}`);
            gOrds.add(`k:${c}`);
          }
    }
    for (const f of gFins)
      if (gst.bounded.get(f.bkey) !== (f.exact ? f.cap : undefined))
        return { unknown: other };
    if (gOrds.size > 512 || ords.size > 512) {
      over = true;
      return { unknown: `${gOrds.size} ordered terms` };
    }
    close(gst);
    const theory = [...gOpq].flatMap((x) => {
      const o = opqs.get(x);
      return !o.foreign && o.row ? [o.row] : [];
    });
    if (theory.length && !opts.fresh)
      seedLemmas();
    const loose = opts.exact ? [...gOpq].filter((x) => {
      const o = opqs.get(x);
      return o.foreign && !o.tied;
    }) : [];
    if (opts.late?.())
      return { unknown: "past the deadline" };
    if (goal.name !== lastGoal)
      solver.fresh();
    lastGoal = goal.name;
    const assume = [...new Set(hs.map((h) => h.a))], index = new Map;
    hs.forEach((h, i) => {
      if (!index.has(h.gid))
        index.set(h.gid, i);
    });
    const lemma = (lits) => add(lits, -1);
    const gos = [...gOrds];
    const search = () => {
      let o = solver.solve(opts.conflicts ?? 200000, opts.late, assume);
      for (let round = 0;lazy && o?.sat; round++) {
        const m = o.model, at = (a, b) => a === b || m[v2(le(a, b))] === true, broken = [];
        for (const a of gos)
          for (const b of gos)
            if (a !== b && at(a, b)) {
              for (const c of gos)
                if (c !== a && c !== b && at(b, c) && !at(a, c) && broken.length < 4096)
                  broken.push([-v2(le(a, b)), -v2(le(b, c)), v2(le(a, c))]);
            }
        if (!broken.length)
          break;
        if (round === 16 || opts.late?.())
          return "the order's transitivity, lazily, did not settle";
        for (const c of broken)
          lemma(c);
        o = solver.solve(opts.conflicts ?? 200000, opts.late, assume);
      }
      return o;
    };
    const groupsOf = (m) => {
      const leq = (a, b) => a === b || m[v2(le(a, b))] === true;
      const os2 = [...gos].sort((a, b) => leq(a, b) && !leq(b, a) ? -1 : leq(b, a) && !leq(a, b) ? 1 : 0), groups = [];
      for (let i = 0;i < os2.length; ) {
        let j = i;
        while (j < os2.length && leq(os2[j], os2[i]) && leq(os2[i], os2[j]))
          j++;
        groups.push(os2.slice(i, j));
        i = j;
      }
      return groups;
    };
    const succList = [...gSuccs].map((k) => succs[k]);
    const theoryTerms = [...new Set(theory.flatMap((t) => Object.keys(t.d).filter((x) => x !== "1")))];
    const feasible = [], locals = [];
    const localOf = (ti, t, ks) => {
      if (locals[ti])
        return locals[ti];
      const xs = Object.keys(t.d).filter((x) => x !== "1"), out = [t.x];
      for (let i2 = 0;i2 < xs.length; i2++)
        for (const b of [...xs.slice(i2 + 1), ...ks])
          for (const [p, q] of [[xs[i2], b], [b, xs[i2]]]) {
            const x = v2(le(p, q));
            if (x !== undefined)
              out.push(x);
          }
      return locals[ti] = out;
    };
    const jointLp = new Simplex(true);
    const pairs0 = new Map;
    const pairOf = (a, b) => {
      const key = `${a}|${b}`;
      let p = pairs0.get(key);
      if (!p) {
        const T = (t) => t.startsWith("k:") ? konst(Number(t.slice(2))) : v(t);
        p = { ab: v2(le(a, b)), ba: v2(le(b, a)), rows: [plus(T(a), times(T(b), -1)), plus(plus(T(b), konst(1)), times(T(a), -1)), plus(T(b), times(T(a), -1)), plus(plus(T(a), konst(1)), times(T(b), -1))] };
        pairs0.set(key, p);
      }
      return p;
    };
    const theoryCheck = (m) => {
      const T = (t) => t.startsWith("k:") ? konst(Number(t.slice(2))) : v(t);
      const theoryRows = (row) => {
        for (const t of theory) {
          const holds = m[t.x] === true;
          if (t.op === "=") {
            if (holds) {
              row(t.d, [t.x]);
              row(times(t.d, -1), [t.x]);
            }
            continue;
          }
          if (holds)
            row(t.op === "<" ? plus(t.d, konst(1)) : t.d, [t.x]);
          else
            row(t.op === "<" ? times(t.d, -1) : plus(times(t.d, -1), konst(1)), [-t.x]);
        }
      };
      const lemmaOf = (r, lits) => {
        if (r.kind !== "refuted")
          return;
        const used = new Set;
        for (const s of r.steps)
          if (s.kind === "input")
            for (const l of lits[s.index])
              used.add(l);
        return used.size ? [...used].map((l) => -l) : undefined;
      };
      const pairRows = (row, a, b) => {
        const p = pairOf(a, b);
        if (m[p.ab] === true)
          row(p.rows[0], [p.ab]);
        else
          row(p.rows[1], [-p.ab]);
        if (m[p.ba] === true)
          row(p.rows[2], [p.ba]);
        else
          row(p.rows[3], [-p.ba]);
      };
      {
        const ks = gos.filter((t) => t.startsWith("k:")), lemmas = [];
        for (const [ti, t] of theory.entries()) {
          const local = localOf(ti, t, ks), seen = feasible[ti] ??= new Set, key = local.map((l) => m[l] === true ? "1" : "0").join("");
          if (seen.has(key))
            continue;
          const rows = [], lits = [], row = (lin, ls) => {
            rows.push({ lin, label: "" });
            lits.push(ls);
          };
          const xs = Object.keys(t.d).filter((x) => x !== "1");
          for (const x of xs)
            row(times(v(x), -1), []);
          for (let i2 = 0;i2 < xs.length; i2++) {
            for (let j = i2 + 1;j < xs.length; j++)
              pairRows(row, xs[i2], xs[j]);
            for (const k2 of ks)
              pairRows(row, xs[i2], k2);
          }
          const holds = m[t.x] === true;
          if (t.op === "=") {
            if (holds) {
              row(t.d, [t.x]);
              row(times(t.d, -1), [t.x]);
            } else
              continue;
          } else if (holds)
            row(t.op === "<" ? plus(t.d, konst(1)) : t.d, [t.x]);
          else
            row(t.op === "<" ? times(t.d, -1) : plus(times(t.d, -1), konst(1)), [-t.x]);
          const l = lemmaOf(solve(rows), lits);
          if (l)
            lemmas.push(l);
          else
            seen.add(key);
        }
        if (lemmas.length)
          return { lemmas };
      }
      {
        const rows = [], lits = [], row = (lin, ls) => {
          rows.push({ lin, label: "" });
          lits.push(ls);
        };
        const ks = gos.filter((t) => t.startsWith("k:")), pairs2 = new Map;
        for (const t of theory) {
          const xs = Object.keys(t.d).filter((x) => x !== "1");
          for (const a of xs)
            for (const b of [...xs, ...ks])
              if (a !== b)
                pairs2.set(a < b ? `${a}|${b}` : `${b}|${a}`, a < b ? [a, b] : [b, a]);
        }
        const all = gos.length <= 48 ? gos : [];
        for (let i2 = 0;i2 < all.length; i2++)
          for (let j = i2 + 1;j < all.length; j++) {
            const a = all[i2], b = all[j];
            if (!(a.startsWith("k:") && b.startsWith("k:")))
              pairs2.set(a < b ? `${a}|${b}` : `${b}|${a}`, a < b ? [a, b] : [b, a]);
          }
        for (const t of new Set([...theoryTerms, ...all.filter((x) => !x.startsWith("k:"))]))
          row(times(v(t), -1), []);
        for (const [a, b] of pairs2.values())
          pairRows(row, a, b);
        const tt = new Set([...theoryTerms, ...all]);
        for (const x of succList)
          if (m[x.s] && (tt.has(x.lo) || tt.has(x.hi))) {
            row(plus(T(x.hi), times(plus(T(x.lo), konst(1)), -1)), [x.s]);
            row(plus(plus(T(x.lo), konst(1)), times(T(x.hi), -1)), [x.s]);
            for (const y of [x.lo, x.hi])
              if (!tt.has(y) && !y.startsWith("k:"))
                row(times(v(y), -1), []);
          }
        theoryRows(row);
        const lemmas = [], off = new Set, theoryLits = new Set(theory.flatMap((t) => [t.x, -t.x]));
        for (let k = 0;k < 8; k++) {
          const keep = rows.map((_, i) => i).filter((i) => !off.has(i)), sub = keep.map((i) => rows[i]), subLits = keep.map((i) => lits[i]);
          let r = jointLp.load(sub);
          if (r.kind === "sat")
            r = jointLp.check();
          if (r.kind === "sat")
            break;
          const l = r.kind === "conflict" ? lemmaOf(solve(r.rows.map((i) => sub[i])), r.rows.map((i) => subLits[i])) : k ? undefined : lemmaOf(solve(sub), subLits);
          if (!l)
            break;
          lemmas.push(l);
          keep.forEach((i) => {
            if (lits[i].some((x) => theoryLits.has(x) && l.includes(-x)))
              off.add(i);
          });
        }
        if (lemmas.length)
          return { lemmas };
      }
      const rows = [], lits = [], row = (lin, ls) => {
        rows.push({ lin, label: "" });
        lits.push(ls);
      };
      const groups = groupsOf(m);
      for (const t of gos)
        if (!t.startsWith("k:"))
          row(times(v(t), -1), []);
      for (const [gi, g] of groups.entries()) {
        for (const t of g.slice(1)) {
          row(plus(T(t), times(T(g[0]), -1)), [v2(le(t, g[0]))]);
          row(plus(T(g[0]), times(T(t), -1)), [v2(le(g[0], t))]);
        }
        const h = groups[gi + 1];
        if (h)
          row(plus(plus(T(g[0]), konst(1)), times(T(h[0]), -1)), [-v2(le(h[0], g[0]))]);
      }
      for (const x of succList)
        if (m[x.s])
          row(plus(T(x.hi), times(plus(T(x.lo), konst(1)), -1)), [x.s]);
      theoryRows(row);
      let q = jointLp.load(rows);
      if (q.kind === "sat")
        q = jointLp.check();
      if (q.kind === "conflict") {
        const l = lemmaOf(solve(q.rows.map((i) => rows[i])), q.rows.map((i) => lits[i]));
        if (l)
          return { lemmas: [l] };
      }
      const exact = () => {
        const r = solve(rows);
        if (r.kind === "sat")
          return { val: new Map(gos.map((t) => [t, t.startsWith("k:") ? Number(t.slice(2)) : r.witness[t] ?? 0])) };
        const l = lemmaOf(r, lits);
        return l && { lemmas: [l] };
      };
      if (q.kind === "sat") {
        const at = (t) => {
          const j = jointLp.indexOf(t);
          return j === undefined ? 0 : jointLp.value(j);
        };
        const val = new Map(gos.map((t) => [t, t.startsWith("k:") ? Number(t.slice(2)) : Math.round(at(t))]));
        const ok = gos.every((t) => t.startsWith("k:") || Math.abs(at(t) - val.get(t)) < 0.000001 && val.get(t) >= 0) && rows.every((row) => Object.entries(row.lin).reduce((x, [k, c]) => x + c * (k === "1" ? 1 : val.get(k) ?? 0), 0) <= 0);
        if (ok)
          return { val, exact };
      }
      return exact();
    };
    const outcome = (o) => typeof o === "string" ? { unknown: o } : o === undefined ? { unknown: "the conflict budget ran out, or the deadline" } : !o.sat ? { sat: false, core: [...new Set([...o.core].flatMap((g) => index.has(g) ? [index.get(g)] : []))].sort((a, b) => a - b) } : loose.length ? { unknown: `${loose.length} comparisons outside the EPR shape` } : { model: o.model };
    const gFinsL = finsList.filter((f) => gFins.has(f)), cellsOf = new Map, odd = [];
    for (const f of gFinsL)
      if (f.parts) {
        if (!cellsOf.has(f.map))
          cellsOf.set(f.map, []);
        cellsOf.get(f.map).push({ id: f.id, parts: f.parts });
      } else if (f.key)
        odd.push({ id: f.id, map: f.map, key: f.key });
    const ordCells = new Map, ordOdd = [];
    for (const id of gos) {
      const inf = ordInfo.get(id);
      if (!inf)
        continue;
      if (inf.parts) {
        if (!ordCells.has(inf.map))
          ordCells.set(inf.map, []);
        ordCells.get(inf.map).push({ id, parts: inf.parts });
      } else
        ordOdd.push({ id, map: inf.map, key: inf.key });
    }
    const { reads, fnParts } = gst;
    const finish = (model, theoryVal) => {
      const val = (l) => model[l] === true;
      const w = Object.create(null);
      for (const f of gFinsL) {
        let x = 0;
        for (let val2 = 0;val2 <= f.cap; val2++)
          if (val(v2(finAt(f, val2))))
            x = val2;
        if (f.id.startsWith("s:"))
          w[f.id.slice(2)] = x;
      }
      const ordVal = theoryVal ?? new Map;
      if (!theoryVal) {
        const groups = groupsOf(model);
        const constOf = (g) => {
          const cs = [...new Set(g.filter((x) => x.startsWith("k:")).map((x) => Number(x.slice(2))))];
          return cs.length > 1 ? NaN : cs[0];
        };
        const groupOf = new Map;
        groups.forEach((g, i) => g.forEach((t) => groupOf.set(t, i)));
        const tight = new Set(succList.filter((x) => val(x.s)).map((x) => `${groupOf.get(x.lo)}>${groupOf.get(x.hi)}`));
        const tied = (i) => tight.has(`${i}>${i + 1}`);
        let prev = -1, far = 0;
        const tupled = Object.values(patterns).some((c) => c.length > 1 && c[0] === 0);
        for (const [gi, g] of groups.entries()) {
          const c = constOf(g);
          if (Number.isNaN(c))
            return { unknown: "the model's order equates two constants" };
          let next = Infinity;
          for (const h of groups.slice(gi + 1)) {
            const d = constOf(h);
            if (d !== undefined) {
              next = d;
              break;
            }
          }
          let x = c ?? (next === Infinity && prev > 0 ? (tupled ? 64 : 1 << 24) * ++far + (tupled ? 7 : 997) * far + prev + 13 : prev + 1);
          if (c === undefined && next !== Infinity && x % 2 === 0 && x + 1 < next)
            x++;
          if (c === undefined && gi > 0 && tied(gi - 1))
            x = prev + 1;
          else if (c === undefined) {
            let k = gi;
            while (tied(k) && constOf(groups[k + 1]) === undefined)
              k++;
            const d = tied(k) ? constOf(groups[k + 1]) : undefined;
            if (d !== undefined)
              x = d - (k + 1 - gi);
          }
          if (x <= prev || x >= next || gi > 0 && tied(gi - 1) && x !== prev + 1)
            return { unknown: noRoom };
          for (const t of g)
            ordVal.set(t, x);
          prev = x;
        }
      }
      for (const [t, x] of ordVal)
        if (t.startsWith("p:") || t.startsWith("s:"))
          w[t.slice(2)] = x;
      const maps = new Map;
      const cellVal = new Map, cells2 = new Map([...cellsOf].map(([mp, cs]) => [mp, [...cs]])), odd2 = [...odd];
      for (const f of gFinsL)
        if (f.id.startsWith("c:")) {
          let x = 0;
          for (let val2 = 0;val2 <= f.cap; val2++)
            if (val(v2(finAt(f, val2))))
              x = val2;
          cellVal.set(f.id, x);
        }
      for (const [mp, cs] of ordCells)
        for (const c of cs) {
          cellVal.set(c.id, ordVal.get(c.id) ?? 0);
          if (!cells2.has(mp))
            cells2.set(mp, []);
          cells2.get(mp).push(c);
        }
      for (const o of ordOdd) {
        cellVal.set(o.id, ordVal.get(o.id) ?? 0);
        odd2.push(o);
      }
      const keyVal = (e) => {
        if (e.op === "tup") {
          const ps = tupleParts(e).map(keyVal);
          if (ps.some((x) => x === undefined))
            return;
          try {
            return ps.slice(0, -1).reduceRight((b, a) => cpair(a, b), ps.at(-1));
          } catch {
            return;
          }
        }
        return keyVal0(e);
      };
      const keyVal0 = (e) => {
        const ts = [], d = { c: 0 };
        if (!linTerms(e, 1, ts, d))
          return;
        let s = d.c;
        for (const [x, c] of ts) {
          if (w[x] === undefined)
            return;
          s += c * w[x];
        }
        return s;
      };
      for (const { f, n, a } of fnParts) {
        if (!maps.has(f))
          maps.set(f, new Map);
        maps.get(f).set(w[a], w[n]);
      }
      let fresh2 = Math.max(0, ...Object.values(w), ...[...maps.values()].flatMap((t) => [...t.values()]));
      const valueAt = (e) => {
        if (e.op === "const")
          return e.value;
        if (e.op === "var")
          return w[e.name] ?? 0;
        if (e.op === "mul") {
          const a = valueAt(e.a);
          return a === undefined ? undefined : a * e.k;
        }
        if (e.op === "add") {
          const a = valueAt(e.a), b = valueAt(e.b);
          return a === undefined || b === undefined ? undefined : a + b;
        }
        if (e.op === "get" && fnMaps.has(e.map)) {
          const k = valueAt(e.key);
          return k === undefined ? undefined : maps.get(e.map)?.get(k);
        }
        return;
      };
      const fnOdd = (x) => {
        tick();
        if (!fnMaps.has(x.map) || partName(x) !== undefined)
          return;
        const key = keyVal(x.key) ?? valueAt(x.key), t = maps.get(x.map) ?? new Map;
        if (key === undefined || t.has(key))
          return;
        maps.set(x.map, t.set(key, ordVal.get(`c:${x.map}#${textOfE(x.key)}`) ?? ++fresh2));
      };
      [...reads].reverse().forEach(fnOdd);
      for (const [mp, cs] of cells2)
        for (const c of cs) {
          let key;
          try {
            key = patterns[mp][0] === 0 ? c.parts.slice(0, -1).reduceRight((b, p) => cpair(w[p], b), w[c.parts.at(-1)]) : c.parts.reduce((s, p, i) => s + w[p] * (patterns[mp][i] ?? 1), 0);
          } catch {
            return { unknown: "a tuple key of the model past 2^53" };
          }
          if (!maps.has(mp))
            maps.set(mp, new Map);
          maps.get(mp).set(key, cellVal.get(c.id));
        }
      for (const o of odd2) {
        const key = keyVal(o.key) ?? valueAt(o.key);
        if (key === undefined)
          continue;
        if (!maps.has(o.map))
          maps.set(o.map, new Map);
        if (!maps.get(o.map).has(key))
          maps.get(o.map).set(key, cellVal.get(o.id));
      }
      const allMaps = new Set;
      for (const x of reads)
        allMaps.add(x.map);
      const st2 = { scalars: {}, maps: Object.fromEntries([...allMaps].map((mp) => [mp, maps.get(mp) ?? new Map])) };
      const m = { name: goal.name, params: [], inputs: [], state: {}, step: {}, maps: Object.fromEntries([...allMaps].map((mp) => [mp, 0])) };
      const env2 = new Proxy({ ...w }, { get: (t, q) => Object.hasOwn(t, q) ? t[q] : 0 });
      for (const [i, f] of fs.entries()) {
        tick();
        try {
          if (f.h && !evalC(f.h, env2, st2, m)) {
            return { unknown: `the abstraction's model breaks hypothesis ${i}` };
          }
        } catch {
          return { unknown: "the model could not be read" };
        }
      }
      const witness = { ...w };
      for (const x of reads) {
        tick();
        const key = x.key.op === "tup" || x.key.op === "proj" ? projected(x.key) : x.key, kv = keyVal(key);
        if (kv === undefined)
          continue;
        if (key.op === "tup") {
          const cell = linear({ op: "get", map: x.map, key }, new Map);
          if (cell)
            witness[Object.keys(cell)[0]] = st2.maps[x.map]?.get(kv) ?? 0;
          continue;
        }
        const l = linear(key, new Map);
        if (l)
          witness[`${x.map}[${canon(l)}]`] = st2.maps[x.map]?.get(kv) ?? 0;
      }
      const values = [...new Set([...[...parts].map((x) => w[x]), ...[...ordVal].filter(([t]) => !t.startsWith("k:") && !t.includes("#")).map(([, x]) => x)].filter((x) => x !== undefined))].sort((a, b) => a - b), elem = new Map(values.map((x, i) => [x, i]));
      const diagram = { elements: values.length, parts: Object.create(null), scalars: Object.create(null), cells: Object.create(null), fns: Object.create(null) };
      for (const x of [...parts, ...ordScalars].sort())
        if (w[x] !== undefined)
          diagram.parts[x] = elem.get(w[x]);
      for (const f of gFinsL)
        if (f.id.startsWith("s:"))
          diagram.scalars[f.id.slice(2)] = w[f.id.slice(2)] ?? 0;
      for (const [mp, cs] of cells2) {
        const seen2 = new Set, out = [];
        for (const c of cs) {
          const at = c.parts.map((x) => elem.get(w[x])), id = at.join(","), value = cellVal.get(c.id);
          if (!seen2.has(id)) {
            seen2.add(id);
            out.push({ at, value: ordMaps.has(mp) ? elem.get(value) ?? value : value });
          }
        }
        diagram.cells[mp] = out.sort((a, b) => {
          for (let i = 0;i < a.at.length; i++)
            if (a.at[i] !== b.at[i])
              return a.at[i] - b.at[i];
          return 0;
        });
      }
      for (const { f, n, a } of fnParts) {
        const t = diagram.fns[f] ??= [], x = elem.get(w[a]);
        if (!t.some((r) => r[0] === x))
          t.push([x, elem.get(w[n])]);
      }
      for (const t of Object.values(diagram.fns))
        t.sort((a, b) => a[0] - b[0]);
      return { sat: true, witness, diagram };
    };
    let cur = outcome(search());
    if (!("model" in cur))
      return cur;
    let done = finish(cur.model, undefined);
    for (let round = 0;theory.length && "unknown" in done && round < 256 && !opts.late?.(); round++) {
      let r = theoryCheck(cur.model);
      if (!r)
        break;
      if ("val" in r) {
        done = finish(cur.model, r.val);
        if ("unknown" in done && r.exact) {
          r = r.exact();
          if (r && "val" in r)
            done = finish(cur.model, r.val);
        }
        if (r && !("val" in r)) {
          for (const l of r.lemmas)
            lemma(l);
          cur = outcome(search());
          if (!("model" in cur))
            return cur;
          done = finish(cur.model, undefined);
          continue;
        }
        if ("unknown" in done)
          done = finish(cur.model, undefined);
        break;
      }
      for (const l of r.lemmas) {
        lemma(l);
        const named = l.map((x) => [names[Math.abs(x)], x > 0]), key = named.map(([k, b]) => (b ? "" : "\xAC") + k).sort().join("|");
        if (lemmaCache.size > 20000)
          lemmaCache.clear();
        lemmaCache.set(key, named);
        lemmasIn.add(key);
      }
      cur = outcome(search());
      if (!("model" in cur))
        return cur;
      done = finish(cur.model, undefined);
    }
    return done;
  };
  let over = false;
  return { decide: (goal, fs, gst, opts) => {
    over = true;
    const d = decideGoal(goal, fs, gst, opts);
    if (!d || !("unknown" in d) || !d.unknown.endsWith("ordered terms"))
      over = false;
    return d;
  }, size: () => over ? Infinity : hyps.size };
}
function cdclSolver(trueFirst, keepPhase) {
  const idx = new Map, back = [0];
  let cap = 0, val = new Int8Array(0), level = new Int32Array(0), act = new Float64Array(0), phase = new Int8Array(0), at = new Int32Array(0);
  const reason = [undefined];
  const heap = [];
  const above = (a, b) => act[a] > act[b] || act[a] === act[b] && a < b;
  const up = (i) => {
    const x = heap[i];
    while (i > 0) {
      const pi = i - 1 >> 1, y = heap[pi];
      if (!above(x, y))
        break;
      heap[i] = y;
      at[y] = i;
      i = pi;
    }
    heap[i] = x;
    at[x] = i;
  };
  const down = (i) => {
    const x = heap[i];
    for (;; ) {
      let c = 2 * i + 1;
      if (c >= heap.length)
        break;
      if (c + 1 < heap.length && above(heap[c + 1], heap[c]))
        c++;
      if (!above(heap[c], x))
        break;
      heap[i] = heap[c];
      at[heap[i]] = i;
      i = c;
    }
    heap[i] = x;
    at[x] = i;
  };
  const push = (x) => {
    if (at[x] >= 0)
      return;
    heap.push(x);
    at[x] = heap.length - 1;
    up(heap.length - 1);
  };
  const pop = () => {
    const x = heap[0], y = heap.pop();
    at[x] = -1;
    if (heap.length) {
      heap[0] = y;
      at[y] = 0;
      down(0);
    }
    return x;
  };
  const vid = (l) => {
    const a = Math.abs(l);
    let i = idx.get(a);
    if (i === undefined) {
      i = back.length;
      idx.set(a, i);
      back.push(a);
      reason.push(undefined);
      if (i >= cap) {
        const n = Math.max(1024, 2 * cap), grow = (x, mk) => {
          const y = mk(n);
          y.set(x);
          return y;
        };
        val = grow(val, (k) => new Int8Array(k));
        level = grow(level, (k) => new Int32Array(k));
        act = grow(act, (k) => new Float64Array(k));
        phase = grow(phase, (k) => new Int8Array(k));
        const at2 = new Int32Array(n).fill(-1);
        at2.set(at);
        at = at2;
        cap = n;
      }
      push(i);
    }
    return l > 0 ? i : -i;
  };
  const watch = new Map;
  const wl = (l) => {
    let w = watch.get(l);
    if (!w)
      watch.set(l, w = []);
    return w;
  };
  const valOf = (l) => val[Math.abs(l)] === 0 ? 0 : val[Math.abs(l)] > 0 === l > 0 ? 1 : -1;
  const trail = [], lim = [];
  const assign = (l, r) => {
    val[Math.abs(l)] = l > 0 ? 1 : -1;
    level[Math.abs(l)] = lim.length;
    reason[Math.abs(l)] = r;
    trail.push(l);
  };
  let qhead = 0, fixed, seen = new Uint8Array(0);
  const coreOf = (lits, out) => {
    const seen = new Set, todo = lits.map(Math.abs);
    while (todo.length) {
      const x = todo.pop();
      if (seen.has(x))
        continue;
      seen.add(x);
      const r = reason[x];
      if (r) {
        for (const o of r.from)
          out.add(o);
        for (const l of r.lits)
          todo.push(Math.abs(l));
      }
    }
    return out;
  };
  const propagate = () => {
    while (qhead < trail.length) {
      const l = trail[qhead++], ws = wl(l);
      eprMeter.n++;
      for (let i = 0;i < ws.length; i++) {
        const c = ws[i];
        if (c.lits[0] === -l) {
          c.lits[0] = c.lits[1];
          c.lits[1] = -l;
        }
        if (valOf(c.lits[0]) > 0)
          continue;
        let moved = false;
        for (let k = 2;k < c.lits.length; k++)
          if (valOf(c.lits[k]) >= 0) {
            const t = c.lits[1];
            c.lits[1] = c.lits[k];
            c.lits[k] = t;
            wl(-c.lits[1]).push(c);
            ws.splice(i--, 1);
            moved = true;
            break;
          }
        if (moved)
          continue;
        if (valOf(c.lits[0]) < 0) {
          qhead = trail.length;
          return c;
        }
        assign(c.lits[0], c);
      }
    }
    return;
  };
  let inc = 1;
  const backjump = (bt) => {
    while (lim.length > bt) {
      const to = lim.pop();
      while (trail.length > to) {
        const x = Math.abs(trail.pop());
        val[x] = 0;
        reason[x] = undefined;
        push(x);
      }
    }
    qhead = Math.min(qhead, trail.length);
  };
  const add = (c) => {
    if (fixed)
      return;
    backjump(0);
    const cl = { lits: c.lits.map(vid), from: new Set([c.from]) };
    if (cl.lits.some((l) => valOf(l) > 0))
      return;
    const open = cl.lits.filter((l) => valOf(l) === 0);
    if (!open.length) {
      fixed = coreOf(cl.lits, new Set(cl.from));
      return;
    }
    cl.lits = [...open, ...cl.lits.filter((l) => valOf(l) < 0)];
    if (open.length === 1)
      assign(open[0], cl);
    else {
      wl(-cl.lits[0]).push(cl);
      wl(-cl.lits[1]).push(cl);
    }
  };
  const solve = (budget, late, assume) => {
    if (fixed)
      return { sat: false, core: fixed };
    backjump(0);
    const as = assume.map(vid);
    let conflicts = 0;
    for (;; ) {
      const confl = propagate();
      if (confl) {
        if (++conflicts > budget || conflicts % 256 === 0 && late?.())
          return;
        if (!lim.length)
          return { sat: false, core: fixed = coreOf(confl.lits, new Set(confl.from)) };
        if (seen.length < back.length)
          seen = new Uint8Array(cap);
        const learnt = [], from = new Set(confl.from), marked = [];
        let p = 0, cnt = 0, c = confl, ti = trail.length - 1;
        do {
          for (const q of c.lits) {
            if (q === p)
              continue;
            const x = Math.abs(q);
            if (!seen[x] && level[x] > 0) {
              seen[x] = 1;
              marked.push(x);
              act[x] = act[x] + inc;
              if (at[x] >= 0)
                up(at[x]);
              if (level[x] === lim.length)
                cnt++;
              else
                learnt.push(q);
            } else if (!seen[x] && level[x] === 0 && reason[x]) {
              seen[x] = 1;
              marked.push(x);
              coreOf([q], from);
            }
          }
          while (!seen[Math.abs(trail[ti])])
            ti--;
          p = trail[ti--];
          c = reason[Math.abs(p)];
          if (c)
            for (const o of c.from)
              from.add(o);
          cnt--;
        } while (cnt > 0);
        for (const x of marked)
          seen[x] = 0;
        learnt.unshift(-p);
        inc *= 1.05;
        let bt = 0, bi = 1;
        for (let i = 1;i < learnt.length; i++)
          if (level[Math.abs(learnt[i])] > bt) {
            bt = level[Math.abs(learnt[i])];
            bi = i;
          }
        if (learnt.length > 1) {
          const t = learnt[1];
          learnt[1] = learnt[bi];
          learnt[bi] = t;
        }
        backjump(bt);
        qhead = trail.length;
        const nc = { lits: learnt, from, learnt: true };
        if (learnt.length > 1) {
          wl(-learnt[0]).push(nc);
          wl(-learnt[1]).push(nc);
        }
        assign(learnt[0], nc);
        continue;
      }
      if (lim.length < as.length) {
        const l = as[lim.length], s = valOf(l);
        if (s < 0)
          return { sat: false, core: coreOf([l], new Set) };
        lim.push(trail.length);
        if (s === 0)
          assign(l);
        continue;
      }
      let best = 0;
      while (heap.length) {
        const x = pop();
        if (val[x] === 0) {
          best = x;
          break;
        }
      }
      if (!best) {
        const model = [];
        for (let x = 1;x < back.length; x++) {
          model[back[x]] = val[x] > 0;
          if (keepPhase.has(back[x]))
            phase[x] = val[x];
        }
        return { sat: true, model };
      }
      lim.push(trail.length);
      assign(phase[best] ? phase[best] * best : trueFirst.has(back[best]) ? best : -best);
    }
  };
  const fresh = () => {
    if (fixed)
      return;
    backjump(0);
    for (const [l, ws] of watch) {
      const ks = ws.filter((c) => !c.learnt);
      if (ks.length !== ws.length)
        watch.set(l, ks);
    }
    act.fill(0);
    phase.fill(0);
    inc = 1;
    heap.length = 0;
    at.fill(-1);
    for (let x = 1;x < back.length; x++)
      push(x);
  };
  return { solve, add, fresh };
}

// kernel/model-values.ts
function modelValueTerms(body, name, free, value) {
  let keyed = false;
  walkOnce(body, (o) => {
    const e = o;
    if (e.op !== "get")
      return;
    walkOnce(e.key, (k) => {
      const part = k;
      if (part.op === "var" && part.name === name)
        keyed = true;
    });
  });
  if (keyed)
    return [];
  const linear = (e) => {
    if (e.op === "var" && e.name === name)
      return { coefficient: 1, constant: 0 };
    if (e.op === "add") {
      const a = linear(e.a), b = linear(e.b);
      return a && b ? { coefficient: a.coefficient + b.coefficient, constant: a.constant + b.constant } : undefined;
    }
    if (e.op === "mul") {
      const a = linear(e.a);
      return a ? { coefficient: e.k * a.coefficient, constant: e.k * a.constant } : undefined;
    }
    const text = JSON.stringify(e);
    if ([...free].some((n) => text.includes(`"name":${JSON.stringify(n)}`)))
      return;
    const constant = value(e);
    return constant === undefined || !Number.isSafeInteger(constant) ? undefined : { coefficient: 0, constant };
  };
  const terms = new Set;
  const visit = (c) => {
    if (c.op === "not")
      return visit(c.x);
    if (c.op === "and" || c.op === "or") {
      c.xs.forEach(visit);
      return;
    }
    if (c.op !== "=" && c.op !== "<=" && c.op !== "<")
      return;
    const a = linear(c.a), b = linear(c.b);
    if (!a || !b)
      return;
    const coefficient = a.coefficient - b.coefficient, constant = b.constant - a.constant;
    if (!coefficient || !Number.isSafeInteger(coefficient) || !Number.isSafeInteger(constant))
      return;
    const boundary = Math.floor(constant / coefficient);
    for (const v of [boundary, boundary + 1, boundary - 1])
      if (Number.isSafeInteger(v) && v >= 0)
        terms.add(v);
  };
  visit(body);
  return [...terms].slice(0, 16).map((value) => ({ op: "const", value }));
}

// kernel/prover-rows.ts
var originals = new WeakMap;
var ids = new WeakMap;
var nodes = new Map;
var serial = 0;
var keyChars = 0;
var rowReuseStats = { nodeHits: 0, nodeMisses: 0, goalHits: 0, rowsHits: 0, rowsBuilt: 0, rowsEvicted: 0 };
var id = (o) => {
  let n = ids.get(o);
  if (n === undefined)
    ids.set(o, n = ++serial);
  return n;
};
function intern(value) {
  if (!value || typeof value !== "object")
    return value;
  const had = originals.get(value);
  if (had)
    return had;
  const values = Array.isArray(value) ? value.map(intern) : Object.fromEntries(Object.entries(value).map(([k, v]) => [k, intern(v)]));
  const ref = (v) => v && typeof v === "object" ? ["@", id(v)] : typeof v === "number" && !Number.isFinite(v) ? ["number", String(v)] : ["value", v];
  const key = Array.isArray(values) ? JSON.stringify(["array", values.map(ref)]) : JSON.stringify(["object", Object.entries(values).sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => [k, ref(v)])]);
  let out = nodes.get(key);
  if (out)
    rowReuseStats.nodeHits++;
  else {
    if (nodes.size >= 1e5 || keyChars + key.length > 32 * 1024 * 1024) {
      nodes.clear();
      keyChars = 0;
    }
    nodes.set(key, out = values);
    keyChars += key.length;
    rowReuseStats.nodeMisses++;
  }
  originals.set(value, out);
  originals.set(out, out);
  id(out);
  return out;
}
var goals = new WeakMap;
var goalPool = new Map;
function sharedGoal(goal) {
  let out = goals.get(goal);
  if (out)
    return out;
  const hyps = goal.hyps.map((c) => intern(c)), key = hyps.map(id).join(",");
  out = goalPool.get(key);
  if (out) {
    rowReuseStats.goalHits++;
    goalPool.delete(key);
  } else
    out = { name: goal.name, hyps };
  if (goalPool.size >= 128)
    goalPool.delete(goalPool.keys().next().value);
  goalPool.set(key, out);
  goals.set(goal, out);
  return out;
}

class ProverRowsCache {
  maxRows;
  maxEntries;
  entries = new Map;
  kept = 0;
  constructor(maxRows, maxEntries = 8192) {
    this.maxRows = maxRows;
    this.maxEntries = maxEntries;
    if (maxRows !== Infinity && (!Number.isSafeInteger(maxRows) || maxRows < 0) || !Number.isSafeInteger(maxEntries) || maxEntries < 1)
      throw new RangeError("invalid row-cache retention budget");
  }
  get size() {
    return this.entries.size;
  }
  get weight() {
    return this.kept;
  }
  get(key) {
    const value = this.entries.get(key);
    if (value) {
      this.entries.delete(key);
      this.entries.set(key, value);
    }
    return value;
  }
  set(key, value) {
    const old = this.entries.get(key);
    if (old) {
      this.kept -= old.length;
      this.entries.delete(key);
    }
    if (value.length > this.maxRows)
      return 0;
    let evicted = 0;
    while (this.entries.size >= this.maxEntries || this.kept + value.length > this.maxRows) {
      const first = this.entries.keys().next().value;
      this.kept -= this.entries.get(first).length;
      this.entries.delete(first);
      evicted++;
    }
    this.entries.set(key, value);
    this.kept += value.length;
    return evicted;
  }
}
var rows = new ProverRowsCache(env.GDP_ROWS_UNWEIGHTED === "1" ? Infinity : 250000);
function proverRows(goal, path) {
  const shared = sharedGoal(goal);
  const key = JSON.stringify([id(shared), [...path].map(([key, a]) => [key, a.holds, canon(a.lin)])]);
  let out = rows.get(key);
  if (out) {
    rowReuseStats.rowsHits++;
    return out;
  }
  rowReuseStats.rowsBuilt++;
  out = leafConstraintsReusing(shared, path);
  rowReuseStats.rowsEvicted += rows.set(key, out);
  return out;
}

// core/lemma-cuts.ts
var originOf = new WeakMap;
var proofOrigins = { enabled: false };
var rowIds = new WeakMap;
var rowIndexes = new WeakMap;
var rowsOf = new WeakMap;
var pathKey = (p) => JSON.stringify([...p].map(([id, a]) => [id, canon(a.lin), a.holds]));
var saveProofRows = (tree, goal, path, rows, atoms) => {
  rowsOf.set(tree, { goal, path: pathKey(path), rows, atoms });
};
function rememberProofRows(tree, goal, path, rows) {
  if (proofOrigins.enabled && "leaf" in tree)
    saveProofRows(tree, goal, path, rows);
}

// kernel/prove.ts
function openE(e, path, out) {
  switch (e.op) {
    case "var":
    case "const":
      return;
    case "mul":
      return openE(e.a, path, out);
    case "prod":
      return openE(e.a, path, out), openE(e.b, path, out);
    case "get":
      return openE(e.key, path, out);
    case "tup":
      return openE(e.a, path, out), openE(e.b, path, out);
    case "proj":
      return openE(e.a.op === "tup" ? e.k === 0 ? e.a.a : e.a.b : e.a, path, out);
    case "if": {
      const t = truth(e.c, path);
      if (t === undefined)
        openC(e.c, path, out);
      else
        openE(t ? e.then : e.else, path, out);
      return;
    }
    case "add":
    case "sub":
    case "min":
    case "max": {
      openE(e.a, path, out), openE(e.b, path, out);
      const a = linear(e.a, path), b = linear(e.b, path);
      if (a && b && !decided(e, path))
        out.push(e.op === "sub" ? sub(b, a) : sub(a, b));
      return;
    }
    default:
      return unreachable(e);
  }
}
function openC(c, path, out) {
  if (truth(c, path) !== undefined)
    return;
  if (c.op === "flag" || c.op === "all")
    return;
  if (c.op === "not")
    return openC(c.x, path, out);
  if (c.op === "and" || c.op === "or")
    return c.xs.forEach((y) => openC(y, path, out));
  if (c.op === "=" && c.a.op === "tup" && c.b.op === "tup")
    return [c.a.a, c.a.b].forEach((x, i) => openC({ op: "=", a: x, b: i ? c.b.b : c.b.a }, path, out));
  const a = linear(c.a, path), b = linear(c.b, path), own = [];
  if (a && b) {
    const d = sub(a, b);
    if (c.op === "<=")
      own.push(d);
    else if (c.op === "<")
      own.push(add(d, k(1)));
    else
      own.push(d, scale(d, -1));
  }
  openE(c.a, path, out), openE(c.b, path, out);
  out.push(...own);
}
function openH(c, path, out, positive = true) {
  if (c.op === "not")
    return openH(c.x, path, out, !positive);
  if (c.op === "and" && positive || c.op === "or" && !positive)
    return c.xs.forEach((y) => openH(y, path, out, positive));
  if (c.op === "and" || c.op === "or") {
    if (truth(c, path) !== undefined)
      return;
    const open = c.xs.filter((y) => truth(y, path) !== !positive);
    if (open.length === 1)
      openH(open[0], path, out, positive);
    else
      openC(c, path, out);
    return;
  }
  if (c.op === "flag" || c.op === "all")
    return;
  if (c.op === "=" && c.a.op === "tup" && c.b.op === "tup") {
    const parts = [{ op: "=", a: c.a.a, b: c.b.a }, { op: "=", a: c.a.b, b: c.b.b }];
    return openH(positive ? { op: "and", xs: parts } : { op: "or", xs: parts.map((x) => ({ op: "not", x })) }, path, out, true);
  }
  const before = out.length;
  openE(c.a, path, out), openE(c.b, path, out);
  if (out.length === before && !positive && c.op === "=" && truth(c, path) === undefined)
    openC(c, path, out);
}
var pairedKeys = { skip: false };
var cellKeys = new Map;
var cellPairs = new Map;
var cellPairsN = 0;
var cellPair = (a, b) => {
  let row = cellPairs.get(a);
  if (!row)
    cellPairs.set(a, row = new Map);
  let pair = row.get(b);
  if (!pair) {
    if (++cellPairsN > 200000) {
      cellPairs.clear();
      cellPairsN = 1;
      cellPairs.set(a, row = new Map);
    }
    const d = sub(cellKey(a).key ?? {}, cellKey(b).key ?? {});
    row.set(b, pair = { d, neg: scale(d, -1) });
  }
  return pair;
};
var cellKey = (n) => {
  let c = cellKeys.get(n);
  if (!c) {
    if (cellKeys.size > 1e5)
      cellKeys.clear();
    cellKeys.set(n, c = cellParts(n));
  }
  return c;
};
var tuplePairs = new Map;
var tupleCellPairs = (a, b) => {
  const ka = cellKey(a).keys, kb = cellKey(b).keys;
  if (!ka && !kb)
    return;
  if (!ka || !kb || ka.length !== kb.length)
    return [];
  const id = `${a} ${b}`;
  let ds = tuplePairs.get(id);
  if (!ds) {
    if (tuplePairs.size > 200000)
      tuplePairs.clear();
    tuplePairs.set(id, ds = ka.map((k, i) => {
      const d = sub(k, kb[i]);
      return [d, scale(d, -1)];
    }));
  }
  return ds;
};
var tupleOpen = (a, b, _ka, _kb, dec) => {
  for (const [d, neg] of tupleCellPairs(a, b)) {
    const x = dec(d), y = dec(neg);
    if (x === undefined)
      return d;
    if (x === true && y === undefined)
      return neg;
    if (!(x && y))
      return;
  }
  return;
};
function openCells(rows, path) {
  const seen = new Set, names = [];
  for (const r of rows)
    for (const n in r.lin)
      if (!seen.has(n)) {
        seen.add(n);
        if (isCell(n))
          names.push(n);
      }
  const out = [];
  const cs = names.map(cellKey);
  const dec = (lin) => path.get(canon(lin))?.holds ?? (path.has(canonFlip(lin)) ? !path.get(canonFlip(lin)).holds : undefined);
  for (let i = 0;i < names.length; i++)
    for (let j = i + 1;j < names.length; j++) {
      if (cs[i].map !== cs[j].map)
        continue;
      if (cs[i].keys || cs[j].keys) {
        const t = cs[i].keys && cs[j].keys ? tupleOpen(names[i], names[j], cs[i].keys, cs[j].keys, dec) : undefined;
        if (t)
          out.push(t);
        continue;
      }
      const pair = cellPair(names[i], names[j]), d = pair.d;
      if (pairedKeys.skip && Object.keys(d).some(isMonomial))
        continue;
      const q0 = cellProducts.on ? "q0" in pair ? pair.q0 : pair.q0 = quotient(d) : undefined;
      if (q0) {
        const q1 = pair.q1 ??= scale(q0, -1);
        const qa = dec(q0), qb = dec(q1);
        if (qa === undefined) {
          out.push(q0);
          continue;
        }
        if (qa === true && qb === undefined) {
          out.push(q1);
          continue;
        }
        if (!(qa && qb))
          continue;
        cellDiffs.set(canon(d), q0);
        cellDiffs.set(canon(pair.neg), q1);
      }
      const a = dec(d), b = dec(pair.neg);
      if (a === undefined)
        out.push(d);
      else if (a === true && b === undefined)
        out.push(pair.neg);
    }
  return out;
}
var quotient = (d) => {
  const keys = Object.keys(d);
  if (!keys.length || keys.some((key) => key === "1" || !isMonomial(key)))
    return;
  const shared = factorsOf(keys[0]).find((f) => keys.every((key) => factorsOf(key).includes(f)));
  if (!shared)
    return;
  const out = {};
  for (const key of keys) {
    const fs = [...factorsOf(key)];
    fs.splice(fs.indexOf(shared), 1);
    out[fs.join("*")] = (out[fs.join("*")] ?? 0) + d[key];
  }
  return out;
};
var cellDiffs = new Map;
var profile = { on: false, goals: [], solves: 0, solveMs: 0, rowsMs: 0, nodes: 0 };
var timed = (f, add) => {
  if (!profile.on)
    return f();
  const t = performance.now();
  try {
    return f();
  } finally {
    add(performance.now() - t);
  }
};
var solveKinds = {};
var solveP = (rows, maxRows) => {
  if (!profile.on)
    return solve(rows, maxRows);
  const t = performance.now(), out = solve(rows, maxRows), ms = performance.now() - t;
  profile.solves++;
  profile.solveMs += ms;
  const s = solveKinds[out.kind] ??= { n: 0, ms: 0, rows: 0 };
  s.n++;
  s.ms += ms;
  s.rows += rows.length;
  return out;
};
var proveDump;
var proveTrace = !!env.PROVE_TRACE;
var cellProducts = { on: false };
var deadline = Infinity;
var deadlineEpr = 0;
var eprTimeSince = (start) => rate ? (eprMeter.n - start) / rate : 0;
var rate = 0;
var meter = () => work.n;
var clock = () => rate ? meter() / rate : performance.now();
function counted(perMs, f, full = false) {
  if (rate)
    return f();
  const outer = deadline;
  rate = perMs;
  deadline = Infinity;
  meter = full ? fullWork : () => work.n;
  try {
    return f();
  } finally {
    rate = 0;
    deadline = outer;
  }
}
var model = [
  ["fm", 2.33],
  ["fcells", 0.0123],
  ["plainRows", 7.93],
  ["values", 0.672],
  ["copies", 0.735],
  ["edges", 0.0435],
  ["scan", 0.0765],
  ["pivotRows", 0.599],
  ["unitRows", 15.6],
  ["unfoldRows", 0.735],
  ["goalNodes", 0.492],
  ["translateRows", 7.93]
];
var fullRate = 250;
var fullWork = () => {
  let n = 0;
  for (const [k, w] of model)
    n += w * costs[k];
  return n;
};
var groundRate = 180;
var workCap = Infinity;
var withWork = (cap, f) => {
  const outer = workCap;
  workCap = Math.min(outer, cap);
  try {
    return f();
  } finally {
    workCap = outer;
  }
};
var wallEnd = Infinity;
var pastWall = () => wallEnd !== Infinity && performance.now() > wallEnd;
function withWall(end, f) {
  const outer = wallEnd;
  wallEnd = Math.min(outer, end);
  try {
    return f();
  } finally {
    wallEnd = outer;
  }
}
var wallAt = () => wallEnd;
var late = (until) => clock() > until || workCap !== Infinity && fullWork() > workCap || pastWall();
var withinDeadline = (until) => Math.min(until, deadline - eprTimeSince(deadlineEpr));
function withDeadline(until, f) {
  const outer = deadline, outerEpr = deadlineEpr;
  deadline = withinDeadline(until);
  deadlineEpr = eprMeter.n;
  try {
    return f();
  } finally {
    deadline = outer;
    deadlineEpr = outerEpr;
  }
}
function grow(goal, path = new Map, budget) {
  if (pastWall())
    return { stuck: "unknown", path, why: outOfBudget(goal, "time", path.size) };
  if (!budget) {
    const ms = Math.max(20000, 1000 * goal.hyps.length);
    if (!rate)
      return withWork(fullWork() + groundRate * ms, () => grow(goal, path, { nodes: 0 }));
    budget = { nodes: 0, until: clock() + ms };
  }
  const end = withinDeadline(budget.until ?? Infinity);
  if (end < (budget.until ?? Infinity))
    budget.until = end;
  if (budget.units === false && unitsNow) {
    unitsNow = false;
    try {
      return grow(goal, path, budget);
    } finally {
      unitsNow = true;
    }
  }
  if (proveDump && !path.size && !budget.nodes) {
    proveDump(goal);
  }
  if (proveTrace && !path.size && !budget.nodes) {
    const t = performance.now(), out = growRoot(goal, path, budget);
    console.error(`[grow] ${goal.name}: ${goal.hyps.length} hyps, ${budget.nodes} nodes, ${Math.round(performance.now() - t)} ms, ${"tree" in out ? "proven" : `${out.stuck}${out.why ? ` (${out.why})` : ""}`}`);
    return out;
  }
  const key = treeCache.on && !path.size && !budget.nodes ? treeKey(goal) : undefined, had = key === undefined ? undefined : treeCache.trees.get(key);
  if (had) {
    treeReuseStats.hits++;
    return { tree: had, nodes: 0 };
  }
  if (key !== undefined) {
    const out = growKept(goal, path, budget);
    if ("tree" in out)
      treeCache.keep(key, out.tree);
    return out;
  }
  return growKept(goal, path, budget);
}
var treeReuseStats = { hits: 0, kept: 0 };
var treeCache = { on: 0, trees: new Map, keep(key, tree) {
  treeReuseStats.kept++;
  if (this.trees.size >= 2000)
    this.trees.clear();
  this.trees.set(key, tree);
} };
var treeKey = (goal) => {
  const text = JSON.stringify(goal.hyps);
  return text.length > 4000000 ? undefined : `${cellProducts.on ? 1 : 0}${unitsNow ? 1 : 0}${text}`;
};
var keepTrees = env.GDP_TREES !== "0";
var queryHook = { depth: 0 };
function logged(kind, goal, f) {
  const t0 = performance.now(), w0 = work.n;
  queryHook.depth++;
  try {
    const out = f();
    queryHook.on?.({ kind, goal, ms: performance.now() - t0, work: work.n - w0, out, depth: queryHook.depth - 1 });
    return out;
  } finally {
    queryHook.depth--;
  }
}
function growKept(goal, path, budget) {
  if (queryHook.on && !path.size && !budget.nodes && !queryHook.depth)
    return logged("grow", goal, () => growKept0(goal, path, budget));
  return growKept0(goal, path, budget);
}
function growKept0(goal, path, budget) {
  if (!profile.on || path.size || budget.nodes)
    return growRoot(goal, path, budget);
  const t = performance.now(), { solves: s0, solveMs: m0, rowsMs: r0, nodes: n0 } = profile;
  const out = growRoot(goal, path, budget);
  profile.goals.push({ name: goal.name, ms: performance.now() - t, nodes: profile.nodes - n0, solves: profile.solves - s0, solveMs: profile.solveMs - m0, rowsMs: profile.rowsMs - r0, proven: "tree" in out });
  return out;
}
var cdclShare = Number(env.GDP_CDCL_SHARE ?? 0.75);
var quickCap = Number(env.GDP_QUICK_CAP ?? 16);
var eprOn = env.GDP_EPR !== "0";
var eprScope = {};
var eprLast = { refuted: false };
function eprFirst(goal, budget, whole = true, stop = () => pastWall() || pastEprCap()) {
  eprLast.refuted = false;
  const start = eprMeter.n, until = budget.until ?? Infinity;
  const d = decide2(goal, eprScope.patterns, { exact: true, late: () => stop() || late(withinDeadline(until - eprTimeSince(start))) });
  if (budget.until !== undefined)
    budget.until = until - eprTimeSince(start);
  if ("unknown" in d)
    return;
  if (d.sat)
    return { stuck: "sat", witness: d.witness, diagram: d.diagram, path: new Map, why: "a model" };
  const last = goal.hyps.length - 1, core = d.core.includes(last) ? d.core : [...d.core, last], part = { name: goal.name, hyps: core.map((i) => goal.hyps[i]) };
  const now = clock(), end = withinDeadline(budget.until ?? Infinity), w = fullWork();
  eprScope.busy = true;
  try {
    const share = whole ? 0.5 : 1;
    const out = withWork(workCap === Infinity ? Infinity : w + share * (workCap - w), () => grow(part, new Map, { nodes: 0, until: end === Infinity ? end : now + share * (end - now) }));
    if (!("tree" in out)) {
      eprLast.refuted = true;
      return;
    }
    if (!whole)
      return { ...out, part, core };
    const tree = widen(part, goal, out.tree);
    return tree ? { tree, nodes: out.nodes } : undefined;
  } finally {
    eprScope.busy = false;
  }
}
var wideAt = Number(env.GDP_WIDE ?? 256);
var wideTerms = Number(env.GDP_WIDE_TERMS ?? 40000);
var wideShare = Number(env.GDP_WIDE_SHARE ?? 0.25);
var wideTrace = !!env.GDP_WIDE_TRACE;
var wideBusy = false;
var wideScope = {};
var wideStats = { goals: 0, trees: 0, models: 0, rounds: 0 };
var wideHook = {};
var cellsIn = (c) => {
  const out = new Set;
  walkOnce(c, (o) => {
    const x = o;
    if (x.op === "get")
      out.add(`${x.map}${JSON.stringify(x.key)}`);
  });
  return out;
};
var brokenOf = (goal) => {
  const maps = new Set;
  walkOnce(goal.hyps, (o) => {
    const x = o;
    if (x.op === "get" && typeof x.map === "string")
      maps.add(x.map);
  });
  const mm = { maps: Object.fromEntries([...maps].map((mp) => [mp, 0])) };
  return (w0, ids = goal.hyps.map((_, i) => i), first = false, defaults) => {
    const w = { ...w0 }, at = new Proxy(w, { get: (t, q) => t[q] ?? 0 }), out = [];
    let st = { scalars: {}, maps: {}, ...defaults ? { defaults } : {} };
    for (let pass = 0;pass < 3; pass++) {
      if (pass)
        for (const n in w) {
          const e = n.startsWith("\u27E6") ? columnTerm(n) : undefined;
          if (e)
            try {
              w[n] = evalE(e, at, st, mm);
            } catch {}
        }
      st = { scalars: {}, maps: Object.fromEntries([...maps].map((mp) => [mp, new Map])), ...defaults ? { defaults } : {} };
      for (const [cell, value] of Object.entries(w)) {
        const br = cell.indexOf("["), key = br > 0 && cell.endsWith("]") && st.maps[cell.slice(0, br)] ? keyValue(cell, w) : undefined;
        if (key !== undefined)
          st.maps[cell.slice(0, br)].set(key, value);
      }
    }
    for (let q = ids.length - 1;q >= 0 && !(first && out.length); q--) {
      const i = ids[q];
      let ok = false;
      try {
        ok = evalC(goal.hyps[i], at, st, mm);
      } catch {}
      if (!ok)
        out.push(i);
    }
    return out.reverse();
  };
};
var termsSeen = new WeakMap;
var termsOf = (goal) => {
  let n = termsSeen.get(goal);
  if (n === undefined) {
    n = 0;
    walkOnce(goal.hyps, () => {
      n++;
    });
    termsSeen.set(goal, n);
  }
  return n;
};
var wideFor = (goal) => !wideBusy && goal.hyps.length >= wideAt && termsOf(goal) >= wideTerms;
function growWide(goal, budget, ask = (g, until) => grow(g, new Map, { nodes: 0, until }), keep = false) {
  const hyps = goal.hyps, last = hyps.length - 1, broken = brokenOf(goal), now = clock(), w = fullWork();
  const end = withinDeadline(budget.until ?? Infinity), span = wideShare * (end - now), room = wideShare * (workCap - w), until = now + span;
  const part = new Set([last]), near = new Set(cellsIn(hyps[last])), cells = new Map;
  const cellsAt = (i) => {
    let c = cells.get(i);
    if (!c)
      cells.set(i, c = cellsIn(hyps[i]));
    return c;
  };
  const take = (i) => {
    part.add(i);
    for (const x of cellsAt(i))
      near.add(x);
  };
  wideBusy = true;
  wideStats.goals++;
  try {
    while (!late(until)) {
      wideStats.rounds++;
      const ids = [...part].sort((a, b) => a - b), g = { name: goal.name, hyps: ids.map((i) => hyps[i]) }, f = Math.max(1 / 16, Math.min(1, 4 * part.size / hyps.length));
      const t0 = performance.now(), at = clock();
      wideScope.judge = (w) => !broken(w, ids, true).length;
      let out;
      try {
        out = withWork(Math.min(w + room, fullWork() + f * room), () => ask(g, Math.min(until, at + f * span)));
      } finally {
        wideScope.judge = undefined;
      }
      wideHook.on?.(g, out);
      if (wideTrace)
        console.error(`[wide] ${goal.name.slice(0, 40)}: part ${g.hyps.length} of ${hyps.length}, ${"tree" in out ? "tree" : out.stuck} in ${Math.round(performance.now() - t0)} ms${"tree" in out ? "" : ` ${out.why?.slice(0, 50) ?? ""}`}`);
      if ("tree" in out && keep) {
        wideStats.trees++;
        return { tree: out.tree, nodes: out.nodes, part: g, core: ids };
      }
      if ("tree" in out) {
        const tree = withWork(w + room, () => withDeadline(until, () => widen(g, goal, out.tree)));
        if (tree)
          wideStats.trees++;
        return tree && { tree, nodes: out.nodes };
      }
      if (out.why === REFUTED)
        return { ...out, ...out.core ? { core: out.core.map((i) => ids[i]) } : {} };
      if (out.stuck !== "sat" || !out.witness)
        return;
      const bad = broken(out.witness);
      if (wideTrace)
        console.error(`[wide]   breaks ${bad.length}${bad.length ? `: ${bad.slice(0, 12).join(" ")}` : ""}`);
      if (!bad.length) {
        wideStats.models++;
        return { ...out, path: new Map };
      }
      const more = bad.filter((i) => !part.has(i)), size = part.size;
      if (!more.length || 2 * size > hyps.length)
        return;
      const shared = (i) => [...cellsAt(i)].some((x) => near.has(x));
      more.sort((a, b) => Number(shared(b)) - Number(shared(a)));
      for (const i of more.slice(0, Math.max(16, size)))
        take(i);
      for (const any of [false, true])
        for (let i = 0;i < last && part.size < 2 * size; i++)
          if (!part.has(i) && (any || shared(i)))
            take(i);
    }
    return;
  } finally {
    wideBusy = false;
  }
}
var wideEprUnits = Number(env.GDP_WIDE_EPR ?? 2000000);
var wideParts = env.GDP_WIDE_PARTS !== "0";
var tupledScope = () => !!eprScope.patterns && Object.values(eprScope.patterns).some((c) => c.length > 1 && c[0] === 0);
var eprPart = (gp, until) => eprFirst(gp, { nodes: 0, until }) ?? grow(gp, new Map, { nodes: 0, until });
function growRoot(goal, path, budget) {
  const wide = !path.size && !budget.nodes && wideFor(goal), epr = !!eprScope.patterns && !eprScope.busy;
  if (wide) {
    const out = epr && wideParts && tupledScope() ? growWide(goal, budget, eprPart) : growWide(goal, budget);
    if (out)
      return out;
  }
  if (epr && !wideBusy && !path.size && !budget.nodes) {
    const out = wide && tupledScope() ? withEprCap(wideEprUnits, () => eprFirst(goal, budget)) : eprFirst(goal, budget);
    if (out)
      return out;
  }
  if (pastWall())
    return { stuck: "unknown", path, why: outOfBudget(goal, "time", path.size) };
  const root = path.size === 0 && budget.nodes === 0 ? leafConstraints(goal, path) : undefined;
  const cdcl = !!root && cdclShare > 0 && !cellProducts.on && Number(/@(\d+) steps/.exec(goal.name)?.[1] ?? 1) <= 1 && !root.some((r) => Object.keys(r.lin).some(isMonomial));
  if (root && unitFirst && unitsNow && !(eprScope.busy && tupledScope())) {
    unitsNow = false;
    try {
      const quick = growPlain(goal, path, { nodes: 0, until: budget.until, cap: cdcl ? quickCap : 64 });
      if ("tree" in quick || quick.stuck === "sat" || quick.why === undefined)
        return quick;
    } finally {
      unitsNow = true;
    }
  }
  if (root) {
    if (cdcl) {
      const now = clock(), end = withinDeadline(budget.until ?? Infinity), w = fullWork();
      const out = withWork(workCap === Infinity ? Infinity : w + cdclShare * (workCap - w), () => growCdcl(goal, path, { nodes: 0, until: end === Infinity ? end : now + cdclShare * (end - now) }));
      if ("tree" in out || out.stuck === "sat" && !(realModels.on && fakeProducts(out.witness)))
        return out;
    }
    const open = new Set(root.flatMap((r) => Object.keys(r.lin)).filter((n) => n.startsWith("\u27E6") && columnTerm(n)?.op === "if")).size;
    const plain = growPlain(goal, path, { nodes: 0, until: budget.until, cap: Math.max(32, Math.round(4000 / 2 ** (open / 2))) });
    if ("tree" in plain || plain.stuck === "sat" || plain.why === undefined)
      return plain;
    const cut = withCuts(goal, path, budget);
    if (cut)
      return cut;
  }
  return growPlain(goal, path, budget);
}
var realModels = { on: env.GDP_REAL_MODELS !== "0" };
var fakeProducts = (w) => !!w && Object.keys(w).some((key) => isMonomial(key) && (w[key] ?? 0) !== factorsOf(key).reduce((acc, f) => acc * (w[f] ?? 0), 1));
function growPlain(goal, path, budget) {
  if (budget.cap !== undefined && budget.nodes >= budget.cap)
    return { stuck: "unknown", path, why: "cap" };
  if (profile.on)
    profile.nodes++;
  if (++budget.nodes > 200000 || late(budget.until ?? Infinity))
    return { stuck: "unknown", path, why: outOfBudget(goal, budget.nodes > 200000 ? "nodes" : "time", path.size) };
  const full = timed(() => rowsAt(goal, path), (ms) => {
    profile.rowsMs += ms;
  });
  work.n += 1 + full.length;
  costs.plainNodes++;
  costs.plainRows += full.length;
  const columns = [...path.values()].some((a) => Object.keys(a.lin).some((key) => key.startsWith("\u27E6")));
  const idx = full.flatMap((r, i) => columns || !Object.keys(r.lin).some((key) => key.startsWith("\u27E6")) ? [i] : []);
  const rows = idx.map((i) => full[i]), at = (i) => i < rows.length ? idx[i] : full.length + i - rows.length;
  const leafOf = (steps0, products0, squares0) => {
    const { steps, products, squares } = products0 || squares0 ? trimmed(rows.length, steps0, products0 ?? [], squares0 ?? []) : { steps: steps0, products: undefined, squares: undefined };
    return { leaf: steps.map((st) => st.kind === "input" ? { ...st, index: at(st.index) } : st), ...products?.length ? { products: products.map(([i, j]) => [at(i), at(j)]) } : {}, ...squares?.length ? { squares } : {} };
  };
  const next = openAt(goal, path, rows).find((lin) => Object.keys(lin).some((key) => key !== "1") && !path.has(canon(lin)) && !path.has(canonFlip(lin)));
  if (next && rows.length > 60) {
    const fast = timed(() => refuteFast(rows), (ms) => {
      profile.solves++;
      profile.solveMs += ms;
    });
    if (fast?.kind === "refuted")
      return { tree: leafOf(fast.steps), nodes: budget.nodes };
  }
  const verdict = next && rows.length > 60 ? solveP(rows, 2 * rows.length) : solveP(rows);
  if (verdict.kind === "refuted")
    return { tree: leafOf(verdict.steps), nodes: budget.nodes };
  if (next && wideScope.judge && verdict.kind === "sat" && wideScope.judge(verdict.witness))
    return { stuck: "sat", witness: verdict.witness, path };
  if (next && !columns && full.length > rows.length) {
    const fast = timed(() => refuteFast(full), (ms) => {
      profile.solves++;
      profile.solveMs += ms;
    });
    if (fast?.kind === "refuted")
      return { tree: { leaf: fast.steps }, nodes: budget.nodes };
  }
  let split = next ?? (verdict.kind === "unknown" ? bisect(rows, path) ?? fractional(verdict.point, path) : undefined);
  if (cellProducts.on && path.size) {
    const [id, last] = [...path].at(-1), q0 = !last.holds ? cellDiffs.get(id) : undefined;
    if (q0) {
      const at = (lin) => rows.findIndex((r) => canon(r.lin) === canon(lin));
      const d = last.lin, f = factorsOf(Object.keys(d)[0]).find((x) => !Object.keys(q0).includes(x) && Object.keys(d).every((key) => factorsOf(key).includes(x)));
      const e1 = at(q0), e2 = at(scale(q0, -1)), sign = f === undefined ? -1 : at({ [f]: -1 });
      if (e1 >= 0 && e2 >= 0 && sign >= 0) {
        const pairs = [[e1, sign], [e2, sign]], out = solve(withProducts(rows, pairs));
        if (out.kind === "refuted")
          return { tree: leafOf(out.steps, pairs), nodes: budget.nodes };
      }
    }
  }
  const monomials = rows.some((r) => Object.keys(r.lin).some(isMonomial));
  if (!split && monomials && verdict.kind === "sat") {
    const w = verdict.witness, value = (key) => w[key] ?? 0;
    const real = rows.every((r) => Object.keys(r.lin).every((key) => !isMonomial(key) || value(key) === factorsOf(key).reduce((acc, f) => acc * value(f), 1)));
    if (real)
      return { stuck: "sat", witness: w, path };
  }
  if (!split && monomials && cellProducts.on) {
    const factorSet = new Set(rows.flatMap((r) => Object.keys(r.lin).filter(isMonomial).flatMap(factorsOf)));
    const byCanon = new Map(rows.map((r, i) => [canon(r.lin), i]));
    const eqs = rows.flatMap((r, i) => Object.keys(r.lin).some((key) => key !== "1" && factorSet.has(key)) && byCanon.has(canon(scale(r.lin, -1))) ? [i] : []);
    const signs = rows.flatMap((r, i) => {
      const keys = Object.keys(r.lin);
      return keys.length === 1 && factorSet.has(keys[0]) && r.lin[keys[0]] < 0 ? [i] : [];
    });
    const pairs = eqs.flatMap((i) => signs.map((j) => [i, j])).slice(0, 200);
    if (pairs.length) {
      const sub = solve(withProducts(rows, pairs));
      if (sub.kind === "refuted")
        return { tree: leafOf(sub.steps, pairs), nodes: budget.nodes };
      const about = rows.flatMap((r, i) => !eqs.includes(i) && Object.keys(r.lin).some((key) => key !== "1" && factorSet.has(key)) && !Object.keys(r.lin).some(isMonomial) ? [i] : []);
      const more = [...pairs, ...about.flatMap((i) => signs.map((j) => [i, j]))].slice(0, 400);
      if (more.length > pairs.length) {
        const ineq = solve(withProducts(rows, more));
        if (ineq.kind === "refuted")
          return { tree: leafOf(ineq.steps, more), nodes: budget.nodes };
      }
    }
  }
  if (!split && monomials && rows.length > 40) {
    const alone = new Map;
    rows.forEach((r, i) => {
      const ks = Object.keys(r.lin).filter((key) => key !== "1");
      if (ks.length === 1 && !isMonomial(ks[0]))
        alone.set(ks[0], [...alone.get(ks[0]) ?? [], i]);
    });
    const seenP = new Set, pairs = [];
    for (const m of new Set(rows.flatMap((r) => Object.keys(r.lin).filter(isMonomial)))) {
      const fs = factorsOf(m);
      if (fs.length !== 2)
        continue;
      for (const i of alone.get(fs[0]) ?? [])
        for (const j of alone.get(fs[1]) ?? []) {
          const key2 = i < j ? `${i},${j}` : `${j},${i}`;
          if (!seenP.has(key2) && pairs.length < 300) {
            seenP.add(key2);
            pairs.push(i < j ? [i, j] : [j, i]);
          }
        }
    }
    if (pairs.length) {
      const mc = solve(withProducts(rows, pairs));
      if (mc.kind === "refuted")
        return { tree: leafOf(mc.steps, pairs), nodes: budget.nodes };
    }
  }
  if (!split && monomials && rows.length <= 40) {
    const factorSet = new Set(rows.flatMap((r) => Object.keys(r.lin).filter(isMonomial).flatMap(factorsOf)));
    const relevant = rows.flatMap((r, i) => Object.keys(r.lin).every((key) => key === "1" || factorsOf(key).every((f) => factorSet.has(f))) ? [i] : []);
    const pairs = [];
    for (const [a, i] of relevant.entries())
      for (const j of relevant.slice(a))
        pairs.push([i, j]);
    pairs.splice(300);
    const product = solve(withProducts(rows, pairs));
    if (product.kind === "refuted")
      return { tree: leafOf(product.steps, pairs), nodes: budget.nodes };
    const degree = Math.max(...rows.flatMap((r) => Object.keys(r.lin).map((key) => key === "1" ? 0 : factorsOf(key).length)));
    if (degree >= 3) {
      const signs = rows.flatMap((r, i) => {
        const key = Object.keys(r.lin)[0];
        return Object.keys(r.lin).length === 1 && Object.values(r.lin)[0] < 0 && !isMonomial(key) && (!isCell(key) || factorSet.has(key)) ? [i] : [];
      });
      const sq = signs.flatMap((i, a) => signs.slice(a).map((j) => [i, j])), cubes = [];
      for (let s = 0;s < sq.length; s++)
        for (let i = 0;i < rows.length; i++)
          cubes.push([rows.length + s, i]);
      const third = solve(withProducts(rows, [...sq, ...cubes, ...pairs]));
      if (third.kind === "refuted")
        return { tree: leafOf(third.steps, [...sq, ...cubes, ...pairs]), nodes: budget.nodes };
    }
    const squares = [...new Map([...productForms(goal, path), ...squareForms(rows)].map((t) => [canon(t), t])).values()].slice(0, 64);
    if (squares.length) {
      const alone = solve(withProducts(rows, [], squares));
      if (alone.kind === "refuted")
        return { tree: leafOf(alone.steps, [], squares), nodes: budget.nodes };
      const sos = solve(withProducts(rows, pairs, squares));
      if (sos.kind === "refuted")
        return { tree: leafOf(sos.steps, pairs, squares), nodes: budget.nodes };
      if (degree >= 3) {
        const signs = rows.flatMap((r, i) => {
          const key = Object.keys(r.lin)[0];
          return Object.keys(r.lin).length === 1 && Object.values(r.lin)[0] < 0 && factorSet.has(key) ? [i] : [];
        });
        const weighted = [...pairs, ...signs.flatMap((i) => squares.map((_, s) => [i, rows.length + s]))].slice(0, 600);
        const third = solve(withProducts(rows, weighted, squares));
        if (third.kind === "refuted")
          return { tree: leafOf(third.steps, weighted, squares), nodes: budget.nodes };
      }
    }
    const ones = rows.flatMap((r, i) => {
      const ks = Object.keys(r.lin);
      return ks.length === 2 && r.lin["1"] === 1 && ks.some((key) => key !== "1" && r.lin[key] === -1 && factorSet.has(key)) ? [i] : [];
    });
    for (const xi of ones.slice(0, 3)) {
      const x = Object.keys(rows[xi].lin).find((key) => key !== "1"), name = (fs) => [...fs].sort().join("*");
      const forms = new Map;
      for (const m of new Set(rows.flatMap((r) => Object.keys(r.lin).filter(isMonomial)))) {
        const [a, b, ...more] = factorsOf(m);
        if (!a || !b || more.length)
          continue;
        for (const [u, w] of [[a, b], [b, a]]) {
          const t = { [name([x, u])]: 1, [w]: -1 };
          forms.set(canon(t), t);
        }
      }
      const times = relevant.map((i) => [i, xi]), sq = [...forms.values()].slice(0, 32);
      const multiplied = solve(withProducts(rows, times, sq));
      if (multiplied.kind === "refuted")
        return { tree: leafOf(multiplied.steps, times, sq), nodes: budget.nodes };
    }
    const factors = [...new Set(rows.flatMap((r) => Object.keys(r.lin).filter(isMonomial).flatMap(factorsOf)))];
    const fresh = (lin) => !path.has(canon(lin)) && !path.has(canonFlip(lin));
    const zero = factors.find((f) => fresh({ [f]: 1 }));
    const apart = factors.flatMap((f, i) => factors.slice(i + 1).map((g) => ({ [f]: 1, [g]: -1 }))).find(fresh);
    if (zero)
      split = { [zero]: 1 };
    else if (apart)
      split = apart;
  }
  if (!split)
    return { stuck: verdict.kind === "sat" ? "sat" : "unknown", ...verdict.kind === "sat" ? { witness: verdict.witness } : {}, path };
  const id = canon(split);
  const yes = growPlain(goal, new Map(path).set(id, { lin: split, holds: true }), budget);
  if (!("tree" in yes))
    return yes;
  const lifted = lift(goal, yes.tree, new Map(path).set(id, { lin: split, holds: true }), path);
  if (lifted)
    return { tree: lifted, nodes: budget.nodes };
  const no = growPlain(goal, new Map(path).set(id, { lin: split, holds: false }), budget);
  if (!("tree" in no))
    return no;
  return { tree: { split, yes: yes.tree, no: no.tree }, nodes: budget.nodes };
}
function trimmed(n0, steps, pairs, squares) {
  const used = new Set(steps.flatMap((st) => st.kind === "input" && st.index >= n0 ? [st.index] : []));
  for (let j = pairs.length - 1;j >= 0; j--)
    if (used.has(n0 + squares.length + j)) {
      for (const i of pairs[j])
        if (i >= n0)
          used.add(i);
    }
  const keepS = squares.flatMap((_, s) => used.has(n0 + s) ? [s] : []), keepP = pairs.flatMap((_, j) => used.has(n0 + squares.length + j) ? [j] : []);
  const to = new Map;
  keepS.forEach((s, r) => to.set(n0 + s, n0 + r));
  keepP.forEach((j, r) => to.set(n0 + squares.length + j, n0 + keepS.length + r));
  const re = (i) => i < n0 ? i : to.get(i);
  return {
    steps: steps.map((st) => st.kind === "input" ? { ...st, index: re(st.index) } : st),
    products: keepP.map((j) => [re(pairs[j][0]), re(pairs[j][1])]),
    squares: keepS.map((s) => squares[s])
  };
}
var productMemo = new WeakMap;
function productForms(goal, path) {
  let prods = productMemo.get(goal);
  if (!prods) {
    const found = [], seen = new WeakSet;
    const walk = (t) => {
      if (seen.has(t))
        return;
      seen.add(t);
      if (t.op === "prod")
        found.push(t);
      for (const val of Object.values(t))
        if (Array.isArray(val))
          val.forEach((x) => walk(x));
        else if (typeof val === "object" && val !== null)
          walk(val);
    };
    goal.hyps.forEach(walk);
    productMemo.set(goal, prods = found);
  }
  const out = [];
  for (const e of prods) {
    if (e.op !== "prod")
      continue;
    const a = linear(e.a, path), b = linear(e.b, path);
    if (!a || !b)
      continue;
    const t = sub(a, b);
    if (Object.keys(t).some((key) => key.includes("\u27E6")) || Object.entries(t).every(([key, c]) => key === "1" || c === 0))
      continue;
    out.push(Object.fromEntries(Object.entries(t).filter(([, c]) => c !== 0)));
  }
  return out;
}
function squareForms(rows) {
  const monos = [...new Set(rows.flatMap((r) => Object.keys(r.lin).filter(isMonomial)))].sort((a, b) => factorsOf(a).length - factorsOf(b).length);
  const out = new Map;
  const name = (fs) => [...fs].sort().join("*");
  const halves = (fs) => {
    const pick = (from, chosen) => {
      if (chosen.length === fs.length / 2) {
        const u = name(chosen.map((i) => fs[i])), w = name(fs.filter((_, i) => !chosen.includes(i)));
        if (u < w) {
          const t = { [u]: 1, [w]: -1 };
          out.set(canon(t), t);
        }
        return;
      }
      for (let i = from;i < fs.length; i++)
        pick(i + 1, [...chosen, i]);
    };
    pick(0, []);
  };
  for (const m of monos) {
    const fs = factorsOf(m);
    if (fs.length > 6)
      continue;
    if (fs.length % 2 === 0)
      halves(fs);
    else
      for (let i = 0;i < fs.length; i++)
        halves(fs.filter((_, j) => j !== i));
    if (out.size >= 64)
      break;
  }
  return [...out.values()].slice(0, 64);
}
var rowsSeen = new WeakMap;
function rowsAt(goal, path) {
  let byPath = rowsSeen.get(goal);
  if (!byPath)
    rowsSeen.set(goal, byPath = new Map);
  let id = "";
  for (const [key, a] of path)
    id += `${a.holds ? "+" : "-"}${key}|`;
  let rows = byPath.get(id);
  if (!rows) {
    if (byPath.size >= 4096)
      byPath.clear();
    byPath.set(id, rows = env.GDP_ROWS_SHARED === "0" ? leafConstraintsReusing(goal, path) : proverRows(goal, path));
  }
  return rows;
}
function lift(goal, tree, from, to) {
  const own = to.size;
  const reads = (t) => ("leaf" in t) ? t.leaf.some((st) => st.kind === "input" && st.index === own) || (t.products ?? []).some(([i, j]) => i === own || j === own) : reads(t.yes) || reads(t.no);
  if (reads(tree))
    return;
  const go = (t, a, b) => {
    if (!("leaf" in t)) {
      const sid = canon(t.split);
      if (b.has(sid) || b.has(canonFlip(t.split)))
        return;
      const yes = go(t.yes, new Map(a).set(sid, { lin: t.split, holds: true }), new Map(b).set(sid, { lin: t.split, holds: true }));
      const no = yes && go(t.no, new Map(a).set(sid, { lin: t.split, holds: false }), new Map(b).set(sid, { lin: t.split, holds: false }));
      return yes && no ? { split: t.split, yes, no } : undefined;
    }
    const ra = rowsAt(goal, a), rb = rowsAt(goal, b), at = new Map;
    rb.forEach((r, i) => {
      const key = canon(r.lin);
      if (!at.has(key))
        at.set(key, i);
    });
    const map = (i) => i < ra.length ? at.get(canon(ra[i].lin)) : undefined;
    const leaf = [];
    for (const st of t.leaf) {
      if (st.kind !== "input") {
        leaf.push(st);
        continue;
      }
      const j = map(st.index);
      if (j === undefined)
        return;
      leaf.push({ ...st, index: j });
    }
    const products = [];
    for (const [i, j] of t.products ?? []) {
      const pi = map(i), pj = map(j);
      if (pi === undefined || pj === undefined)
        return;
      products.push([pi, pj]);
    }
    return { leaf, ...t.products ? { products } : {}, ...t.squares ? { squares: t.squares } : {} };
  };
  return go(tree, from, to);
}
function widen(part, whole, tree, opaque = {}, pp = new Map, wp = pp) {
  if (pastWall())
    return;
  const names = Object.keys(opaque);
  const rename = (lin) => {
    if (!names.length)
      return lin;
    let out = {};
    for (const [key, c] of Object.entries(lin)) {
      const e = opaque[key];
      if (e) {
        const l = linear(e, wp);
        if (!l)
          return;
        out = add(out, scale(l, c));
      } else if (names.some((n) => key.includes(n)))
        return;
      else
        out = add(out, { [key]: c });
    }
    return out;
  };
  if (!("leaf" in tree)) {
    const id = canon(tree.split), wl = rename(tree.split);
    if (!wl) {
      const o = grow(whole, wp);
      return "tree" in o ? o.tree : undefined;
    }
    const wid = canon(wl), known = Object.keys(wl).every((key) => key === "1") ? (wl["1"] ?? 0) <= 0 : wp.has(wid) ? wp.get(wid).holds : wp.has(canonFlip(wl)) ? !wp.get(canonFlip(wl)).holds : undefined;
    if (known !== undefined)
      return widen(part, whole, known ? tree.yes : tree.no, opaque, new Map(pp).set(id, { lin: tree.split, holds: known }), wp);
    const yes = widen(part, whole, tree.yes, opaque, new Map(pp).set(id, { lin: tree.split, holds: true }), new Map(wp).set(wid, { lin: wl, holds: true }));
    const no = yes && widen(part, whole, tree.no, opaque, new Map(pp).set(id, { lin: tree.split, holds: false }), new Map(wp).set(wid, { lin: wl, holds: false }));
    return yes && no ? { split: wl, yes, no } : undefined;
  }
  const rp = rowsAt(part, pp);
  if (pastWall())
    return;
  const rw = rowsAt(whole, wp), at = new Map;
  const remember = (out) => {
    rememberProofRows(out, whole, wp, rw);
    return out;
  };
  rw.forEach((r, i) => {
    const key = canon(r.lin);
    if (!at.has(key))
      at.set(key, i);
  });
  const map = (i) => {
    if (i >= rp.length)
      return i - rp.length + rw.length;
    const l = rename(rp[i].lin);
    return l && at.get(canon(l));
  };
  const leaf = [], products = [], squares = (tree.squares ?? []).map(rename);
  let ok = squares.every(Boolean);
  for (const st of ok ? tree.leaf : []) {
    if (st.kind !== "input") {
      leaf.push(st);
      continue;
    }
    const j = map(st.index);
    if (j === undefined) {
      ok = false;
      break;
    }
    leaf.push({ ...st, index: j });
  }
  for (const [i, j] of ok ? tree.products ?? [] : []) {
    const pi = map(i), pj = map(j);
    if (pi === undefined || pj === undefined) {
      ok = false;
      break;
    }
    products.push([pi, pj]);
  }
  if (ok && names.length && !checkRefutation(withProducts(rw, products, squares), leaf))
    ok = false;
  if (ok)
    return remember({ leaf, ...tree.products ? { products } : {}, ...tree.squares ? { squares } : {} });
  const absurd = rw.findIndex((r) => Object.keys(r.lin).every((key) => key === "1") && (r.lin["1"] ?? 0) > 0);
  if (absurd >= 0)
    return remember({ leaf: [{ kind: "input", index: absurd }] });
  const out = grow(whole, wp);
  return "tree" in out ? out.tree : undefined;
}
var nearSeen = new WeakMap;
var namesOf2 = (t) => {
  const out = new Set;
  walkOnce(t, (o) => {
    costs.goalNodes++;
    for (const [key, v] of Object.entries(o))
      if ((key === "name" || key === "map") && typeof v === "string")
        out.add(v);
  });
  return out;
};
function nearOf(goal) {
  let out = nearSeen.get(goal);
  if (!out) {
    const theirs = new Set(namesOf2(goal.hyps.at(-1)));
    nearSeen.set(goal, out = goal.hyps.map((h) => [...namesOf2(h)].every((n) => theirs.has(n))));
  }
  return out;
}
var unitFirst = env.GDP_UNITS !== "0";
var unitsNow = true;
var unitAtoms = (goal) => unitFirst && unitsNow ? unitsOf(goal) : [];
var unitSeen = new WeakMap;
function unitsOf(goal) {
  let out = unitSeen.get(goal);
  if (out)
    return out;
  const root = new Map, rows = leafConstraints(goal, root), seen = new Set, given = new Set;
  costs.unitRows += rows.length;
  const lo = new Map, hi = new Map;
  for (const r of rows) {
    given.add(canon(r.lin));
    const vs = Object.keys(r.lin).filter((key) => key !== "1");
    if (vs.length !== 1)
      continue;
    const x = vs[0], c = r.lin[x], k = r.lin["1"] ?? 0, bound = -k / c;
    if (c > 0)
      hi.set(x, Math.min(hi.get(x) ?? Infinity, Math.floor(bound)));
    else
      lo.set(x, Math.max(lo.get(x) ?? -Infinity, Math.ceil(bound)));
  }
  const range = (lin) => Object.entries(lin).reduce(([a, b], [x, c]) => x === "1" ? [a + c, b + c] : c > 0 ? [a + c * (lo.get(x) ?? -Infinity), b + c * (hi.get(x) ?? Infinity)] : [a + c * (hi.get(x) ?? Infinity), b + c * (lo.get(x) ?? -Infinity)], [0, 0]);
  out = [];
  for (const h of goal.hyps.slice(0, -1)) {
    const atoms = [];
    openH(h, root, atoms);
    for (const lin of atoms) {
      const id = canon(lin);
      if (seen.has(id) || seen.has(canonFlip(lin)) || !Object.keys(lin).some((key) => key !== "1"))
        continue;
      seen.add(id);
      const [a, b] = range(lin);
      if (given.has(id) || given.has(canon(atomOf(lin, false).lin)) || b <= 0 || a >= 1)
        out.push(lin);
    }
  }
  unitSeen.set(goal, out);
  return out;
}
var openSeen = new WeakMap;
function openAt(goal, path, rows) {
  const open = [];
  const hyps = goal.hyps, last = hyps.length - 1;
  let byHyp = openSeen.get(goal);
  if (!byHyp)
    openSeen.set(goal, byHyp = new Map);
  const openOf = (h) => {
    let seen = byHyp.get(h);
    if (!seen)
      byHyp.set(h, seen = {});
    return reusing(seen, path, (p) => {
      const out = [];
      openH(h, p, out);
      return out;
    });
  };
  const put = (xs) => {
    for (const x of xs)
      open.push(x);
  };
  if (unitFirst && unitsNow)
    put(unitsOf(goal));
  if (last >= 0)
    put(openOf(hyps[last]));
  const near = nearOf(goal);
  for (const [i, h] of hyps.entries())
    if (i !== last && near[i])
      put(openOf(h));
  for (const [i, h] of hyps.entries())
    if (i !== last && !near[i])
      put(openOf(h));
  put(openCells(rows, path));
  return open;
}
function outOfBudget(goal, limit, depth) {
  const steps = Number(/@(\d+) steps/.exec(goal.name)?.[1] ?? 1);
  return `the prover's ${limit === "nodes" ? "200,000-node" : "time"} budget ran out at ${goal.hyps.length} hypotheses, ${depth} case splits deep. ` + `Each case a step decides multiplies the cases to refute, so ${steps > 1 ? `a law over ${steps} steps` : "many interacting cases"} can outgrow it: ` + "state the law over fewer steps (a one-step law and an invariant often give the same), or split it into laws about fewer conditions";
}
function withCuts(goal, path, budget) {
  const rows = leafConstraints(goal, path);
  const columns = [...new Set(rows.flatMap((r) => Object.keys(r.lin)).filter((n) => n.startsWith("\u27E6")))].map((n) => ({ n, e: columnTerm(n) })).filter((x) => x.e.op === "if" && !decided(x.e, path)).sort((a, b) => Number(a.n.slice(1, -1)) - Number(b.n.slice(1, -1)));
  const chain = [];
  let at = new Map(path);
  for (const { n, e } of columns) {
    if (late(budget.until ?? Infinity))
      return;
    if (e.op !== "if")
      continue;
    const a = linear(e.then, at), b = linear(e.else, at), focus = topAtoms(e.c, at);
    if (!a || !b || !focus.length)
      continue;
    for (const lemma of [sub(v(n), a), sub(v(n), b), sub(a, v(n)), sub(b, v(n))]) {
      const id = canon(lemma);
      if (at.has(id) || Object.keys(lemma).every((key) => key === "1"))
        continue;
      const no = growFocused(goal, new Map(at).set(id, { lin: lemma, holds: false }), focus, { nodes: 0, until: budget.until });
      if ("tree" in no) {
        chain.push({ split: lemma, no: no.tree });
        at = new Map(at).set(id, { lin: lemma, holds: true });
      }
    }
  }
  if (!chain.length)
    return;
  const rest = growPlain(goal, at, budget);
  if (!("tree" in rest))
    return rest;
  return { tree: chain.reduceRight((acc, c) => ({ split: c.split, yes: acc, no: c.no }), rest.tree), nodes: budget.nodes };
}
function topAtoms(c, path) {
  if (c.op === "not")
    return topAtoms(c.x, path);
  if (c.op === "and" || c.op === "or")
    return c.xs.flatMap((y) => topAtoms(y, path));
  if (c.op === "flag" || c.op === "all")
    return [];
  const a = linear(c.a, path), b = linear(c.b, path);
  if (!a || !b)
    return [];
  const atoms = c.op === "<=" ? [sub(a, b)] : c.op === "<" ? [add(sub(a, b), k(1))] : [sub(a, b), sub(b, a)];
  return atoms.filter((l) => Object.keys(l).some((key) => key !== "1") && !path.has(canon(l)) && !path.has(canonFlip(l)));
}
function growFocused(goal, path, focus, budget, near = focus) {
  if (++budget.nodes > 64 || late(budget.until ?? Infinity))
    return { stuck: "unknown", path };
  const leaf = leafConstraints(goal, path);
  work.n += 1 + leaf.length;
  costs.plainRows += leaf.length;
  const verdict = solveNear(leaf, [...near, ...[...path.values()].slice(-1).map((a) => a.lin)]);
  if (verdict.kind === "refuted")
    return { tree: { leaf: verdict.steps }, nodes: budget.nodes };
  const split = focus.find((l) => !path.has(canon(l)) && !path.has(canonFlip(l)));
  if (!split)
    return { stuck: verdict.kind === "sat" ? "sat" : "unknown", path };
  const id = canon(split);
  const yes = growFocused(goal, new Map(path).set(id, { lin: split, holds: true }), focus, budget, near);
  if (!("tree" in yes))
    return yes;
  const no = growFocused(goal, new Map(path).set(id, { lin: split, holds: false }), focus, budget, near);
  if (!("tree" in no))
    return no;
  return { tree: { split, yes: yes.tree, no: no.tree }, nodes: budget.nodes };
}
function solveNear(rows, seeds) {
  const uses = new Map;
  for (const r of rows)
    for (const key in r.lin)
      if (key !== "1")
        uses.set(key, (uses.get(key) ?? 0) + 1);
  const hub = (key) => (uses.get(key) ?? 0) > Math.max(16, rows.length / 8);
  const reach = new Set(seeds.flatMap((l) => Object.keys(l).filter((key) => key !== "1")));
  for (let hop = 0;hop < 2; hop++) {
    const from = new Set(reach);
    for (const r of rows) {
      const keys = Object.keys(r.lin).filter((key) => key !== "1");
      if (keys.some((key) => from.has(key) && !hub(key)))
        keys.forEach((key) => reach.add(key));
    }
  }
  const picked = rows.flatMap((r, i) => Object.keys(r.lin).every((key) => key === "1" || reach.has(key)) ? [i] : []);
  const near = solve(picked.map((i) => rows[i]));
  return near.kind === "refuted" ? { kind: "refuted", steps: near.steps.map((st) => st.kind === "input" ? { ...st, index: picked[st.index] } : st) } : near;
}
function bisect(rows, path) {
  const refutes = (extra) => solve([...rows, { lin: extra, label: "" }]).kind === "refuted";
  const names = [...new Set(rows.flatMap((r) => Object.keys(r.lin).filter((key) => key !== "1")))];
  for (const x of names) {
    let hi = 1;
    while (hi < 1 << 20 && !refutes({ 1: hi + 1, [x]: -1 }))
      hi *= 2;
    if (hi >= 1 << 20)
      continue;
    let lo = 0, top = hi;
    while (lo < top) {
      const c = Math.floor((lo + top) / 2);
      if (refutes({ [x]: 1, 1: -c }))
        lo = c + 1;
      else
        top = c;
    }
    const mid = Math.floor((lo + hi) / 2);
    for (const c of lo === hi ? [lo, lo - 1] : [mid]) {
      const lin = c === 0 ? { [x]: 1 } : { [x]: 1, 1: -c };
      if (!path.has(canon(lin)) && !path.has(canonFlip(lin)))
        return lin;
    }
  }
  return;
}
function fractional(point, path) {
  for (const [x, value] of Object.entries(point ?? {})) {
    if (Math.abs(value - Math.round(value)) < 0.000000001 || isMonomial(x))
      continue;
    const c = Math.floor(value), lin = c === 0 ? { [x]: 1 } : { [x]: 1, 1: -c };
    if (!path.has(canon(lin)) && !path.has(canonFlip(lin)))
      return lin;
  }
  return;
}
var eachRead = (f) => {
  const inE = (e) => {
    if (e.op === "get") {
      f(e);
      inE(e.key);
    } else if (e.op === "if")
      inC(e.c), inE(e.then), inE(e.else);
    else if (e.op === "mul" || e.op === "proj")
      inE(e.a);
    else if ("b" in e)
      inE(e.a), inE(e.b);
  };
  const inC = (c) => c.op === "flag" ? undefined : c.op === "all" ? inC(c.c) : c.op === "not" ? inC(c.x) : c.op === "and" || c.op === "or" ? c.xs.forEach(inC) : (inE(c.a), inE(c.b));
  return { inE, inC };
};
function mapReads(goals) {
  const all = new Map, out = new Map;
  const { inC } = eachRead((e0) => {
    const key = e0.key.op === "tup" || e0.key.op === "proj" ? projected(e0.key) : e0.key, id = JSON.stringify(key);
    for (const p of tupleParts(key))
      all.set(JSON.stringify(p), p);
    if (!out.has(e0.map))
      out.set(e0.map, new Map);
    out.get(e0.map).set(id, key);
  });
  for (const g of goals)
    g.hyps.forEach(inC);
  return { keys: [...all.values()], byMap: new Map([...out].map(([mp, ks]) => [mp, [...ks.values()]])) };
}
var keyValue = (cell, w) => {
  const inner = cell.slice(cell.indexOf("[") + 1, -1);
  if (inner.startsWith("\u27E8")) {
    const parts = cellParts(cell).keys.map((k) => keyValue(`_[${canon(k)}]`, w));
    if (parts.some((x) => x === undefined))
      return;
    try {
      return parts.slice(0, -1).reduceRight((b, a) => cpair(a, b), parts.at(-1));
    } catch {
      return;
    }
  }
  const parts = [];
  let depth = 0, from = 0;
  for (let i = 0;i < inner.length; i++) {
    const ch = inner[i];
    if (ch === "[")
      depth++;
    else if (ch === "]")
      depth--;
    else if (ch === "," && depth === 0) {
      parts.push(inner.slice(from, i));
      from = i + 1;
    }
  }
  parts.push(inner.slice(from));
  let value = 0;
  for (const part of parts.filter(Boolean)) {
    const at = part.lastIndexOf(":"), name = part.slice(0, at), coef = Number(part.slice(at + 1));
    if (name === "1")
      value += coef;
    else if (name in w)
      value += coef * w[name];
    else if (name.includes("["))
      return;
  }
  return value;
};
var modelCuts = env.GDP_MODEL_CUTS !== "0";
var disjuncts = (c) => c.op === "or" ? c.xs.flatMap(disjuncts) : c.op === "not" && c.x.op === "and" ? c.x.xs.flatMap((y) => disjuncts({ op: "not", x: y })) : c.op === "not" && c.x.op === "not" ? disjuncts(c.x.x) : [c];
function modelInstances(m, laws, inst, goal, w, most = 64, sorted = false) {
  const pm = plainOf(m), qs = Object.entries(pm.step.flags ?? {}).filter((e) => e[1].op === "all" && w[`?${e[0]}`] === 1);
  const keyed = laws.filter((l) => l.forall);
  if (!keyed.length && !qs.length)
    return;
  const fns = Object.keys(pm.fns ?? {}), mm = { ...pm, fns: undefined, maps: { ...pm.maps ?? {}, ...Object.fromEntries([...fns, ...pm.inputMaps ?? [], ...Object.keys(pm.counts ?? {})].map((f) => [f, 0])) } };
  const maps = Object.fromEntries(Object.keys(mm.maps).map((mp) => [mp, new Map]));
  for (const [cell, value] of Object.entries(w)) {
    const br = cell.indexOf("[");
    if (br < 0 || !cell.endsWith("]") || !maps[cell.slice(0, br)])
      continue;
    const key = keyValue(cell, w);
    if (key !== undefined)
      maps[cell.slice(0, br)].set(key, value);
  }
  const st = { scalars: {}, maps }, read = (at) => new Proxy(at, { get: (t, p) => (p in t) ? t[p] : w[p] ?? 0, has: (t, p) => (p in t) || (p in w) });
  for (const [c, d] of Object.entries(pm.counts ?? {})) {
    const had = maps[c], sum = (x) => {
      const e1 = read(d.base ? { [d.j]: Math.floor(x / d.base), [d.lo]: x % d.base } : { [d.j]: x }), n = Math.min(256, evalE(d.below, e1, st, mm));
      let t = 0;
      for (let k = 0;k < n; k++)
        t += evalE(d.body, read({ ...e1, [d.key]: k }), st, mm);
      return t;
    };
    maps[c] = new class extends Map {
      get(x) {
        if (!super.has(x))
          super.set(x, 0), super.set(x, sum(x));
        return super.get(x);
      }
    }(had);
  }
  const ev = (f) => {
    try {
      return f();
    } catch {
      return;
    }
  };
  const valueOf = (e) => {
    try {
      return evalE(e, read({}), st, mm);
    } catch {
      return;
    }
  };
  const { keys, byMap } = mapReads([goal]), all = new Map;
  const tupled = [...byMap.values()].some((ks) => ks.some((k) => k.op === "tup"));
  for (const e of keys) {
    const v2 = valueOf(e);
    if (v2 !== undefined && !all.has(v2))
      all.set(v2, e);
  }
  if (!all.size)
    return;
  const witnessFirst = (p) => {
    const isW = (e) => /"name":"(some\$|w\?)/.test(JSON.stringify(e));
    return new Map([...[...p].filter(([, e]) => isW(e)), ...[...p].filter(([, e]) => !isW(e))]);
  };
  const zero = { op: "const", value: 0 };
  const accepts = instanceSortGuard(m, laws);
  const sortsOf = (body, names, atoms) => sortTerms(body, names, fns, (mp) => tupled ? [...keys, ...byMap.get(mp) ?? []] : keys).map((ts) => {
    const p = new Map;
    for (const e of ts ?? []) {
      const v2 = valueOf(e);
      if (v2 !== undefined && !p.has(v2) && (!atoms || e.op === "var"))
        p.set(v2, e);
    }
    const fallback = new Map([...all].filter(([, e]) => !atoms || e.op === "var"));
    const q = p.size ? p : fallback, r = witnessFirst(q);
    return ts || r.has(0) ? r : r.set(0, zero);
  });
  const out = { ...inst };
  let added = 0, evals = 0, left = 0, ineligible = false;
  const each = (id, names, body, atoms) => {
    if (pastWall())
      return;
    const until = evals + Math.max(256, Math.floor((20000 - evals) / Math.max(1, left--)));
    const have = new Set, had = out[id] ?? [], n = names.length, sorts = sortsOf(body, names, atoms);
    const keyNames = new Set;
    eachRead((e) => {
      if (fns.includes(e.map))
        return;
      const text = JSON.stringify(e.key);
      for (const name of names)
        if (text.includes(`"name":${JSON.stringify(name)}`))
          keyNames.add(name);
    }).inC(body);
    if (n === 1 && keyNames.has(names[0])) {
      const covered = new Set(had.map(valueOf));
      if ([...sorts[0].keys()].every((v2) => covered.has(v2)))
        return;
    }
    for (let t = 0;t + n <= had.length; t += n)
      have.add(JSON.stringify(had.slice(t, t + n)));
    const ready = Array.from({ length: n + 1 }, () => []);
    if (modelCuts)
      for (const d of disjuncts(body)) {
        const t = JSON.stringify(d);
        ready[names.reduce((a, x, j) => t.includes(`"name":${JSON.stringify(x)}`) ? j + 1 : a, 0)].push(d);
      }
    const go = (i, at, terms) => {
      if (added >= most || evals > until || evals % 512 === 0 && pastWall())
        return;
      for (const d of ready[i]) {
        evals++;
        if (ev(() => evalC(d, read(at), st, mm)) === true)
          return;
      }
      if (i === n) {
        evals++;
        if (ev(() => evalC(body, read(at), st, mm)) !== false)
          return;
        const id2 = JSON.stringify(terms);
        if (have.has(id2))
          return;
        if (sorted && terms.some((e, j) => !accepts(id, j, e))) {
          ineligible = true;
          return;
        }
        have.add(id2);
        out[id] = [...out[id] ?? [], ...terms];
        added++;
        return;
      }
      const domain = new Map(sorts[i]);
      if (!keyNames.has(names[i])) {
        const free = new Set(names.slice(i));
        const extra = modelValueTerms(body, names[i], free, (e) => {
          try {
            return evalE(e, read(at), st, mm);
          } catch {
            return;
          }
        });
        if (extra.length)
          for (const [v2] of domain)
            domain.set(v2, { op: "const", value: v2 });
        for (const e of extra) {
          const v2 = valueOf(e);
          if (v2 !== undefined)
            domain.set(v2, e);
        }
      }
      for (const [v2, e] of domain)
        go(i + 1, { ...at, [names[i]]: v2 }, [...terms, e]);
    };
    go(0, {}, []);
    if (modelsTrace)
      console.error(`[models]   ${atoms ? "atoms" : "all"} ${id.slice(0, 30)}: sorts ${sorts.map((x) => x.size).join("x")}, evals ${evals} of ${until}, added ${added}`);
  };
  for (const atoms of [true, false]) {
    if (atoms === false && added)
      break;
    evals = 0;
    left = keyed.length + qs.length;
    for (const l of keyed)
      each(l.name, [l.forall, ...l.keys ?? []], l.holds, atoms);
    for (const [f, q] of qs)
      each(`?${f}`, boundOf(q), q.c, atoms);
  }
  return added || ineligible ? out : undefined;
}
var modelsTrace = !!env.GDP_MODELS_TRACE;
var modelFloor = Number(env.GDP_MODEL_FLOOR ?? 1000);
var fixedMemo = new WeakMap;
function sortTerms(body, vars, fns, at) {
  const out = vars.map(() => {
    return;
  });
  eachRead((e) => {
    if (fns.includes(e.map) || !vars.some((x) => JSON.stringify(e.key).includes(`"name":${JSON.stringify(x)}`)))
      return;
    for (const t of at(e.map)) {
      const b = matchMany(e.key, t, vars);
      if (b)
        vars.forEach((x, i) => {
          if (x in b)
            (out[i] ??= []).push(b[x]);
        });
    }
  }).inC(body);
  return out;
}
function matchMany(pattern, term, xs) {
  const bound = {};
  const go = (p, t) => {
    if (p.op === "var" && xs.includes(p.name)) {
      if (p.name in bound)
        return JSON.stringify(bound[p.name]) === JSON.stringify(t);
      bound[p.name] = t;
      return true;
    }
    if (p.op !== t.op)
      return false;
    const pe = Object.entries(p), te = t;
    return pe.every(([k, val]) => k === "op" || (typeof val === "object" && val !== null ? Array.isArray(val) ? Array.isArray(te[k]) && te[k].length === val.length && val.every((y, i) => go(y, te[k][i])) : go(val, te[k]) : val === te[k]));
  };
  if (go(pattern, term))
    return bound;
  const p = radix(pattern), t = p && radix(term);
  if (!p || !t || p.length !== t.length || p.some(([, c], i) => c !== t[i][1]))
    return;
  const out = {};
  for (const [i, [e]] of p.entries()) {
    const u = t[i][0];
    if (e.op === "var" && xs.includes(e.name)) {
      if (e.name in out && JSON.stringify(out[e.name]) !== JSON.stringify(u))
        return;
      out[e.name] = u;
    } else if (JSON.stringify(e) !== JSON.stringify(u))
      return;
  }
  return out;
}
var radix = (e) => {
  const out = [];
  const go = (x, k) => x.op === "add" ? go(x.a, k) && go(x.b, k) : x.op === "mul" ? go(x.a, k * x.k) : x.op === "var" || x.op === "get" ? (out.push([x, k]), true) : false;
  if (!go(e, 1) || out.length < 2)
    return;
  out.sort((a, b) => b[1] - a[1]);
  return out.every(([, c], i) => i === 0 || c !== out[i - 1][1]) ? out : undefined;
};
var triggerOn = env.GDP_TRIGGER !== "0";
var leafRowsOf = new WeakMap;
function usedHyps(goal, tree, path = new Map, out = new Set) {
  const known = "leaf" in tree && !tree.products && !tree.squares ? leafRowsOf.get(tree) : undefined;
  if (known && "leaf" in tree) {
    for (const st of tree.leaf)
      if (st.kind === "input") {
        const s = known.at.get(st.index)?.src;
        if (typeof s === "number" && s >= 0)
          out.add(s);
      }
    return out;
  }
  if ("leaf" in tree) {
    const rows = rowsAt(goal, path), n = rows.length, sq = tree.squares?.length ?? 0;
    const mark = (i) => {
      if (i < n) {
        const s = rows[i].src;
        if (s && "fact" in s)
          out.add(s.fact);
      } else if (i >= n + sq) {
        const pq = tree.products?.[i - n - sq];
        if (pq) {
          mark(pq[0]);
          mark(pq[1]);
        }
      }
    };
    for (const st of tree.leaf)
      if (st.kind === "input")
        mark(st.index);
    return out;
  }
  const id = canon(tree.split);
  usedHyps(goal, tree.yes, new Map(path).set(id, { lin: tree.split, holds: true }), out);
  return usedHyps(goal, tree.no, new Map(path).set(id, { lin: tree.split, holds: false }), out);
}
var atPoint = { on: false };
var memoCap = Number(env.GDP_MEMO_CAP ?? 4);
var memos = new Map;
var machineText = new WeakMap;
var lawText = new WeakMap;
var alpha = env.GDP_MEMO_ALPHA !== "0";
var sortedOn = env.GDP_SORTED !== "0";
var sortsMemo = new WeakMap;
var sortPlacesOn = env.GDP_SORT_PLACES !== "0";
function sortsOf(m, laws) {
  const par = new Map, find = (a) => {
    const q = par.get(a);
    if (q === undefined || q === a)
      return a;
    const r = find(q);
    par.set(a, r);
    return r;
  };
  const named = new Set, union = (a, b) => {
    named.add(a);
    named.add(b);
    const ra = find(a), rb = find(b);
    if (ra !== rb)
      par.set(ra, rb);
  };
  const pats = patternsOf(m, laws), whole = new Map;
  const sortPlaces = sortPlacesOn && Object.values(pats).some((c) => c.length > 1 && c[0] === 0);
  const valued = (e) => sortPlaces && !((pats[e.map]?.length ?? 0) > 1) && e.key.op !== "tup" && (e.key.op === "var" || e.key.op === "get");
  const leaves = (e, k, out) => {
    if (e.op === "add") {
      leaves(e.a, k, out);
      leaves(e.b, k, out);
    } else if (e.op === "mul")
      leaves(e.a, k * e.k, out);
    else if (e.op !== "const")
      out.push([e, k]);
  };
  const walkC = (c, name) => {
    const node = (e) => e.op === "var" ? name(e.name) : e.op === "get" && (m.fns?.[e.map] || valued(e)) ? `F:${e.map}` : undefined;
    const visit = (o) => {
      if (!o || typeof o !== "object")
        return;
      const x = o;
      if (x.op === "get" && x.key) {
        if (m.fns?.[x.map]) {
          const n = node(x.key);
          if (n)
            union(n, `A:${x.map}`);
        } else if (x.key.op === "tup" && sortPlaces)
          tupleParts(x.key).forEach((e, i) => {
            const n = node(e);
            if (n)
              union(n, `M:${x.map}:${i}`);
          });
        else {
          const ls = [];
          leaves(x.key, 1, ls);
          const pat = pats[x.map] ?? [1];
          if (pat.length > 1 && ls.length === 1 && ls[0][1] === 1) {
            const n = node(ls[0][0]);
            if (n)
              union(n, `K:${x.map}`);
          } else {
            if (pat.length > 1)
              whole.set(JSON.stringify(x.key), `K:${x.map}`);
            for (const [e, k] of ls) {
              const idx = pat.indexOf(k), n = node(e);
              if (n && idx >= 0)
                union(n, `M:${x.map}:${idx}`);
            }
          }
        }
      }
      if ((x.op === "<" || x.op === "<=" || x.op === "=") && x.a && x.b) {
        const la = [], lb = [];
        leaves(x.a, 1, la);
        leaves(x.b, 1, lb);
        if (la.length === 1 && lb.length === 1 && Math.abs(la[0][1]) === 1 && Math.abs(lb[0][1]) === 1) {
          const p = node(la[0][0]), q = node(lb[0][0]);
          if (p && q)
            union(p, q);
        }
      }
      for (const y of Object.values(o))
        visit(y);
    };
    visit(c);
  };
  const plain = (v) => `V:${v}`;
  walkC(m.step, plain);
  if (m.assume)
    walkC(m.assume, plain);
  if (m.pre)
    walkC(m.pre, plain);
  for (const [f, c] of Object.entries(m.step.flags ?? {}))
    if (c.op === "all") {
      const bs = new Set(boundOf(c));
      walkC(c, (v) => bs.has(v) ? `Q:${f}:${v}` : `V:${v}`);
      witnessesOf(f, c).forEach((w, j) => union(`V:${w}`, `Q:${f}:${boundOf(c)[j]}`));
    }
  for (const [mp, w] of Object.entries(m.step.maps ?? {}))
    if (!("each" in w))
      walkC({ op: "get", map: mp, key: w.key }, plain);
  for (const [mp, w] of Object.entries(m.step.maps ?? {}))
    if ("each" in w)
      union(`V:${w.each}`, (pats[mp] ?? [1]).length > 1 ? `K:${mp}` : `M:${mp}:0`);
  for (const l of laws) {
    const own = new Set([l.forall, ...l.keys ?? []].filter(Boolean));
    walkC(l.holds, (v) => own.has(v) ? `L:${l.name}:${v}` : `V:${v}`);
  }
  const multi = Object.keys(pats).filter((mp) => pats[mp].length > 1);
  for (let grew = true;grew; ) {
    grew = false;
    for (const a of multi)
      for (const b of multi)
        if (a < b && find(`K:${a}`) !== find(`K:${b}`) && pats[a].join() === pats[b].join() && pats[a].every((_, i) => named.has(`M:${a}:${i}`) && named.has(`M:${b}:${i}`) && find(`M:${a}:${i}`) === find(`M:${b}:${i}`))) {
          union(`K:${a}`, `K:${b}`);
          grew = true;
        }
  }
  const anchorOf = new Map;
  for (const a of par.keys())
    if (/^(M|K|A|F):/.test(a))
      anchorOf.set(find(a), true);
  for (const a of [...par.values()])
    if (/^(M|K|A|F):/.test(a))
      anchorOf.set(find(a), true);
  const of = (e) => {
    const w = whole.get(JSON.stringify(e));
    if (w)
      return w;
    const ls = [];
    leaves(e, 1, ls);
    if (ls.length !== 1 || ls[0][1] !== 1) {
      const cs = ls.map(([, c]) => c).sort((a, b) => b - a).join(",");
      const mp = Object.keys(pats).find((k2) => pats[k2].length > 1 && [...pats[k2]].sort((a, b) => b - a).join(",") === cs);
      return mp ? `K:${mp}` : `K:?${cs}`;
    }
    const x = ls[0][0];
    return x.op === "var" ? x.name.endsWith("#") ? undefined : `V:${x.name}` : x.op === "get" && (m.fns?.[x.map] || valued(x)) ? `F:${x.map}` : undefined;
  };
  return { key: (law, k) => `L:${law}:${k}`, of, find, anchored: (a) => /^K:/.test(a) || !!anchorOf.get(find(a)) };
}
function instanceSortGuard(m, laws) {
  if (!sortedOn)
    return () => true;
  let byLaws = sortsMemo.get(m);
  if (!byLaws)
    sortsMemo.set(m, byLaws = new Map);
  const lk = laws.map((l) => l.name).join("\x01");
  let s = byLaws.get(lk);
  if (!s) {
    if (byLaws.size >= 64)
      byLaws.clear();
    byLaws.set(lk, s = sortsOf(m, laws));
  }
  const S = s;
  const keysOf = (n) => {
    if (n.startsWith("?")) {
      const c = m.step.flags?.[n.slice(1)];
      return c?.op === "all" ? boundOf(c).map((k) => `Q:${n.slice(1)}:${k}`) : undefined;
    }
    const l = laws.find((x) => x.name === n);
    return l?.forall ? [l.forall, ...l.keys ?? []].map((k) => S.key(n, k)) : undefined;
  };
  const wanted = new Map;
  return (n, j, e) => {
    if (!wanted.has(n))
      wanted.set(n, keysOf(n));
    const want = wanted.get(n)?.[j], se = S.of(e);
    return !want || !se || !S.anchored(se) || !S.anchored(want) || S.find(se) === S.find(want);
  };
}
var setFirstOn = env.GDP_SET_FIRST !== "0";

// kernel/model-sequence.ts
function modelSequence(path = new Map) {
  const fixedPath = new Map(path);
  let session, held, texts = [];
  return (goal, end) => {
    const budget = { nodes: 0, until: end };
    if (wideFor(goal)) {
      session = undefined;
      held = undefined;
      return growCdcl(goal, fixedPath, budget, { model: true, core: true, point: true });
    }
    const current = goal.hyps.map((h) => JSON.stringify(h)), at = new Map(current.map((h, i) => [h, i]));
    if (!held || !session || texts.some((h) => !at.has(h))) {
      held = { name: goal.name, hyps: [...goal.hyps] };
      texts = [...current];
      session = cdclSession(held, fixedPath, { model: true, core: true, point: true });
    } else {
      const old = new Set(texts);
      current.forEach((h, i) => {
        if (!old.has(h)) {
          held.hyps.push(goal.hyps[i]);
          texts.push(h);
          old.add(h);
        }
      });
      if (texts.at(-1) !== current.at(-1)) {
        held.hyps.push(goal.hyps.at(-1));
        texts.push(current.at(-1));
      }
    }
    const out = session.run(budget);
    return out.core ? { ...out, core: [...new Set(out.core.map((i) => at.get(texts[i])))] } : out;
  };
}

// core/count-facts.ts
var stable2 = (t) => JSON.stringify(t, (_, v) => v && typeof v === "object" && !Array.isArray(v) ? Object.fromEntries(Object.entries(v).sort(([a], [b]) => a.localeCompare(b))) : v);
var namesIn = (t, out = new Set) => {
  if (typeof t === "string")
    out.add(t);
  else if (t && typeof t === "object")
    for (const [key, v] of Object.entries(t)) {
      out.add(key);
      namesIn(v, out);
    }
  return out;
};
var fresh = (used, prefix) => {
  let i = 0;
  while (used.has(`${prefix}${i}`))
    i++;
  const name = `${prefix}${i}`;
  used.add(name);
  return name;
};
var limit = (n, fallback, cap) => n === undefined ? fallback : Number.isSafeInteger(n) && n >= 0 ? Math.min(n, cap) : 0;
function condition(c, atoms) {
  if (c.op === "flag" || c.op === "all")
    return;
  if (c.op === "not") {
    const a = condition(c.x, atoms);
    return a === undefined ? undefined : { op: "not", a };
  }
  if (c.op === "and" || c.op === "or") {
    const xs = c.xs.map((v) => condition(v, atoms));
    return xs.some((v) => v === undefined) ? undefined : { op: c.op, xs };
  }
  const key = stable2(c);
  atoms.set(key, c);
  return { atom: key };
}
function booleanBody(e, atoms) {
  if (e.op === "const")
    return e.value === 0 ? false : e.value === 1 ? true : undefined;
  if (e.op !== "if")
    return;
  const c = condition(e.c, atoms), a = booleanBody(e.then, atoms), b = booleanBody(e.else, atoms);
  if (c === undefined || a === undefined || b === undefined)
    return;
  return { op: "or", xs: [{ op: "and", xs: [c, a] }, { op: "and", xs: [{ op: "not", a: c }, b] }] };
}
var evaluate = (f, values) => typeof f === "boolean" ? f : ("atom" in f) ? values.get(f.atom) : f.op === "not" ? !evaluate(f.a, values) : f.op === "and" ? f.xs.every((x) => evaluate(x, values)) : f.xs.some((x) => evaluate(x, values));
var abs = (n) => n < 0n ? -n : n;
var gcd2 = (a, b) => {
  while (b) {
    const r = a % b;
    a = b;
    b = r;
  }
  return abs(a);
};
var primitive = (a, b) => {
  const d = [...a, ...b].reduce(gcd2, 0n);
  if (d > 1n) {
    for (let i = 0;i < a.length; i++)
      a[i] = a[i] / d;
    for (let i = 0;i < b.length; i++)
      b[i] = b[i] / d;
  }
};
function proposeCountFacts(counts, context = [], options = {}) {
  const out = { insts: [], regions: [], skipped: [] };
  const used = namesIn([counts, context]);
  for (const s of options.reserved ?? [])
    used.add(s);
  const key = fresh(used, "region$key$"), atomCap = limit(options.maxAtoms, 8, 12);
  const countCap = limit(options.maxCounts, 64, 128), factCap = limit(options.maxFacts, 256, 4096);
  const groups = new Map, seen = new Set;
  for (const c of counts) {
    if (seen.has(c.v)) {
      out.skipped.push({ count: c.v, reason: "duplicate count name" });
      continue;
    }
    seen.add(c.v);
    const bound = stable2(c.below), group = groups.get(bound) ?? [];
    group.push(c);
    groups.set(bound, group);
  }
  const emitted = new Set;
  const emit = (cs, coeff, below) => {
    if (out.insts.length >= factCap || coeff.some((c) => abs(c) > BigInt(Number.MAX_SAFE_INTEGER)))
      return;
    const terms = cs.flatMap((c, i) => coeff[i] ? [[Number(coeff[i]), c.v]] : []);
    const unit = Number(coeff[cs.length] ?? 0n);
    if (!terms.length && unit === 0)
      return;
    const signature = stable2([below, terms, unit]);
    if (emitted.has(signature))
      return;
    emitted.add(signature);
    out.insts.push({ wit: fresh(used, "region$w$"), below, terms, unit });
  };
  for (const group of groups.values()) {
    const atoms = new Map, cs = [], fs = [];
    for (const c of group) {
      if (cs.length >= countCap) {
        out.skipped.push({ count: c.v, reason: "count cap" });
        continue;
      }
      const local = new Map, f = booleanBody(substE(c.body, { vars: { [c.key]: x(key) }, maps: {}, flags: {} }), local);
      if (f === undefined) {
        out.skipped.push({ count: c.v, reason: "non-Boolean body" });
        continue;
      }
      if (new Set([...atoms.keys(), ...local.keys()]).size > atomCap) {
        out.skipped.push({ count: c.v, reason: "atom cap" });
        continue;
      }
      for (const [a, c] of local)
        atoms.set(a, c);
      cs.push(c);
      fs.push(f);
    }
    if (!cs.length)
      continue;
    const below = cs[0].below, keys = [...atoms.keys()];
    const rows = Array.from({ length: 2 ** keys.length }, (_, bits) => {
      const values = new Map(keys.map((k, i) => [k, !!(bits & 1 << i)]));
      return fs.map((f) => Number(evaluate(f, values)));
    });
    out.regions.push({ below, atoms: [...atoms.values()], counts: cs.map((c) => c.v), rows });
    const basis = [];
    for (let j = 0;j <= cs.length; j++) {
      const col = rows.map((row) => BigInt(j === cs.length ? 1 : row[j]));
      const coeff = Array.from({ length: cs.length + 1 }, (_, i) => i === j ? 1n : 0n);
      for (const b of basis) {
        const a = col[b.pivot], d = b.col[b.pivot];
        if (!a)
          continue;
        for (let i = 0;i < col.length; i++)
          col[i] = d * col[i] - a * b.col[i];
        for (let i = 0;i < coeff.length; i++)
          coeff[i] = d * coeff[i] - a * b.coeff[i];
        primitive(col, coeff);
      }
      const pivot = col.findIndex((x) => x !== 0n);
      if (pivot < 0) {
        emit(cs, coeff, below);
        emit(cs, coeff.map((c) => -c), below);
      } else
        basis.push({ pivot, col, coeff });
    }
    for (let a = 0;a < cs.length; a++) {
      const coeff = new Array(cs.length + 1).fill(0n);
      coeff[a] = 1n;
      coeff[cs.length] = -1n;
      emit(cs, coeff, below);
      for (let b = 0;b < cs.length; b++)
        if (a !== b) {
          if (rows.every((row) => row[a] <= row[b])) {
            const sub = new Array(cs.length + 1).fill(0n);
            sub[a] = 1n;
            sub[b] = -1n;
            emit(cs, sub, below);
          }
          if (a < b) {
            const meet = new Array(cs.length + 1).fill(0n);
            meet[a] = 1n;
            meet[b] = 1n;
            meet[cs.length] = -1n;
            emit(cs, meet, below);
          }
        }
    }
  }
  return out;
}
function countsForReads(decls, reads) {
  const out = [];
  for (const [v, map, term] of reads) {
    const d = decls.find((d) => d.map === map);
    if (!d)
      return;
    const base = d.base ?? 0, lo = d.lo ?? d.j;
    if (base && !(term.op === "add" && term.a.op === "mul" && term.a.k === base))
      return;
    const hi = base && term.op === "add" && term.a.op === "mul" ? term.a.a : { op: "const", value: 0 };
    const low = base && term.op === "add" ? term.b : term;
    const at = { vars: { [d.j]: hi, [lo]: low }, maps: {}, flags: {} };
    out.push({ v, key: d.key, below: substE(d.below, at), body: substE(d.body, at) });
  }
  return out;
}

// core/count-unions.ts
var key = (x) => JSON.stringify(x);
var cond = (c, atoms) => {
  if (c.op === "flag" || c.op === "all")
    return;
  if (c.op === "not") {
    const b = cond(c.x, atoms);
    return b === undefined ? undefined : { not: b };
  }
  if (c.op === "and" || c.op === "or") {
    const bs = c.xs.map((c) => cond(c, atoms));
    return bs.some((b) => b === undefined) ? undefined : { [c.op]: bs };
  }
  const atom = key(c);
  atoms.add(atom);
  return { atom };
};
var body = (e, atoms) => {
  if (e.op === "const")
    return e.value === 0 ? false : e.value === 1 ? true : undefined;
  if (e.op !== "if")
    return;
  const c = cond(e.c, atoms), a = body(e.then, atoms), b = body(e.else, atoms);
  return c === undefined || a === undefined || b === undefined ? undefined : { or: [{ and: [c, a] }, { and: [{ not: c }, b] }] };
};
var evaluate2 = (b, at) => typeof b === "boolean" ? b : ("atom" in b) ? at.get(b.atom) : ("not" in b) ? !evaluate2(b.not, at) : ("and" in b) ? b.and.every((c) => evaluate2(c, at)) : b.or.some((c) => evaluate2(c, at));
function proposeCountUnions(counts, pairs, maxFacts = 128) {
  const out = [], seen = new Set;
  const add = (a, b, cover) => {
    if (out.length >= maxFacts || cover.some((c) => c.v === a.v || c.v === b.v))
      return;
    const terms = [[1, a.v], [1, b.v], ...cover.map((c) => [-1, c.v])];
    const signature = key(terms);
    if (!seen.has(signature)) {
      seen.add(signature);
      out.push({ wit: `union$${out.length}`, below: a.below, terms, unit: 0 });
    }
  };
  const groups = new Map;
  for (const c of counts.slice(0, 128)) {
    const k = key(c.below), cs = groups.get(k) ?? [];
    cs.push(c);
    groups.set(k, cs);
  }
  for (const cs of groups.values()) {
    const byName = new Map(cs.map((c) => [c.v, c])), regions = new Map;
    for (const c of cs) {
      const atoms = new Set, f = body(substE(c.body, { vars: { [c.key]: x("union$key") }, maps: {}, flags: {} }), atoms);
      if (f === undefined || atoms.size !== 2)
        continue;
      const ks = [...atoms].sort();
      let mask = 0;
      for (let bits = 0;bits < 4; bits++)
        if (evaluate2(f, new Map(ks.map((k, i) => [k, !!(bits & 1 << i)]))))
          mask |= 1 << bits;
      if (![1, 2, 4, 8].includes(mask))
        continue;
      const id = key(ks), rs = regions.get(id) ?? new Map;
      if (!rs.has(mask))
        rs.set(mask, c);
      regions.set(id, rs);
    }
    for (const c of cs) {
      const e = substE(c.body, { vars: { [c.key]: x("union$key") }, maps: {}, flags: {} });
      const atoms = new Set, f = body(e, atoms);
      const atom = e.op === "get" ? key({ op: "=", a: e, b: { op: "const", value: 1 } }) : atoms.size === 1 ? [...atoms][0] : undefined;
      if (!atom)
        continue;
      const on = (v) => e.op === "get" ? v : f !== undefined && evaluate2(f, new Map([[atom, v]]));
      for (const [id, rs] of regions) {
        const ks = JSON.parse(id), i = ks.indexOf(atom);
        if (i < 0)
          continue;
        const parts = [1, 2, 4, 8].filter((_, bits) => on(!!(bits & 1 << i))).map((mask) => rs.get(mask));
        const [left, right] = parts;
        if (parts.length !== 2 || !left || !right || out.length + 2 > maxFacts)
          continue;
        for (const sign of [1, -1]) {
          const terms = [[sign, c.v], [-sign, left.v], [-sign, right.v]], signature = key(terms);
          if (!seen.has(signature)) {
            seen.add(signature);
            out.push({ wit: `union$${out.length}`, below: c.below, terms, unit: 0 });
          }
        }
      }
    }
    const triples = [...regions.values()].filter((rs) => rs.has(2) && rs.has(4) && rs.has(8)).map((rs) => [rs.get(2), rs.get(4), rs.get(8)]);
    const positive = pairs.flatMap(([a, b]) => byName.has(a) && byName.has(b) && a !== b ? [[byName.get(a), byName.get(b)]] : []);
    const normalized = new Map(cs.map((c) => [c.v, substE(c.body, { vars: { [c.key]: x("union$key") }, maps: {}, flags: {} })]));
    const primitive = (e) => {
      if (e.op === "get")
        return e;
      if (e.op !== "if" || e.then.op !== "const" || e.then.value !== 1 || e.else.op !== "const" || e.else.value !== 0)
        return;
      const c = e.c;
      if (c.op === "=" && c.a.op === "get" && c.b.op === "const" && c.b.value === 1)
        return c.a;
      if (c.op === "=" && c.b.op === "get" && c.a.op === "const" && c.a.value === 1)
        return c.b;
      if (c.op === "<=" && c.a.op === "const" && c.a.value === 1 && c.b.op === "get")
        return c.b;
      if (c.op === "<" && c.a.op === "const" && c.a.value === 0 && c.b.op === "get")
        return c.b;
      return;
    };
    for (const [a, b] of positive) {
      if (out.length >= maxFacts)
        break;
      const members = new Set;
      for (const c of [a, b])
        walkOnce(normalized.get(c.v), (o) => {
          if (o.op === "get")
            members.add(key(o));
        });
      for (const c of cs) {
        const view = primitive(normalized.get(c.v));
        if (view && members.has(key(view)))
          add(a, b, [c]);
      }
      for (const cover of triples)
        add(a, b, cover);
    }
    for (const [a, b] of positive)
      for (const c of cs)
        add(a, b, [c]);
  }
  return out;
}

// core/count-demand.ts
var stable3 = (v) => JSON.stringify(v, (_, a) => a && typeof a === "object" && !Array.isArray(a) ? Object.fromEntries(Object.entries(a).sort(([a], [b]) => a.localeCompare(b))) : a);
var limit2 = (n, fallback, cap) => n === undefined ? fallback : Number.isSafeInteger(n) && n >= 0 ? Math.min(n, cap) : 0;
var evaluate3 = (b, values) => typeof b === "boolean" ? b : ("atom" in b) ? values.get(b.atom) : ("not" in b) ? !evaluate3(b.not, values) : ("and" in b) ? b.and.every((c) => evaluate3(c, values)) : b.or.some((c) => evaluate3(c, values));
var atomKey = (c) => c.op === "=" && stable3(c.a) > stable3(c.b) ? stable3({ ...c, a: c.b, b: c.a }) : stable3(c);
function proposeCountDemand(counts, demanded, options = {}) {
  const cap = limit2(options.maxFacts, 128, 128);
  let work = limit2(options.maxWork, 200000, 1e6);
  const take = () => work > 0 && --work >= 0;
  if (!cap || !work || !demanded.size)
    return [];
  const used = new Set, byId = new Map;
  const inspect = (value) => {
    const stack = [[value, 0]];
    let nodes = 0;
    while (stack.length) {
      if (!take() || ++nodes > 4096)
        return false;
      const [v, depth] = stack.pop();
      if (depth > 128)
        return false;
      if (typeof v === "string")
        used.add(v);
      else if (v && typeof v === "object") {
        for (const child of Object.values(v)) {
          if (!take())
            return false;
          stack.push([child, depth + 1]);
        }
      }
    }
    return true;
  };
  for (const c of counts) {
    if (!take() || !inspect(c))
      return [];
    if (!byId.has(c.v))
      byId.set(c.v, c);
  }
  for (const name of options.reserved ?? []) {
    if (!take())
      return [];
    used.add(name);
  }
  let serial = 0;
  const fresh = () => {
    while (take()) {
      const name = `demand$${serial++}`;
      if (!used.has(name)) {
        used.add(name);
        return name;
      }
    }
    return;
  };
  const member = fresh();
  if (!member)
    return [];
  const requested = [], bounds = new Set;
  for (const id of demanded) {
    if (!take())
      return [];
    const c = byId.get(id);
    if (c) {
      requested.push(c);
      bounds.add(stable3(c.below));
    }
  }
  if (!requested.length)
    return [];
  const groups = new Map;
  for (const c of requested) {
    const key = stable3(c.below), group = groups.get(key) ?? [];
    group.push(c);
    groups.set(key, group);
  }
  for (const c of byId.values()) {
    if (!take())
      return [];
    if (demanded.has(c.v))
      continue;
    const key = stable3(c.below);
    if (bounds.has(key))
      groups.get(key).push(c);
  }
  const out = [], emitted = new Set;
  const emit = (below, terms) => {
    if (out.length >= cap || !take())
      return;
    if (new Set(terms.map(([, id]) => id)).size !== terms.length)
      return;
    const signature = stable3([below, [...terms].sort((a, b) => a[1].localeCompare(b[1]))]);
    if (emitted.has(signature))
      return;
    const wit = fresh();
    if (!wit)
      return;
    emitted.add(signature);
    out.push({ wit, below, terms, unit: 0 });
  };
  for (const cs of groups.values()) {
    if (!work || out.length >= cap)
      break;
    const views = new Map, families = new Map;
    const indicators = new Map, memberships = new Map;
    for (const count of cs) {
      if (!take())
        break;
      const e = substE(count.body, { vars: { [count.key]: x(member) }, maps: {}, flags: {} });
      const members = new Set, atoms = new Set;
      const scan = (v) => {
        if (!take() || !v || typeof v !== "object")
          return;
        if ("op" in v && v.op === "get")
          members.add(stable3(v));
        for (const child of Object.values(v))
          scan(child);
      };
      scan(e);
      const cond = (c) => {
        if (!take() || c.op === "flag" || c.op === "all")
          return;
        if (c.op === "not") {
          const b = cond(c.x);
          return b === undefined ? undefined : { not: b };
        }
        if (c.op === "and" || c.op === "or") {
          const bs = c.xs.map(cond);
          return bs.some((b) => b === undefined) ? undefined : { [c.op]: bs };
        }
        const a = atomKey(c);
        atoms.add(a);
        return atoms.size > 2 ? undefined : { atom: a };
      };
      const body = (v) => {
        if (!take())
          return;
        if (v.op === "const")
          return v.value === 0 ? false : v.value === 1 ? true : undefined;
        if (v.op !== "if")
          return;
        const c = cond(v.c), a = body(v.then), b = body(v.else);
        return c === undefined || a === undefined || b === undefined ? undefined : { or: [{ and: [c, a] }, { and: [{ not: c }, b] }] };
      };
      const f = body(e), keys = [...atoms].sort();
      const view = { count, atoms: keys, members };
      if (f !== undefined && keys.length <= 2) {
        view.mask = 0;
        for (let bits = 0;bits < 2 ** keys.length; bits++) {
          if (evaluate3(f, new Map(keys.map((k, i) => [k, !!(bits & 1 << i)]))))
            view.mask |= 1 << bits;
        }
      }
      if (!work)
        break;
      if (e.op === "get")
        view.indicator = atomKey({ op: "=", a: e, b: { op: "const", value: 1 } });
      else if (keys.length === 1 && (view.mask === 1 || view.mask === 2))
        view.indicator = keys[0];
      views.set(count.v, view);
      if (view.indicator) {
        const list = indicators.get(view.indicator) ?? [];
        list.push(view);
        indicators.set(view.indicator, list);
        for (const m of members) {
          const vs = memberships.get(m) ?? [];
          vs.push(view);
          memberships.set(m, vs);
        }
      }
      if (keys.length !== 2 || ![1, 2, 4, 8].includes(view.mask ?? 0))
        continue;
      const id = stable3(keys), family = families.get(id) ?? { atoms: keys, regions: new Map, members: new Set };
      if (!family.regions.has(view.mask))
        family.regions.set(view.mask, view);
      for (const m of members)
        family.members.add(m);
      families.set(id, family);
    }
    const byAtom = new Map, byMember = new Map, demandFamilies = new Set;
    for (const family of families.values()) {
      if (!take())
        break;
      for (const atom of family.atoms) {
        const fs = byAtom.get(atom) ?? [];
        fs.push(family);
        byAtom.set(atom, fs);
      }
      for (const m of family.members) {
        const fs = byMember.get(m) ?? [];
        fs.push(family);
        byMember.set(m, fs);
      }
      if ([...family.regions.values()].some((v) => demanded.has(v.count.v)))
        demandFamilies.add(family);
    }
    const partition = (v, family, required) => {
      if (!take() || out.length + 2 > cap)
        return;
      let mask;
      if (v.indicator) {
        const index = family.atoms.indexOf(v.indicator);
        if (index < 0)
          return;
        const on = v.mask !== 1;
        mask = [0, 1, 2, 3].reduce((m, bits) => !!(bits & 1 << index) === on ? m | 1 << bits : m, 0);
      } else if (stable3(v.atoms) === stable3(family.atoms) && v.mask !== undefined)
        mask = v.mask;
      else
        return;
      const parts = [];
      for (const bit of [1, 2, 4, 8])
        if (mask & bit) {
          const part = family.regions.get(bit);
          if (!part)
            return;
          parts.push(part);
        }
      if (parts.length < 2 || required && !parts.some((p) => p.count.v === required))
        return;
      for (const sign of [1, -1])
        emit(v.count.below, [[sign, v.count.v], ...parts.map((p) => [-sign, p.count.v])]);
    };
    if (options.partitions !== false)
      for (const c of requested) {
        if (!take() || out.length >= cap)
          break;
        const v = views.get(c.v);
        if (!v)
          continue;
        if (v.indicator)
          for (const f of byAtom.get(v.indicator) ?? []) {
            if (!work)
              break;
            partition(v, f);
          }
        else {
          const f = families.get(stable3(v.atoms));
          if (!f)
            continue;
          partition(v, f);
          for (const atom of f.atoms)
            for (const indicator of indicators.get(atom) ?? []) {
              if (!work)
                break;
              partition(indicator, f, c.v);
            }
        }
      }
    const seenPairs = new Set;
    const pair = (aId, bId) => {
      if (!take() || out.length >= cap || aId === bId || !demanded.has(aId) && !demanded.has(bId))
        return;
      const a = views.get(aId), b = views.get(bId);
      if (!a || !b)
        return;
      const key = stable3([aId, bId].sort());
      if (seenPairs.has(key))
        return;
      seenPairs.add(key);
      const selected = new Set, covers = new Set;
      for (const f of demandFamilies) {
        if (!take())
          return;
        selected.add(f);
      }
      for (const m of new Set([...a.members, ...b.members])) {
        if (!take())
          return;
        for (const f of byMember.get(m) ?? []) {
          if (!take())
            return;
          selected.add(f);
        }
        for (const v of memberships.get(m) ?? []) {
          if (!take())
            return;
          covers.add(v);
        }
      }
      const add = (cover) => emit(a.count.below, [[1, aId], [1, bId], ...cover.map((v) => [-1, v.count.v])]);
      for (const f of selected) {
        if (!take() || out.length >= cap)
          return;
        const cover = [2, 4, 8].map((bit) => f.regions.get(bit));
        if (cover.every((v) => v !== undefined))
          add(cover);
      }
      for (const v of covers) {
        if (!take() || out.length >= cap)
          return;
        add([v]);
      }
    };
    if (options.pairs) {
      for (const [a, b] of options.pairs) {
        if (!work || out.length >= cap)
          break;
        pair(a, b);
      }
    } else {
      const ds = cs.filter((c) => demanded.has(c.v));
      for (let i = 0;i < ds.length && work && out.length < cap; i++) {
        for (let j = i + 1;j < ds.length && work && out.length < cap; j++)
          pair(ds[i].v, ds[j].v);
      }
      for (const raw of [true, false])
        for (const a of ds)
          for (const b of cs) {
            if (!take() || out.length >= cap)
              break;
            if (demanded.has(b.v) || b.body.op === "get" !== raw)
              continue;
            const left = views.get(a.v), right = views.get(b.v);
            if (!raw && (!left || !right || ![...left.members].some((m) => right.members.has(m))))
              continue;
            pair(a.v, b.v);
          }
    }
  }
  return out;
}

// core/count-write-frames.ts
var stable4 = (value) => JSON.stringify(value, (_, v) => v && typeof v === "object" && !Array.isArray(v) ? Object.fromEntries(Object.entries(v).sort(([a], [b]) => a.localeCompare(b))) : v);
function membership(c) {
  if (c.op === "=") {
    if (c.a.op === "get" && c.b.op === "const" && c.b.value === 1)
      return c.a;
    if (c.b.op === "get" && c.a.op === "const" && c.a.value === 1)
      return c.b;
  }
  if ((c.op === "<=" && c.a.op === "const" && c.a.value === 1 || c.op === "<" && c.a.op === "const" && c.a.value === 0) && c.b.op === "get")
    return c.b;
  return;
}
function literals(c, positive = true) {
  if (c.op === "not")
    return literals(c.x, !positive);
  if (c.op === "and" && positive) {
    const out = [];
    for (const child of c.xs) {
      const part = literals(child);
      if (!part || out.length + part.length > 2)
        return;
      out.push(...part);
    }
    return out;
  }
  const cell = membership(c);
  return cell && [{ cell, positive }];
}
function shape(body) {
  if (body.op !== "if" || body.then.op !== "const" || body.then.value !== 1 || body.else.op !== "const" || body.else.value !== 0)
    return;
  const ls = literals(body.c);
  if (ls?.length === 1)
    return ls[0].positive ? { kind: "single", literals: ls } : undefined;
  if (!ls || ls.length !== 2 || stable4(ls[0].cell) === stable4(ls[1].cell))
    return;
  const positives = ls.filter((l) => l.positive).length;
  return positives ? { kind: positives === 2 ? "intersection" : "difference", literals: ls } : undefined;
}
function booleanSources(c, inputs, out, positive = true) {
  if (c.op === "not") {
    booleanSources(c.x, inputs, out, !positive);
    return;
  }
  if (c.op === "and" || c.op === "or") {
    for (const child of c.xs)
      booleanSources(child, inputs, out, positive);
    return;
  }
  const cell = positive && membership(c);
  if (cell && inputs.has(cell.map))
    out.add(cell.map);
}
function copySources(value, inputs, out = new Set) {
  if (value.op === "get" && inputs.has(value.map))
    out.add(value.map);
  if (value.op === "if") {
    if (value.then.op === "const" && value.then.value === 1 && value.else.op === "const" && value.else.value === 0)
      booleanSources(value.c, inputs, out);
    copySources(value.then, inputs, out);
    copySources(value.else, inputs, out);
  }
  return out;
}
function proposeWriteCountFrames(m, ds, cert, demanded, maxFacts = 32) {
  const cap = Number.isSafeInteger(maxFacts) && maxFacts >= 0 ? Math.min(maxFacts, 32) : 0;
  if (!cap || !demanded.size)
    return [];
  const used = new Set, seenObjects = new Set, pending = [m, ds, cert, [...demanded]];
  while (pending.length) {
    const value = pending.pop();
    if (typeof value === "string")
      used.add(value);
    else if (value && typeof value === "object" && !seenObjects.has(value)) {
      seenObjects.add(value);
      for (const [key, child] of Object.entries(value)) {
        used.add(key);
        pending.push(child);
      }
    }
  }
  let serial = 0;
  const fresh = () => {
    while (used.has(`writeFrame$${serial}`))
      serial++;
    const name = `writeFrame$${serial++}`;
    used.add(name);
    return name;
  };
  const writers = new Map, inputs = new Set(m.inputMaps ?? []);
  for (const [map, write] of Object.entries(m.step.maps ?? {})) {
    const sources = copySources(write.value, inputs);
    if (sources.size)
      writers.set(map, sources);
  }
  if (!writers.size)
    return [];
  const declarations = new Map;
  for (const d of ds)
    if (!declarations.has(d.map))
      declarations.set(d.map, d);
  const indexKey = (map, kind, below) => stable4([map, kind, below]);
  const incoming = new Map, readIds = new Set;
  for (const read of cert.reads) {
    if (readIds.has(read[0]))
      continue;
    readIds.add(read[0]);
    if (read[1].endsWith("#"))
      continue;
    const c = countsForReads(ds, [read])?.[0], s = c && shape(c.body);
    if (!c || !s)
      continue;
    for (const [map, sources] of writers) {
      if (!s.literals.some((l) => sources.has(l.cell.map)) || s.kind !== "single" && !s.literals.some((l) => l.cell.map === map))
        continue;
      const key = indexKey(map, s.kind, c.below), group = incoming.get(key) ?? [];
      group.push(c);
      incoming.set(key, group);
    }
  }
  const signature = (i) => {
    const coefficients = new Map;
    for (const [z, id] of i.terms)
      coefficients.set(id, (coefficients.get(id) ?? 0) + z);
    return stable4([i.unit, [...coefficients].filter(([, z]) => z !== 0).sort(([a], [b]) => a.localeCompare(b))]);
  };
  const emitted = new Set(cert.insts.map(signature)), out = [];
  readIds.clear();
  for (const read of cert.reads) {
    if (readIds.has(read[0]))
      continue;
    readIds.add(read[0]);
    if (!demanded.has(read[0]) || !read[1].endsWith("#"))
      continue;
    const preRead = [read[0], read[1].slice(0, -1), read[2]];
    const before = countsForReads(ds, [preRead])?.[0], s = before && shape(before.body);
    const postDecl = declarations.get(read[1]);
    if (!before || !s || !postDecl)
      continue;
    const post = countsForReads([{ ...postDecl, body: n(0) }], [read])?.[0];
    if (!post || stable4(post.below) !== stable4(before.below))
      continue;
    for (const map of new Set(s.literals.map((l) => l.cell.map))) {
      const kinds = s.kind === "intersection" && s.literals.every((l) => l.cell.map === map) ? [s.kind, "single"] : [s.kind];
      for (const kind of kinds)
        for (const c of incoming.get(indexKey(map, kind, post.below)) ?? []) {
          if (c.v === read[0])
            continue;
          for (const sign of [1, -1]) {
            if (out.length >= cap)
              return out;
            const terms = [[sign, read[0]], [-sign, c.v]], key = signature({ terms, unit: 0 });
            if (emitted.has(key))
              continue;
            emitted.add(key);
            out.push({ wit: fresh(), below: post.below, terms, unit: 0 });
          }
        }
    }
  }
  return out;
}

// core/count-recovery/live-dependencies.ts
function piecesAt(c, path, neg = false) {
  const t = truth(c, path);
  if (t !== undefined)
    return t !== neg ? [] : [{ op: "or", xs: [] }];
  if (c.op === "not")
    return piecesAt(c.x, path, !neg);
  if (c.op === "and" && !neg || c.op === "or" && neg)
    return c.xs.flatMap((x) => piecesAt(x, path, neg));
  if (c.op === "and" || c.op === "or") {
    const open = c.xs.filter((x) => truth(x, path) === undefined);
    if (open.length === 1)
      return piecesAt(open[0], path, neg);
  }
  return [neg ? { op: "not", x: c } : c];
}
function sourceWitnessContext(source, core, wits, path) {
  const active = new Set;
  walkLive(core.hyps, path, (o) => {
    if (o.op === "var" && wits.has(o.name))
      active.add(o.name);
  });
  if (!active.size)
    return core;
  const extra = source.hyps.filter((c) => {
    if (core.hyps.includes(c))
      return false;
    let wanted = false, foreign = false;
    walkLive(c, path, (o) => {
      if (o.op === "var" && wits.has(o.name)) {
        if (active.has(o.name))
          wanted = true;
        else
          foreign = true;
      }
    });
    return wanted && !foreign;
  });
  return extra.length ? { ...core, hyps: [...core.hyps, ...extra] } : core;
}
function sourceScalarContext(source, core, names, path) {
  const extra = source.hyps.flatMap((c) => piecesAt(c, path)).filter((c) => {
    if (core.hyps.includes(c))
      return false;
    let scalar = true;
    walkLive(c, path, (o) => {
      if (o.op === "get" || o.op === "flag" || o.op === "all" || o.op === "var" && !names.has(o.name))
        scalar = false;
    });
    return scalar;
  });
  return extra.length ? { ...core, hyps: [...core.hyps, ...extra] } : core;
}
function walkLive(root, path, visit) {
  const seen = new WeakSet;
  const go = (value) => {
    if (!value || typeof value !== "object" || seen.has(value))
      return;
    seen.add(value);
    if (["not", "and", "or", "<", "<=", "="].includes(value.op) && truth(value, path) !== undefined)
      return;
    if (value.op === "if") {
      const chosen = truth(value.c, path);
      if (chosen !== undefined) {
        go(chosen ? value.then : value.else);
        return;
      }
    }
    visit(value);
    for (const child of Array.isArray(value) ? value : Object.values(value))
      go(child);
  };
  go(root);
}

// core/count-recovery/ops.ts
var wallSpan = (_phase, run) => run();
var wallTree = wallSpan;

// core/count-recovery/conditional-cuts.ts
var alive = (until) => performance.now() < until;
var flip = (lin) => add(k(1), scale(lin, -1));
var put = (path, lin, holds) => new Map(path).set(canon(lin), { lin, holds });
var plain = (lin) => Object.keys(lin).every((name) => !name.includes("\u27E6")) && Object.values(lin).every(Number.isSafeInteger);
var decide3 = (lin, path) => {
  if (!Object.values(lin).every(Number.isSafeInteger))
    return;
  if (Object.keys(lin).every((name) => name === "1"))
    return (lin["1"] ?? 0) <= 0;
  const direct = path.get(canon(lin))?.holds;
  if (direct !== undefined)
    return direct;
  const opposite = path.get(canonFlip(lin))?.holds;
  return opposite === undefined ? undefined : !opposite;
};
var proofPath = (when, cut) => {
  const path = new Map;
  let duplicate = 0;
  for (const atom of [{ lin: cut, holds: false }, ...when.map((lin) => ({ lin, holds: true }))]) {
    const id = canon(atom.lin);
    path.set(path.has(id) ? `@${duplicate++}` : id, atom);
  }
  return path;
};
function transport(source, goal, tree, from, to, until, missing) {
  if (!alive(until))
    return;
  if ("split" in tree) {
    const known = decide3(tree.split, to);
    if (known !== undefined)
      return transport(source, goal, known ? tree.yes : tree.no, put(from, tree.split, known), to, until, missing);
    const yes = transport(source, goal, tree.yes, put(from, tree.split, true), put(to, tree.split, true), until, missing);
    const no = yes && transport(source, goal, tree.no, put(from, tree.split, false), put(to, tree.split, false), until, missing);
    return yes && no ? { split: tree.split, yes, no } : undefined;
  }
  const before = leafConstraintsReusing(source, from), after = leafConstraintsReusing(goal, to), at = new Map;
  for (const [i, row] of after.entries()) {
    if (!alive(until))
      return;
    if (Number.isSafeInteger(row.lin["1"]) && (row.lin["1"] ?? 0) > 0 && Object.entries(row.lin).every(([name, value]) => name === "1" || value === 0))
      return { leaf: [{ kind: "input", index: i }] };
    const id = canon(row.lin);
    if (!at.has(id))
      at.set(id, i);
  }
  const index = (i) => {
    if (!Number.isSafeInteger(i) || i < 0)
      return;
    if (i >= before.length)
      return i - before.length + after.length;
    const row = before[i], found = at.get(canon(row.lin));
    if (found === undefined)
      missing?.(row.lin);
    return found;
  };
  const leaf = [], products = [];
  for (const step of tree.leaf) {
    if (!alive(until))
      return;
    if (step.kind !== "input")
      leaf.push(step);
    else {
      const i = index(step.index);
      if (i === undefined)
        return;
      leaf.push({ ...step, index: i });
    }
  }
  for (const [a, b] of tree.products ?? []) {
    if (!alive(until))
      return;
    const i = index(a), j = index(b);
    if (i === undefined || j === undefined)
      return;
    products.push([i, j]);
  }
  return alive(until) ? { leaf, ...tree.products ? { products } : {}, ...tree.squares ? { squares: tree.squares } : {} } : undefined;
}

class ObservedPath extends Map {
  observed;
  constructor(path, observed) {
    super(path);
    this.observed = observed;
  }
  get(key) {
    this.observed.add(key);
    return super.get(key);
  }
  has(key) {
    this.observed.add(key);
    return super.has(key);
  }
}
function dependencies(goal, tree, path, facts, atoms, until) {
  if (!alive(until))
    return false;
  if ("split" in tree)
    return dependencies(goal, tree.yes, put(path, tree.split, true), facts, atoms, until) && dependencies(goal, tree.no, put(path, tree.split, false), facts, atoms, until);
  const rows = leafConstraintsReusing(goal, new ObservedPath(path, atoms)), values = [...path.values()];
  const observe = (i) => {
    const src = rows[i]?.src;
    if (src && "fact" in src)
      facts.add(src.fact);
    if (src && "atom" in src) {
      const atom = values[src.atom];
      if (atom) {
        atoms.add(canon(atom.lin));
        atoms.add(canonFlip(atom.lin));
      }
    }
  };
  for (const step of tree.leaf) {
    if (!alive(until))
      return false;
    if (step.kind === "input")
      observe(step.index);
  }
  for (const [a, b] of tree.products ?? []) {
    if (!alive(until))
      return false;
    observe(a);
    observe(b);
  }
  return alive(until);
}
function localGoal(goal, lemma) {
  if (lemma.slice === undefined)
    return goal;
  if (!lemma.slice.every((i) => Number.isSafeInteger(i) && i >= 0 && i < goal.hyps.length))
    return;
  return { ...goal, hyps: lemma.slice.map((i) => goal.hyps[i]) };
}
function checked(goal, tree, path, until) {
  if (!alive(until))
    return false;
  try {
    return check(goal, tree, path) && alive(until);
  } catch {
    return false;
  }
}
function inline(goal, source, tree, from, scope, base, lemmas, until, diagnose) {
  if (!alive(until))
    return;
  const available = [];
  for (const lemma of lemmas) {
    if (!alive(until))
      return;
    if (plain(lemma.cut) && lemmaPath([lemma], scope) !== scope)
      available.push(lemma);
  }
  const required = [];
  const target = (cuts) => lemmaPath(cuts.map((lemma) => ({ ...lemma, when: [] })), base);
  let path = base, proof;
  for (;; ) {
    if (!alive(until))
      return;
    let absent;
    path = target(required);
    proof = transport(source, goal, tree, from, path, until, (row) => {
      absent = canon(row);
    });
    if (proof)
      break;
    const lemma = available.find((candidate) => canon(candidate.cut) === absent && !required.includes(candidate));
    if (!lemma || !alive(until)) {
      diagnose?.({ reason: alive(until) ? "missing-row" : "deadline", row: absent, available: available.length, required: required.length });
      return;
    }
    const local = localGoal(goal, lemma);
    if (!local || !checked(local, lemma.tree, proofPath(lemma.when, lemma.cut), until))
      return;
    required.push(lemma);
    required.sort((a, b) => available.indexOf(a) - available.indexOf(b));
  }
  for (let i = required.length - 1;i >= 0; i--) {
    if (!alive(until))
      return;
    const lemma = required[i], prefix = target(required.slice(0, i)), known = decide3(lemma.cut, prefix);
    const local = localGoal(goal, lemma);
    if (!local)
      return;
    if (known === true)
      proof = transport(goal, goal, proof, path, prefix, until);
    else {
      const no = transport(local, goal, lemma.tree, proofPath(lemma.when, lemma.cut), known === false ? prefix : put(prefix, lemma.cut, false), until);
      if (!no)
        return;
      if (known === false)
        proof = no;
      else {
        const yes = transport(goal, goal, proof, path, put(prefix, lemma.cut, true), until);
        if (!yes)
          return;
        proof = { split: lemma.cut, yes, no };
      }
    }
    if (!proof)
      return;
    path = prefix;
  }
  return alive(until) ? proof : undefined;
}
function admitCut(goal, source, tree, from, scope, cut, available, until) {
  if (!alive(until) || !plain(cut))
    return;
  let when = [];
  for (const atom of scope.values()) {
    if (!alive(until))
      return;
    when.push(atom.holds ? atom.lin : flip(atom.lin));
  }
  let base = proofPath(when, cut), proof = inline(goal, source, tree, from, scope, base, available, until);
  if (!proof)
    return;
  const facts = new Set, atoms = new Set;
  if (!dependencies(goal, proof, base, facts, atoms, until))
    return;
  let slice = [...facts].sort((a, b) => a - b), small = { ...goal, hyps: slice.map((i) => goal.hyps[i]) };
  const narrowed = transport(goal, small, proof, base, base, until);
  if (narrowed)
    proof = narrowed;
  else {
    slice = goal.hyps.map((_, i) => i);
    small = goal;
  }
  const less = when.filter((lin) => atoms.has(canon(lin)) || atoms.has(canonFlip(lin)));
  if (less.length < when.length) {
    const next = proofPath(less, cut), reduced = transport(small, small, proof, base, next, until);
    if (reduced) {
      when = less;
      base = next;
      proof = reduced;
    }
  }
  for (let i = when.length - 1;i >= 0; i--) {
    if (!alive(until))
      return;
    const less = when.filter((_, j) => j !== i), next = proofPath(less, cut);
    const reduced = transport(small, small, proof, base, next, until);
    if (reduced) {
      when = less;
      base = next;
      proof = reduced;
    }
  }
  return checked(small, proof, base, until) ? { when, cut, tree: proof, slice } : undefined;
}
var hypothesisIndex = new WeakMap;
function relevantHypotheses(goal, source, tree, path, available, until) {
  const used = new Set;
  if (!dependencies(source, tree, path, used, new Set, until))
    return;
  let index = hypothesisIndex.get(goal);
  if (!index) {
    index = new Map;
    const visit = (value, owner) => {
      if (!alive(until))
        return false;
      const key = JSON.stringify(value), owners = index.get(key) ?? new Set;
      owners.add(owner);
      index.set(key, owners);
      if (value.op === "and" || value.op === "or")
        return value.xs.every((c) => visit(c, owner));
      return value.op !== "not" || visit(value.x, owner);
    };
    if (!goal.hyps.every(visit))
      return;
    hypothesisIndex.set(goal, index);
  }
  const selected = new Set;
  for (const i of used)
    for (const j of index.get(JSON.stringify(source.hyps[i])) ?? [])
      selected.add(j);
  for (const lemma of available) {
    if (lemma.slice === undefined || lemma.slice.some((i) => !Number.isSafeInteger(i) || i < 0 || i >= goal.hyps.length))
      return;
    for (const i of lemma.slice)
      selected.add(i);
  }
  return [...selected].sort((a, b) => a - b);
}
function admitConditionalCut(goal, source, tree, from, scope, cut, available, until) {
  if (!alive(until) || !plain(cut))
    return;
  const slice = relevantHypotheses(goal, source, tree, from, available, until);
  if (slice && slice.length < goal.hyps.length) {
    const positions = new Map(slice.map((old, index) => [old, index])), small = { ...goal, hyps: slice.map((i) => goal.hyps[i]) };
    const local = available.map((lemma) => ({ ...lemma, slice: lemma.slice.map((i) => positions.get(i)) }));
    const result = admitCut(small, source, tree, from, scope, cut, local, until);
    if (result)
      return { ...result, slice: (result.slice ?? small.hyps.map((_, i) => i)).map((i) => slice[i]) };
  }
  return admitCut(goal, source, tree, from, scope, cut, available, until);
}
function inlineConditionalCuts(goal, source, tree, from, scope, lemmas, until, diagnose) {
  const begun = performance.now(), proof = inline(goal, source, tree, from, scope, scope, lemmas, until, diagnose);
  const accepted = !!proof && checked(goal, proof, scope, until);
  diagnose?.({ reason: accepted ? "complete" : alive(until) ? proof ? "check-failed" : "transport-failed" : "deadline", proposed: !!proof, checked: accepted, wallMs: performance.now() - begun });
  return accepted ? proof : undefined;
}

// research/track-m/section18-data.ts
function normalize(value, reads = [], decode = () => {
  return;
}) {
  const map = new Map(reads.map((r) => [r[0], { op: "get", map: r[1], key: r[2] }]));
  const visit = (v, seen = new Set) => {
    if (!v || typeof v !== "object")
      return v;
    if (Array.isArray(v))
      return v.map((x) => visit(x, seen));
    if (v.op === "var" && !seen.has(v.name)) {
      const e = map.get(v.name) ?? decode(v.name);
      if (e)
        return visit(e, new Set([...seen, v.name]));
    }
    const out = Object.fromEntries(Object.keys(v).sort().map((k) => [k, visit(v[k], seen)]));
    if (["and", "or"].includes(v.op))
      out.xs.sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b)));
    return out;
  };
  return visit(value);
}
function dependence(value, state = []) {
  const out = { op: false, guard: false, postState: false };
  const go = (v) => {
    if (!v || typeof v !== "object")
      return;
    if (v.op === "var") {
      out.op ||= v.name === "op";
      out.guard ||= v.name.startsWith("?");
      out.postState ||= state.some((s) => v.name === s + "#");
    }
    if (v.op === "flag")
      out.guard = true;
    if (v.op === "get")
      out.postState ||= v.map.endsWith("#");
    Object.values(v).forEach(go);
  };
  go(value);
  return out;
}
var independent = (x) => !x.op && !x.guard && !x.postState;

// research/track-m/section18-recorder.ts
var now = () => fullWork() / fullRate;
var copyPath = (p) => new Map(p ?? []);
var proofPath2 = (when, cut) => {
  const p = new Map;
  let n = 0;
  for (const a of [{ lin: cut, holds: false }, ...when.map((lin) => ({ lin, holds: true }))]) {
    const k = canon(a.lin);
    p.set(p.has(k) ? "@" + n++ : k, a);
  }
  return p;
};
function dependencies2(goal, tree, path, marks = () => {
  return;
}) {
  const facts = new Set, atoms = new Set, original = new Map(path);

  class Observed extends Map {
    constructor(p) {
      super(p);
    }
    get(k) {
      atoms.add(k);
      return super.get(k);
    }
    has(k) {
      atoms.add(k);
      return super.has(k);
    }
  }
  const visit = (t, p, context = { goal, lemmas: [] }) => {
    const own = marks(t);
    if (own) {
      context = own;
      for (const lemma of own.lemmas) {
        const slice = lemma.slice ?? own.goal.hyps.map((_, i) => i), local = { ...own.goal, hyps: slice.map((i) => own.goal.hyps[i]) }, used = dependencies2(local, lemma.tree, proofPath2(lemma.when, lemma.cut));
        for (const i of used.indices)
          facts.add(slice[i]);
        for (const condition of lemma.when) {
          const k = canon(condition);
          atoms.add(k);
        }
      }
    }
    if ("split" in t) {
      const k = canon(t.split);
      visit(t.yes, new Map(p).set(k, { lin: t.split, holds: true }), context);
      visit(t.no, new Map(p).set(k, { lin: t.split, holds: false }), context);
      return;
    }
    const active = lemmaPath(context.lemmas, p), rows = leafConstraints(context.goal, new Observed(active)), values = [...active.values()], mark = (i) => {
      if (i >= rows.length + (t.squares?.length ?? 0)) {
        const pair = t.products?.[i - rows.length - (t.squares?.length ?? 0)];
        if (pair) {
          mark(pair[0]);
          mark(pair[1]);
        }
        return;
      }
      const s = rows[i]?.src;
      if (s && "fact" in s)
        facts.add(s.fact);
      if (s && "atom" in s) {
        const a = values[s.atom];
        if (a)
          atoms.add(canon(a.lin));
      }
    };
    for (const x of t.leaf)
      if (x.kind === "input")
        mark(x.index);
  };
  visit(tree, path);
  return { indices: [...facts].sort((a, b) => a - b), atoms: [...original].filter(([k]) => atoms.has(k)).map(([, a]) => a) };
}

class Recorder {
  enabled = true;
  phase = "initial";
  marks = new WeakMap;
  frames = [];
  stack = [];
  roots = [];
  machine;
  law = "";
  op = 0;
  reset(m, law, op, enabled = true) {
    this.enabled = enabled;
    this.frames = [];
    this.stack = [];
    this.roots = [];
    this.machine = m;
    this.law = law;
    this.op = op;
    this.marks = new WeakMap;
  }
  noteMark(tree, context) {
    if (this.enabled)
      this.marks.set(tree, context);
  }
  conditions(lin) {
    return { op: "<=", a: linearExpr(lin), b: { op: "const", value: 0 } };
  }
  probe(name, good, goal, path, run) {
    const a = this.attempt(name, good);
    try {
      const tree = run();
      this.mark(a, { source: goal, sourceTree: tree, sourcePath: path, target: goal, tree, targetPath: path });
      return tree;
    } finally {
      this.end(a);
    }
  }
  snapshots(tree) {
    const out = [];
    const visit = (t, p) => {
      const mark = this.marks.get(t);
      if (mark)
        out.push({ path: p, ...mark });
      if ("split" in t) {
        visit(t.yes, [...p, "yes"]);
        visit(t.no, [...p, "no"]);
      }
    };
    if (tree)
      visit(tree, []);
    return out;
  }
  root(g) {
    if (this.enabled && !this.roots.includes(g))
      this.roots.push(g);
  }
  begin(kind, name, meta = {}) {
    if (!this.enabled)
      return;
    const f = { id: this.frames.length, parent: this.stack.at(-1)?.id, kind, name, start: now(), children: 0, meta };
    this.frames.push(f);
    this.stack.push(f);
    return f;
  }
  end(f) {
    if (!f)
      return;
    if (this.stack.pop() !== f)
      throw Error("lemma ledger stack mismatch");
    f.end = now();
    f.units = f.end - f.start;
    f.exclusive = f.units - f.children;
    const p = this.stack.at(-1);
    if (p)
      p.children += f.units;
  }
  helper(name, args, run) {
    if (!this.enabled)
      return run();
    const field = name === "field", g = args[field ? 2 : 0], cert = args[field ? 3 : 1], root = args[field ? 7 : 4], f = this.begin("helper", name, { goal: g, cert: { reads: [...cert.reads], insts: [...cert.insts] }, path: copyPath(root), phase: this.phase });
    try {
      return run();
    } finally {
      this.end(f);
    }
  }
  attempt(name, good, extra = {}) {
    if (!this.enabled)
      return;
    const h = [...this.stack].reverse().find((f) => f.kind === "helper");
    if (!h)
      return;
    return this.begin("attempt", name, { good, helper: h?.id, ...extra });
  }
  mark(f, data) {
    if (f)
      f.data = { ...data, sourcePath: copyPath(data.sourcePath), targetPath: copyPath(data.targetPath) };
  }
  admitted(data) {
    const a = [...this.stack].reverse().find((f) => f.kind === "attempt");
    this.mark(a, { ...data, source: data.part, sourceTree: data.tree, sourcePath: data.from, target: data.g, tree: data.lemma.tree, targetPath: proofPath2(data.lemma.when, data.lemma.cut), admitted: true });
  }
  invoke(name, fn, args) {
    if (!this.enabled || !this.stack.length)
      return fn(...args);
    const transport = ["widen", "liftCountProxies", "admitConditionalCut", "inlineConditionalCuts", "transportConditionalProof"].includes(name), checking = ["check", "checkConditionalProof"].includes(name), source = ["seq", "query", "grow", "booleanCore", "refuteFast", "fieldCase", "proveNaturalCases"].includes(name), f = this.begin("operation", name);
    f.phase = transport ? "transport" : checking ? "check" : source ? "source" : "setup";
    try {
      const v = fn(...args);
      f.outcome = checking ? v ? "checked" : "rejected" : source ? v && (v.tree || v.leaf || v.split || v.kind === "refuted") ? "proof" : "failed" : "done";
      return v;
    } finally {
      this.end(f);
    }
  }
  audit() {
    if (this.stack.length)
      throw Error("unclosed ledger");
    const started = now(), state = Object.keys(this.machine.state), results = [];
    const ancestor = (f, kind) => {
      let p = f;
      while (p) {
        if (p.kind === kind)
          return p;
        p = p.parent === undefined ? undefined : this.frames[p.parent];
      }
      return;
    };
    const helperFrames = this.frames.filter((f) => f.kind === "helper"), attempts = this.frames.filter((f) => f.kind === "attempt");
    const costs = (a) => {
      const out = { setup: 0, failed: 0, source: 0, check: 0, transport: 0 };
      for (const f of this.frames)
        if (ancestor(f, "attempt") === a) {
          const phase = f.kind === "operation" ? f.phase === "source" ? f.outcome === "proof" ? "source" : "failed" : f.phase : "setup";
          out[phase] += f.exclusive ?? 0;
        }
      return out;
    };
    for (const a of attempts) {
      const h = a.meta.helper === undefined ? undefined : this.frames[a.meta.helper], reads = h?.meta.cert.reads ?? [], norm = (x) => normalize(x, reads, columnTerm), statement = norm(a.meta.good), literal = dependence(statement, state), data = a.data, cost = costs(a);
      let sourceChecked = false, targetChecked = false, rootChecked = false, used = null, rootProof = null, error;
      const auditStart = now(), auditWallStart = performance.now();
      try {
        if (data?.sourceTree && data.source) {
          sourceChecked = checkConditionalProof(data.source, data.sourceTree, data.sourcePath);
          if (sourceChecked) {
            const dep = dependencies2(data.source, data.sourceTree, data.sourcePath, (t) => this.marks.get(t));
            used = { indices: dep.indices, premises: dep.indices.map((i) => norm(data.source.hyps[i])), path: dep.atoms.map((atom) => ({ holds: atom.holds, condition: norm({ op: "<=", a: linearExpr(atom.lin), b: { op: "const", value: 0 } }) })) };
          }
        }
        if (data?.tree && data.target)
          targetChecked = checkConditionalProof(data.target, data.tree, data.targetPath);
        const root = this.roots[0], source = data?.admitted ? { ...data.g, hyps: (data.lemma.slice ?? data.g.hyps.map((_, i) => i)).map((i) => data.g.hyps[i]) } : data?.source, tree = data?.admitted ? data.lemma.tree : data?.sourceTree, path = data?.admitted ? proofPath2(data.lemma.when, data.lemma.cut) : data?.sourcePath;
        if (root && source && tree && (sourceChecked || data.admitted) && data?.tree && independent(literal)) {
          const terms = ["<=", "<"].includes(a.meta.good.op) ? a.meta.good : undefined;
          if (terms) {
            const left = linear(terms.a, path), right = linear(terms.b, path);
            if (left && right) {
              const cut = sub(left, right);
              if (terms.op === "<")
                cut["1"] = (cut["1"] ?? 0) + 1;
              const begin = now(), lemma = admitConditionalCut(root, source, tree, path, new Map, cut, [], Infinity);
              if (lemma && !lemma.when.length) {
                const small = { ...root, hyps: (lemma.slice ?? root.hyps.map((_, i) => i)).map((i) => root.hyps[i]) };
                rootChecked = check(small, lemma.tree, proofPath2([], lemma.cut));
                rootProof = { lemma, goal: small, cost: now() - begin, dependence: dependence(norm(small.hyps), state) };
              }
            }
          }
        }
      } catch (e) {
        error = String(e);
      }
      const dep = used ? dependence([used.premises, used.path], state) : null, eligible = targetChecked && rootChecked && independent(rootProof.dependence);
      results.push({ id: a.id, helper: h?.name, phase: h?.meta.phase, entryPath: h?.meta.path ? [...h.meta.path] : [], kind: a.name, statement, key: JSON.stringify(statement), literal, proofDependence: dep, sourceChecked, targetChecked, emitted: !!data?.tree, admitted: !!data?.admitted, productionChecked: data?.productionChecked ?? false, eligible, rootChecked, rootDependence: rootProof?.dependence, rootAdmissionUnits: rootProof?.cost ?? 0, units: cost, totalExclusive: Object.values(cost).reduce((x, y) => x + y, 0), auditUnits: now() - auditStart, auditWallMs: performance.now() - auditWallStart, premises: used, sourceMarks: this.snapshots(data?.sourceTree), targetMarks: this.snapshots(data?.tree), error, source: data?.source, sourceTree: data?.sourceTree, sourcePath: data?.sourcePath ? [...data.sourcePath] : null, target: data?.target, tree: data?.tree, targetPath: data?.targetPath ? [...data.targetPath] : null, rootProof, reads });
    }
    const helperRootUnits = helperFrames.filter((f) => {
      let p = f.parent;
      while (p !== undefined) {
        if (this.frames[p].kind === "helper")
          return false;
        p = this.frames[p].parent;
      }
      return true;
    }).reduce((n, f) => n + (f.units ?? 0), 0), attemptUnits = results.reduce((n, r) => n + r.totalExclusive, 0);
    return { law: this.law, op: this.op, results, helperRootUnits, attemptUnits, nonAttemptHelperUnits: helperRootUnits - attemptUnits, auditUnits: now() - started, frames: this.frames.map(({ meta, data: _data, ...f }) => ({ ...f, meta: f.kind === "helper" ? { goal: meta.goal.name, hyps: meta.goal.hyps.length, reads: meta.cert.reads.length } : f.kind === "attempt" ? { helper: meta.helper } : undefined })) };
  }
}
function linearExpr(lin) {
  const xs = Object.entries(lin).map(([k, v]) => k === "1" ? { op: "const", value: v } : { op: "mul", k: v, a: { op: "var", name: k } });
  return xs.reduce((a, b) => ({ op: "add", a, b }), { op: "const", value: 0 });
}
var lemmaRecorder = new Recorder;

// core/count-recovery/conditional-check-cache.ts
var stats = { leafChecks: 0, leafHits: 0, leafFallbacks: 0, fullHyps: 0, sliceHyps: 0, independentChecks: 0, independentHits: 0, retargetChecks: 0, retargetHits: 0 };
var pathKey2 = (path) => JSON.stringify([...path].map(([key, a]) => [key, a.holds, canon(a.lin)]));
var leaves = new WeakMap;
function slicedCheck(goal, tree, path) {
  if (!("leaf" in tree))
    return check(goal, tree, path);
  let trees = leaves.get(goal);
  if (!trees)
    leaves.set(goal, trees = new WeakMap);
  let paths = trees.get(tree);
  if (!paths)
    trees.set(tree, paths = new Map);
  const key = pathKey2(path), old = paths.get(key);
  if (old !== undefined) {
    stats.leafHits++;
    return old;
  }
  stats.leafChecks++;
  stats.fullHyps += goal.hyps.length;
  let ok = false;
  try {
    const rows = leafConstraintsReusing(goal, path), needed = new Set, visited = new Set, squares = tree.squares?.length ?? 0;
    const mark = (i) => {
      if (!Number.isSafeInteger(i) || i < 0)
        throw new Error("invalid input");
      if (visited.has(i))
        return;
      visited.add(i);
      if (i < rows.length) {
        const src = rows[i].src;
        if (src && "fact" in src)
          needed.add(src.fact);
      } else if (i >= rows.length + squares) {
        const product = tree.products?.[i - rows.length - squares];
        if (!product)
          throw new Error("invalid product");
        mark(product[0]);
        mark(product[1]);
      }
    };
    for (const step of tree.leaf)
      if (step.kind === "input")
        mark(step.index);
    for (const [a, b] of tree.products ?? []) {
      mark(a);
      mark(b);
    }
    const small = { ...goal, hyps: [...needed].sort((a, b) => a - b).map((i) => goal.hyps[i]) }, target = leafConstraintsReusing(small, path), at = new Map;
    stats.sliceHyps += small.hyps.length;
    target.forEach((row, i) => {
      const id = canon(row.lin);
      if (!at.has(id))
        at.set(id, i);
    });
    const index = (i) => {
      if (i >= rows.length)
        return i - rows.length + target.length;
      const moved = at.get(canon(rows[i].lin));
      if (moved === undefined)
        throw new Error("missing row");
      return moved;
    };
    const moved = { ...tree, leaf: tree.leaf.map((s) => s.kind === "input" ? { ...s, index: index(s.index) } : s), ...tree.products ? { products: tree.products.map(([a, b]) => [index(a), index(b)]) } : {} };
    ok = check(small, moved, path);
  } catch {
    ok = false;
  }
  if (!ok) {
    stats.leafFallbacks++;
    ok = check(goal, tree, path);
  }
  paths.set(key, ok);
  return ok;
}
var independent2 = new WeakMap;
function independentHit(goal, lemma) {
  stats.independentChecks++;
  if (!independent2.get(goal)?.has(lemma))
    return false;
  stats.independentHits++;
  return true;
}
function rememberIndependent(goal, lemma) {
  let set = independent2.get(goal);
  if (!set)
    independent2.set(goal, set = new WeakSet);
  set.add(lemma);
}
var retargets = new WeakMap;
function retargetHit(lemma, key) {
  stats.retargetChecks++;
  const old = retargets.get(lemma)?.get(key);
  if (old)
    stats.retargetHits++;
  return old;
}
function rememberRetarget(lemma, key, result) {
  let map = retargets.get(lemma);
  if (!map)
    retargets.set(lemma, map = new Map);
  map.set(key, result);
}
var indices = new WeakMap;
function targetIndex(goal, until) {
  if (!(performance.now() < until))
    return;
  let at = indices.get(goal);
  if (!at) {
    at = new Map;
    for (const [i, h] of goal.hyps.entries()) {
      if (!(performance.now() < until))
        return;
      const key = JSON.stringify(h);
      if (!at.has(key))
        at.set(key, i);
    }
    indices.set(goal, at);
  }
  return at;
}

// core/count-recovery/conditional-proof.ts
var marked = new WeakMap;
var alive2 = (until) => performance.now() < until;
var flip2 = (lin) => add(k(1), scale(lin, -1));
var put2 = (path, lin, holds) => new Map(path).set(canon(lin), { lin, holds });
var sameGoal = (a, b) => a === b || JSON.stringify(a.hyps) === JSON.stringify(b.hyps);
function markConditionalProof(goal, tree, lemmas) {
  marked.set(tree, { goal, lemmas });
  lemmaRecorder.noteMark(tree, { goal, lemmas });
  return tree;
}
function hasConditionalProof(tree) {
  const seen = new WeakSet;
  const visit = (t) => {
    if (marked.has(t))
      return true;
    if (seen.has(t))
      return false;
    seen.add(t);
    return "split" in t && (visit(t.yes) || visit(t.no));
  };
  return visit(tree);
}
var proofPath3 = (when, cut) => {
  const path = new Map;
  let duplicate = 0;
  for (const atom of [{ lin: cut, holds: false }, ...when.map((lin) => ({ lin, holds: true }))]) {
    const id = canon(atom.lin);
    path.set(path.has(id) ? `@${duplicate++}` : id, atom);
  }
  return path;
};
var validLin = (lin) => !!lin && typeof lin === "object" && !Array.isArray(lin) && (Object.getPrototypeOf(lin) === Object.prototype || Object.getPrototypeOf(lin) === null) && Object.values(lin).every(Number.isSafeInteger);
var localGoal2 = (goal, lemma) => {
  if (lemma.slice === undefined)
    return goal;
  if (!Array.isArray(lemma.slice) || !Array.from(lemma.slice).every((i) => Number.isSafeInteger(i) && i >= 0 && i < goal.hyps.length))
    return;
  return { ...goal, hyps: lemma.slice.map((i) => goal.hyps[i]) };
};
function independent3(goal, lemmas, until) {
  if (!alive2(until) || !Array.isArray(lemmas))
    return false;
  for (const lemma of Array.from(lemmas)) {
    if (!alive2(until) || !lemma || !Array.isArray(lemma.when) || !Array.from(lemma.when).every(validLin) || !validLin(lemma.cut))
      return false;
    if (independentHit(goal, lemma))
      continue;
    const local = localGoal2(goal, lemma);
    if (!local || !check(local, lemma.tree, proofPath3(lemma.when, lemma.cut)))
      return false;
    rememberIndependent(goal, lemma);
  }
  return alive2(until);
}
var legalSplit = (tree, path) => !path.has(canon(tree.split)) && !Object.keys(tree.split).every((key) => key === "1");
function checked2(goal, tree, path, until) {
  const visit = (t, p, context) => {
    if (!alive2(until))
      return false;
    const own = marked.get(t);
    if (own) {
      if (!sameGoal(goal, own.goal) || !independent3(own.goal, own.lemmas, until))
        return false;
      context = own;
    }
    if ("leaf" in t)
      return slicedCheck(goal, t, lemmaPath(context.lemmas, p)) && alive2(until);
    return legalSplit(t, p) && visit(t.yes, put2(p, t.split, true), context) && visit(t.no, put2(p, t.split, false), context);
  };
  return visit(tree, path, { goal, lemmas: [] }) && alive2(until);
}
function checkConditionalProof(goal, tree, path = new Map) {
  try {
    return checked2(goal, tree, path, Infinity);
  } catch {
    return false;
  }
}
var decide4 = (lin, path) => {
  if (!Object.values(lin).every(Number.isSafeInteger))
    return;
  if (Object.keys(lin).every((name) => name === "1"))
    return (lin["1"] ?? 0) <= 0;
  const direct = path.get(canon(lin))?.holds;
  if (direct !== undefined)
    return direct;
  const opposite = path.get(canonFlip(lin))?.holds;
  return opposite === undefined ? undefined : !opposite;
};
function leaf(from, to, tree, before, after, until) {
  if (!alive2(until))
    return;
  const old = leafConstraintsReusing(from, before), rows = leafConstraintsReusing(to, after), at = new Map;
  for (const [i, row] of rows.entries()) {
    if (!alive2(until))
      return;
    if (Number.isSafeInteger(row.lin["1"]) && (row.lin["1"] ?? 0) > 0 && Object.entries(row.lin).every(([name, value]) => name === "1" || value === 0))
      return { leaf: [{ kind: "input", index: i }] };
    const id = canon(row.lin);
    if (!at.has(id))
      at.set(id, i);
  }
  const index = (i) => {
    if (!Number.isSafeInteger(i) || i < 0)
      return;
    return i >= old.length ? i - old.length + rows.length : at.get(canon(old[i].lin));
  };
  const steps = [], products = [];
  for (const step of tree.leaf) {
    if (!alive2(until))
      return;
    if (step.kind !== "input")
      steps.push(step);
    else {
      const i = index(step.index);
      if (i === undefined)
        return;
      steps.push({ ...step, index: i });
    }
  }
  for (const [a, b] of tree.products ?? []) {
    if (!alive2(until))
      return;
    const i = index(a), j = index(b);
    if (i === undefined || j === undefined)
      return;
    products.push([i, j]);
  }
  return alive2(until) ? { leaf: steps, ...tree.products ? { products } : {}, ...tree.squares ? { squares: tree.squares } : {} } : undefined;
}
function ordinary(from, to, tree, before, after, until) {
  if (!alive2(until))
    return;
  if ("leaf" in tree)
    return leaf(from, to, tree, before, after, until);
  const known = decide4(tree.split, after);
  if (known !== undefined)
    return ordinary(from, to, known ? tree.yes : tree.no, put2(before, tree.split, known), after, until);
  const yes = ordinary(from, to, tree.yes, put2(before, tree.split, true), put2(after, tree.split, true), until);
  const no = yes && ordinary(from, to, tree.no, put2(before, tree.split, false), put2(after, tree.split, false), until);
  return yes && no ? { split: tree.split, yes, no } : undefined;
}
function retarget(from, to, lemmas, scope, until, onlyMissing = false) {
  if (!independent3(from, lemmas, until))
    return;
  const out = [], target = targetIndex(to, until);
  if (!target)
    return;
  for (const lemma of lemmas) {
    if (!alive2(until))
      return;
    const source = localGoal2(from, lemma), slice = [], texts = [];
    const missing = [];
    for (const hyp of source.hyps) {
      if (!alive2(until))
        return;
      const text = JSON.stringify(hyp), i = target.get(text);
      texts.push(text);
      if (i === undefined)
        missing.push(hyp);
      else
        slice.push(i);
    }
    const key = onlyMissing && !missing.length ? JSON.stringify([slice, texts]) : undefined;
    const cached = key === undefined ? undefined : retargetHit(lemma, key);
    if (cached) {
      out.push(cached);
      continue;
    }
    const when = [...lemma.when];
    for (const atom of !onlyMissing || missing.length ? scope.values() : []) {
      if (!alive2(until))
        return;
      when.push(atom.holds ? atom.lin : flip2(atom.lin));
    }
    const path = proofPath3(when, lemma.cut);
    if (missing.length) {
      const supplied = new Set([...scope.values()].map((atom) => canon(atom.holds ? atom.lin : flip2(atom.lin))));
      for (const hyp of missing) {
        if (!alive2(until))
          return;
        const rows = facts(hyp, path);
        if (!rows.length || !rows.every((row) => supplied.has(canon(row))))
          return;
      }
    }
    const local = { ...to, hyps: slice.map((i) => to.hyps[i]) };
    const tree = ordinary(source, local, lemma.tree, proofPath3(lemma.when, lemma.cut), path, until);
    if (!tree || !alive2(until) || !check(local, tree, proofPath3(when, lemma.cut)) || !alive2(until))
      return;
    const moved = { when, cut: lemma.cut, tree, slice };
    if (key !== undefined)
      rememberRetarget(lemma, key, moved);
    out.push(moved);
  }
  return alive2(until) ? out : undefined;
}
function transportConditionalProof(from, to, tree, before, after, until) {
  try {
    const visit = (t, a, b, source, target) => {
      if (!alive2(until))
        return;
      const own = marked.get(t);
      if (own) {
        const lemmas = retarget(own.goal, to, own.lemmas, b, until, true);
        if (!lemmas)
          return;
        source = own;
        target = { goal: to, lemmas };
      }
      let out;
      if ("leaf" in t)
        out = leaf(source.goal, to, t, lemmaPath(source.lemmas, a), lemmaPath(target.lemmas, b), until);
      else {
        const known = decide4(t.split, b);
        if (known !== undefined)
          out = visit(known ? t.yes : t.no, put2(a, t.split, known), b, source, target);
        else {
          const yes = visit(t.yes, put2(a, t.split, true), put2(b, t.split, true), source, target);
          const no = yes && visit(t.no, put2(a, t.split, false), put2(b, t.split, false), source, target);
          if (yes && no)
            out = { split: t.split, yes, no };
        }
      }
      if (out && own && !marked.has(out))
        markConditionalProof(to, out, target.lemmas);
      return out;
    };
    const out = visit(tree, before, after, { goal: from, lemmas: [] }, { goal: to, lemmas: [] });
    return out && checked2(to, out, after, until) ? out : undefined;
  } catch {
    return;
  }
}
function collectConditionalCertificate(goal, tree, until) {
  try {
    const lemmas = [];
    const collect = (t, path) => {
      if (!alive2(until))
        return false;
      const own = marked.get(t);
      if (own) {
        const cuts = retarget(own.goal, goal, own.lemmas, path, until);
        if (!cuts)
          return false;
        for (const cut of cuts) {
          if (!alive2(until))
            return false;
          lemmas.push(cut);
        }
      }
      return "leaf" in t || legalSplit(t, path) && collect(t.yes, put2(path, t.split, true)) && collect(t.no, put2(path, t.split, false));
    };
    if (!collect(tree, new Map))
      return;
    const finish = (t, path, context) => {
      if (!alive2(until))
        return;
      context = marked.get(t) ?? context;
      if ("leaf" in t)
        return leaf(context.goal, goal, t, lemmaPath(context.lemmas, path), lemmaPath(lemmas, path), until);
      const yes = finish(t.yes, put2(path, t.split, true), context);
      const no = yes && finish(t.no, put2(path, t.split, false), context);
      return yes && no ? { split: t.split, yes, no } : undefined;
    };
    const out = finish(tree, new Map, { goal, lemmas: [] });
    return out && alive2(until) && checkGoalLemmas(goal, out, lemmas) && alive2(until) ? { tree: out, lemmas } : undefined;
  } catch {
    return;
  }
}

// core/count-recovery/rename-proof.ts
function renameProof(goal, tree, from, to, names, until, target = goal, indices = new WeakMap) {
  const vars = Object.fromEntries(Object.entries(names).map(([a, b]) => [a, x(b)])), terms = new WeakMap;
  const renamed = (e) => {
    let next = terms.get(e);
    if (!next) {
      next = substE(e, { vars, maps: {}, flags: {} });
      terms.set(e, next);
    }
    return next;
  };
  const form = (lin, path) => {
    let out = {};
    for (const [name, k] of Object.entries(lin)) {
      const next = column(name, path);
      if (!next)
        return;
      out = add(out, scale(next, k));
    }
    return out;
  };
  const column = (name, path) => {
    if (name === "1")
      return { "1": 1 };
    const term = columnTerm(name);
    if (term)
      return linear(renamed(term), path);
    const factors = factorsOf(name);
    if (factors.length > 1) {
      let out = { "1": 1 };
      for (const factor of factors) {
        const next = column(factor, path), product = next && times3(out, next);
        if (!product)
          return;
        out = product;
      }
      return out;
    }
    if (isCell(name)) {
      const cell = cellParts(name), parts = cell.keys ?? (cell.key ? [cell.key] : []), keys = parts.map((key) => form(key, path));
      if (!keys.length || keys.some((key) => !key))
        return;
      const key = cell.keys ? `\u27E8${keys.map((key) => canon(key)).join("|")}\u27E9` : canon(keys[0]);
      return { [`${cell.map}[${key}]`]: 1 };
    }
    return { [Object.hasOwn(names, name) ? names[name] : name]: 1 };
  };
  const visit = (t, a, b) => {
    if (late(until))
      return;
    if ("split" in t) {
      const split = form(t.split, b);
      if (!split)
        return;
      const old = canon(t.split), id = canon(split), known = Object.keys(split).every((k) => k === "1") ? (split["1"] ?? 0) <= 0 : b.has(id) ? b.get(id).holds : b.has(canonFlip(split)) ? !b.get(canonFlip(split)).holds : undefined;
      if (known !== undefined)
        return visit(known ? t.yes : t.no, new Map(a).set(old, { lin: t.split, holds: known }), b);
      const yes = visit(t.yes, new Map(a).set(old, { lin: t.split, holds: true }), new Map(b).set(id, { lin: split, holds: true }));
      const no = yes && visit(t.no, new Map(a).set(old, { lin: t.split, holds: false }), new Map(b).set(id, { lin: split, holds: false }));
      return yes && no ? { split, yes, no } : undefined;
    }
    const before = rowsAt(goal, a), after = rowsAt(target, b);
    let at = indices.get(after);
    if (!at) {
      at = new Map;
      after.forEach((row, i) => {
        const id = canon(row.lin);
        if (!at.has(id))
          at.set(id, i);
      });
      indices.set(after, at);
    }
    const index = (i) => {
      if (!Number.isInteger(i) || i < 0)
        return;
      if (i >= before.length)
        return i - before.length + after.length;
      const row = form(before[i].lin, b);
      return row && at.get(canon(row));
    };
    const leaf = [], products = [], squares = [];
    for (const step of t.leaf) {
      if (step.kind !== "input")
        leaf.push(step);
      else {
        const i = index(step.index);
        if (i === undefined)
          return;
        leaf.push({ ...step, index: i });
      }
    }
    for (const [i, j] of t.products ?? []) {
      const a = index(i), b = index(j);
      if (a === undefined || b === undefined)
        return;
      products.push([a, b]);
    }
    for (const square of t.squares ?? []) {
      const next = form(square, b);
      if (!next)
        return;
      squares.push(next);
    }
    return { leaf, ...t.products ? { products } : {}, ...t.squares ? { squares } : {} };
  };
  return visit(tree, from, to);
}

// core/count-recovery/row-cases.ts
function activeWriteKey(m, root) {
  const flags = {}, found = new Map;
  for (const [name, c] of Object.entries(m.step.flags ?? {}))
    flags[name] = c.op === "all" ? same(x(`?${name}`), n(1)) : substC(c, { vars: {}, maps: {}, flags });
  for (const write of Object.values(m.step.maps ?? {})) {
    if (!("each" in write))
      continue;
    walkLive(substE(write.value, { vars: {}, maps: {}, flags }), root, (o) => {
      if (o.op !== "if" || truth(o.c, root) !== undefined)
        return;
      walkLive(o.c, root, (c) => {
        if (c.op !== "=" || truth(c, root) !== undefined)
          return;
        for (const [at, key] of [[c.a, c.b], [c.b, c.a]]) {
          if (at.op !== "var" || at.name !== write.each)
            continue;
          let scalar = true;
          walkOnce(key, (e) => {
            if (e.op === "get" || e.op === "var" && e.name === write.each)
              scalar = false;
          });
          if (!scalar)
            continue;
          const id = JSON.stringify(key), had = found.get(id);
          found.set(id, { key, rank: (had?.rank ?? 0) + 1 });
        }
      });
    });
  }
  return [...found.values()].sort((a, b) => b.rank - a.rank)[0]?.key;
}
function activeWriteRow(m, root) {
  const exact = activeWriteKey(m, root);
  if (exact?.op === "var" && m.inputs.includes(exact.name))
    return exact.name;
  const flags = {}, inputs = new Set(m.inputs), ranks = new Map;
  for (const [name, c] of Object.entries(m.step.flags ?? {}))
    flags[name] = c.op === "all" ? same(x(`?${name}`), n(1)) : substC(c, { vars: {}, maps: {}, flags });
  for (const write of Object.values(m.step.maps ?? {})) {
    if (!("each" in write))
      continue;
    const body = substE(write.value, { vars: {}, maps: {}, flags });
    walkLive(body, root, (o) => {
      if (o.op !== "if" || truth(o.c, root) !== undefined)
        return;
      walkLive(o.c, root, (c) => {
        if (!["=", "<", "<="].includes(c.op) || truth(c, root) !== undefined)
          return;
        let indexed = false, cell = false;
        const found = new Set;
        walkOnce(c, (e) => {
          if (e.op === "get")
            cell = true;
          if (e.op === "var") {
            if (e.name === write.each)
              indexed = true;
            if (inputs.has(e.name))
              found.add(e.name);
          }
        });
        if (indexed && !cell) {
          for (const name of found)
            ranks.set(name, (ranks.get(name) ?? 0) + 1);
        }
      });
    });
  }
  return [...ranks].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))[0]?.[0];
}
function rowPairs(m, cert, root = new Map, fieldClaim) {
  const ranks = new Map, inputs = new Set(m.inputs);
  walkOnce(m.step.maps, (o) => {
    if (o.op === "get" && o.key.op === "var" && inputs.has(o.key.name))
      ranks.set(o.key.name, (ranks.get(o.key.name) ?? 0) + 1);
  });
  const fallback = [...ranks].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))[0]?.[0], exact = activeWriteKey(m, root), named = exact ? undefined : activeWriteRow(m, root) ?? fallback, actor = exact ?? (named ? x(named) : undefined);
  if (!actor)
    return [];
  const names = new Set, read = cert.reads.find((r) => r[1].endsWith("#"));
  if (read)
    walkOnce(read[2], (o) => {
      if (o.op === "var" && !inputs.has(o.name) && !m.params.includes(o.name))
        names.add(o.name);
    });
  else if (fieldClaim)
    walkLive(fieldClaim, root, (o) => {
      if (o.op === "get" && o.map in (m.step.maps ?? {}) && o.key.op === "var" && !inputs.has(o.key.name) && !m.params.includes(o.key.name))
        names.add(o.key.name);
    });
  return [...names].slice(0, 2).map((name) => [x(name), actor]);
}
var proveRowCases = (...args) => wallTree("row-case-reconstruction", () => proveRowCasesImpl(...args));
function proveRowCasesImpl(g, root, pairs, until, prove, trace, options = {}) {
  if (!pairs.length || clock() >= until)
    return;
  const cache = new Map, history = new Map;
  const renaming = {}, pair = pairs.length === 2 ? pairs : undefined;
  let mirror = !!pair;
  if (pair)
    for (let i = 0;i < 2; i++) {
      const a = pair[0][i], b = pair[1][i];
      if (JSON.stringify(a) === JSON.stringify(b))
        continue;
      if (a.op !== "var" || b.op !== "var" || renaming[a.name] && renaming[a.name] !== b.name || renaming[b.name] && renaming[b.name] !== a.name) {
        mirror = false;
        break;
      }
      renaming[a.name] = b.name;
      renaming[b.name] = a.name;
    }
  const leaf = (path, key) => {
    if (clock() >= until)
      return;
    const begun = clock(), old = cache.get(key);
    const opposite = key.split("/").reverse().join("/");
    const compatible = (old) => {
      const vars = Object.fromEntries(Object.entries(renaming).map(([a, b]) => [a, x(b)]));
      let score = 0;
      for (const [a, b] of pairs) {
        const left = linear(a, old.path), right = linear(b, old.path), nextLeft = linear(substE(a, { vars, maps: {}, flags: {} }), path), nextRight = linear(substE(b, { vars, maps: {}, flags: {} }), path);
        if (!left || !right || !nextLeft || !nextRight)
          continue;
        for (const sign of [1, -1]) {
          const source = old.path.get(canon(scale(sub(left, right), sign)))?.holds, target = path.get(canon(scale(sub(nextLeft, nextRight), sign)))?.holds;
          if (source !== undefined && target !== undefined)
            score += source === target ? 1 : -1;
        }
      }
      return score;
    };
    if (mirror && key.includes("/"))
      for (const old of [...history.get(opposite) ?? []].reverse().sort((a, b) => compatible(b) - compatible(a))) {
        if (compatible(old) < 3 || hasConditionalProof(old.tree))
          continue;
        const t = renameProof(g, old.tree, old.path, path, renaming, Math.min(until, clock() + 50));
        const accepted = !!t && (options.deferToCaller || checkConditionalProof(g, t, path));
        if (accepted && t) {
          trace?.({ stage: "row-mirror", from: opposite, to: key, ms: Math.round(clock() - begun), checked: !options.deferToCaller, proposed: true, deferred: !!options.deferToCaller });
          cache.set(key, { path: new Map(path), tree: t });
          return t;
        }
      }
    if (old) {
      const end = Math.min(until, clock() + 50), t = hasConditionalProof(old.tree) ? transportConditionalProof(g, g, old.tree, old.path, path, Math.min(wallAt(), performance.now() + Math.max(0, end - clock()) * 10)) : withDeadline(end, () => widen(g, g, old.tree, {}, old.path, path));
      const accepted = !!t && (options.deferToCaller || checkConditionalProof(g, t, path));
      if (accepted && t) {
        trace?.({ stage: "row-case", key, cached: true, ms: Math.round(clock() - begun), checked: !options.deferToCaller, proposed: true, deferred: !!options.deferToCaller });
        return t;
      }
    }
    const t = prove(path, Math.min(until, clock() + 1500)), accepted = !!t && (options.deferToCaller || checkConditionalProof(g, t, path));
    trace?.({ stage: "row-case", key, cached: false, ms: Math.round(clock() - begun), checked: !options.deferToCaller && accepted, proposed: !!t, deferred: !!options.deferToCaller });
    if (!t || !accepted)
      return;
    const entry = { path: new Map(path), tree: t };
    cache.set(key, entry);
    history.set(key, [...history.get(key) ?? [], entry]);
    return t;
  };
  const split = (pair, path, yes, no) => {
    const condition = { op: "=", a: pair[0], b: pair[1] }, known = truth(condition, path);
    if (known !== undefined)
      return known ? yes(path) : no(path);
    const a = linear(pair[0], path), b = linear(pair[1], path);
    if (!a || !b)
      return;
    const diff = sub(a, b), back = scale(diff, -1);
    const branch = (lin, p, on, off) => {
      const id = canon(lin), had = p.get(id)?.holds;
      if (had !== undefined)
        return had ? on(p) : off(p);
      const y = on(new Map(p).set(id, { lin, holds: true }));
      if (!y)
        return;
      const n = off(new Map(p).set(id, { lin, holds: false }));
      return n ? { split: lin, yes: y, no: n } : undefined;
    };
    return branch(diff, path, (p) => branch(back, p, yes, no), no);
  };
  const out = split(pairs[0], root, (p) => options.splitEqual && pairs[1] ? split(pairs[1], p, (q) => leaf(q, "equal/equal"), (q) => leaf(q, "equal/different")) : leaf(p, "equal"), (p) => pairs.length < 2 ? leaf(p, "different") : split(pairs[1], p, (q) => leaf(q, "different/equal"), (q) => leaf(q, "different/different")));
  return options.deferToCaller ? out : out && checkConditionalProof(g, out, root) ? out : undefined;
}

// core/count-recovery/scalar-guards.ts
var id2 = (value) => JSON.stringify(value);
var goalHints = new WeakMap;
function scalarHints(goal) {
  const cached = goalHints.get(goal);
  if (cached?.hyps === goal.hyps)
    return cached.atoms;
  const atoms = [], pending = [goal.hyps], seen = new Set;
  let left = 20000;
  while (pending.length && --left >= 0 && atoms.length < 128) {
    const value = pending.pop();
    if (!value || typeof value !== "object" || seen.has(value))
      continue;
    seen.add(value);
    const c = value;
    if ((c.op === "<" || c.op === "<=" || c.op === "=") && c.a?.op === "get" && c.b?.op === "get" && ["var", "const"].includes(c.a.key?.op) && ["var", "const"].includes(c.b.key?.op))
      atoms.push({ op: c.op, a: c.a, b: c.b });
    const children = Object.values(value);
    for (let i = children.length - 1;i >= 0; i--)
      pending.push(children[i]);
  }
  goalHints.set(goal, { hyps: goal.hyps, atoms });
  return atoms;
}
function bounded(value) {
  const active = new WeakSet, done = new WeakSet;
  let left = 20000;
  const visit = (v, depth) => {
    if (--left < 0 || depth > 80)
      return false;
    if (!v || typeof v !== "object")
      return true;
    if (active.has(v))
      return false;
    if (done.has(v))
      return true;
    active.add(v);
    for (const child of Object.values(v))
      if (!visit(child, depth + 1))
        return false;
    active.delete(v);
    done.add(v);
    return true;
  };
  return visit(value, 0);
}
function scalarSource(ds, reads, inst) {
  const selected = new Set(inst.terms.filter(([k]) => k !== 0).map(([, name]) => name));
  const maps = new Set(reads.filter(([name]) => selected.has(name)).map((r) => r[1]));
  let left = 4096;
  for (const d of ds) {
    if (!maps.has(d.map))
      continue;
    const pending = [d.body], seen = new Set;
    while (pending.length && --left >= 0) {
      const value = pending.pop();
      if (!value || typeof value !== "object" || seen.has(value))
        continue;
      seen.add(value);
      const o = value;
      if ((o.op === "<" || o.op === "<=" || o.op === "=") && o.a?.op === "get" && o.b?.op === "get" && [o.a.key, o.b.key].some((key) => key.op === "var" && key.name === d.key))
        return true;
      pending.push(...Object.values(value));
    }
    if (left < 0)
      return false;
  }
  return false;
}
function countScalarGuards(m, ds, reads, inst, root, goal) {
  try {
    const selected = new Set(inst.terms.map(([, name]) => name));
    const frame = !!goal && inst.terms.length === 2 && reads.some(([name, map]) => selected.has(name) && map.endsWith("#"));
    if (!frame && !scalarSource(ds, reads, inst))
      return [];
    const picked = reads.filter(([name]) => selected.has(name)), maps = new Set(picked.map((r) => r[1]));
    if (!bounded([ds.filter((d) => maps.has(d.map)), picked, inst, m.inputs, m.params, m.inputMaps, m.step.flags]))
      return [];
    return propose(m, ds, reads, inst, root, goal);
  } catch {
    return [];
  }
}
function propose(m, ds, reads, inst, root, goal) {
  const selected = new Set(inst.terms.filter(([k]) => k !== 0).map(([, name]) => name));
  if (!selected.size || inst.terms.some(([k]) => !Number.isSafeInteger(k)))
    return [];
  const flags = Object.entries(m.step.flags ?? {});
  const opaqueFlags = Object.fromEntries(flags.map(([name]) => [name, same(x(`?${name}`), n(1))]));
  const normal = { maps: {}, flags: opaqueFlags };
  const picked = reads.filter(([name]) => selected.has(name));
  const declarations = ds.filter((d) => picked.some((r) => r[1] === d.map)).map((d) => ({
    ...d,
    below: substE(d.below, { ...normal, vars: {} }),
    body: substE(d.body, { ...normal, vars: {} })
  }));
  const counts = countsForReads(declarations, picked);
  if (!counts || counts.length !== selected.size || new Set(picked.map((r) => r[0])).size !== picked.length)
    return [];
  const forbidden = new Set([inst.wit, ...reads.map((r) => r[0]), ...ds.map((d) => d.key)]);
  for (const [name, q] of flags) {
    forbidden.add(`?${name}`);
    if (q.op === "all")
      for (const key of [q.key, ...q.keys ?? []])
        forbidden.add(key);
  }
  for (const write of Object.values(m.step.maps ?? {}))
    if ("each" in write)
      forbidden.add(write.each);
  const allowed = new Set([...m.inputs, ...m.params]);
  for (const read of picked)
    walkOnce(read[2], (o) => {
      if (o.op === "var")
        allowed.add(o.name);
    });
  for (const name of forbidden)
    allowed.delete(name);
  const used = new Set([...allowed, ...forbidden]);
  walkOnce([declarations, flags], (o) => {
    if (o.op === "var")
      used.add(o.name);
  });
  let member = "scalar$member";
  while (used.has(member))
    member += "$";
  const countMaps = new Set([...ds.map((d) => d.map), ...Object.keys(m.counts ?? {})]);
  const primitiveMaps = (value) => {
    const out = new Set, followed = new Set;
    const visit = (part) => {
      walkOnce(part, (o) => {
        if (o.op === "get" && !countMaps.has(o.map))
          out.add(o.map);
        const name = o.op === "flag" ? o.name : o.op === "var" && o.name.startsWith("?") ? o.name.slice(1) : undefined;
        if (name !== undefined && !followed.has(name)) {
          followed.add(name);
          const flag = flags.find(([key]) => key === name)?.[1];
          if (flag)
            visit(flag);
        }
      });
    };
    visit(value);
    return out;
  };
  const positive = new Set(inst.terms.filter(([k]) => k > 0).map(([, name]) => name)), carried = new Set(m.inputMaps ?? []);
  const preferred = new Set(counts.filter((c) => positive.has(c.v)).flatMap((c) => [...primitiveMaps(c.body)].filter((map) => carried.has(map))));
  const relevant = preferred.size ? preferred : new Set(counts.flatMap((c) => [...primitiveMaps(c.body)]));
  const cell = (e) => e.op === "get" && !countMaps.has(e.map) && (e.key.op === "var" ? allowed.has(e.key.name) : e.key.op === "const" && Number.isSafeInteger(e.key.value) && e.key.value >= 0);
  const memberCell = (e) => e.op === "get" && !countMaps.has(e.map) && e.key.op === "var" && e.key.name === member;
  const anchors = new Map;
  for (const [name, q] of flags) {
    if (q.op !== "all" || q.keys?.length || truth(same(x(`?${name}`), n(1)), root) !== true)
      continue;
    if (![...primitiveMaps(q.c)].some((map) => relevant.has(map)))
      continue;
    const body = substC(q.c, { ...normal, vars: { [q.key]: x(member) } });
    walkOnce(body, (o) => {
      if (o.op !== "=")
        return;
      for (const [from, to] of [[o.a, o.b], [o.b, o.a]]) {
        if (!memberCell(from) || !cell(to))
          continue;
        const key = id2(from);
        if (!anchors.has(key) && anchors.size < 32)
          anchors.set(key, to);
      }
    });
  }
  const atoms = [], seen = new Set;
  const add = (c) => {
    if (atoms.length >= 32 || !cell(c.a) || !cell(c.b) || id2(c.a) === id2(c.b) || id2(c.a.key) === id2(c.b.key))
      return;
    const key = c.op === "=" ? id2([c.op, ...[id2(c.a), id2(c.b)].sort()]) : id2(c);
    if (!seen.has(key)) {
      seen.add(key);
      atoms.push(c);
    }
  };
  const maps = Object.fromEntries([
    ...new Set([...anchors.values()].flatMap((e) => e.op === "get" ? [e.map] : [])),
    ...counts.flatMap((c) => [...primitiveMaps(c.body)])
  ].map((map) => [map, (key) => anchors.get(id2({ op: "get", map, key })) ?? { op: "get", map, key }]));
  for (const count of counts) {
    const body = substE(count.body, { ...normal, vars: { [count.key]: x(member) } });
    walkOnce(body, (o) => {
      if (o.op !== "<" && o.op !== "<=" && o.op !== "=")
        return;
      let mentions = false;
      walkOnce(o, (v) => {
        if (v.op === "var" && v.name === member)
          mentions = true;
      });
      if (!mentions)
        return;
      const comparison = substC(o, { vars: {}, maps, flags: opaqueFlags });
      if (comparison.op === "<" || comparison.op === "<=" || comparison.op === "=")
        add(comparison);
    });
  }
  const pair = (c) => id2([id2(c.a.key), id2(c.b.key)].sort());
  const goalPairs = new Set(atoms.map(pair)), rowKeys = new Set;
  for (const read of picked)
    walkOnce(read[2], (o) => {
      if (o.op === "var" && allowed.has(o.name))
        rowKeys.add(id2(o));
    });
  const inputs = new Set(m.inputs);
  for (const count of counts)
    walkOnce(count.body, (o) => {
      if (o.op === "var" && inputs.has(o.name) && allowed.has(o.name))
        rowKeys.add(id2(o));
    });
  for (const anchor of anchors.values())
    if (cell(anchor))
      rowKeys.add(id2(anchor.key));
  if (goal)
    for (const hint of scalarHints(goal)) {
      if (cell(hint.a) && cell(hint.b) && (goalPairs.has(pair(hint)) || rowKeys.has(id2(hint.a.key)) && rowKeys.has(id2(hint.b.key))))
        add(hint);
    }
  const fields = (c) => id2([c.a.map, c.b.map].sort());
  const out = [], scopes = new Set;
  const emit = (cs) => {
    if (out.length >= 8)
      return;
    const status = cs.map((c) => truth(c, root));
    if (status.includes(false))
      return;
    const open = cs.filter((_, i) => status[i] !== true);
    if (!open.length)
      return;
    const key = id2(open.map(id2).sort());
    if (!scopes.has(key)) {
      scopes.add(key);
      out.push(open);
    }
  };
  const strict = atoms.filter((c) => c.op === "<"), equal = atoms.filter((c) => c.op === "=");
  if (inst.terms.length === 2 && picked.some(([, map]) => map.endsWith("#"))) {
    for (let i = 0;i < equal.length; i++)
      for (const other of equal.slice(i + 1)) {
        if (pair(equal[i]) === pair(other) && fields(equal[i]) !== fields(other))
          emit([equal[i], other]);
      }
  }
  for (const c of strict) {
    emit([c]);
    for (const eq of equal)
      if (pair(c) === pair(eq) && fields(c) !== fields(eq))
        emit([eq, c]);
    if (out.length >= 8)
      break;
  }
  for (let i = 0;i < equal.length; i++) {
    const eq = equal[i];
    emit([eq]);
    for (const other of equal.slice(i + 1))
      if (pair(eq) === pair(other) && fields(eq) !== fields(other))
        emit([eq, other]);
  }
  for (const c of atoms)
    if (c.op === "<=")
      emit([c]);
  return out;
}

// core/count-recovery/member-inclusions.ts
var text = (v) => JSON.stringify(v);
var member = (c) => {
  if (c.op === "=" && c.a.op === "get" && c.b.op === "const" && c.b.value === 1)
    return c.a;
  if (c.op === "=" && c.b.op === "get" && c.a.op === "const" && c.a.value === 1)
    return c.b;
  if (c.op === "<" && c.a.op === "const" && c.a.value === 0 && c.b.op === "get")
    return c.b;
  if (c.op === "<=" && c.a.op === "const" && c.a.value === 1 && c.b.op === "get")
    return c.b;
  return;
};
var predicate = (e) => e.op === "if" && e.then.op === "const" && e.then.value === 1 && e.else.op === "const" && e.else.value === 0 ? e.c : e.op === "get" ? same(e, n(1)) : undefined;
var parts = (c) => c.op === "and" ? c.xs.flatMap(parts) : [c];
function memberInclusions(m, ds, reads) {
  const picked = reads.filter(([, map]) => !map.endsWith("#")), names = new Set(picked.map((r) => r[1])), decls = ds.filter((d) => names.has(d.map));
  if (!m.inputMaps?.length || !bounded([m.step.flags, decls, picked]))
    return [];
  const counts = countsForReads(decls, picked);
  if (!counts)
    return [];
  const used = new Set;
  walkOnce([m.step.flags, decls, picked], (o) => {
    if (o.op === "var")
      used.add(o.name);
  });
  let key = "inclusion$member";
  while (used.has(key))
    key += "$";
  const mentions = (v) => {
    let found = false;
    walkOnce(v, (o) => {
      if (o.op === "var" && o.name === key)
        found = true;
    });
    return found;
  };
  const inputs = new Set(m.inputMaps), facts = new Map;
  for (const q of Object.values(m.step.flags ?? {})) {
    if (q.op !== "all" || q.keys?.length)
      continue;
    const c = substC(q.c, { vars: { [q.key]: x(key) }, maps: {}, flags: {} });
    if (c.op !== "or" || c.xs.length !== 2)
      continue;
    for (let i = 0;i < 2; i++) {
      const a = c.xs[i], source = a.op === "not" ? member(a.x) : undefined;
      if (!source || !inputs.has(source.map) || source.key.op !== "var" || source.key.name !== key)
        continue;
      const entry = facts.get(source.map) ?? { known: new Set, anchors: new Map };
      for (const consequent of parts(c.xs[1 - i])) {
        const membership = member(consequent);
        if (membership)
          entry.known.add(text(membership));
        if (consequent.op !== "=")
          continue;
        for (const [from, to] of [[consequent.a, consequent.b], [consequent.b, consequent.a]]) {
          if (from.op === "get" && to.op === "get" && mentions(from.key) && !mentions(to) && !entry.anchors.has(text(from)))
            entry.anchors.set(text(from), to);
        }
      }
      facts.set(source.map, entry);
    }
  }
  const out = [], seen = new Set;
  let work = 20000;
  for (const a of counts) {
    const body = substE(a.body, { vars: { [a.key]: x(key) }, maps: {}, flags: {} }), p = predicate(body), source = p && member(p);
    if (!source || !inputs.has(source.map) || source.key.op !== "var" || source.key.name !== key)
      continue;
    const entry = facts.get(source.map);
    if (!entry?.anchors.size)
      continue;
    const known = new Set([...entry.known, text(source)]);
    for (const b of counts) {
      if (--work < 0 || out.length >= 128)
        return out;
      if (a.v === b.v || text(a.below) !== text(b.below))
        continue;
      const target = predicate(substE(b.body, { vars: { [b.key]: x(key) }, maps: {}, flags: {} }));
      if (!target)
        continue;
      let changed = false;
      const maps = Object.fromEntries([...new Set([...entry.anchors.keys()].map((k) => JSON.parse(k).map))].map((map) => [map, (at) => {
        const from = { op: "get", map, key: at }, to = entry.anchors.get(text(from));
        if (to) {
          changed = true;
          return to;
        }
        return from;
      }]));
      const rewritten = substC(target, { vars: {}, maps, flags: {} });
      if (!changed)
        continue;
      const simplify = (c) => {
        const view = member(c);
        if (view && known.has(text(view)))
          return true;
        if (c.op === "and" || c.op === "or") {
          const xs = c.xs.map(simplify), and = c.op === "and";
          if (xs.includes(!and))
            return !and;
          const rest = xs.filter((v) => typeof v !== "boolean");
          return !rest.length ? and : rest.length === 1 ? rest[0] : { op: c.op, xs: rest };
        }
        if (c.op === "not") {
          const v = simplify(c.x);
          return typeof v === "boolean" ? !v : { op: "not", x: v };
        }
        if (c.op === "=" || c.op === "<" || c.op === "<=") {
          if (text(c.a) === text(c.b))
            return c.op !== "<";
          if (c.a.op === "const" && c.b.op === "const")
            return c.op === "=" ? c.a.value === c.b.value : c.op === "<" ? c.a.value < c.b.value : c.a.value <= c.b.value;
        }
        return c;
      };
      const reduced = simplify(rewritten);
      if (reduced === false || typeof reduced !== "boolean" && mentions(reduced))
        continue;
      const guards = reduced === true ? [] : parts(reduced);
      if (guards.some((c) => !["=", "<", "<="].includes(c.op)))
        continue;
      const id = text([a.v, b.v, guards]);
      if (seen.has(id))
        continue;
      seen.add(id);
      out.push({ positive: a.v, negative: b.v, carried: source.map, below: a.below, guards });
    }
  }
  return out;
}

// core/count-focused.ts
function independentCountInstances(m, laws, before, next, witnesses) {
  const blocked = new Set(witnesses), out = { ...before };
  let changed = false;
  for (const [name, terms] of Object.entries(next)) {
    const law = laws.find((l) => l.name === name), had = before[name] ?? [];
    if (terms.length <= had.length)
      continue;
    if (!law) {
      out[name] = terms;
      changed = true;
      continue;
    }
    const names = [law.forall, ...law.keys ?? []], positions = new Set, arity = names.length;
    walkOnce(law.holds, (o) => {
      if (o.op === "get" && m.counts?.[o.map])
        walkOnce(o.key, (v) => {
          if (v.op === "var") {
            const i = names.indexOf(v.name);
            if (i >= 0)
              positions.add(i);
          }
        });
    });
    const extra = [];
    for (let i = had.length;i < terms.length; i += arity) {
      const tuple = terms.slice(i, i + arity);
      if (tuple.length !== arity)
        continue;
      let dependent = false;
      for (const j of positions)
        walkOnce(tuple[j], (o) => {
          if (o.op === "var" && blocked.has(o.name))
            dependent = true;
        });
      if (!dependent)
        extra.push(...tuple);
    }
    if (extra.length) {
      out[name] = [...had, ...extra];
      changed = true;
    }
  }
  return changed ? out : undefined;
}
function demandCountCert(m, decls, full, claim) {
  const wanted = new Set, reserved = new Set([...m.inputs, ...m.params, ...Object.keys(m.state), ...full.insts.map((q) => q.wit)]);
  walkOnce(claim, (o) => {
    if (o.op === "var") {
      reserved.add(o.name);
      if (full.reads.some((read) => read[0] === o.name))
        wanted.add(o.name);
    }
    if (o.op === "get") {
      for (const read of full.reads)
        if (read[1] === o.map && JSON.stringify(read[2]) === JSON.stringify(o.key))
          wanted.add(read[0]);
    }
  });
  if (wanted.size < 2)
    return full;
  const cs = countsForReads(decls, full.reads);
  if (!cs)
    return full;
  const byId = new Map(cs.map((c) => [c.v, c])), byCell = new Map(full.reads.map((r) => [JSON.stringify([r[1], r[2]]), r[0]])), heads = new Set(wanted), projected = new Set, actor = activeWriteRow(m, new Map);
  for (const read of full.reads)
    if (heads.has(read[0]) && read[1].endsWith("#")) {
      const names = new Set;
      walkOnce(read[2], (o) => {
        if (o.op === "var" && !m.inputs.includes(o.name) && !m.params.includes(o.name))
          names.add(o.name);
      });
      const vars = [...names];
      if (actor && vars.length <= 3)
        for (let mask = 1;mask < 1 << vars.length; mask++) {
          const key = substE(read[2], { vars: Object.fromEntries(vars.filter((_, i) => mask & 1 << i).map((name) => [name, x(actor)])), maps: {}, flags: {} }), id = byCell.get(JSON.stringify([read[1].slice(0, -1), key]));
          if (id)
            projected.add(id);
        }
      const twin = byCell.get(JSON.stringify([read[1].slice(0, -1), read[2]]));
      if (twin)
        heads.add(twin);
    }
  for (const id of projected)
    wanted.add(id);
  const pending = [...wanted], expanded = new Set, primitiveMaps = new Set, expandedFlags = new Set;
  while (pending.length) {
    const id = pending.shift();
    if (expanded.has(id))
      continue;
    expanded.add(id);
    const add = (id) => {
      if (id && !wanted.has(id)) {
        wanted.add(id);
        pending.push(id);
      }
    };
    const read = full.reads.find((r) => r[0] === id);
    if (read?.[1].endsWith("#"))
      add(byCell.get(JSON.stringify([read[1].slice(0, -1), read[2]])));
    const depend = (value) => {
      walkOnce(value, (o) => {
        if (o.op === "get") {
          primitiveMaps.add(o.map);
          add(byCell.get(JSON.stringify([o.map, o.key])));
        }
        const name = o.op === "flag" ? o.name : o.op === "var" && o.name.startsWith("?") ? o.name.slice(1) : undefined;
        if (name && !expandedFlags.has(name)) {
          expandedFlags.add(name);
          const flag = m.step.flags?.[name];
          if (flag)
            depend(flag);
        }
      });
    };
    const body = byId.get(id)?.body;
    if (body)
      depend(body);
  }
  const preDecls = new Map(decls.filter((d) => !d.map.endsWith("#")).map((d) => [d.map, d]));
  const postMaps = Object.fromEntries(Object.keys(m.maps ?? {}).map((map) => [map, (key) => ({ op: "get", map: `${map}#`, key })]));
  const postVars = Object.fromEntries(Object.keys(m.state).map((name) => [name, { op: "var", name: `${name}#` }]));
  const proposalDecls = decls.map((d) => {
    const pre = d.map.endsWith("#") ? preDecls.get(d.map.slice(0, -1)) : undefined;
    return pre && pre.key === d.key && pre.j === d.j && pre.lo === d.lo && pre.base === d.base ? { ...d, body: substE(pre.body, { vars: postVars, maps: postMaps, flags: {} }) } : d;
  });
  const proposalCounts = countsForReads(proposalDecls, full.reads) ?? cs;
  const bounded = (body) => {
    const todo = [body];
    let seen = 0;
    while (todo.length) {
      const e = todo.pop();
      if (++seen > 256)
        return false;
      if (e.op === "const") {
        if (e.value !== 0 && e.value !== 1)
          return false;
      } else if (e.op === "if")
        todo.push(e.then, e.else);
      else
        return false;
    }
    return true;
  };
  walkOnce([m, decls, full], (o) => {
    if (o && typeof o === "object") {
      for (const value of Object.values(o))
        if (typeof value === "string")
          reserved.add(value);
    }
  });
  const ranges = [];
  let serial = 0;
  for (const count of cs)
    if (wanted.has(count.v) && bounded(count.body) && ranges.length < 16) {
      let wit;
      do {
        wit = `range$${serial++}`;
      } while (reserved.has(wit));
      reserved.add(wit);
      ranges.push({ wit, below: count.below, terms: [[1, count.v]], unit: -1 });
      const read = full.reads.find((r) => r[0] === count.v), pre = read?.[1].endsWith("#") ? preDecls.get(read[1].slice(0, -1)) : undefined;
      let fields = false;
      if (pre)
        walkOnce(pre.body, (o) => {
          if (o.op === "<" && o.a.op === "get" && o.b.op === "get")
            fields = true;
        });
      if (fields && ranges.length < 16) {
        do {
          wit = `range$${serial++}`;
        } while (reserved.has(wit));
        reserved.add(wit);
        ranges.push({ wit, below: count.below, terms: [[1, count.v]], unit: 0 });
      }
    }
  const proposed = [...ranges, ...proposeCountDemand(proposalCounts, wanted, { pairs: [], maxFacts: 64 - ranges.length, reserved })];
  for (const q of proposed)
    reserved.add(q.wit);
  const carriedView = (e) => {
    if (e.op === "get")
      return e;
    if (e.op !== "if" || e.then.op !== "const" || e.then.value !== 1 || e.else.op !== "const" || e.else.value !== 0)
      return;
    const c = e.c;
    if (c.op === "=") {
      if (c.a.op === "get" && c.b.op === "const" && c.b.value === 1)
        return c.a;
      if (c.b.op === "get" && c.a.op === "const" && c.a.value === 1)
        return c.b;
    }
    if (c.op === "<=" && c.a.op === "const" && c.a.value === 1 && c.b.op === "get" || c.op === "<" && c.a.op === "const" && c.a.value === 0 && c.b.op === "get")
      return c.b;
    return;
  };
  const carried = cs.filter((c) => {
    const view = carriedView(c.body);
    return view?.op === "get" && (wanted.has(c.v) || primitiveMaps.has(view.map)) && (m.inputMaps ?? []).includes(view.map);
  }), pairs = [...heads].flatMap((head) => carried.filter((c) => c.v !== head).map((c) => [head, c.v]));
  const share = Math.max(1, Math.floor((128 - proposed.length) / Math.max(1, pairs.length)));
  for (const pair of pairs) {
    if (proposed.length >= 128)
      break;
    const batch = proposeCountDemand(proposalCounts, new Set([...pair, ...projected]), { pairs: [pair], partitions: false, maxFacts: Math.min(share, 128 - proposed.length), reserved });
    for (const q of batch) {
      reserved.add(q.wit);
      proposed.push(q);
    }
  }
  if (!proposed.length) {
    const frames = proposeWriteCountFrames(m, decls, full, wanted);
    return frames.length ? { reads: full.reads, insts: [...frames, ...full.insts] } : full;
  }
  const key = (q) => JSON.stringify({ below: q.below, unit: q.unit, terms: [...q.terms].sort((a, b) => a[1].localeCompare(b[1]) || a[0] - b[0]) }), seen = new Set, structured = [];
  for (const q of [...proposed, ...full.insts.filter((q) => q.terms.length >= 3)]) {
    const id = key(q);
    if (seen.has(id))
      continue;
    seen.add(id);
    structured.push(q);
    if (structured.length === 128)
      break;
  }
  const merged = { reads: full.reads, insts: [...full.insts.filter((q) => q.terms.length < 3), ...structured] }, frames = proposeWriteCountFrames(m, decls, merged, wanted);
  return frames.length ? { reads: merged.reads, insts: [...frames, ...merged.insts] } : merged;
}
function focusCountCert(m, decls, full, options = {}) {
  const cs = countsForReads(decls, full.reads);
  if (!cs)
    return { reads: full.reads, insts: [] };
  const inputs = new Set(m.inputMaps ?? []), text = (e) => JSON.stringify(e);
  const bodies = new Map(cs.map((c) => [c.v, substE(c.body, { vars: { [c.key]: x("$member") }, maps: {}, flags: {} })]));
  const indicator = (e) => e.op === "if" && e.then.op === "const" && e.then.value === 1 && e.else.op === "const" && e.else.value === 0 ? member(e.c) ?? e : e;
  const predicate = (e) => e.op === "if" && e.then.op === "const" && e.then.value === 1 && e.else.op === "const" && e.else.value === 0 ? e.c : e.op === "get" ? { op: "=", a: e, b: { op: "const", value: 1 } } : undefined;
  const conjuncts = (c) => c.op === "and" ? c.xs.flatMap(conjuncts) : [text(c)];
  const member = (c) => {
    if (c.op === "=" && c.a.op === "get" && c.b.op === "const" && c.b.value === 1)
      return c.a;
    if (c.op === "=" && c.b.op === "get" && c.a.op === "const" && c.a.value === 1)
      return c.b;
    if (c.op === "<" && c.a.op === "const" && c.a.value === 0 && c.b.op === "get")
      return c.b;
    if (c.op === "<=" && c.a.op === "const" && c.a.value === 1 && c.b.op === "get")
      return c.b;
    return;
  };
  const views = new Map;
  for (const q of Object.values(m.step.flags ?? {}))
    if (q.op === "all" && !q.keys?.length) {
      const c = substC(q.c, { vars: { [q.key]: x("$member") }, maps: {}, flags: {} });
      if (c.op !== "or" || c.xs.length !== 2)
        continue;
      const a = c.xs[0].op === "not" ? c.xs[0].x : undefined, b = c.xs[1];
      const src = a && member(a), view = member(b);
      if (src?.op !== "get" || !inputs.has(src.map) || !view)
        continue;
      const got = views.get(src.map) ?? new Set;
      got.add(text(view));
      views.set(src.map, got);
    }
  const stored = new Set;
  for (const [id, map] of full.reads) {
    const d = decls.find((d) => d.map === map);
    if (!d || map.endsWith("#"))
      continue;
    let request = false;
    walkOnce([d.below, d.body], (o) => {
      if (o.op === "get" && inputs.has(o.map) || o.op === "var" && m.inputs.includes(o.name) && ![d.j, d.lo, d.key].includes(o.name))
        request = true;
    });
    if (!request)
      stored.add(id);
  }
  const algebraicSeen = new Set;
  const eligible = options.algebraic ? full.insts.filter((q) => {
    if (q.unit !== 0 || q.terms.length < 3 || q.terms.length > 5 || !q.terms.every(([k]) => Math.abs(k) === 1))
      return false;
    const id = text({ below: q.below, unit: q.unit, terms: [...q.terms].sort((a, b) => a[1].localeCompare(b[1]) || a[0] - b[0]) });
    if (algebraicSeen.has(id))
      return false;
    algebraicSeen.add(id);
    return true;
  }) : [];
  const unionPriority = (q) => {
    const positive = q.terms.filter(([k]) => k === 1).map(([, id]) => id);
    const post = positive.some((id) => full.reads.some((r) => r[0] === id && r[1].endsWith("#")));
    const carried = positive.some((id) => {
      const b = bodies.get(id), e = b && indicator(b);
      return e?.op === "get" && inputs.has(e.map) && (!options.carried || e.map === options.carried);
    });
    return post && carried ? q.terms.filter(([k]) => k === -1).every(([, id]) => stored.has(id)) ? 2 : 1 : 0;
  };
  const unions = eligible.filter((q) => q.terms.length === 5).sort((a, b) => unionPriority(b) - unionPriority(a)).slice(0, 8);
  const regions = new Set(unions.flatMap((q) => q.terms.filter(([k]) => k === -1).map(([, id]) => id)));
  const requestSizes = new Set([...bodies].filter(([, b]) => {
    const e = indicator(b);
    return e.op === "get" && inputs.has(e.map);
  }).map(([id]) => id));
  const overlap = (q) => q.terms.filter(([, id]) => regions.has(id)).length;
  const booleanIdentity = (q) => {
    const ps = q.terms.map(([, id]) => {
      const b = bodies.get(id);
      return b && predicate(b);
    });
    if (ps.some((p) => !p))
      return false;
    const atoms = new Map, atom = (c) => text(member(c) ?? c);
    const visit = (c) => {
      if (c.op === "and" || c.op === "or")
        c.xs.forEach(visit);
      else if (c.op === "not")
        visit(c.x);
      else if (!atoms.has(atom(c)))
        atoms.set(atom(c), atoms.size);
    };
    ps.forEach((p) => visit(p));
    if (atoms.size > 8)
      return false;
    const value = (c, bits) => c.op === "and" ? c.xs.every((p) => value(p, bits)) : c.op === "or" ? c.xs.some((p) => value(p, bits)) : c.op === "not" ? !value(c.x, bits) : !!(bits & 1 << atoms.get(atom(c)));
    for (let bits = 0;bits < 1 << atoms.size; bits++)
      if (q.terms.reduce((sum, [k], i) => sum + k * (value(ps[i], bits) ? 1 : 0), 0) !== 0)
        return false;
    return true;
  };
  const identityPriority = (q) => (booleanIdentity(q) ? q.terms.length === 3 ? 200 : 100 : 0) + overlap(q) + (q.terms.some(([, id]) => requestSizes.has(id)) ? 10 : 0);
  const identities = eligible.filter((q) => q.terms.length !== 5).map((q) => ({ q, rank: identityPriority(q) })).sort((a, b) => b.rank - a.rank).map(({ q }) => q);
  const algebraic = new Set([...unions, ...identities.slice(0, 16 - unions.length)]);
  const insts = full.insts.filter((q) => {
    if (options.frames && q.unit === 0 && q.terms.length === 3) {
      const ps = q.terms.filter(([k]) => k === 1).map(([, v]) => v), ns = q.terms.filter(([k]) => k === -1).map(([, v]) => v);
      const cover = ns.length === 1 ? bodies.get(ns[0]) : undefined, view = cover && indicator(cover);
      if (ps.length === 2 && view?.op === "get" && stored.has(ns[0]))
        for (const id of ps) {
          const post = full.reads.some((r) => r[0] === id && r[1].endsWith("#")), other = bodies.get(ps.find((p) => p !== id)), source = other && indicator(other);
          if (!post || source?.op !== "get" || !inputs.has(source.map))
            continue;
          let present = false;
          walkOnce(bodies.get(id), (o) => {
            if (o.op === "get" && text(o) === text(view))
              present = true;
          });
          if (present)
            return true;
        }
    }
    if (algebraic.has(q))
      return true;
    if (q.unit !== 0 || q.terms.length !== 2)
      return false;
    const positive = q.terms.find(([n]) => n === 1)?.[1], negative = q.terms.find(([n]) => n === -1)?.[1];
    if (!positive || !negative)
      return false;
    const a = bodies.get(positive), b = bodies.get(negative);
    if (!a || !b)
      return false;
    if (text(indicator(a)) === text(indicator(b)))
      return true;
    if (options.algebraic && text(indicator(a)) === text(indicator(b)))
      return true;
    const pa = predicate(a), pb = predicate(b);
    if (pa && pb) {
      const have = new Set(conjuncts(pa)), need = new Set(conjuncts(pb));
      if (have.size === need.size && [...need].every((p) => have.has(p)))
        return true;
      if ((options.structural !== false || options.frames && full.reads.some((r) => r[0] === positive && r[1].endsWith("#")) && full.reads.some((r) => r[0] === negative && r[1].endsWith("#"))) && [...need].every((p) => have.has(p)))
        return true;
    }
    if (options.frames && stored.has(negative) && full.reads.some((r) => r[0] === positive && r[1].endsWith("#"))) {
      const members = (c) => c.op === "and" ? c.xs.flatMap(members) : member(c) ? [member(c)] : [];
      const covers = pb ? members(pb) : [], direct = indicator(b);
      if (direct.op === "get")
        covers.push(direct);
      let present = false;
      if (covers.length)
        walkOnce(a, (o) => {
          if (o.op === "get" && covers.some((c) => text(o) === text(c)))
            present = true;
        });
      if (present)
        return true;
    }
    const source = indicator(a);
    if (source.op !== "get" || !inputs.has(source.map) || options.carried && source.map !== options.carried)
      return false;
    if (options.targets?.length) {
      const targetNames = new Set(options.targets.flatMap((t) => t.op === "var" ? [t.name] : []));
      let relevant = false;
      walkOnce(b, (o) => {
        if (o.op === "var" && targetNames.has(o.name))
          relevant = true;
      });
      if (!relevant)
        return false;
    }
    const view = views.get(source.map);
    if (!view?.size)
      return stored.has(negative);
    let matches = false;
    walkOnce(b, (o) => {
      if (o.op === "get" && view.has(text(o)))
        matches = true;
    });
    return matches;
  });
  if (options.frames || options.requestFrames || options.copyFrames) {
    const used = new Set([...m.inputs, ...m.params, ...Object.keys(m.state), ...full.insts.map((i) => i.wit), ...full.reads.map((r) => r[0])]);
    walkOnce(cs, (o) => {
      if (o.op === "var")
        used.add(o.name);
    });
    let serial = 0;
    const add = (terms, below) => {
      if (insts.some((i) => i.unit === 0 && JSON.stringify(i.terms) === JSON.stringify(terms)))
        return;
      let wit;
      do {
        wit = `frame$${serial++}`;
      } while (used.has(wit));
      used.add(wit);
      insts.push({ wit, below, terms, unit: 0 });
    };
    const byId = new Map(cs.map((c) => [c.v, c])), afters = full.reads.filter((r) => r[1].endsWith("#")).slice(0, 16);
    if (options.copyFrames) {
      const rank = (key) => {
        const names = new Set;
        walkOnce(key, (o) => {
          if (o.op === "var")
            names.add(o.name);
        });
        return names.size && [...names].every((name) => m.inputs.includes(name)) ? Math.min(...[...names].map((name) => m.inputs.indexOf(name))) : [...names].some((name) => m.inputs.includes(name)) ? 100 : 200;
      };
      const pools = afters.flatMap((after) => {
        const c = byId.get(after[0]);
        if (!c)
          return [];
        const before = full.reads.filter((old) => old[1] === after[1].slice(0, -1) && text(old[2]) !== text(after[2]) && text(byId.get(old[0])?.below) === text(c.below)).sort((a, b) => rank(a[2]) - rank(b[2]));
        return [{ after, c, before }];
      });
      let copies = 0;
      for (let row = 0;copies < 16; row++) {
        let found = false;
        for (const pool of pools) {
          const before = pool.before[row];
          if (!before)
            continue;
          found = true;
          add([[1, pool.after[0]], [-1, before[0]]], pool.c.below);
          add([[1, before[0]], [-1, pool.after[0]]], pool.c.below);
          if (++copies >= 16)
            break;
        }
        if (!found)
          break;
      }
    }
    for (const after of afters) {
      const c = byId.get(after[0]);
      if (!c)
        continue;
      if (options.frames)
        add([[1, after[0]]], c.below);
      const before = full.reads.find((r) => r[1] === after[1].slice(0, -1) && text(r[2]) === text(after[2]));
      if (options.frames && before && text(byId.get(before[0])?.below) === text(c.below)) {
        add([[1, after[0]], [-1, before[0]]], c.below);
        add([[1, before[0]], [-1, after[0]]], c.below);
      }
      if (options.requestFrames) {
        const shape = (v) => Array.isArray(v) ? v.map(shape) : v && typeof v === "object" ? v.op === "get" ? { op: "cell" } : v.op === "var" ? { op: "key" } : Object.fromEntries(Object.entries(v).map(([k, v]) => [k, shape(v)])) : v;
        const beforeDecl = decls.find((d) => d.map === after[1].slice(0, -1));
        if (beforeDecl)
          for (const read of full.reads) {
            if (read[1].endsWith("#"))
              continue;
            const d = decls.find((d) => d.map === read[1]), count = byId.get(read[0]);
            if (!d || !count || text(count.below) !== text(c.below))
              continue;
            let carried = false;
            walkOnce(d.body, (o) => {
              if (o.op === "get" && inputs.has(o.map) && (!options.carried || o.map === options.carried))
                carried = true;
            });
            if (!carried || text(shape(indicator(d.body))) !== text(shape(indicator(beforeDecl.body))))
              continue;
            add([[1, after[0]], [-1, read[0]]], c.below);
            add([[1, read[0]], [-1, after[0]]], c.below);
          }
      }
    }
  }
  const inferred = memberInclusions(m, decls, full.reads), reserved = new Set([...m.inputs, ...m.params, ...Object.keys(m.state), ...full.insts.map((q) => q.wit), ...full.reads.map((r) => r[0])]);
  walkOnce(cs, (o) => {
    if (o.op === "var")
      reserved.add(o.name);
  });
  let memberSerial = 0;
  for (const p of inferred) {
    if (options.carried && options.carried !== p.carried)
      continue;
    const terms = [[1, p.positive], [-1, p.negative]], signature = JSON.stringify(terms);
    if (insts.some((q) => q.unit === 0 && JSON.stringify(q.terms) === signature))
      continue;
    const prior = full.insts.find((q) => q.unit === 0 && JSON.stringify(q.terms) === signature);
    if (prior) {
      insts.push(prior);
      continue;
    }
    let wit;
    do {
      wit = `member$${memberSerial++}`;
    } while (reserved.has(wit));
    reserved.add(wit);
    insts.push({ wit, below: p.below, terms, unit: 0 });
  }
  const focused = { reads: full.reads, insts };
  return options.algebraic && options.claim ? demandCountCert(m, decls, focused, options.claim) : focused;
}

// core/count-witness-flags.ts
var mapsIn2 = (value) => {
  const maps = new Set;
  walkOnce(value, (o) => {
    if (o.op === "get")
      maps.add(o.map);
  });
  return maps;
};
function seedCountWitnessFlags(m, at, packets, preferCarried = false, options = {}) {
  let out = at;
  const flags = Object.entries(m.step.flags ?? {}).filter(([, q]) => q.op === "all" && !q.keys?.length).map(([name, q]) => ({ name: `?${name}`, maps: mapsIn2(q) })).filter((q) => ![...q.maps].some((mp) => (mp in (m.counts ?? {}))));
  for (const { decls, cert } of packets) {
    const bodies = new Map(cert.reads.map(([id, map]) => {
      const d = decls.find((d) => d.map === map);
      return [id, d ? (options.dependencies ?? mapsIn2)(d.body) : new Set];
    }));
    for (const inst of cert.insts) {
      let used = new Set(inst.terms.flatMap(([, id]) => [...bodies.get(id) ?? []]));
      if (preferCarried) {
        const carried = new Set(inst.terms.filter(([coefficient]) => coefficient > 0).flatMap(([, id]) => [...bodies.get(id) ?? []]).filter((mp) => m.inputMaps?.includes(mp)));
        if (carried.size || options.carriedOnly)
          used = carried;
      }
      for (const f of flags)
        if (!f.maps.size || [...f.maps].some((mp) => used.has(mp))) {
          const term = x(inst.wit), had = out[f.name] ?? [];
          if (had.some((e) => e.op === "var" && e.name === inst.wit))
            continue;
          if (out === at)
            out = { ...at };
          out[f.name] = [...had, term];
        }
    }
  }
  return out;
}

// research/track-m/section13-control.ts
var shardControl = { mode: "off", op: -1, context: {}, capture: () => {}, finish: () => {}, query: (_packet, run) => run() };

// core/count-select.ts
function selectCountBounds(base, candidates, until, options = {}) {
  const path = options.path ?? new Map, ask = modelSequence(path), started = clock();
  for (let n = candidates.length ? 1 : 0;n <= candidates.length && clock() < until; n++) {
    const goal = { ...base, hyps: [...base.hyps, ...candidates.slice(0, n).map((c) => c.bound)] }, q = ask(goal, Math.min(until, clock() + (options.queryMs ?? 200)));
    const used = "tree" in q ? usedHyps(goal, q.tree, path) : q.why === REFUTED && q.core ? new Set(q.core) : undefined;
    if (used) {
      const indices = candidates.slice(0, n).filter((_, i) => used.has(base.hyps.length + i)).map((c) => c.index);
      options.trace?.({ stage: "count-core-select", pool: candidates.length, assumed: n, indices, ms: Math.round(clock() - started) });
      return { indices, assumed: n, fallback: false };
    }
    if ("tree" in q || q.stuck !== "sat")
      break;
  }
  if (clock() >= until)
    return;
  const indices = candidates.map((c) => c.index);
  options.trace?.({ stage: "count-core-select", pool: candidates.length, indices, fallback: true, ms: Math.round(clock() - started) });
  return { indices, assumed: indices.length, fallback: true };
}

// core/count-recovery/action-guard.ts
function actionGuard(m, selector, value) {
  if (value === undefined)
    return;
  const flags = Object.fromEntries(Object.entries(m.step.flags ?? {}).map(([name, q]) => [name, q.op === "all" ? same(x(`?${name}`), n(1)) : q]));
  const guards = [];
  for (const q of Object.values(m.step.flags ?? {})) {
    if (q.op === "all")
      continue;
    let matches = false;
    walkOnce(q, (o) => {
      if (o.op === "=" && [[o.a, o.b], [o.b, o.a]].some(([a, b]) => a.op === "var" && a.name === selector && b.op === "const" && b.value === value))
        matches = true;
    });
    if (matches)
      guards.push(substC(q, { vars: {}, maps: {}, flags }));
  }
  return guards.length === 1 ? guards[0] : guards.length ? any(...guards) : undefined;
}
function activeCarried(m, path) {
  const out = new Set, inputs = new Set(m.inputMaps ?? []);
  for (const [name, q] of Object.entries(m.step.flags ?? {})) {
    if (q.op !== "all" || truth(same(x(`?${name}`), n(1)), path) !== true)
      continue;
    walkOnce(q.c, (o) => {
      if (o.op === "get" && inputs.has(o.map))
        out.add(o.map);
    });
  }
  if (!out.size && m.inputMaps?.[0])
    out.add(m.inputMaps[0]);
  return out;
}
function copiesRows(m, root) {
  const flags = {};
  let copy = false;
  for (const [name, c] of Object.entries(m.step.flags ?? {}))
    flags[name] = c.op === "all" ? same(x(`?${name}`), n(1)) : substC(c, { vars: {}, maps: {}, flags });
  for (const [map, write] of Object.entries(m.step.maps ?? {})) {
    if (!("each" in write))
      continue;
    walkLive(substE(write.value, { vars: {}, maps: {}, flags }), root, (o) => {
      if (o.op !== "get" || o.map !== map)
        return;
      walkOnce(o.key, (key) => {
        if (key.op === "var" && key.name !== write.each && m.inputs.includes(key.name))
          copy = true;
      });
    });
  }
  return copy;
}

// core/count-recovery/lift-count-proxies.ts
var liftCountProxies = (...args) => wallTree("transport", () => liftCountProxiesImpl(...args));
function liftCountProxiesImpl(part, whole, tree, reads, pp = new Map, wp = new Map, diagnose, options = {}) {
  const aliases = new Map(reads.map(([id, map, key]) => [id, { op: "get", map, key }]));
  const substitutions = Object.fromEntries(aliases), terms = new Map;
  const remapTerm = (name) => {
    if (terms.has(name))
      return terms.get(name);
    const term = columnTerm(name);
    let uses = false;
    if (term)
      walkOnce(term, (o) => {
        if (o.op === "var" && aliases.has(o.name))
          uses = true;
      });
    const mapped = term && uses ? substE(term, { vars: substitutions, maps: {}, flags: {} }) : undefined;
    terms.set(name, mapped);
    return mapped;
  };
  const replace = (lin, path) => {
    let out = {};
    for (const [name, coefficient] of Object.entries(lin)) {
      const e = aliases.get(name) ?? remapTerm(name), value = e ? linear(e, path) : { [name]: 1 };
      if (!value || !e && [...aliases.keys()].some((id) => name.includes(id)))
        return;
      out = add(out, scale(value, coefficient));
    }
    return out;
  };
  const go = (t, source, target) => {
    if (!("leaf" in t)) {
      const split = replace(t.split, target);
      if (!split)
        return;
      const id = canon(split), known = target.get(id)?.holds;
      if (known !== undefined)
        return go(known ? t.yes : t.no, new Map(source).set(canon(t.split), { lin: t.split, holds: known }), target);
      const yes = go(t.yes, new Map(source).set(canon(t.split), { lin: t.split, holds: true }), new Map(target).set(id, { lin: split, holds: true }));
      const no = yes && go(t.no, new Map(source).set(canon(t.split), { lin: t.split, holds: false }), new Map(target).set(id, { lin: split, holds: false }));
      return yes && no ? { split, yes, no } : undefined;
    }
    if (t.products?.length || t.squares?.length)
      return;
    const rp = rowsAt(part, source), rw = rowsAt(whole, target), exact = new Map, normalized = new Map, columns = new Map;
    for (const [id, e] of aliases) {
      const l = linear(e, target);
      if (!l)
        return;
      const entries = Object.entries(l);
      if (entries.length !== 1 || entries[0][1] !== 1)
        return;
      columns.set(entries[0][0], id);
    }
    const normalize = (lin) => {
      let out = {};
      for (const [name, c] of Object.entries(lin))
        out = add(out, { [columns.get(name) ?? name]: c });
      return out;
    };
    rw.forEach((r, i) => {
      const id = canon(r.lin), norm = canon(normalize(r.lin));
      if (!exact.has(id))
        exact.set(id, i);
      if (!normalized.has(norm))
        normalized.set(norm, i);
    });
    const steps = [], indices = [];
    const input = (index) => {
      steps.push({ kind: "input", index });
      return steps.length - 1;
    };
    for (const s of t.leaf) {
      if (s.kind === "input") {
        const row = rp[s.index];
        if (!row)
          return;
        const desired = replace(row.lin, target);
        if (!desired)
          return;
        const direct = exact.get(canon(desired));
        if (direct !== undefined) {
          indices.push(input(direct));
          continue;
        }
        if (!Object.keys(desired).length) {
          const a = rw.findIndex((r) => exact.has(canon(scale(r.lin, -1))));
          if (a < 0) {
            diagnose?.({ reason: "missing-zero-row" });
            return;
          }
          const b = exact.get(canon(scale(rw[a].lin, -1))), left = input(a), right = input(b);
          steps.push({ kind: "combine", a: left, b: right, ma: 1, mb: 1 });
          indices.push(steps.length - 1);
          continue;
        }
        const base = normalized.get(canon(row.lin));
        if (base === undefined) {
          diagnose?.({ reason: "missing-row", row: row.lin, desired });
          return;
        }
        let at = input(base), value = rw[base].lin;
        for (const [id, e] of aliases) {
          const c = value[id] ?? 0;
          if (!c)
            continue;
          const l = linear(e, target);
          if (!l)
            return;
          const bridge = sub(l, { [id]: 1 }), signed = c > 0 ? bridge : scale(bridge, -1), r = exact.get(canon(signed));
          if (r === undefined) {
            diagnose?.({ reason: "missing-binding", id, row: signed });
            return;
          }
          const b = input(r);
          steps.push({ kind: "combine", a: at, b, ma: 1, mb: Math.abs(c) });
          at = steps.length - 1;
          value = add(value, scale(bridge, c));
        }
        if (canon(value) !== canon(desired))
          return;
        indices.push(at);
      } else if (s.kind === "combine") {
        const a = indices[s.a], b = indices[s.b];
        if (a === undefined || b === undefined)
          return;
        steps.push({ ...s, a, b });
        indices.push(steps.length - 1);
      } else {
        const of = indices[s.of];
        if (of === undefined)
          return;
        steps.push({ ...s, of });
        indices.push(steps.length - 1);
      }
    }
    return { leaf: steps };
  };
  const guards = new Map;
  walkOnce(whole.hyps, (c) => {
    if (c.op !== "or" || c.xs.length !== 2)
      return;
    const eq = c.xs.find((x) => x.op === "=" && x.a.op === "var" && aliases.has(x.a.name)), guard = c.xs.find((x) => x !== eq);
    if (!eq || guard?.op !== "<=")
      return;
    const a = linear(guard.a, wp), b = linear(guard.b, wp);
    if (!a || !b)
      return;
    const lin = sub(a, b);
    if (Object.keys(lin).every((k) => k === "1") && (lin["1"] ?? 0) > 0)
      return;
    guards.set(canon(lin), lin);
  });
  const all = [...guards.values()];
  const open = (i, path) => {
    if (i === all.length)
      return go(tree, pp, path);
    const split = all[i], id = canon(split), known = path.get(id)?.holds;
    if (known === false)
      return open(i + 1, path);
    const badPath = new Map(path).set(id, { lin: split, holds: true }), out = solve(rowsAt(whole, badPath), 2000);
    if (out.kind !== "refuted") {
      diagnose?.({ reason: "domain-not-refuted", split });
      return;
    }
    const yes = { leaf: out.steps };
    if (!options.deferCheck && !check(whole, yes, badPath))
      return;
    if (known === true)
      return yes;
    const no = open(i + 1, new Map(path).set(id, { lin: split, holds: false }));
    return no ? { split, yes, no } : undefined;
  };
  const out = open(0, wp), accepted = !!out && (options.deferCheck || check(whole, out, wp));
  diagnose?.({ reason: "complete", guards: all.length, checked: !options.deferCheck && accepted, ...options.deferCheck ? { proposed: !!out, deferred: true } : {} });
  return accepted ? out : undefined;
}

// core/count-recovery/pre-state-source.ts
function preStateCountSource(goal, cert, claim, path, extra = []) {
  const post = cert.reads.filter((r) => r[1].endsWith("#")), postIds = new Set(post.map((r) => r[0])), postMaps = new Set(post.map((r) => r[1]));
  const keep = cert.insts.map((q, index) => ({ q, index })).filter(({ q }) => q.terms.every(([, id]) => !postIds.has(id))), indices = new Set(keep.map(({ index }) => index));
  const discarded = new Set(cert.insts.filter((_, i) => !indices.has(i)).map((q) => q.wit)), offset = goal.hyps.length - cert.insts.length;
  const weaken = (c) => {
    if (c.op === "and") {
      const xs = c.xs.flatMap((child) => {
        const kept = weaken(child);
        return kept ? [kept] : [];
      });
      return xs.length ? { ...c, xs } : undefined;
    }
    let invalid = false;
    walkLive(c, path, (o) => {
      if (o.op === "get" && postMaps.has(o.map) || o.op === "var" && (postIds.has(o.name) || discarded.has(o.name)))
        invalid = true;
    });
    return invalid ? undefined : c;
  };
  const hyps = goal.hyps.slice(0, offset).flatMap((c) => piecesAt(c, path)).flatMap((c) => {
    const kept = weaken(c);
    return kept ? [kept] : [];
  });
  return { goal: { ...goal, hyps: [...hyps, ...extra, claim, ...keep.map(({ index }) => goal.hyps[offset + index])] }, cert: { reads: cert.reads.filter((r) => !postIds.has(r[0])), insts: keep.map(({ q }) => q) } };
}

// core/count-recovery/fold-path.ts
var expressions = new Set(["var", "const", "mul", "prod", "add", "sub", "min", "max", "if", "get", "tup", "proj"]);
var conditions = new Set(["not", "and", "or", "<", "<=", "="]);
function foldPath(g, path) {
  const seen = new WeakMap, opaque = {};
  const yes = { op: "and", xs: [] }, no = { op: "or", xs: [] };
  const f = (o) => {
    if (!o || typeof o !== "object")
      return o;
    if (seen.has(o))
      return seen.get(o);
    let out;
    if (Array.isArray(o))
      out = o.map(f);
    else if (conditions.has(o.op) && truth(o, path) !== undefined)
      out = truth(o, path) ? yes : no;
    else if (o.op === "if" && truth(o.c, path) !== undefined)
      out = f(truth(o.c, path) ? o.then : o.else);
    else {
      out = Object.fromEntries(Object.entries(o).map(([k, v]) => [k, f(v)]));
      if (out.op === "and" || out.op === "or") {
        const neutral = out.op === "and" ? "and" : "or", xs = out.xs.filter((c) => !((c.op === "and" || c.op === "or") && c.op === neutral && c.xs.length === 0));
        out = xs.length === 1 ? xs[0] : { ...out, xs };
      }
    }
    seen.set(o, out);
    if (expressions.has(o.op)) {
      const a = linear(out, path), b = linear(o, path), entry = a && Object.entries(a);
      if (a && b && entry?.length === 1 && entry[0][0] !== "1" && entry[0][1] === 1 && canon(a) !== canon(b))
        opaque[entry[0][0]] = o;
    }
    return out;
  };
  return { goal: { ...g, hyps: g.hyps.map(f) }, opaque };
}

// core/count-recovery/key-closure.ts
var closeKeyReads = (...args) => wallSpan("key-proposals", () => closeKeyReadsImpl(...args));
function closeKeyReadsImpl(g, root, reads, wits, until) {
  const proposals = [], seen = new Set, cuts = [], cells = new Map;
  let path = root;
  const add = (c) => {
    const id = JSON.stringify(c);
    if (!seen.has(id)) {
      seen.add(id);
      proposals.push(c);
    }
  };
  const member = (key) => {
    let hit = false;
    walkOnce(key, (o) => {
      if (o.op === "var" && wits.has(o.name))
        hit = true;
    });
    return hit;
  };
  for (const { map, key } of reads) {
    const xs = cells.get(map) ?? [];
    if (!xs.some((k) => JSON.stringify(k) === JSON.stringify(key)))
      xs.push(key);
    cells.set(map, xs);
    if (!member(key))
      continue;
    const subs = [];
    walkOnce(key, (o) => {
      if (o.op === "sub")
        subs.push(o);
    });
    for (const s of subs.reverse())
      add({ op: "<=", a: s.b, b: s.a });
  }
  for (const keys of cells.values())
    for (let i = 0;i < keys.length; i++)
      for (let j = i + 1;j < keys.length; j++)
        if (member(keys[i]) || member(keys[j]))
          add({ op: "=", a: keys[i], b: keys[j] });
  const force = (split) => {
    const id = canon(split);
    if (path.get(id)?.holds === true)
      return true;
    if (clock() >= until)
      return false;
    const other = new Map(path).set(id, { lin: split, holds: false }), out = refuteFast(rowsAt(g, other), 128);
    if (out?.kind !== "refuted")
      return false;
    cuts.push({ split, no: { leaf: out.steps } });
    path = new Map(path).set(id, { lin: split, holds: true });
    return true;
  };
  for (const c of proposals.slice(0, 24)) {
    if (clock() >= until)
      break;
    if (truth(c, path) !== undefined)
      continue;
    for (const split of facts(c, path))
      if (!force(split)) {
        const inverse = scale(split, -1);
        inverse["1"] = (inverse["1"] ?? 0) + 1;
        force(inverse);
      }
  }
  return { path, cuts };
}

// core/count-recovery/rebase-path.ts
function rebasePath(g, tree, from, to, until, target = g) {
  return wallTree(target === g ? "pin-pruning" : "source-reindexing", () => {
    const indices = new WeakMap;
    const visit = (t, a, b) => {
      if (late(until))
        return;
      if (!("leaf" in t)) {
        const id = canon(t.split), known = b.get(id)?.holds;
        if (known !== undefined)
          return visit(known ? t.yes : t.no, new Map(a).set(id, { lin: t.split, holds: known }), b);
        const yes = visit(t.yes, new Map(a).set(id, { lin: t.split, holds: true }), new Map(b).set(id, { lin: t.split, holds: true }));
        const no = yes && visit(t.no, new Map(a).set(id, { lin: t.split, holds: false }), new Map(b).set(id, { lin: t.split, holds: false }));
        return yes && no ? { split: t.split, yes, no } : undefined;
      }
      const before = rowsAt(g, a), after = rowsAt(target, b);
      let at = indices.get(after);
      if (!at) {
        at = new Map;
        after.forEach((r, i) => {
          const id = canon(r.lin);
          if (!at.has(id))
            at.set(id, i);
        });
        indices.set(after, at);
      }
      const map = (i) => i < before.length ? at.get(canon(before[i].lin)) : i - before.length + after.length;
      const leaf = [];
      for (const step of t.leaf) {
        if (step.kind !== "input") {
          leaf.push(step);
          continue;
        }
        const index = map(step.index);
        if (index === undefined)
          return;
        leaf.push({ ...step, index });
      }
      const products = [];
      for (const [a, b] of t.products ?? []) {
        const x = map(a), y = map(b);
        if (x === undefined || y === undefined)
          return;
        products.push([x, y]);
      }
      return { leaf, ...t.products ? { products } : {}, ...t.squares ? { squares: t.squares } : {} };
    };
    return visit(tree, from, to);
  });
}

// core/count-recovery/boolean-core.ts
function walkChoices(root, path, visit) {
  const goals = new WeakSet, conditions = new WeakSet;
  const go = (value, condition = false) => {
    const seen = condition ? conditions : goals;
    if (!value || typeof value !== "object" || seen.has(value))
      return;
    seen.add(value);
    if (condition && ["not", "and", "or", "<", "<=", "="].includes(value.op) && truth(value, path) !== undefined)
      return;
    if (value.op === "if") {
      const chosen = truth(value.c, path);
      if (chosen !== undefined) {
        go(chosen ? value.then : value.else);
        return;
      }
      visit(value);
      go(value.c, true);
      go(value.then);
      go(value.else);
      return;
    }
    visit(value);
    for (const child of Array.isArray(value) ? value : Object.values(value))
      go(child, condition);
  };
  go(root);
}
function booleanCandidates(g, root, wits, extended = false) {
  const walk = extended ? walkChoices : walkLive;
  const chosen = new Map, add = (c, score) => {
    if (truth(c, root) !== undefined)
      return;
    const id = JSON.stringify(c), old = chosen.get(id);
    chosen.set(id, { c, score: score + (old?.score ?? 0) });
  };
  for (const h of g.hyps) {
    let c = h;
    while (c.op === "not")
      c = c.x;
    if (c.op === "<" || c.op === "<=" || c.op === "=")
      add(c, 1000);
  }
  walk(g.hyps, root, (o) => {
    if (o.op === "=" && o.a.op === "var" && o.b.op === "var") {
      const a = wits.has(o.a.name), b = wits.has(o.b.name);
      if (!a && !b)
        add(o, 10);
      else if (a !== b)
        add(o, 1500);
    }
    if ((o.op === "<" || o.op === "<=") && o.a.op === "var" && o.b.op === "var" && o.a.name !== o.b.name && !wits.has(o.a.name) && !wits.has(o.b.name))
      add(o, extended ? 1400 : 750);
    if (extended && ["<", "<=", "="].includes(o.op)) {
      let left = false, right = false, witness = false;
      walkLive(o.a, root, (e) => {
        if (e.op === "get")
          left = true;
        if (e.op === "var" && wits.has(e.name))
          witness = true;
      });
      walkLive(o.b, root, (e) => {
        if (e.op === "get")
          right = true;
        if (e.op === "var" && wits.has(e.name))
          witness = true;
      });
      if (left && right && witness)
        add(o, 1000);
    }
    if (!["=", "<="].includes(o.op))
      return;
    const value = o.op === "=" && o.b.op === "const" && o.b.value === 1 ? o.a : o.op === "<=" && o.a.op === "const" && o.a.value === 1 ? o.b : undefined;
    if (extended && value?.op === "if" && value.then.op === "const" && value.then.value === 1 && value.else.op === "const" && value.else.value === 0) {
      let hit = false;
      walkOnce(value, (e) => {
        if (e.op === "var" && wits.has(e.name))
          hit = true;
      });
      if (hit)
        add(o, 1800);
    }
    const cell = o.op === "=" && o.a.op === "get" && o.b.op === "const" && o.b.value === 1 ? o.a : o.op === "<=" && o.a.op === "const" && o.a.value === 1 && o.b.op === "get" ? o.b : undefined;
    if (!cell)
      return;
    let hit = false;
    walkOnce(cell.key, (x) => {
      if (x.op === "var" && wits.has(x.name))
        hit = true;
    });
    if (hit)
      add(o, extended ? 1200 : o.op === "<=" ? 100 : 50);
  });
  const cells = new Map;
  walk(g.hyps, root, (o) => {
    if (o.op === "get" && linear(o.key, root)) {
      const xs = cells.get(o.map) ?? [];
      if (!xs.some((k) => JSON.stringify(k) === JSON.stringify(o.key)))
        xs.push(o.key);
      cells.set(o.map, xs);
    }
  });
  const mentions = (key) => {
    const out = new Set;
    walkOnce(key, (o) => {
      if (o.op === "var" && wits.has(o.name))
        out.add(o.name);
    });
    return out;
  };
  for (const keys of cells.values())
    for (let i = 0;i < keys.length; i++)
      for (let j = i + 1;j < keys.length; j++) {
        const a = keys[i], b = keys[j], wanted = mentions(a);
        if ([...mentions(b)].some((w) => wanted.has(w)))
          add(same(a, b), 500);
      }
  return [...chosen.values()];
}
var booleanCore = (...args) => wallTree("tree-reconstruction", () => booleanCoreImpl(...args));
function booleanCoreImpl(g, root, wits, until, trace, options = {}) {
  const start = clock(), scalarGuards = options.scalarGuards ?? false, extended = options.extended ?? false;
  let pinned = new Map(root);
  const prefix = [];
  const pin = (split) => {
    const id = canon(split);
    if (pinned.get(id)?.holds === true)
      return true;
    if (clock() >= until)
      return false;
    const other = new Map(pinned).set(id, { lin: split, holds: false }), out = refuteFast(rowsAt(g, other), 256);
    const no = out?.kind === "refuted" ? { leaf: out.steps } : undefined;
    if (!no || !options.deferCheck && !check(g, no, other))
      return false;
    prefix.push({ split, no });
    pinned = new Map(pinned).set(id, { lin: split, holds: true });
    return true;
  };
  for (let round = 0;round < 2 && clock() < until; round++)
    for (const h of g.hyps)
      for (const split of facts(h, pinned))
        pin(split);
  const guards = new Map, walk = scalarGuards ? walkChoices : walkLive;
  walk(g.hyps, root, (o) => {
    if (o.op === "if")
      walkOnce(o.c, (c) => {
        if (!["<", "<=", "="].includes(c.op))
          return;
        let witness = false, plain = true;
        walkOnce(c, (e) => {
          if (e.op === "var" && wits.has(e.name))
            witness = true;
          if (["get", "if", "sub", "min", "max", "prod", "tup", "proj"].includes(e.op))
            plain = false;
        });
        if (plain && (scalarGuards || witness))
          guards.set(JSON.stringify(c), c);
      });
  });
  for (const c of guards.values())
    for (const split of facts(c, pinned)) {
      if (scalarGuards && truth(c, pinned) !== undefined)
        break;
      if (!pin(split)) {
        const inverse = scale(split, -1);
        inverse["1"] = (inverse["1"] ?? 0) + 1;
        pin(inverse);
      }
    }
  const candidates = booleanCandidates(g, scalarGuards ? pinned : root, wits, extended).filter(({ c }) => truth(c, pinned) === undefined);
  const selected = candidates.sort((a, b) => b.score - a.score).slice(0, 8), slots = [];
  const expand = (c) => c.op === "=" ? [{ op: "<=", a: c.a, b: c.b }, { op: "<=", a: c.b, b: c.a }] : [c];
  const cs = selected.flatMap(({ c }, slot) => {
    const parts = expand(c);
    slots.push(...parts.map(() => slot));
    return parts;
  });
  let nodes = 0, leaves = 0, last;
  const go = (i, path, keysClosed = false, plan = cs) => {
    if (clock() >= until)
      return;
    nodes++;
    const out = refuteFast(rowsAt(g, path), 1000);
    if (out?.kind === "refuted")
      return { leaf: out.steps };
    if (i === plan.length) {
      leaves++;
      const out = grow(g, path, { nodes: 0, until, units: true });
      if ("tree" in out)
        return out.tree;
      last ??= { path: [...path], outcome: out.stuck, ...options.model && "witness" in out ? { model: out.witness, columns: Object.fromEntries(Object.keys(out.witness ?? {}).filter((name) => name.startsWith("\u27E6")).slice(0, 8).map((name) => [name, columnTerm(name)])) } : {} };
      return;
    }
    if (extended && !keysClosed) {
      let field = false;
      walkOnce(plan[i], (o) => {
        if (o.op === "get")
          field = true;
      });
      if (field) {
        const reads = [];
        walkChoices(g.hyps, path, (o) => {
          if (o.op === "get")
            reads.push({ map: o.map, key: o.key });
        });
        const begun = clock(), closed = closeKeyReads(g, path, reads, wits, until);
        const folded = new WeakMap, fold = (e) => {
          const found = folded.get(e);
          if (found)
            return found;
          const out = foldPath({ name: "candidate operand", hyps: [same(e, x("boolean$probe"))] }, closed.path).goal.hyps[0];
          const result = out?.op === "=" ? out.a : e;
          folded.set(e, result);
          return result;
        };
        const fresh = new Map;
        for (const candidate of booleanCandidates(g, closed.path, wits, true)) {
          const c = candidate.c, normalized = c.op === "<" || c.op === "<=" || c.op === "=" ? { ...c, a: fold(c.a), b: fold(c.b) } : c;
          if (truth(normalized, closed.path) !== undefined)
            continue;
          const id = JSON.stringify(normalized), old = fresh.get(id);
          fresh.set(id, { c: normalized, score: Math.max(old?.score ?? 0, candidate.score) });
        }
        const remaining = Math.max(0, 8 - (slots[i] ?? 8)), refreshed = [...fresh.values()].sort((a, b) => b.score - a.score).slice(0, remaining).flatMap(({ c }) => expand(c));
        let tree = go(0, closed.path, true, refreshed);
        if (tree)
          for (const cut of [...closed.cuts].reverse())
            tree = { split: cut.split, yes: tree, no: cut.no };
        trace.push({ stage: "key-closure", facts: closed.cuts.length, ms: Math.round(clock() - begun), proposed: !!tree });
        return tree;
      }
    }
    const c = plan[i], known = truth(c, path);
    if (known !== undefined)
      return go(i + 1, path, keysClosed, plan);
    if (c.op !== "<" && c.op !== "<=")
      return;
    const a = linear(c.a, path), b = linear(c.b, path);
    if (!a || !b)
      return;
    const split = sub(a, b);
    if (c.op === "<")
      split["1"] = (split["1"] ?? 0) + 1;
    const id = canon(split), yes = go(i + 1, new Map(path).set(id, { lin: split, holds: true }), keysClosed, plan), no = yes && go(i + 1, new Map(path).set(id, { lin: split, holds: false }), keysClosed, plan);
    return yes && no ? { split, yes, no } : undefined;
  };
  let tree = go(0, pinned);
  if (tree) {
    const paths = [new Map(root)];
    for (const p of prefix)
      paths.push(new Map(paths.at(-1)).set(canon(p.split), { lin: p.split, holds: true }));
    let removed = 0;
    for (let i = prefix.length - 1;i >= 0; i--) {
      const p = prefix[i], shorter = rebasePath(g, tree, paths[i + 1], paths[i], until);
      if (shorter) {
        tree = shorter;
        removed++;
      } else
        tree = { split: p.split, yes: tree, no: p.no };
    }
    trace.push({ stage: "pin-prune", removed, kept: prefix.length - removed });
  }
  const accepted = !!tree && (options.deferCheck || check(g, tree, root)), checked = accepted && !options.deferCheck;
  trace.push({ stage: "boolean-core", facts: prefix.length, cuts: cs.length, nodes, leaves, ms: Math.round(clock() - start), checked, proposed: !!tree, deferred: !!options.deferCheck, ...options.model ? { choices: cs.map((c) => ({ op: c.op, ..."a" in c ? { a: JSON.stringify(c.a).slice(0, 180), b: JSON.stringify(c.b).slice(0, 180) } : {} })) } : {}, ...last ? { last } : {} });
  return accepted ? tree : undefined;
}

// core/count-recovery/natural-cases.ts
function naturalSplits(g, root) {
  const expressions = [g.hyps], seen = new Set, splits = new Map;
  const columns = [...root.values()].flatMap((p) => Object.keys(p.lin));
  for (const name of columns) {
    if (seen.has(name))
      continue;
    seen.add(name);
    const term = columnTerm(name);
    if (term) {
      expressions.push(term);
      walkOnce(term, (o) => {
        if (o.op === "var")
          columns.push(o.name);
      });
    }
  }
  walkOnce(expressions, (o) => {
    if (o.op !== "sub" || truth({ op: "<=", a: o.a, b: o.b }, root) !== undefined)
      return;
    const a = linear(o.a, root), b = linear(o.b, root);
    if (!a || !b)
      return;
    const split = sub(a, b);
    splits.set(canon(split), split);
  });
  return [...splits.values()].slice(0, 2);
}
function proveNaturalCases(g, root, until, trace = [], options = {}) {
  const splits = naturalSplits(g, root);
  if (!splits.length)
    return;
  const started = clock();
  const go = (index, path) => {
    if (clock() >= until)
      return;
    const split = splits[index];
    if (!split) {
      const out = grow(g, path, { nodes: 0, until: Math.min(until, clock() + 100), units: false });
      trace.push({ stage: "natural-case-leaf", proposed: "tree" in out, ...!("tree" in out) ? { outcome: out.stuck, ..."witness" in out ? { model: out.witness } : {} } : {} });
      return "tree" in out ? out.tree : undefined;
    }
    const id = canon(split);
    if (path.has(id))
      return go(index + 1, path);
    const yes = go(index + 1, new Map(path).set(id, { lin: split, holds: true }));
    if (!yes)
      return;
    const no = go(index + 1, new Map(path).set(id, { lin: split, holds: false }));
    return no ? { split, yes, no } : undefined;
  };
  const tree = go(0, root), accepted = !!tree && (options.deferCheck || check(g, tree, root));
  trace.push({ stage: "natural-cases", cases: splits.length, ms: Math.round(clock() - started), checked: accepted && !options.deferCheck, proposed: !!tree, deferred: !!options.deferCheck });
  return accepted ? tree : undefined;
}

// core/count-recovery/leaf-allowance.ts
var leafAllowance = (remaining, leavesLeft) => {
  const available = Math.max(0, remaining);
  return Math.min(available / Math.max(1, leavesLeft), available / 3);
};

// core/count-recovery/derivability-closure.ts
var put3 = (p, lin, holds) => new Map(p).set(canon(lin), { lin, holds });
var plain2 = (lin) => !Object.keys(lin).some((k) => k.startsWith("\u27E6"));
var fast = (g, p) => {
  const q = lemmaRecorder.invoke("refuteFast", refuteFast, [lemmaRecorder.invoke("rowsAt", rowsAt, [g, p]), 256]);
  return q?.kind === "refuted" ? { leaf: q.steps } : undefined;
};
var decide5 = (lin, path) => path.get(canon(lin))?.holds ?? (path.has(canonFlip(lin)) ? !path.get(canonFlip(lin)).holds : undefined);
var active = (saved, path) => saved.filter((s) => lemmaPath([s.lemma], path) !== path);
function deriveCountClosure(m, ds, g, cert, root, until, trace, options = {}) {
  const wanted = new Set;
  walkLive(options.claim, root, (o) => {
    if (o.op === "var" && cert.reads.some((r) => r[0] === o.name))
      wanted.add(o.name);
    if (o.op === "get") {
      for (const r of cert.reads)
        if (r[1] === o.map && JSON.stringify(r[2]) === JSON.stringify(o.key))
          wanted.add(r[0]);
    }
  });
  if (wanted.size < 2 || !cert.insts.some((q) => q.unit === 0 && q.terms.length >= 3) || clock() >= until || pastWall())
    return;
  const started = clock(), reserve = Math.min(400, (until - started) / 3), buildEnd = until - reserve;
  const raw = g.hyps.slice(0, -cert.insts.length), ids = new Set(cert.reads.map((r) => r[0])), maps = new Set(cert.reads.map((r) => r[1])), wits = new Set(cert.insts.map((q) => q.wit));
  const saved = [], models = [], pins = [];
  let base = new Map(root);
  let leafEnd;
  const alive = () => clock() < until && !pastWall(), building = () => clock() < (leafEnd ?? buildEnd) && !pastWall();
  const wallEnd = () => Math.min(wallAt(), performance.now() + Math.min(1e4, Math.max(0, (leafEnd ?? until) - clock()) * 10));
  const transport = (from, to, t, a, b) => alive() ? withDeadline(Math.min(until, leafEnd ?? until), () => lemmaRecorder.invoke("widen", widen, [from, to, t, {}, a, b])) : undefined;
  const sourceCache = new WeakMap;
  const source = (path, witness) => {
    let entry = sourceCache.get(path);
    if (!entry) {
      const rows = [];
      for (const c of raw.flatMap((c) => piecesAt(c, path))) {
        let skip = false;
        const owners = new Set;
        walkLive(c, path, (o) => {
          if (o.op === "get" && maps.has(o.map) || o.op === "var" && ids.has(o.name))
            skip = true;
          else if (o.op === "var" && wits.has(o.name))
            owners.add(o.name);
        });
        if (!skip && owners.size <= 1)
          rows.push({ c, owner: owners.values().next().value });
      }
      entry = { rows, views: new Map };
      sourceCache.set(path, entry);
    }
    let view = entry.views.get(witness);
    if (!view) {
      view = entry.rows.filter((r) => r.owner === undefined || r.owner === witness).map((r) => r.c);
      entry.views.set(witness, view);
    }
    return view;
  };
  const accept = (good, part, tree, from, scope, index) => {
    if (!building())
      return false;
    const a = linear(good.a, from), b = linear(good.b, from);
    if (!a || !b)
      return false;
    const cut = sub(a, b);
    if (!plain2(cut))
      return false;
    if (truth(good, lemmaPath(saved.map((s) => s.lemma), scope)) === true)
      return true;
    const lemma = lemmaRecorder.invoke("admitConditionalCut", admitConditionalCut, [g, part, tree, from, scope, cut, saved.map((s) => s.lemma), wallEnd()]);
    if (!lemma || !building())
      return false;
    lemmaRecorder.admitted({ good, part, tree, from, scope, lemma, g, cert });
    saved.push({ lemma, good, ...index === undefined ? {} : { index } });
    trace.push({ stage: "closure-cut", index, when: lemma.when, cut: lemma.cut });
    return true;
  };
  const pin = (atom) => {
    if (decide5(atom, base) === true)
      return true;
    if (!plain2(atom) || !building())
      return false;
    const __lemma = lemmaRecorder.attempt("closure-pin", lemmaRecorder.conditions(atom));
    try {
      const noPath = put3(base, atom, false), part = { name: g.name, hyps: raw }, tree = fast(part, noPath), no = tree && transport(part, g, tree, noPath, noPath);
      lemmaRecorder.mark(__lemma, { source: part, sourceTree: tree, sourcePath: noPath, target: g, tree: no, targetPath: noPath });
      if (!no)
        return false;
      pins.push({ split: atom, no });
      base = put3(base, atom, true);
      return true;
    } finally {
      lemmaRecorder.end(__lemma);
    }
  };
  for (const guarded of fieldBounds(m, ds, cert, { claim: options.claim, path: base })) {
    if (!building())
      break;
    if (guarded.op !== "<=")
      continue;
    const condition = guarded.a.op === "if" ? guarded.a.c : undefined;
    if (condition && truth(condition, base) === false)
      continue;
    const conditions = condition ? facts(condition, base) : [];
    conditions.forEach(pin);
    let scope = new Map(base);
    for (const atom of conditions)
      scope = put3(scope, atom, true);
    if (condition && truth(condition, scope) !== true)
      continue;
    const good = { op: "<=", a: guarded.a.op === "if" ? guarded.a.then : guarded.a, b: guarded.b }, a = linear(good.a, scope), b = linear(good.b, scope);
    if (!a || !b || !plain2(sub(a, b)) || truth(good, lemmaPath(saved.map((s) => s.lemma), scope)) === true)
      continue;
    const __lemma = lemmaRecorder.attempt("closure-scalar", good);
    try {
      const before = clock(), traceStart = trace.length, noPath = put3(scope, sub(a, b), false), small = { name: g.name, hyps: source(scope) }, direct = fast(small, noPath);
      let accepted = !!direct && accept(good, small, direct, noPath, scope);
      if (!accepted && options.fieldSource && building()) {
        const claim = { op: "not", x: good }, prior = preStateCountSource(g, cert, claim, scope), path = lemmaPath(saved.map((s) => s.lemma), scope);
        const tree = options.fieldSource(prior.goal, prior.cert, claim, path, Math.min(buildEnd, clock() + 250));
        if (tree)
          accepted = accept(good, prior.goal, tree, path, scope);
      }
      trace.push({ stage: "closure-scalar", plain: good, checked: accepted, ms: clock() - before, ...!accepted ? { sourceTail: trace.slice(traceStart).slice(-8) } : {} });
    } finally {
      lemmaRecorder.end(__lemma);
    }
  }
  const pairMap = new Map((options.pairs ?? []).map((pair) => [JSON.stringify(pair), pair]));
  for (const read of cert.reads)
    if (wanted.has(read[0]) && read[1].endsWith("#"))
      for (const pair of rowPairs(m, { reads: [read] }, base, options.claim))
        pairMap.set(JSON.stringify(pair), pair);
  const pairs = [...pairMap.values()].slice(0, 2), scopes = [], scopeByKey = new Map;
  const addScope = (path) => {
    const key = JSON.stringify([...path].map(([id, a]) => [id, a.holds])), old = scopeByKey.get(key);
    if (old)
      return old;
    scopeByKey.set(key, path);
    scopes.push(path);
    return path;
  };
  const rowChoices = (path, pair) => {
    const c = { op: "=", a: pair[0], b: pair[1] };
    if (truth(c, path) !== undefined)
      return [path];
    const a = linear(pair[0], path), b = linear(pair[1], path);
    if (!a || !b)
      return [path];
    const f = sub(a, b), back = scale(f, -1);
    return [put3(put3(path, f, true), back, true), put3(put3(path, f, true), back, false), put3(path, f, false)];
  };
  addScope(base);
  for (const pair of pairs)
    for (const scope of rowChoices(base, pair))
      addScope(scope);
  let complete = [base];
  for (const pair of pairs)
    complete = complete.flatMap((path) => rowChoices(path, pair));
  for (const scope of complete)
    addScope(scope);
  const rowScopes = [...scopes];
  const postReads = new Set(cert.reads.filter((r) => r[1].endsWith("#")).map((r) => r[0]));
  const conditional = (index) => cert.insts[index].terms.some(([, id]) => postReads.has(id));
  const readMap = new Map(cert.reads.map(([id, map]) => [id, map]));
  const frame = (index) => {
    const q = cert.insts[index];
    if (q.terms.length !== 2)
      return false;
    const [a, b] = q.terms.map(([, id]) => readMap.get(id));
    return !!a && !!b && (a.endsWith("#") && a.slice(0, -1) === b || b.endsWith("#") && b.slice(0, -1) === a);
  };
  const vector = (q) => JSON.stringify([...q.terms].sort((a, b) => a[1].localeCompare(b[1]) || a[0] - b[0]));
  const memberHints = new Map(memberInclusions(m, ds, cert.reads).map((p) => [vector({ wit: "", unit: 0, below: p.below, terms: [[1, p.positive], [-1, p.negative]] }), p.guards]));
  const bridges = new Set(proposeWriteCountFrames(m, ds, { reads: cert.reads, insts: [] }, wanted).map(vector));
  const predicates = new Map;
  for (const read of cert.reads) {
    const plainRead = [read[0], read[1].endsWith("#") ? read[1].slice(0, -1) : read[1], read[2]], count = countsForReads(ds, [plainRead])?.[0];
    if (!count)
      continue;
    const body = substE(count.body, { vars: { [count.key]: x("closure$member") }, maps: {}, flags: {} });
    if (body.op !== "if" || body.then.op !== "const" || body.then.value !== 1 || body.else.op !== "const" || body.else.value !== 0)
      continue;
    const atoms = new Set, collect = (c) => {
      if (c.op === "and")
        c.xs.forEach(collect);
      else
        atoms.add(JSON.stringify(c));
    };
    collect(body.c);
    predicates.set(read[0], atoms);
  }
  const inclusion = (q) => {
    if (q.unit !== 0 || q.terms.length !== 2)
      return false;
    const a = q.terms.find(([z]) => z === 1)?.[1], b = q.terms.find(([z]) => z === -1)?.[1];
    if (!a || !b || postReads.has(a) !== postReads.has(b))
      return false;
    const left = predicates.get(a), right = predicates.get(b);
    return !!left && !!right && [...right].every((atom) => left.has(atom));
  };
  const rank = (index) => {
    const q = cert.insts[index], arity = q.terms.length;
    return q.unit !== 0 && arity === 1 ? -2 : inclusion(q) ? -1 : arity === 1 && wanted.has(q.terms[0][1]) ? 0 : !conditional(index) && arity === 3 ? 0 : bridges.has(vector(q)) ? 1 : !conditional(index) && arity === 5 ? 2 : frame(index) ? 3 : !conditional(index) ? 4 : arity === 3 ? 5 : arity === 2 ? 6 : 7;
  };
  const pool = cert.insts.flatMap((q, index) => q.terms.length <= 5 ? [index] : []).sort((a, b) => rank(a) - rank(b));
  const rowNames = new Set;
  for (const pair of pairs)
    walkLive(pair, base, (o) => {
      if (o.op === "var" && !m.inputs.includes(o.name))
        rowNames.add(o.name);
    });
  const sourceRows = new Map(pool.map((index) => {
    const names = new Set;
    for (const [, id] of cert.insts[index].terms) {
      const read = cert.reads.find((r) => r[0] === id);
      if (read)
        walkLive(read[2], base, (o) => {
          if (o.op === "var" && rowNames.has(o.name))
            names.add(o.name);
        });
    }
    return [index, names];
  }));
  const scalarAtoms = new Set, scopeCache = new Map;
  const scopesFor = (index) => {
    const old = scopeCache.get(index);
    if (old)
      return old;
    const rows = rowScopes.filter((scope) => [...scope].every(([id, atom]) => base.has(id) || Object.keys(atom.lin).every((name) => !rowNames.has(name) || sourceRows.get(index).has(name))));
    const bridge = bridges.has(vector(cert.insts[index])), guarded = [], equalRows = rows.filter((scope) => scope !== base && scope.size <= base.size + 2 && pairs.some(([a, b]) => truth({ op: "=", a, b }, scope) === true));
    const distinctRows = bridge ? rows.filter((scope) => {
      const states = pairs.map(([a, b]) => truth({ op: "=", a, b }, scope));
      return states.includes(true) && states.includes(false);
    }) : [];
    const origins = conditional(index) ? [...distinctRows, ...equalRows, base] : [base];
    const preferred = memberHints.get(vector(cert.insts[index]));
    const proposed = [...preferred ? [preferred] : [], ...countScalarGuards(m, ds, cert.reads, cert.insts[index], base, { name: g.name, hyps: source(base, cert.insts[index].wit) })].slice(0, 8), equal = proposed.filter((guards) => guards.every((c) => c.op === "="));
    const choices = bridge && equal.length ? equal.sort((a, b) => b.length - a.length) : proposed;
    for (const guards of choices)
      for (const origin of origins) {
        let scope = new Map(origin), valid = true;
        const aliases = {};
        for (const [a, b] of pairs)
          if (a.op === "var" && truth({ op: "=", a, b }, origin) === true)
            aliases[a.name] = b;
        for (const original of guards) {
          const condition = substC(original, { vars: aliases, maps: {}, flags: {} });
          if (truth(condition, scope) === false) {
            valid = false;
            break;
          }
          for (const atom of facts(condition, scope)) {
            if (!plain2(atom)) {
              valid = false;
              break;
            }
            scalarAtoms.add(canon(atom));
            scalarAtoms.add(canonFlip(atom));
            scope = put3(scope, atom, true);
          }
          if (!valid)
            break;
        }
        if (valid)
          guarded.push(addScope(scope));
      }
    const unique = new Set, out = (bridge ? [base, ...rows, ...guarded] : [base, ...guarded, ...rows]).filter((scope) => {
      const key = JSON.stringify([...scope].map(([id, a]) => [id, a.holds]));
      if (unique.has(key))
        return false;
      unique.add(key);
      return true;
    });
    scopeCache.set(index, out);
    return out;
  };
  let rounds = 0, fixedPoint = false;
  for (const index of pool)
    scopesFor(index);
  const excludedAt = new Map, attempted = new Map;
  const validPoint = (part, path, point) => {
    const model = { ...point };
    walkLive(part.hyps, path, (o) => {
      if (o.op === "var" && !Object.hasOwn(model, o.name))
        model[o.name] = 0;
    });
    for (const atom of path.values())
      for (const name of Object.keys(atom.lin))
        if (name !== "1" && !Object.hasOwn(model, name))
          model[name] = 0;
    if (!Object.values(model).every(Number.isSafeInteger) || brokenOf(part)(model).length)
      return;
    return [...path.values()].every((a) => {
      const n = Object.entries(a.lin).reduce((s, [k, z]) => s + z * (k === "1" ? 1 : model[k]), 0);
      return Number.isFinite(n) && (a.holds ? n <= 0 : n > 0);
    }) ? model : undefined;
  };
  const attempt = (index, scope, end) => {
    if (!building())
      return "unknown";
    scope = addScope(scope);
    const version = saved.length, key = `${scopes.indexOf(scope)}:${index}`, had = attempted.get(key);
    if (had?.version === version)
      return had.outcome;
    const inst = cert.insts[index], h = g.hyps[raw.length + index];
    if (h?.op !== "or" || h.xs[0]?.op !== "<=")
      return "unknown";
    const good = { op: "<=", a: h.xs[0].a, b: h.xs[0].b }, available = active(saved, scope), path = scope, before = clock();
    const __lemma = lemmaRecorder.attempt("closure-count", good);
    try {
      const part = { name: g.name, hyps: [...source(path, inst.wit), ...available.map((s) => s.good), h, { op: "not", x: good }] };
      const reused = models.some((m) => validPoint({ ...part, hyps: part.hyps.map((c) => substC(c, { vars: { [inst.wit]: x(m.witness) }, maps: {}, flags: {} })) }, path, m.model) !== undefined);
      if (reused) {
        attempted.set(key, { version, outcome: "sat" });
        trace.push({ stage: "closure-source", scope: scopes.indexOf(scope), index, outcome: "reused-model", ms: clock() - before });
        return "sat";
      }
      const queryLimit = Math.min(end, clock() + (inst.terms.length === 5 ? 150 : 50)), q = lemmaRecorder.invoke("query", modelSequence(path), [part, queryLimit]);
      let tree = "tree" in q ? q.tree : undefined, proofSource = part, validModel = false;
      if (!tree && !("tree" in q) && q.stuck === "sat" && q.witness) {
        const model = validPoint(part, path, q.witness);
        if (model) {
          validModel = true;
          models.push({ witness: inst.wit, model });
          if (models.length > 32)
            models.shift();
        }
      } else if (!tree && !("tree" in q) && q.why === REFUTED && q.core?.length && q.core.length <= 8 && building()) {
        const limit = Math.min(end, Math.max(queryLimit, clock() + 100)), small = { ...part, hyps: q.core.map((i) => part.hyps[i]) }, oldPoint = atPoint.on;
        atPoint.on = false;
        try {
          let local = lemmaRecorder.invoke("booleanCore", booleanCore, [small, path, new Set([inst.wit]), limit, trace, { deferCheck: true, extended: true, scalarGuards: true, model: true }]);
          if (!local && clock() < limit) {
            const folded = foldPath(small, path), out = lemmaRecorder.invoke("grow", grow, [folded.goal, path, { nodes: 0, until: Math.min(limit, clock() + 25), units: false }]);
            local = "tree" in out ? withDeadline(limit, () => lemmaRecorder.invoke("widen", widen, [folded.goal, small, out.tree, folded.opaque, path, path])) : undefined;
          }
          if (local) {
            tree = local;
            proofSource = small;
          }
        } finally {
          atPoint.on = oldPoint;
        }
      }
      const accepted = !!tree && accept(good, proofSource, tree, path, scope, index), outcome = accepted ? "checked" : validModel ? "sat" : "unknown";
      attempted.set(key, { version, outcome });
      if (!accepted)
        lemmaRecorder.mark(__lemma, { source: proofSource, sourceTree: tree, sourcePath: path, target: g });
      trace.push({ stage: "closure-source", scope: scopes.indexOf(scope), index, core: "tree" in q ? undefined : q.core?.length, tree: !!tree, outcome, ms: clock() - before });
      return outcome;
    } finally {
      lemmaRecorder.end(__lemma);
    }
  };
  const pure = (c, path) => {
    let other = false;
    walkLive(c, path, (o) => {
      if (o.op === "get" || o.op === "var" && wits.has(o.name))
        other = true;
    });
    return !other;
  };
  const replacements = Object.fromEntries([...maps].map((map) => [map, (key) => {
    const r = cert.reads.find((r) => r[1] === map && JSON.stringify(r[2]) === JSON.stringify(key));
    return r ? x(r[0]) : { op: "get", map, key };
  }]));
  const flags = Object.fromEntries(Object.keys(m.step.flags ?? {}).map((name) => [name, { op: "flag", name }]));
  const abstracted = raw.map((c) => substC(c, { vars: {}, maps: replacements, flags }));
  const finish = (scope, end, depth = 0) => {
    if (!alive())
      return;
    scope = addScope(scope);
    const before = clock(), scopeKey = JSON.stringify([...scope].map(([id, a]) => [id, a.holds])), excluded = excludedAt.get(scopeKey) ?? new Set, previousEnd = leafEnd;
    excludedAt.set(scopeKey, excluded);
    leafEnd = end;
    const numericFor = () => ({ name: g.name, hyps: [...abstracted.flatMap((c) => piecesAt(c, scope)).filter((c) => pure(c, scope)), ...countBindingsAt(cert.reads, scope), ...active(saved, scope).map((s) => s.good).filter((c) => pure(c, scope))] });
    const stop = (reason) => {
      trace.push({ stage: "closure-final", mode: "model-driven", outcome: "unknown", reason, path: [...scope], cuts: active(saved, scope).length, ms: clock() - before, total: clock() - started });
      return;
    };
    const merge = (candidate) => {
      const path = new Map(scope);
      for (const a of candidate.values()) {
        const known = decide5(a.lin, path);
        if (known !== undefined && known !== a.holds)
          return;
        path.set(canon(a.lin), a);
      }
      return addScope(path);
    };
    try {
      for (let round = 0;round <= pool.length && building(); round++) {
        rounds++;
        const available = active(saved, scope), numeric = numericFor(), natural = lemmaRecorder.invoke("proveNaturalCases", proveNaturalCases, [numeric, scope, end, trace, { deferCheck: true }]), q = natural ? { tree: natural } : lemmaRecorder.invoke("query", modelSequence(scope), [numeric, end]);
        let proof = "tree" in q ? q.tree : undefined;
        if (!proof && !("tree" in q) && q.why === REFUTED && q.core) {
          const small = { ...numeric, hyps: q.core.map((i) => numeric.hyps[i]) }, direct = fast(small, scope), out = direct ? undefined : lemmaRecorder.invoke("grow", grow, [small, scope, { nodes: 0, until: end, units: false }]), local = direct ?? (out && "tree" in out ? out.tree : undefined);
          if (local)
            proof = transport(small, numeric, local, scope, scope);
        }
        if (proof) {
          const extended = lemmaPath(available.map((s) => s.lemma), scope), lifted = lemmaRecorder.invoke("liftCountProxies", liftCountProxies, [numeric, g, proof, cert.reads, scope, extended, (e) => trace.push({ stage: "closure-transport", ...e }), { deferCheck: true }]);
          const tree = lifted && (options.conditional ? markConditionalProof(g, lifted, available.map((s) => s.lemma)) : lemmaRecorder.invoke("inlineConditionalCuts", inlineConditionalCuts, [g, g, lifted, extended, scope, available.map((s) => s.lemma), wallEnd(), (e) => trace.push({ stage: "closure-inline", ...e })]));
          trace.push({ stage: "closure-final", mode: "model-driven", fixedPoint, hyps: numeric.hyps.length, cuts: available.length, rounds: round + 1, closedIndices: available.flatMap((s) => s.index === undefined ? [] : [s.index]), outcome: tree ? "checked" : "untransported", ms: clock() - before, total: clock() - started });
          return tree;
        }
        if ("tree" in q || q.stuck !== "sat" || !q.witness)
          return stop("no-numeric-model");
        const point = { ...q.witness };
        for (const index of pool) {
          const h = g.hyps[raw.length + index];
          if (h?.op === "or" && h.xs[0]?.op === "<=")
            walkLive(h.xs[0], scope, (o) => {
              if (o.op === "var" && !Object.hasOwn(point, o.name))
                point[o.name] = 0;
            });
        }
        const model = validPoint(numeric, scope, point);
        if (!model)
          return stop("invalid-numeric-model");
        const violated = pool.filter((index) => {
          const h = g.hyps[raw.length + index];
          return h?.op === "or" && h.xs[0]?.op === "<=" && brokenOf({ name: "candidate", hyps: [h.xs[0]] })(model).length > 0;
        }), pending = new Set(violated.filter((i) => !excluded.has(i))), startedVersion = saved.length;
        trace.push({ stage: "closure-model-round", round: round + 1, scope: scopes.indexOf(scope), violated, pending: [...pending], excluded: [...excluded], cuts: available.length, pool: pool.length });
        if (!pending.size) {
          fixedPoint = true;
          return stop("no-unexcluded-violated-fact");
        }
        while (pending.size && building()) {
          const indices = [...pending], baseGoal = numericFor(), goods = indices.map((i) => g.hyps[raw.length + i].xs[0]), assumed = { ...baseGoal, hyps: [...baseGoal.hyps, ...goods] }, selection = lemmaRecorder.invoke("query", modelSequence(scope), [assumed, end]);
          const core = "tree" in selection ? [...usedHyps(assumed, selection.tree, scope)] : selection.why === REFUTED ? selection.core : undefined;
          const validAssumedModel = !("tree" in selection) && selection.stuck === "sat" && selection.witness && validPoint(assumed, scope, selection.witness);
          if (!core?.length && !validAssumedModel)
            return stop("no-batch-core-or-model");
          const chosen = core?.length ? core.filter((i) => i >= baseGoal.hyps.length).map((i) => indices[i - baseGoal.hyps.length]).filter((i) => i !== undefined) : indices;
          trace.push({ stage: "closure-batch-core", scope: scopes.indexOf(scope), round: round + 1, indices: chosen, core: core?.length, selector: core?.length ? "refuted" : "sat" });
          if (!chosen.length) {
            if (saved.length > startedVersion)
              break;
            return stop("empty-batch-core");
          }
          let changed = false;
          for (const index of chosen) {
            if (!building())
              break;
            pending.delete(index);
            const candidates = scopesFor(index).map(merge).filter((p) => p !== undefined), hinted = memberHints.has(vector(cert.insts[index])), order = hinted ? [...candidates.filter((p) => p !== scope), scope] : [scope, ...candidates], seen = new Set;
            let allSat = true, proved = false;
            for (const path of order) {
              if (seen.has(path))
                continue;
              seen.add(path);
              if (!building()) {
                allSat = false;
                break;
              }
              const result = attempt(index, path, end);
              if (result === "checked") {
                changed = true;
                proved = true;
                break;
              }
              if (result !== "sat")
                allSat = false;
            }
            if (allSat && !proved)
              excluded.add(index);
          }
          const guard = saved.slice(startedVersion).flatMap((s) => s.lemma.when).find((atom) => scalarAtoms.has(canon(atom)) && decide5(atom, scope) === undefined);
          if (guard) {
            if (depth >= 8)
              return stop("scalar-depth");
            const yes = scalar(put3(scope, guard, true), end, depth + 1), no = yes && scalar(put3(scope, guard, false), end, depth + 1);
            trace.push({ stage: "closure-model-split", depth, split: guard, proposed: !!yes && !!no, ms: clock() - before });
            return yes && no ? { split: guard, yes, no } : undefined;
          }
          if (changed)
            break;
        }
        if (saved.length === startedVersion)
          return stop(building() ? "batch-exhausted" : "time");
      }
      return stop("time");
    } finally {
      leafEnd = previousEnd;
    }
  };
  const scalar = (path, end, depth = 0) => {
    if (!alive())
      return;
    const candidates = new Map;
    for (const { lemma } of saved) {
      if (lemma.when.some((atom) => decide5(atom, path) === false))
        continue;
      for (const atom of lemma.when) {
        const id = canon(atom);
        if (!scalarAtoms.has(id) || decide5(atom, path) !== undefined)
          continue;
        const old = candidates.get(id);
        candidates.set(id, { atom, uses: (old?.uses ?? 0) + 1 });
      }
    }
    const next = [...candidates.values()].sort((a, b) => b.uses - a.uses)[0];
    if (!next || depth >= 8)
      return finish(path, end, depth);
    const yes = scalar(put3(path, next.atom, true), end, depth + 1), no = yes && scalar(put3(path, next.atom, false), end, depth + 1);
    trace.push({ stage: "closure-scalar-case", depth, split: next.atom, proposed: !!yes && !!no });
    return yes && no ? { split: next.atom, yes, no } : undefined;
  };
  let leavesLeft = Math.max(1, complete.length);
  const atLeaf = (path, end) => {
    const before = clock(), remaining = Math.max(0, until - before), draw = leafAllowance(remaining, leavesLeft), stop = Math.min(end, before + draw);
    trace.push({ stage: "closure-leaf-budget", remaining, leavesLeft, draw, granted: Math.max(0, stop - before), end: stop });
    return scalar(path, stop);
  };
  const rowTrace = (event) => {
    const e = event;
    if (e.stage === "row-case" || e.stage === "row-mirror")
      leavesLeft = Math.max(1, leavesLeft - 1);
    trace.push(event);
  };
  let tree = pairs.length ? proveRowCases(g, base, pairs, until, atLeaf, rowTrace, { deferToCaller: true, splitEqual: true }) : atLeaf(base, until);
  for (let i = pins.length - 1;tree && i >= 0; i--)
    tree = { split: pins[i].split, yes: tree, no: pins[i].no };
  const checked = !!tree && alive() && (options.conditional ? lemmaRecorder.invoke("checkConditionalProof", checkConditionalProof, [g, tree, root]) : lemmaRecorder.invoke("check", check, [g, tree, root]));
  trace.push({ stage: "closure-complete", cuts: saved.length, rounds, fixedPoint, checked, total: clock() - started });
  return checked ? tree : undefined;
}

// core/count-recovery/carried-case.ts
function carriedCase(g, root, maps, wits, until, trace) {
  let cell;
  walkLive(g.hyps, root, (o) => {
    if (!cell && o.op === "get" && maps.includes(o.map) && o.key.op === "var" && wits.has(o.key.name) && truth({ op: "<=", a: n(1), b: o }, root) === undefined)
      cell = o;
  });
  if (!cell)
    return;
  const value = linear(cell, root);
  if (!value)
    return;
  const split = sub({ "1": 1 }, value), id = canon(split), started = clock();
  const noPath = new Map(root).set(id, { lin: split, holds: false }), no = grow(g, noPath, { nodes: 0, until, units: true });
  const yesPath = new Map(root).set(id, { lin: split, holds: true }), yes = "tree" in no && clock() < until ? grow(g, yesPath, { nodes: 0, until, units: true }) : undefined;
  const tree = "tree" in no && yes && "tree" in yes ? { split, yes: yes.tree, no: no.tree } : undefined, checked = !!tree && check(g, tree, root);
  trace.push({ stage: "carried-core", cell, ms: Math.round(clock() - started), no: "tree" in no, yes: !!yes && "tree" in yes, checked });
  return checked ? tree : undefined;
}

// core/count-recovery/field-only.ts
function fieldOnlyGoal(g, m, cert, claim, path = new Map) {
  const counted = new Set(cert.reads.map((r) => r[0])), maps = new Set(cert.reads.map((r) => r[1])), wits = new Set(cert.insts.map((i) => i.wit));
  const hasCount = (c) => {
    let hit = false;
    walkLive(c, path, (o) => {
      if (o.op === "get" && (maps.has(o.map) || m.counts?.[o.map.replace(/#$/, "")]) || o.op === "var" && (counted.has(o.name) || wits.has(o.name)))
        hit = true;
    });
    return hit;
  };
  const end = g.hyps.length - cert.insts.length, original = g.hyps.slice(0, end);
  const conclusion = claim ?? original.at(-1), index = original.findIndex((c) => c === conclusion);
  if (!conclusion || index < 0 || hasCount(conclusion))
    return;
  const weaker = (c) => {
    if (c.op === "and") {
      const xs = c.xs.flatMap((child) => {
        const next = weaker(child);
        return next ? [next] : [];
      });
      return xs.length ? { op: "and", xs } : undefined;
    }
    return hasCount(c) ? undefined : c;
  };
  return { ...g, hyps: original.filter((_, i) => i !== index).flatMap((c) => {
    const next = weaker(c);
    return next ? [next] : [];
  }).concat(conclusion) };
}

// core/count-recovery/field-case.ts
function fieldDirection(claim, path) {
  let direction;
  walkChoices(claim, path, (read) => {
    if (read.op !== "get")
      return;
    walkOnce(read.key, (o) => {
      if (direction || o.op !== "sub" || o.a.op !== "var" || o.b.op !== "var" || truth({ op: "<=", a: o.a, b: o.b }, path) !== undefined)
        return;
      const a = linear(o.a, path), b = linear(o.b, path);
      if (a && b)
        direction = sub(a, b);
    });
  });
  return direction;
}
function fieldCase(m, g, cert, claim, path, until, trace, naturalDepth = 0, memo) {
  const cached = memo?.get(g, path, until);
  if (cached) {
    trace?.({ stage: "source-memo", scope: "field-case" });
    return cached;
  }
  const tree = fieldCaseImpl(m, g, cert, claim, path, until, trace, naturalDepth, memo);
  if (tree)
    memo?.put(g, path, tree);
  return tree;
}
function fieldCaseImpl(m, g, cert, claim, path, until, trace, naturalDepth, memo) {
  const field = fieldOnlyGoal(g, m, cert, claim, path);
  if (!field || clock() >= until)
    return;
  const began = clock();
  const direct = refuteFast(rowsAt(field, path), 256);
  if (direct?.kind === "refuted") {
    const tree = withDeadline(until, () => widen(field, g, { leaf: direct.steps }, {}, path, path));
    trace?.({ stage: "field-case", hyps: field.hyps.length, ms: Math.round(clock() - began), proposed: !!tree, outcome: "linear" });
    return tree;
  }
  const folded = foldPath(field, path), query = modelSequence(path)(folded.goal, until);
  if (!("tree" in query) && query.stuck === "sat") {
    trace?.({ stage: "field-case", hyps: field.hyps.length, ms: Math.round(clock() - began), proposed: false, outcome: query.stuck, model: query.witness });
    return;
  }
  const reduced = !("tree" in query) && query.why === REFUTED && query.core?.length ? { ...folded.goal, hyps: query.core.map((i) => folded.goal.hyps[i]) } : folded.goal;
  const direction = naturalDepth < 2 && !("tree" in query) && query.why === REFUTED ? fieldDirection({ op: "and", xs: reduced.hyps }, path) : undefined;
  if (direction) {
    const id = canon(direction), yes = fieldCase(m, g, cert, claim, new Map(path).set(id, { lin: direction, holds: true }), until, trace, naturalDepth + 1, memo);
    const no = yes && fieldCase(m, g, cert, claim, new Map(path).set(id, { lin: direction, holds: false }), until, trace, naturalDepth + 1, memo);
    const tree = yes && no ? { split: direction, yes, no } : undefined;
    trace?.({ stage: "field-natural-direction", ms: Math.round(clock() - began), proposed: !!tree });
    return tree;
  }
  const keys = new Set;
  let packed = false;
  if (!("tree" in query) && query.why === REFUTED && query.core?.length && query.core.length <= 8)
    walkOnce(reduced.hyps, (o) => {
      if (o.op !== "get" || ["var", "const"].includes(o.key.op))
        return;
      packed = true;
      walkOnce(o.key, (k) => {
        if (k.op === "var" && !m.inputs.includes(k.name) && !m.params.includes(k.name) && !(k.name in m.state))
          keys.add(k.name);
      });
    });
  const events = [], point = packed ? booleanCore(reduced, path, keys, until, events, { extended: true, scalarGuards: true, deferCheck: true }) : undefined;
  for (const event of events)
    trace?.(event);
  const out = point ? { tree: point } : ("tree" in query) ? query : grow(reduced, path, { nodes: 0, until, units: true });
  const expanded = "tree" in out ? withDeadline(until, () => widen(reduced, folded.goal, out.tree, {}, path, path)) : undefined;
  const lifted = expanded && withDeadline(until, () => widen(folded.goal, field, expanded, folded.opaque, path, path));
  const tree = lifted && withDeadline(until, () => widen(field, g, lifted, {}, path, path));
  trace?.({ stage: "field-case", hyps: field.hyps.length, core: query.core?.length, ms: Math.round(clock() - began), proposed: !!tree, outcome: "tree" in query ? "tree" : query.stuck, ...!("tree" in query) && query.stuck === "sat" ? { model: query.witness } : {} });
  return tree;
}

// core/count-recovery/field-bound-lemmas.ts
function countBindingsAt(reads, root) {
  const columns = new Set([...root.values()].flatMap((p) => Object.keys(p.lin)));
  for (const name of columns) {
    const e = columnTerm(name);
    if (e)
      walkOnce(e, (o) => {
        if (o.op === "var")
          columns.add(o.name);
        if (o.op === "get")
          for (const key of Object.keys(linear(o, root) ?? {}))
            columns.add(key);
      });
  }
  return reads.flatMap(([id, map, key]) => {
    const cell = { op: "get", map, key }, lin = linear(cell, root);
    return lin && Object.keys(lin).some((k) => columns.has(k)) ? [same(x(id), cell)] : [];
  });
}
function fieldBounds(m, ds, cert, options = {}) {
  const key = x("$member"), bounds = [];
  for (const [name, q] of Object.entries(m.step.flags ?? {}))
    if (q.op === "all")
      walkOnce(substC(q.c, { vars: { [q.key]: key }, maps: {}, flags: {} }), (c) => {
        const next = c.op === "<" && c.b?.op === "add" && c.b.b.op === "const" && c.b.b.value === 1 ? c.b.a : undefined;
        const pairs = c.op === "=" ? [[c.a, c.b], [c.b, c.a]] : c.op === "<=" ? [[c.a, c.b]] : next ? [[c.a, next]] : [];
        for (const [left, right] of pairs)
          if (right && left?.op === "get" && JSON.stringify(left).includes('"name":"$member"') && !JSON.stringify(right).includes('"name":"$member"'))
            bounds.push({ a: left, b: right, guard: { op: "=", a: x(`?${name}`), b: { op: "const", value: 1 } } });
      });
  const out = [], seen = new Set, pre = new Set(cert.reads.filter((r) => !r[1].endsWith("#")).map((r) => r[0]));
  for (const c of countsForReads(ds, cert.reads) ?? [])
    if (pre.has(c.v))
      walkOnce(substE(c.body, { vars: { [c.key]: key }, maps: {}, flags: {} }), (p) => {
        if (p.op !== "<" || p.a?.op !== "get" || JSON.stringify(p.b).includes('"name":"$member"'))
          return;
        for (const b of bounds)
          if (JSON.stringify(b.a) === JSON.stringify(p.a)) {
            const guard = p.b.op === "get" ? { op: "and", xs: [b.guard, { op: "<", a: p.b.key, b: c.below }] } : b.guard;
            const candidate = { op: "<=", a: { op: "if", c: guard, then: p.b, else: { op: "const", value: 0 } }, b: b.b }, id = JSON.stringify(candidate);
            if (!seen.has(id)) {
              seen.add(id);
              out.push(candidate);
            }
          }
      });
  const explicit = new Set;
  if (options.claim)
    walkLive(options.claim, options.path ?? new Map, (o) => {
      if (o.op === "get")
        explicit.add(JSON.stringify(o));
    });
  const targets = new Set(explicit), twins = cert.reads.filter((r) => r[1].endsWith("#")).map(([v, map, key]) => [v, map.slice(0, -1), key]);
  for (const c of countsForReads(ds, twins) ?? [])
    walkOnce(substE(c.body, { vars: { [c.key]: key }, maps: {}, flags: {} }), (p) => {
      if (p.op === "<" && bounds.some((b) => JSON.stringify(b.a) === JSON.stringify(p.a)))
        targets.add(JSON.stringify(p.b));
    });
  walkOnce(m.step.maps, (o) => {
    if (o.op === "get" && o.key.op === "var" && m.inputs.includes(o.key.name))
      targets.add(JSON.stringify(o));
  });
  const focused = out.filter((c) => c.op === "<=" && c.a.op === "if" && targets.has(JSON.stringify(c.a.then)));
  return (focused.length ? focused : out).sort((a, b) => Number(b.op === "<=" && b.a.op === "if" && explicit.has(JSON.stringify(b.a.then))) - Number(a.op === "<=" && a.a.op === "if" && explicit.has(JSON.stringify(a.a.then)))).slice(0, 4);
}
function emptyCountCandidate(m, cert, inst) {
  if (inst.unit !== 0 || inst.terms.length !== 1 || inst.terms[0][0] !== 1)
    return false;
  const read = cert.reads.find((r) => r[0] === inst.terms[0][1]);
  if (!read?.[1].endsWith("#"))
    return false;
  const count = m.counts?.[read[1].slice(0, -1)];
  if (!count)
    return false;
  let fields = false;
  walkOnce(count.body, (o) => {
    if (o.op === "<" && o.a.op === "get" && o.b.op === "get")
      fields = true;
  });
  return fields;
}
var fieldBoundLemmas = (...args) => lemmaRecorder.helper("field", args, () => wallTree("proposal-control", () => {
  const [, , g, , until, trace, , path = new Map, options = {}] = args;
  if (clock() >= until || pastWall()) {
    trace.push({ stage: "source-budget-exhausted" });
    return;
  }
  const cached = options.memo?.get(g, path, until);
  if (cached && (options.deferCheck || lemmaRecorder.invoke("check", check, [g, cached, path]))) {
    trace.push({ stage: "source-memo", scope: "field" });
    return cached;
  }
  const tree = fieldBoundLemmasImpl(...args);
  if (tree && !hasConditionalProof(tree))
    options.memo?.put(g, path, tree);
  return tree;
}));
function fieldBoundLemmasImpl(m, ds, g, cert, until, trace, onModel, root = new Map, options = {}) {
  const pointOptions = { deferCheck: !!options.deferCheck };
  const seq = modelSequence(root), ctx = [], path = new Map(root), lemmas = [];
  const accept = (tree, path) => tree && (options.deferCheck || lemmaRecorder.invoke("check", check, [g, tree, path])) ? tree : undefined;
  const verdict = (tree) => ({ checked: !options.deferCheck && !!tree, ...options.deferCheck ? { proposed: !!tree, deferred: true } : {} });
  const rowPlan = options.splitRows !== false ? rowPairs(m, cert, root, options.fieldClaim).slice(0, 2) : [];
  let arithmetic;
  const postMaps = new Set(cert.reads.filter((r) => r[1].endsWith("#")).map((r) => r[1])), postIds = new Set(cert.reads.filter((r) => r[1].endsWith("#")).map((r) => r[0]));
  if (options.closure !== false) {
    const closed = deriveCountClosure(m, ds, g, cert, root, until, trace, { claim: options.fieldClaim, pairs: rowPlan, conditional: options.conditional, fieldSource: (source, proposal, claim, path, end) => fieldBoundLemmas(m, ds, source, proposal, end, trace, onModel, path, { ...options, closure: false, splitRows: false, deferCheck: true, fieldClaim: claim }) });
    if (closed)
      return closed;
  }
  if (rowPlan.length && !postIds.size && options.fieldClaim) {
    const rows = new Set(rowPlan.flatMap(([key]) => key.op === "var" ? [key.name] : [])), columns = new Set;
    walkOnce(options.fieldClaim, (o) => {
      if (o.op === "get" && o.key.op !== "var")
        walkOnce(o.key, (k) => {
          if (k.op === "var" && !rows.has(k.name) && !m.inputs.includes(k.name) && !m.params.includes(k.name))
            columns.add(k.name);
        });
    });
    const candidates = [];
    walkOnce(options.fieldClaim, (c) => {
      if (!candidates.length && c.op === "<" && c.a.op === "var" && columns.has(c.a.name) && truth(c, root) === undefined)
        candidates.push(c);
    });
    let domain = candidates[0];
    if (domain && domain.a.op === "var") {
      const column = domain.a.name, strides = [];
      walkOnce(options.fieldClaim, (o) => {
        if (o.op !== "get")
          return;
        const key = linear(o.key, root);
        if (!key || key[column] !== 1)
          return;
        for (const row of rows) {
          const width = Math.abs(key[row] ?? 0);
          if (Number.isInteger(width) && width > 1)
            strides.push(width);
        }
      });
      if (strides.length)
        domain = { op: "<", a: domain.a, b: n(Math.min(...strides)) };
    }
    if (domain && truth(domain, root) === undefined) {
      const a = linear(domain.a, root), b = linear(domain.b, root);
      if (a && b) {
        const split = sub(a, b);
        split["1"] = (split["1"] ?? 0) + 1;
        const id = canon(split), negative = new Map(root).set(id, { lin: split, holds: false }), positive = new Map(root).set(id, { lin: split, holds: true });
        const no = lemmaRecorder.probe("field-column-domain", domain, g, negative, () => lemmaRecorder.invoke("fieldCase", fieldCase, [m, g, cert, options.fieldClaim, negative, Math.min(until, clock() + 50), (e) => trace.push(e), 0, options.memo]));
        if (no) {
          const yes = fieldBoundLemmas(m, ds, g, cert, until, trace, onModel, positive, options), tree = yes ? { split, yes, no } : undefined;
          trace.push({ stage: "field-column-domain", domain, proposed: !!tree });
          return tree && (options.deferCheck || lemmaRecorder.invoke("check", check, [g, tree, root])) ? tree : undefined;
        }
      }
    }
  }
  if (rowPlan.length && !postIds.size) {
    trace.push({ stage: "field-row-pairs", pairs: rowPlan });
    return proveRowCases(g, root, rowPlan, until, (branch, end) => {
      const cached = options.memo?.get(g, branch, end);
      if (cached) {
        trace.push({ stage: "source-memo", scope: "field-row" });
        return cached;
      }
      const tree = lemmaRecorder.invoke("fieldCase", fieldCase, [m, g, cert, options.fieldClaim, branch, end, (e) => trace.push(e), 0, options.memo]) ?? fieldBoundLemmas(m, ds, g, cert, end, trace, onModel, branch, { ...options, splitRows: false, deferCheck: true });
      if (tree)
        options.memo?.put(g, branch, tree);
      return tree;
    }, (e) => trace.push(e), { deferToCaller: !!options.deferCheck, splitEqual: copiesRows(m, root) });
  }
  const base = g.hyps.slice(0, g.hyps.length - cert.insts.length).flatMap((c) => piecesAt(c, root)).filter((c) => {
    let post = false;
    walkLive(c, root, (o) => {
      if (o.op === "get" && postMaps.has(o.map) || o.op === "var" && postIds.has(o.name))
        post = true;
    });
    return !post;
  });
  const cs = new Map((countsForReads(ds, cert.reads) ?? []).map((c) => [c.v, { ...c, body: substE(c.body, { vars: { [c.key]: x("$member") }, maps: {}, flags: {} }) }]));
  const view = (e) => {
    if (e.op !== "if" || e.then.op !== "const" || e.then.value !== 1 || e.else.op !== "const" || e.else.value !== 0)
      return e;
    const c = e.c;
    if (c.op === "=" && c.a.op === "get" && c.b.op === "const" && c.b.value === 1)
      return c.a;
    if (c.op === "=" && c.b.op === "get" && c.a.op === "const" && c.a.value === 1)
      return c.b;
    if (c.op === "<=" && c.a.op === "const" && c.a.value === 1 && c.b.op === "get")
      return c.b;
    if (c.op === "<" && c.a.op === "const" && c.a.value === 0 && c.b.op === "get")
      return c.b;
    return e;
  };
  const signature = (e) => {
    const pred = e.op === "get" ? { op: "=", a: e, b: { op: "const", value: 1 } } : e.op === "if" && e.then.op === "const" && e.then.value === 1 && e.else.op === "const" && e.else.value === 0 ? e.c : undefined;
    const atoms = (c) => c.op === "and" ? c.xs.flatMap(atoms) : [JSON.stringify(c)];
    return pred ? JSON.stringify([...new Set(atoms(pred))].sort()) : undefined;
  };
  const narrow = (good) => {
    const keep = cert.insts.flatMap((inst, i) => {
      if (inst.unit !== 0 || inst.terms.length !== 2 || inst.terms.some((t) => postIds.has(t[1])))
        return [];
      const positive = inst.terms.find((t) => t[0] === 1), negative = inst.terms.find((t) => t[0] === -1), a = positive && cs.get(positive[1]), b = negative && cs.get(negative[1]);
      if (!a || !b)
        return [];
      const as = signature(a.body), bs = signature(b.body), same = as !== undefined && as === bs, input = view(a.body).op === "get" && (m.inputMaps ?? []).includes(view(a.body).map);
      let target = false;
      walkOnce(b.body, (o) => {
        if (o.op === "<" && JSON.stringify(o.b) === JSON.stringify(good.a.op === "if" ? good.a.then : good.a))
          target = true;
      });
      return same || input && target ? [i] : [];
    });
    const wanted = new Set(keep.map((i) => cert.insts[i].wit)), all = new Set(cert.insts.map((i) => i.wit));
    const weaken = (c) => {
      if (c.op === "and") {
        const xs = c.xs.flatMap((c) => {
          const n = weaken(c);
          return n ? [n] : [];
        });
        return xs.length ? { op: "and", xs } : undefined;
      }
      let other = false, own = false;
      walkLive(c, root, (o) => {
        if (o.op === "var" && all.has(o.name)) {
          if (wanted.has(o.name))
            own = true;
          else
            other = true;
        }
      });
      return other && !own ? undefined : c;
    };
    return [...base.flatMap((c) => {
      const n = weaken(c);
      return n ? [n] : [];
    }), ...keep.map((i) => g.hyps[g.hyps.length - cert.insts.length + i])];
  };
  const solve = (goal, limit, finish = false) => {
    const budget = limit, started = clock(), q = lemmaRecorder.invoke("seq", seq, [goal, Math.min(until, clock() + budget)]);
    trace.push({ stage: "field-query", hyps: goal.hyps.length, ms: Math.round(clock() - started), limit: budget, outcome: "tree" in q ? "tree" : q.stuck, core: q.core?.length, ...!("tree" in q) && q.stuck === "sat" ? { model: q.witness } : {} });
    if ("tree" in q)
      return q.tree;
    if (q.stuck === "sat" && q.witness)
      options.onSourceModel?.(goal, q.witness, root);
    if (finish && q.stuck === "sat" && q.witness && onModel?.(goal, q.witness))
      return;
    const reduced = q.why === REFUTED && q.core?.length ? { ...goal, hyps: q.core.map((i) => goal.hyps[i]) } : finish ? goal : undefined;
    if (!reduced)
      return;
    const before = atPoint.on;
    atPoint.on = !(root.size > 0 && !finish && q.core && q.core.length <= 8);
    try {
      const deadline = Math.min(until, clock() + (finish ? Math.max(0, until - clock()) : 250));
      if (!finish && root.size > 0 && q.core && q.core.length <= 8) {
        const start = clock(), folded = foldPath(reduced, root), out = lemmaRecorder.invoke("grow", grow, [folded.goal, root, { nodes: 0, until: Math.min(deadline, clock() + 25), units: false }]);
        const lifted = "tree" in out ? withDeadline(deadline, () => lemmaRecorder.invoke("widen", widen, [folded.goal, reduced, out.tree, folded.opaque, root, root])) : undefined;
        trace.push({ stage: "folded-core", aliases: Object.keys(folded.opaque).length, ms: Math.round(clock() - start), sourceChecked: "tree" in out, lifted: !!lifted });
        if (lifted)
          return withDeadline(deadline, () => lemmaRecorder.invoke("widen", widen, [reduced, goal, lifted, {}, root, root]));
        const direct = lemmaRecorder.invoke("booleanCore", booleanCore, [reduced, root, new Set(cert.insts.map((i) => i.wit)), deadline, trace, pointOptions]);
        if (direct)
          return withDeadline(deadline, () => lemmaRecorder.invoke("widen", widen, [reduced, goal, direct, {}, root, root]));
        const contextual = sourceWitnessContext(goal, reduced, new Set(cert.insts.map((i) => i.wit)), root);
        if (contextual !== reduced && clock() < deadline) {
          const extra = contextual.hyps.slice(reduced.hyps.length);
          trace.push({ stage: "witness-context", added: extra.length, extra: extra.flatMap((c) => piecesAt(c, root)) });
          const expanded = lemmaRecorder.invoke("booleanCore", booleanCore, [contextual, root, new Set(cert.insts.map((i) => i.wit)), deadline, trace, pointOptions]);
          if (expanded)
            return withDeadline(deadline, () => lemmaRecorder.invoke("widen", widen, [contextual, goal, expanded, {}, root, root]));
        }
      }
      const split = !finish && root.size > 0 && q.core && q.core.length <= 8 ? carriedCase(reduced, root, m.inputMaps ?? [], new Set(cert.insts.map((i) => i.wit)), deadline, trace) : undefined;
      if (split)
        return withDeadline(deadline, () => lemmaRecorder.invoke("widen", widen, [reduced, goal, split, {}, root, root]));
      const out = lemmaRecorder.invoke("grow", grow, [reduced, root, { nodes: 0, until: deadline, units: root.size > 0 && !!q.core && q.core.length <= 8 }]);
      return "tree" in out ? withDeadline(deadline, () => lemmaRecorder.invoke("widen", widen, [reduced, goal, out.tree, {}, root, root])) : undefined;
    } finally {
      atPoint.on = before;
    }
  };
  for (let i = 0;i < cert.reads.length; i++)
    for (let j = i + 1;j < cert.reads.length; j++) {
      const a = cert.reads[i], b = cert.reads[j];
      if (a[1] !== b[1] || truth({ op: "=", a: a[2], b: b[2] }, root) !== true)
        continue;
      for (const [left, right] of [[a[0], b[0]], [b[0], a[0]]]) {
        if (clock() >= until || pastWall())
          break;
        const split = sub({ [left]: 1 }, { [right]: 1 });
        if (path.get(canon(split))?.holds === true)
          continue;
        const noPath = new Map(path).set(canon(split), { lin: split, holds: false }), begun = clock();
        const __lemma = lemmaRecorder.attempt("read-alias", { op: "<=", a: { op: "var", name: left }, b: { op: "var", name: right } });
        try {
          trace.push({ stage: "read-alias-start", left, right });
          const bindings = g.hyps.filter((c) => c.op === "=" && [[c.a, c.b], [c.b, c.a]].some(([v, e]) => v?.op === "var" && [left, right].includes(v.name) && e?.op === "get" && e.map === a[1]));
          if (bindings.length !== 2)
            continue;
          const small = { name: "equal-key count reads", hyps: bindings }, out = lemmaRecorder.invoke("refuteFast", refuteFast, [lemmaRecorder.invoke("rowsAt", rowsAt, [small, noPath]), 256]);
          const local = out?.kind === "refuted" ? { leaf: out.steps } : undefined;
          const no = local && lemmaRecorder.invoke("check", check, [small, local, noPath]) ? lemmaRecorder.invoke("liftCountProxies", liftCountProxies, [small, g, local, [], noPath, noPath, undefined, options]) : undefined, accepted = !!no && (options.deferCheck || lemmaRecorder.invoke("check", check, [g, no, noPath]));
          lemmaRecorder.mark(__lemma, { source: small, sourceTree: local, sourcePath: noPath, target: g, tree: accepted ? no : undefined, targetPath: noPath, productionChecked: !options.deferCheck && accepted });
          trace.push({ stage: "read-alias", left, right, ms: Math.round(clock() - begun), checked: !options.deferCheck && accepted, ...options.deferCheck ? { proposed: accepted, deferred: true } : {} });
          if (accepted && no) {
            lemmas.push({ split, no });
            ctx.push({ op: "<=", a: x(left), b: x(right) });
            path.set(canon(split), { lin: split, holds: true });
          }
        } finally {
          lemmaRecorder.end(__lemma);
        }
      }
    }
  if (clock() >= until || pastWall())
    return;
  const ceilings = fieldBounds(m, ds, cert, { claim: options.fieldClaim, path: root }), domains = [];
  for (const good of ceilings)
    if (good.op === "<=" && good.a.op === "if") {
      const parts = good.a.c.op === "and" ? good.a.c.xs : [good.a.c];
      for (const c of parts)
        if (c.op === "<" && !domains.some((d) => JSON.stringify(c) === JSON.stringify(d)))
          domains.push(c);
    }
  for (const domain of domains) {
    if (truth(domain, path) !== undefined || (clock() >= until || pastWall()))
      continue;
    if (domain.op !== "<")
      continue;
    const a = linear(domain.a, root), b = linear(domain.b, root);
    if (!a || !b)
      continue;
    const split = sub(a, b);
    split["1"] = (split["1"] ?? 0) + 1;
    const __lemma = lemmaRecorder.attempt("field-domain", domain);
    try {
      const noPath = new Map(path).set(canon(split), { lin: split, holds: false }), start = clock();
      const part = { ...g, hyps: [...g.hyps.slice(0, g.hyps.length - cert.insts.length), ...ctx, { op: "not", x: domain }] }, direct = lemmaRecorder.invoke("refuteFast", refuteFast, [lemmaRecorder.invoke("rowsAt", rowsAt, [part, root]), 256]);
      const proof = direct?.kind === "refuted" ? { leaf: direct.steps } : solve(part, 50);
      const lifted = proof && lemmaRecorder.invoke("widen", widen, [part, g, proof, {}, root, noPath]), no = accept(lifted, noPath);
      lemmaRecorder.mark(__lemma, { source: part, sourceTree: proof, sourcePath: root, target: g, tree: no, targetPath: noPath, productionChecked: !options.deferCheck && !!no });
      trace.push({ stage: "field-domain", domain, direct: direct?.kind === "refuted", ms: Math.round(clock() - start), ...verdict(no) });
      if (no) {
        lemmas.push({ split, no });
        ctx.push(domain);
        path.set(canon(split), { lin: split, holds: true });
      }
    } finally {
      lemmaRecorder.end(__lemma);
    }
  }
  const finishField = () => {
    if (postIds.size || !options.fieldClaim || !lemmas.length || (clock() >= until || pastWall()))
      return;
    const offset = g.hyps.length - cert.insts.length, part = { ...g, hyps: [...g.hyps.slice(0, offset), ...ctx, ...g.hyps.slice(offset)] };
    const field = lemmaRecorder.invoke("fieldCase", fieldCase, [m, part, cert, options.fieldClaim, path, Math.min(until, clock() + 150), (e) => trace.push(e)]);
    let tree = field && lemmaRecorder.invoke("widen", widen, [part, g, field, {}, path, path]);
    trace.push({ stage: "field-ceiling-conclusion", facts: lemmas.length, proposed: !!tree });
    if (tree) {
      for (const { split, no } of [...lemmas].reverse())
        tree = { split, yes: tree, no };
      if (options.deferCheck || lemmaRecorder.invoke("check", check, [g, tree, root]))
        return tree;
    }
    return;
  };
  const activeCeilings = new Set(ceilings.flatMap((good) => good.op === "<=" && good.a.op === "if" && truth(good.a.c, path) === true ? [JSON.stringify([good.a.then, good.b])] : []));
  for (const good of ceilings) {
    if (good.op === "<=" && good.a.op === "if" && truth(good.a.c, path) !== true && activeCeilings.has(JSON.stringify([good.a.then, good.b])))
      continue;
    if (good.op !== "<=" || (clock() >= until || pastWall()))
      break;
    if (truth(good, path) === true)
      continue;
    const a = linear(good.a, path), b = linear(good.b, path);
    if (!a || !b)
      continue;
    const split = sub(a, b), noPath = new Map(path).set(canon(split), { lin: split, holds: false }), start = clock();
    const __lemma = lemmaRecorder.attempt("field-bound", good);
    try {
      const facts = narrow(good), part = { ...g, hyps: [...facts, ...ctx, { op: "not", x: good }] }, proof = solve(part, 250), lifted = proof && lemmaRecorder.invoke("widen", widen, [part, g, proof, {}, root, noPath]), no = accept(lifted, noPath);
      lemmaRecorder.mark(__lemma, { source: part, sourceTree: proof, sourcePath: root, target: g, tree: no, targetPath: noPath, productionChecked: !options.deferCheck && !!no });
      trace.push({ stage: "field-bound", bound: good, ms: Math.round(clock() - start), proved: !!no, ...verdict(no) });
      if (no) {
        lemmas.push({ split, no });
        ctx.push(good);
        path.set(canon(split), { lin: split, holds: true });
        const field = finishField();
        if (field)
          return field;
      }
    } finally {
      lemmaRecorder.end(__lemma);
    }
  }
  if (clock() >= until || pastWall())
    return;
  const field = finishField();
  if (field)
    return field;
  {
    const carriedMaps = activeCarried(m, root), countMaps = new Set(cert.reads.map((r) => r[1])), countIds = new Set(cert.reads.map((r) => r[0])), wits = new Set(cert.insts.map((i) => i.wit)), raw = g.hyps.slice(0, g.hyps.length - cert.insts.length);
    const pieces = (c) => piecesAt(c, root);
    const alias = (inst) => {
      if (inst.unit !== 0 || inst.terms.length !== 2 || inst.terms.some(([, id]) => postIds.has(id)))
        return false;
      const a = cs.get(inst.terms[0][1]), b = cs.get(inst.terms[1][1]);
      return !!a && !!b && JSON.stringify(view(a.body)) === JSON.stringify(view(b.body));
    };
    const requestFrame = (inst) => inst.terms.length === 2 && inst.terms.some(([, id]) => postIds.has(id)) && inst.terms.some(([, id]) => {
      const c = cs.get(id), b = c && view(c.body);
      return b?.op === "get" && (m.inputMaps ?? []).includes(b.map);
    });
    const frame = (inst) => {
      if (inst.terms.length !== 2)
        return false;
      const [a, b] = inst.terms.map(([, id]) => cert.reads.find((r) => r[0] === id));
      return !!a && !!b && a[1].replace(/#$/, "") === b[1].replace(/#$/, "") && a[1].endsWith("#") !== b[1].endsWith("#") && JSON.stringify(a[2]) === JSON.stringify(b[2]);
    };
    const copyFrame = (inst) => {
      if (inst.terms.length !== 2)
        return false;
      const [a, b] = inst.terms.map(([, id]) => cert.reads.find((r) => r[0] === id));
      return !!a && !!b && a[1].replace(/#$/, "") === b[1].replace(/#$/, "") && a[1].endsWith("#") !== b[1].endsWith("#") && JSON.stringify(a[2]) !== JSON.stringify(b[2]);
    };
    const selected = (inst) => {
      if (inst.unit !== 0)
        return false;
      if (emptyCountCandidate(m, cert, inst))
        return true;
      if (rowPlan.length && inst.terms.some(([, id]) => postIds.has(id)))
        return false;
      const carried = inst.terms.some(([k, id]) => {
        const c = cs.get(id), b = c && view(c.body);
        return k === 1 && b?.op === "get" && carriedMaps.has(b.map);
      });
      if (rowPlan.length && carried && inst.terms.length === 2) {
        const localRows = new Set(rowPlan.flatMap(([key]) => key.op === "var" ? [key.name] : [])), positive = inst.terms.find(([k]) => k === 1), negative = inst.terms.find(([k]) => k === -1);
        const source = positive && cs.get(positive[1]), target = negative && cs.get(negative[1]), input = source && view(source.body);
        let local = false;
        if (target)
          walkLive(target.body, root, (o) => {
            if (o.op === "var" && localRows.has(o.name) || o.op === "get" && (m.inputMaps ?? []).includes(o.map) && input?.op === "get" && o.map !== input.map)
              local = true;
          });
        if (local)
          return false;
      }
      if (inst.terms.length === 3 || inst.terms.length === 5 && carried)
        return true;
      if (inst.terms.length !== 2)
        return false;
      const [a, b] = inst.terms.map(([, id]) => cert.reads.find((r) => r[0] === id));
      return carried || alias(inst) || frame(inst) || copyFrame(inst) || !!a && !!b && a[1].endsWith("#") && b[1].endsWith("#") || requestFrame(inst) || !!a && !!b && a[1].endsWith("#") && !b[1].endsWith("#");
    };
    const pure = (c) => {
      let skip = false;
      walkLive(c, root, (o) => {
        if (o.op === "get" || o.op === "var" && wits.has(o.name))
          skip = true;
      });
      return !skip;
    };
    const maps = Object.fromEntries([...countMaps].map((map) => [map, (key) => {
      const r = cert.reads.find((r) => r[1] === map && JSON.stringify(r[2]) === JSON.stringify(key));
      return r ? x(r[0]) : { op: "get", map, key };
    }]));
    const flags = Object.fromEntries(Object.keys(m.step.flags ?? {}).map((name) => [name, { op: "flag", name }]));
    const numericBase = raw.map((c) => substC(c, { vars: {}, maps, flags })).flatMap((c) => pieces(c)).filter(pure);
    const numericBindings = countBindingsAt(cert.reads, root);
    const finish = () => {
      if (rowPlan.length || arithmetic || (clock() >= until || pastWall()))
        return;
      const numeric = { ...g, hyps: [...numericBase, ...numericBindings, ...ctx.filter(pure)] }, begun = clock(), q = lemmaRecorder.invoke("seq", seq, [numeric, Math.min(until, clock() + 200)]);
      trace.push({ stage: "count-arithmetic", hyps: numeric.hyps.length, ms: Math.round(clock() - begun), outcome: "tree" in q ? "tree" : q.stuck, core: q.core?.length, ...!("tree" in q) && q.stuck === "sat" ? { model: q.witness } : {} });
      let proof = "tree" in q ? q.tree : undefined;
      if (!proof && !("tree" in q) && q.why === REFUTED && q.core?.length) {
        const reduced = { ...numeric, hyps: q.core.map((i) => numeric.hyps[i]) }, out = lemmaRecorder.invoke("grow", grow, [reduced, root, { nodes: 0, until: Math.min(until, clock() + 400), units: false }]);
        if ("tree" in out)
          proof = lemmaRecorder.invoke("widen", widen, [reduced, numeric, out.tree, {}, root, root]);
      }
      if (!proof && !("tree" in q) && q.stuck === "unknown")
        proof = lemmaRecorder.invoke("proveNaturalCases", proveNaturalCases, [numeric, root, Math.min(until, clock() + 400), trace, pointOptions]);
      const lifted = proof && lemmaRecorder.invoke("liftCountProxies", liftCountProxies, [numeric, g, proof, cert.reads, root, path, (event) => trace.push({ stage: "count-transport", ...event }), options]);
      if (lifted)
        arithmetic = lifted;
    };
    const diagonalCopy = (inst) => {
      if (!copyFrame(inst))
        return false;
      const source = inst.terms.map(([, id]) => cert.reads.find((r) => r[0] === id)).find((r) => r && !r[1].endsWith("#")), key = source?.[2];
      if (key?.op === "tup")
        return JSON.stringify(key.a) === JSON.stringify(key.b);
      const decl = source && m.counts?.[source[1]];
      return key?.op === "add" && !!decl?.lo && key.a.op === "mul" && key.a.k === decl.base && JSON.stringify(key.a.a) === JSON.stringify(key.b);
    };
    const writer = activeWriteRow(m, root);
    const afterRead = (inst) => inst.terms.map(([, id]) => cert.reads.find((r) => r[0] === id)).find((r) => r?.[1].endsWith("#"));
    const coordinates = (read) => {
      const key = read[2], d = m.counts?.[read[1].replace(/#$/, "")];
      if (key.op === "tup")
        return [key.a, key.b];
      if (d?.lo && key.op === "add" && key.a.op === "mul" && key.a.k === d.base)
        return [key.a.a, key.b];
      return [key];
    };
    const rank = (inst) => {
      if (emptyCountCandidate(m, cert, inst))
        return -1;
      const after = afterRead(inst), keys = after && coordinates(after);
      if (writer && frame(inst) && keys?.every((key) => truth(same(key, x(writer)), root) === false))
        return -0.75;
      if (copyFrame(inst)) {
        if (writer && keys) {
          const before = inst.terms.map(([, id]) => cert.reads.find((r) => r[0] === id)).find((r) => r && !r[1].endsWith("#")), oldKeys = before && coordinates(before);
          let moved = false, matched = !!oldKeys && oldKeys.length === keys.length;
          for (let i = 0;matched && i < keys.length; i++) {
            const changed = truth(same(keys[i], x(writer)), root), old = oldKeys[i];
            if (changed === false && truth(same(old, keys[i]), root) !== true)
              return 0.5;
            if (changed === true) {
              moved = true;
              matched = old.op === "var" && m.inputs.includes(old.name) && old.name !== writer;
            }
            if (changed === undefined)
              matched = false;
          }
          if (matched && moved)
            return -0.5;
        }
        return diagonalCopy(inst) ? 0.5 : 0;
      }
      return requestFrame(inst) || alias(inst) ? 0 : inst.terms.length === 2 && inst.terms.every(([, id]) => postIds.has(id)) ? 1 : frame(inst) ? 2 : inst.terms.length === 3 && inst.terms.every(([, id]) => !postIds.has(id)) ? 3 : inst.terms.length === 5 ? 4 : inst.terms.length === 2 ? 5 : 6;
    };
    finish();
    const ordered = [...cert.insts.entries()].sort((a, b) => rank(a[1]) - rank(b[1])), excluded = new Set, confirmed = new Set;
    const boundOf = (index) => {
      const h = g.hyps[raw.length + index];
      return h?.op === "or" && h.xs[0]?.op === "<=" ? h.xs[0] : undefined;
    };
    let fallbackSelection = false;
    const pick = () => {
      const pool = ordered.filter(([index, inst]) => {
        const good = boundOf(index);
        return !excluded.has(index) && !confirmed.has(index) && selected(inst) && !!good && truth(good, path) !== true;
      });
      if (rowPlan.length) {
        fallbackSelection = true;
        return numericBindings.length ? pool : [];
      }
      const selection = selectCountBounds({ ...g, hyps: [...numericBase, ...numericBindings, ...ctx.filter(pure)] }, pool.map(([index]) => ({ index, bound: boundOf(index) })), until, { path: root, queryMs: 200, trace: (event) => trace.push({ ...event, stage: "needed-lemmas" }) });
      if (!selection)
        return [];
      fallbackSelection = selection.fallback;
      const needed = new Set(selection.indices);
      const identity = (inst) => inst.terms.length === 3 && inst.terms.every(([, id]) => !postIds.has(id));
      return pool.filter(([index]) => needed.has(index)).sort((a, b) => Number(identity(b[1])) - Number(identity(a[1])));
    };
    let queue = pick(), cursor = 0;
    while (cursor < queue.length) {
      const [index, inst] = queue[cursor++];
      if (arithmetic || (clock() >= until || pastWall()))
        break;
      if (!selected(inst))
        continue;
      const h = g.hyps[raw.length + index];
      if (h?.op !== "or" || h.xs[0]?.op !== "<=")
        continue;
      const good = h.xs[0];
      if (truth(good, path) === true)
        continue;
      const split = Object.fromEntries(inst.terms.map(([n, v]) => [v, n])), noPath = new Map(path).set(canon(split), { lin: split, holds: false });
      const __lemma = lemmaRecorder.attempt("field-count", good);
      try {
        const relevant = raw.flatMap((c) => pieces(c)).filter((c) => {
          let skip = false;
          walkLive(c, root, (o) => {
            if (o.op === "get" && countMaps.has(o.map) || o.op === "var" && (countIds.has(o.name) || wits.has(o.name) && o.name !== inst.wit))
              skip = true;
          });
          return !skip;
        });
        const part = { ...g, hyps: [...relevant, ...ctx, h, { op: "not", x: good }] }, started = clock();
        let proof;
        if (inst.terms.length === 3 && inst.terms.every(([, id]) => !postIds.has(id))) {
          const tiny = { name: g.name, hyps: [h, { op: "not", x: good }] }, fast = lemmaRecorder.invoke("booleanCore", booleanCore, [tiny, root, new Set([inst.wit]), Math.min(until, clock() + 30), trace, pointOptions]);
          if (fast)
            proof = lemmaRecorder.invoke("widen", widen, [tiny, part, fast, {}, root, root]);
          trace.push({ stage: "direct-partition", index, proved: !!proof });
        }
        const directCopy = copyFrame(inst) || frame(inst);
        if (directCopy) {
          const copyUntil = diagonalCopy(inst) ? Math.max(clock(), until - 200) : Math.min(until, started + 230);
          const tiny = sourceScalarContext({ name: g.name, hyps: raw }, { name: g.name, hyps: [h, { op: "not", x: good }] }, new Set([...m.params, ...m.inputs, ...Object.keys(m.state)]), root), fast = lemmaRecorder.invoke("booleanCore", booleanCore, [tiny, root, new Set([inst.wit]), copyUntil, trace, { ...pointOptions, model: false, extended: true, scalarGuards: true }]);
          if (fast)
            proof = lemmaRecorder.invoke("widen", widen, [tiny, part, fast, {}, root, root]);
          trace.push({ stage: "direct-copy", index, terms: inst.terms, reads: inst.terms.map(([, id]) => cert.reads.find((r) => r[0] === id)), proved: !!proof });
        }
        proof ??= solve(part, directCopy ? Math.max(0, 230 - (clock() - started)) : 150);
        const lifted = proof && withDeadline(Math.min(until, started + (directCopy ? 230 : 150)), () => lemmaRecorder.invoke("widen", widen, [part, g, proof, {}, root, noPath])), no = accept(lifted, noPath);
        lemmaRecorder.mark(__lemma, { source: part, sourceTree: proof, sourcePath: root, target: g, tree: no, targetPath: noPath, productionChecked: !options.deferCheck && !!no });
        trace.push({ stage: "count-lemma", index, arity: inst.terms.length, terms: inst.terms, ms: Math.round(clock() - started), ...verdict(no) });
        if (no) {
          confirmed.add(index);
          lemmas.push({ split, no });
          ctx.push(good);
          path.set(canon(split), { lin: split, holds: true });
          finish();
        } else {
          excluded.add(index);
          if (!fallbackSelection) {
            queue = pick();
            cursor = 0;
          }
        }
      } finally {
        lemmaRecorder.end(__lemma);
      }
    }
    finish();
  }
  if (clock() >= until || pastWall())
    return;
  const part = { ...g, hyps: [...g.hyps, ...ctx] }, start = clock();
  let tree = arithmetic;
  if (!tree && rowPlan.length) {
    trace.push({ stage: "row-pairs", pairs: rowPlan });
    tree = proveRowCases(g, path, rowPlan, until, (branch, end) => fieldBoundLemmas(m, ds, g, cert, end, trace, onModel, branch, { splitRows: false, deferCheck: true, memo: options.memo, onSourceModel: options.onSourceModel }), (e) => trace.push(e), { deferToCaller: true, splitEqual: copiesRows(m, root) });
  }
  if (!tree) {
    const proof = solve(part, Math.max(150, until - clock() - 200), true);
    tree = proof && lemmaRecorder.invoke("widen", widen, [part, g, proof, {}, root, path]);
  }
  trace.push({ stage: "field-bound-conclusion", facts: lemmas.length, ms: Math.round(clock() - start), proved: !!tree });
  if (!tree)
    return;
  for (const { split, no } of [...lemmas].reverse())
    tree = { split, yes: tree, no };
  if (options.deferCheck)
    return tree;
  const checked = lemmaRecorder.invoke("check", check, [g, tree, root]);
  return checked ? tree : undefined;
}

// core/count-recovery/frame-lemmas.ts
var frameLemmas = (...args) => lemmaRecorder.helper("frame", args, () => wallTree("proposal-control", () => frameLemmasImpl(...args)));
function frameLemmasImpl(g, cert, until, trace, root = new Map, options = {}) {
  let failed = 0;
  const seq = modelSequence(root), base = g.hyps.slice(0, g.hyps.length - cert.insts.length), ctx = [], path = new Map(root), lemmas = [];
  const reads = new Map(cert.reads.map((r) => [r[0], r])), maps = new Set(cert.reads.map((r) => r[1])), wits = new Set(cert.insts.map((i) => i.wit));
  const weaken = (c, wit) => {
    if (c.op === "and") {
      const xs = c.xs.flatMap((x) => {
        const y = weaken(x, wit);
        return y ? [y] : [];
      });
      return xs.length ? { op: "and", xs } : undefined;
    }
    let count = false, other = false, own = false;
    walkLive(c, root, (o) => {
      if (o.op === "get" && maps.has(o.map))
        count = true;
      if (o.op === "var" && wits.has(o.name)) {
        if (o.name === wit)
          own = true;
        else
          other = true;
      }
    });
    return count || other && !own ? undefined : c;
  };
  const project = (hyps) => {
    const maps = Object.fromEntries([...new Set(cert.reads.map((r) => r[1]))].map((map) => [map, (key) => {
      const r = cert.reads.find((r) => r[1] === map && JSON.stringify(r[2]) === JSON.stringify(key));
      return r ? x(r[0]) : { op: "get", map, key };
    }]));
    const flags = {};
    walkOnce(hyps, (o) => {
      if (o.op === "flag")
        flags[o.name] = { op: "flag", name: o.name };
    });
    return hyps.map((c) => substC(c, { vars: {}, maps, flags })).flatMap((c) => piecesAt(c, root)).filter((c) => {
      let skip = false;
      walkLive(c, root, (o) => {
        if (o.op === "get" || o.op === "var" && wits.has(o.name))
          skip = true;
      });
      return !skip;
    });
  };
  const solve = (goal, limit, finish = false) => {
    if (finish) {
      const hyps = project(goal.hyps);
      const numeric = { ...goal, hyps }, start = clock(), q = lemmaRecorder.invoke("seq", seq, [numeric, Math.min(until, clock() + 150)]);
      trace.push({ stage: "frame-arithmetic", hyps: hyps.length, ms: Math.round(clock() - start), outcome: "tree" in q ? "tree" : q.stuck, core: q.core?.length });
      let proof = "tree" in q ? q.tree : undefined;
      if (!proof && !("tree" in q) && q.why === REFUTED && q.core?.length) {
        const reduced = { ...numeric, hyps: q.core.map((i) => hyps[i]) }, out = lemmaRecorder.invoke("grow", grow, [reduced, root, { nodes: 0, until: Math.min(until, clock() + 150), units: false }]);
        if ("tree" in out)
          proof = lemmaRecorder.invoke("widen", widen, [reduced, numeric, out.tree, {}, root, root]);
      }
      if (proof) {
        const lifted = lemmaRecorder.invoke("liftCountProxies", liftCountProxies, [numeric, goal, proof, cert.reads, root, root, (event) => trace.push({ stage: "proxy-lift", ...event }), options]);
        trace.push({ stage: "frame-arithmetic-lift", ms: Math.round(clock() - start), proved: !!lifted });
        if (lifted)
          return lifted;
      }
    }
    const q = lemmaRecorder.invoke("seq", seq, [goal, Math.min(until, clock() + limit)]);
    if ("tree" in q)
      return q.tree;
    if (q.why !== REFUTED || !q.core?.length)
      return;
    const reduced = { ...goal, hyps: q.core.map((i) => goal.hyps[i]) };
    if (options.boolean && q.core.length <= 8) {
      const tree = lemmaRecorder.invoke("booleanCore", booleanCore, [reduced, root, wits, Math.min(until, clock() + 100), trace, options]);
      if (tree)
        return lemmaRecorder.invoke("widen", widen, [reduced, goal, tree, {}, root, root]);
    }
    const out = lemmaRecorder.invoke("grow", grow, [reduced, root, { nodes: 0, until: Math.min(until, clock() + 200), units: false }]);
    return "tree" in out ? lemmaRecorder.invoke("widen", widen, [reduced, goal, out.tree, {}, root, root]) : undefined;
  };
  const candidates = cert.insts.flatMap((instance, i) => {
    if (instance.unit !== 0 || instance.terms.length !== 2)
      return [];
    const [a, b] = instance.terms.map((t) => reads.get(t[1])), h = g.hyps[base.length + i];
    return a && b && a[1].replace(/#$/, "") === b[1].replace(/#$/, "") && a[1].endsWith("#") !== b[1].endsWith("#") && JSON.stringify(a[2]) === JSON.stringify(b[2]) && h?.op === "or" && h.xs[0]?.op === "<=" ? [{ i, instance, h, good: h.xs[0] }] : [];
  });
  let selected;
  if (candidates.length && clock() < until) {
    const numeric = project(base), trial = { ...g, hyps: [...numeric, ...candidates.map((c) => c.good)] }, start = clock(), q = lemmaRecorder.invoke("seq", seq, [trial, Math.min(until, clock() + 150)]);
    const core = "tree" in q ? usedHyps(trial, q.tree, root) : q.why === REFUTED && q.core ? new Set(q.core) : undefined;
    if (core)
      selected = new Set(candidates.filter((_, i) => core.has(numeric.length + i)).map((c) => c.i));
    trace.push({ stage: "frame-core", pool: candidates.length, selected: selected ? [...selected] : null, ms: Math.round(clock() - start) });
  }
  for (const { i, instance, h, good } of candidates) {
    if (clock() >= until)
      break;
    if (selected && !selected.has(i))
      continue;
    const split = Object.fromEntries(instance.terms.map(([n, v]) => [v, n])), noPath = new Map(path).set(canon(split), { lin: split, holds: false });
    const __lemma = lemmaRecorder.attempt("frame", good);
    try {
      const relevant = base.flatMap((c) => piecesAt(c, root)).flatMap((c) => {
        const kept = weaken(c, instance.wit);
        return kept ? [kept] : [];
      });
      const part = { ...g, hyps: [...relevant, ...ctx, h, { op: "not", x: good }] }, start = clock(), tree = solve(part, 150);
      const no = tree && lemmaRecorder.invoke("widen", widen, [part, g, tree, {}, root, noPath]);
      lemmaRecorder.mark(__lemma, { source: part, sourceTree: tree, sourcePath: root, target: g, tree: no, targetPath: noPath, productionChecked: false });
      trace.push({ stage: "frame-lemma", index: i, ms: Math.round(clock() - start), proved: !!no });
      if (!no) {
        if (++failed >= (options.stopAfterFailed ?? Infinity) && !lemmas.length)
          return;
        continue;
      }
      lemmas.push({ split, no });
      ctx.push(good);
      path.set(canon(split), { lin: split, holds: true });
    } finally {
      lemmaRecorder.end(__lemma);
    }
  }
  if (clock() >= until)
    return;
  if (!lemmas.length) {
    if (selected?.size !== 0)
      return;
    const tree = solve(g, Math.max(0, until - clock()), true);
    return tree && (options.deferCheck || lemmaRecorder.invoke("check", check, [g, tree, root])) ? tree : undefined;
  }
  const part = { ...g, hyps: [...g.hyps, ...ctx] }, start = clock(), found = solve(part, Math.max(150, until - clock() - 200), true);
  let tree = found && lemmaRecorder.invoke("widen", widen, [part, g, found, {}, root, path]);
  trace.push({ stage: "frame-conclusion", facts: lemmas.length, ms: Math.round(clock() - start), proved: !!tree });
  if (!tree)
    return;
  for (const lemma of [...lemmas].reverse())
    tree = { split: lemma.split, yes: tree, no: lemma.no };
  return options.deferCheck || lemmaRecorder.invoke("check", check, [g, tree, root]) ? tree : undefined;
}

// core/count-recovery/guard-cases.ts
var guardCases = (...args) => wallTree("guard-case-reconstruction", () => guardCasesImpl(...args));
function guardCasesImpl(m, ds, g, cert, guard, until, trace, slot = 0, root = new Map, options = {}) {
  const deferNested = !!options.deferCheck;
  const conditions = [], booleans = true;
  const collect = (c) => {
    if (c.op === "and" || booleans && c.op === "or")
      return c.xs.every(collect);
    if (booleans && c.op === "not")
      return collect(c.x);
    if (c.op === "=") {
      conditions.push({ op: "<=", a: c.a, b: c.b }, { op: "<=", a: c.b, b: c.a });
      return true;
    }
    if (c.op === "<=") {
      conditions.push(c);
      return true;
    }
    if (c.op === "<") {
      conditions.push({ op: "<=", a: plus2(c.a, n(1)), b: c.b });
      return true;
    }
    return false;
  };
  if (!collect(guard) || conditions.length > 12)
    return;
  const inactiveGoal = { ...g, hyps: [...g.hyps.slice(0, slot), { op: "not", x: guard }, ...g.hyps.slice(slot)] };
  let inactive, attempted = false, inactiveLeaf;
  const leaf = (hyps, path, active) => {
    if (clock() >= until)
      return;
    const assumption = active ? guard : { op: "and", xs: hyps }, sourceOnly = false, goal = sourceOnly ? g : { ...g, hyps: [...g.hyps.slice(0, slot), assumption, ...g.hyps.slice(slot)] }, start = clock(), end = active ? until : Math.min(until, clock() + 500);
    const cached = options.memo?.get(g, path, end);
    if (cached && (deferNested || checkConditionalProof(g, cached, path))) {
      trace.push({ stage: "source-memo", scope: "guard", active });
      return cached;
    }
    const rowDependent = active && rowPairs(m, cert, path, options.claim).length > 0;
    let proof = rowDependent ? undefined : fieldCase(m, goal, cert, options.claim, path, Math.min(end, clock() + 150), (e) => trace.push({ ...e, guardActive: active }), 0, options.memo);
    if (!proof && !active) {
      if (!attempted) {
        attempted = true;
        const begun = clock();
        inactive = frameLemmas(inactiveGoal, cert, end, trace, root, { stopAfterFailed: 2, deferCheck: deferNested });
        trace.push({ stage: "shared-frame", ms: Math.round(clock() - begun), proved: !!inactive });
      }
      if (inactive) {
        const shared = widen(inactiveGoal, g, inactive, {}, root, path), accepted = !!shared && (deferNested || checkConditionalProof(g, shared, path));
        trace.push({ stage: "shared-frame-lift", ms: Math.round(clock() - start), checked: accepted && !deferNested, proposed: !!shared, deferred: deferNested });
        if (accepted)
          return shared;
      }
    }
    if (!proof && !active && inactiveLeaf) {
      const shared = withDeadline(Math.min(end, clock() + 50), () => widen(g, g, inactiveLeaf.tree, {}, inactiveLeaf.path, path)), accepted = !!shared && (deferNested || checkConditionalProof(g, shared, path));
      trace.push({ stage: "inactive-path-reuse", ms: Math.round(clock() - start), checked: accepted && !deferNested, proposed: !!shared, deferred: deferNested });
      if (accepted)
        return shared;
    }
    if (!proof && !active) {
      const simple = solve(rowsAt(goal, path), 500);
      if (simple.kind === "refuted")
        proof = { leaf: simple.steps };
    }
    if (!proof)
      proof = active ? fieldBoundLemmas(m, ds, goal, cert, end, trace, undefined, path, { deferCheck: true, fieldClaim: options.claim, memo: options.memo, conditional: options.conditional }) : frameLemmas(goal, cert, end, trace, path, { deferCheck: deferNested });
    if (!proof && clock() < end) {
      const before = atPoint.on;
      atPoint.on = false;
      try {
        const out = grow(goal, path, { nodes: 0, until: end, units: false });
        if ("tree" in out)
          proof = out.tree;
      } finally {
        atPoint.on = before;
      }
    }
    const lifted = proof && (sourceOnly ? proof : hasConditionalProof(proof) ? transportConditionalProof(goal, g, proof, path, path, Math.min(wallAt(), performance.now() + Math.max(0, end - clock()) * 10)) : widen(goal, g, proof, {}, path, path)), accepted = !!lifted && (active || deferNested || checkConditionalProof(g, lifted, path));
    if (accepted && lifted && !hasConditionalProof(lifted))
      options.memo?.put(g, path, lifted);
    if (!active && accepted && lifted && !inactiveLeaf)
      inactiveLeaf = { tree: lifted, path: new Map(path) };
    trace.push({ stage: "guard-leaf", active, sourceOnly, hyps: hyps.length, ms: Math.round(clock() - start), checked: !active && !deferNested && accepted, proposed: !!proof, transported: !!lifted, deferred: active || deferNested });
    return accepted ? lifted : undefined;
  };
  const visit = (i, hyps, path) => {
    if (booleans) {
      const active = truth(guard, path);
      if (active !== undefined)
        return leaf(hyps, path, active);
      if (i === conditions.length)
        return;
    } else if (i === conditions.length)
      return leaf(hyps, path, true);
    if (clock() >= until)
      return;
    const c = conditions[i];
    if (c.op !== "<=")
      return;
    const known = truth(c, path);
    if (known === true)
      return visit(i + 1, [...hyps, c], path);
    if (known === false)
      return booleans ? visit(i + 1, [...hyps, { op: "not", x: c }], path) : leaf([...hyps, { op: "not", x: c }], path, false);
    const a = linear(c.a, path), b = linear(c.b, path);
    if (!a || !b)
      return;
    const split = sub(a, b), id = canon(split);
    const noPath = new Map(path).set(id, { lin: split, holds: false }), no = booleans ? visit(i + 1, [...hyps, { op: "not", x: c }], noPath) : leaf([...hyps, { op: "not", x: c }], noPath, false);
    if (!no)
      return;
    const yesPath = new Map(path).set(id, { lin: split, holds: true }), yes = visit(i + 1, [...hyps, c], yesPath);
    return yes ? { split, yes, no } : undefined;
  };
  const tree = visit(0, [], new Map(root));
  const accepted = !!tree && (options.deferCheck || checkConditionalProof(g, tree, root));
  trace.push({ stage: "guard-complete", cuts: conditions.length, checked: !options.deferCheck && accepted, ...options.deferCheck ? { proposed: !!tree, deferred: true } : {} });
  return accepted ? tree : undefined;
}

// core/count-cert-grow.ts
function appendCountCert(current, next, context) {
  const used = new Set([...current.reads.map((r) => r[0]), ...current.insts.map((i) => i.wit)]);
  walkOnce([context, current, next], (o) => {
    if (o.op === "var")
      used.add(o.name);
  });
  let serial = 0;
  const fresh = (prefix) => {
    let name;
    do {
      name = `${prefix}$${serial++}`;
    } while (used.has(name));
    used.add(name);
    return name;
  };
  const key = (r) => JSON.stringify(r.slice(1));
  const byKey = new Map(current.reads.map((r) => [key(r), r[0]])), renamed = new Map;
  let changed = false;
  for (const read of next.reads) {
    let name = byKey.get(key(read));
    if (name === undefined) {
      name = fresh("countRead");
      current.reads.push([name, read[1], read[2]]);
      byKey.set(key(read), name);
      changed = true;
    }
    renamed.set(read[0], name);
  }
  const signature = (i) => JSON.stringify([i.unit, i.below, [...i.terms].sort((a, b) => a[1].localeCompare(b[1]) || a[0] - b[0])]);
  const have = new Set(current.insts.map(signature));
  for (const instance of next.insts) {
    const terms = instance.terms.map(([k, id]) => [k, renamed.get(id) ?? id]), candidate = { ...instance, terms }, sig = signature(candidate);
    if (have.has(sig))
      continue;
    current.insts.push({ ...candidate, wit: fresh("countWitness") });
    have.add(sig);
    changed = true;
  }
  return changed;
}

// core/count-recovery/source-memo.ts
var scopes = new WeakMap;
var fresh2 = () => ({ entries: new Map, ids: new WeakMap, next: 0, indices: new WeakMap });
var sourceMemoStats = { foreignAttempts: 0, foreignHits: 0, crossLawHits: 0, localHits: 0 };
function sourceProofMemo(scope, context) {
  const shared = env.GDP_SOURCE_CONTEXTS !== "0";
  let cache = shared && scope ? scopes.get(scope) : undefined;
  if (!cache) {
    cache = fresh2();
    if (shared && scope)
      scopes.set(scope, cache);
  }
  const { entries, ids } = cache, data = cache;
  const key = (goal, path) => {
    let id = ids.get(goal);
    if (id === undefined) {
      id = data.next++;
      ids.set(goal, id);
    }
    return (shared ? `${id}/` : "") + JSON.stringify([...path].map(([atom, p]) => [atom, p.holds]).sort(([a], [b]) => String(a).localeCompare(String(b))));
  };
  return {
    get(goal, path, until) {
      if (clock() >= until)
        return;
      const old = entries.get(key(goal, path));
      if (old) {
        const tree = withDeadline(until, () => widen(old.goal, goal, old.tree, {}, old.path, path));
        if (tree) {
          sourceMemoStats.localHits++;
          return tree;
        }
        if (!shared)
          return;
      }
      const distance = (p) => {
        let n = 0;
        for (const [id, v] of path)
          if (p.get(id)?.holds !== v.holds)
            n++;
        for (const id of p.keys())
          if (!path.has(id))
            n++;
        return n;
      };
      const nearby = [...entries.values()].filter((e) => shared || e.goal === goal).sort((a, b) => Number(b.goal === goal) - Number(a.goal === goal) || distance(a.path) - distance(b.path)).slice(0, 8);
      const foreignEnd = Math.min(until, clock() + 50);
      for (const e of nearby) {
        const foreign = e.goal !== goal;
        if (foreign && clock() >= foreignEnd)
          break;
        if (foreign)
          sourceMemoStats.foreignAttempts++;
        const tree = renameProof(e.goal, e.tree, e.path, path, {}, Math.min(until, clock() + (foreign ? 10 : 25)), goal, shared && env.GDP_SOURCE_INDEX !== "0" ? data.indices : undefined);
        if (tree) {
          if (foreign) {
            sourceMemoStats.foreignHits++;
            if (e.context !== context)
              sourceMemoStats.crossLawHits++;
          } else
            sourceMemoStats.localHits++;
          return tree;
        }
      }
      return;
    },
    put(goal, path, tree) {
      const id = key(goal, path);
      entries.delete(id);
      entries.set(id, { goal, path: new Map(path), tree, context });
      if (shared && entries.size > 128)
        entries.delete(entries.keys().next().value);
    }
  };
}

// core/count-cases.ts
function finiteCountChoice(m) {
  const values = new Map;
  walkOnce([m.step, m.assume], (o) => {
    if (o.op !== "=")
      return;
    const [a, b] = o.a.op === "var" ? [o.a, o.b] : [o.b, o.a];
    if (a.op !== "var" || b.op !== "const" || !m.inputs.includes(a.name))
      return;
    const vs = values.get(a.name) ?? new Set;
    vs.add(b.value);
    values.set(a.name, vs);
  });
  return [...values].filter(([, v]) => v.size > 2 && v.size <= 16).sort((a, b) => b[1].size - a[1].size)[0];
}
function withoutCountWitnesses(m, laws, at, discard) {
  if (!discard.size)
    return at;
  const out = {};
  for (const [name, terms] of Object.entries(at)) {
    const law = laws.find((l) => l.name === name), flag = name.startsWith("?") ? m.step.flags?.[name.slice(1)] : undefined;
    const arity = law ? 1 + (law.keys?.length ?? 0) : flag?.op === "all" ? boundOf(flag).length : 1, kept = [];
    for (let i = 0;i < terms.length; i += arity) {
      const tuple = terms.slice(i, i + arity);
      let unwanted = false;
      walkOnce(tuple, (o) => {
        if (o.op === "var" && discard.has(o.name))
          unwanted = true;
      });
      if (!unwanted)
        kept.push(...tuple);
    }
    out[name] = kept;
  }
  return out;
}
function selectedCase(m, laws, at, cert, packet, path, until, build, options) {
  const full = mcGoal(packet.goal.hyps, packet.decls, cert);
  if (!full || !cert.insts.length)
    return;
  const offset = full.hyps.length - cert.insts.length, base = { ...full, hyps: full.hyps.slice(0, offset) }, excluded = new Set;
  const candidates = cert.insts.flatMap((_, index) => {
    const h = full.hyps[offset + index];
    return h?.op === "or" && h.xs[0]?.op === "<=" ? [{ index, bound: h.xs[0] }] : [];
  });
  while (clock() < until && !pastWall()) {
    const selected = selectCountBounds(base, candidates.filter((c) => !excluded.has(c.index)), until, { path, queryMs: options.queryMs, trace: options.trace });
    if (!selected || selected.fallback)
      return;
    const chosen = new Set(selected.indices), insts = cert.insts.filter((_, i) => chosen.has(i)), slim = { ...cert, insts };
    const discard = new Set(cert.insts.filter((_, i) => !chosen.has(i)).map((c) => c.wit)), clean = withoutCountWitnesses(m, laws, at, discard);
    const instances = seedCountWitnessFlags(m, clean, [{ decls: packet.decls, cert: slim }], true), source = build(instances), goal = mcGoal(source.goal.hyps, source.decls, slim);
    if (!goal)
      return;
    let confirmed = new Map(path), failed;
    const cuts = [];
    for (const index of selected.indices) {
      const bound = candidates.find((c) => c.index === index).bound;
      if (truth(bound, confirmed) === true)
        continue;
      if (bound.op !== "<=") {
        failed = index;
        break;
      }
      const a = linear(bound.a, confirmed), b = linear(bound.b, confirmed);
      if (!a || !b) {
        failed = index;
        break;
      }
      const split = sub(a, b), id = canon(split), noPath = new Map(confirmed).set(id, { lin: split, holds: false });
      const proof = grow(goal, noPath, { nodes: 0, until: Math.min(until, clock() + (options.queryMs ?? 200)), units: options.units });
      if (!("tree" in proof)) {
        failed = index;
        break;
      }
      cuts.push({ split, no: proof.tree });
      confirmed = new Map(confirmed).set(id, { lin: split, holds: true });
    }
    if (failed !== undefined) {
      excluded.add(failed);
      options.trace?.({ stage: "count-core-excluded", index: failed, excluded: [...excluded] });
      continue;
    }
    const closed = grow(goal, confirmed, { nodes: 0, until, units: options.units });
    if (!("tree" in closed))
      return;
    let tree = closed.tree;
    for (const cut of cuts.reverse())
      tree = { split: cut.split, yes: tree, no: cut.no };
    if (!check(goal, tree, path))
      return;
    options.trace?.({ stage: "count-case-certificate", before: cert.insts.length, after: insts.length, indices: selected.indices, hyps: goal.hyps.length });
    return { goal, tree, indices: selected.indices };
  }
  return;
}
function proveCountCases(m, laws, at, cert, until, build, options = {}) {
  return withDeadline(until, () => {
    if (clock() >= until || pastWall())
      return;
    const choice = finiteCountChoice(m);
    if (!choice)
      return;
    const [name, vs] = choice, cuts = [...vs].sort((a, b) => a - b), path = new Map, conditions = [];
    const splitAt = (v) => v ? { [name]: 1, "1": -v } : { [name]: 1 };
    let activeCert = cert, packet = build(at), root = mcGoal(packet.goal.hyps, packet.decls, activeCert);
    if (!root)
      return;
    let goal = { ...root, name: packet.goal.name };
    lemmaRecorder.root(goal);
    lemmaRecorder.phase = "initial";
    const rebuild = () => {
      packet = build(at);
      if (options.propose) {
        const known = new Set(cert.reads.map((r) => JSON.stringify(r.slice(1))));
        let missing = false;
        walkOnce(packet.goal.hyps, (o) => {
          if (o.op === "get" && packet.decls.some((d) => d.map === o.map) && !known.has(JSON.stringify([o.map, o.key])))
            missing = true;
        });
        if (missing && appendCountCert(cert, options.propose(packet.goal, packet.decls), packet.goal.hyps)) {
          at = seedCountWitnessFlags(m, at, [{ decls: packet.decls, cert }], true);
          packet = build(at);
        }
      }
      root = mcGoal(packet.goal.hyps, packet.decls, activeCert);
      if (root)
        goal = { ...root, name: packet.goal.name };
      return !!root;
    };
    const seq = modelSequence(), records = [], branches = [];
    const fallbackPath = new Map(cuts.map((value) => {
      const lin = splitAt(value);
      return [canon(lin), { lin, holds: false }];
    })), fallbackResult = refuteFast(rowsAt(goal, fallbackPath), 256);
    const fallbackTree = fallbackResult?.kind === "refuted" ? { leaf: fallbackResult.steps } : undefined, needed = fallbackTree ? usedHyps(goal, fallbackTree, fallbackPath) : new Set;
    const fallback = fallbackTree ? { goal, tree: fallbackTree, indices: cert.insts.flatMap((_, i) => needed.has(goal.hyps.length - cert.insts.length + i) ? [i] : []) } : undefined;
    options.trace?.({ stage: "case-fallback", proposed: !!fallback });
    const memo = sourceProofMemo(m, packet.goal.name), initial = at, merged = { ...at }, previous = atPoint.on;
    atPoint.on = !options.corePointOnly;
    const coreGrow = (g, end) => {
      const before = atPoint.on;
      atPoint.on = true;
      try {
        return grow(g, new Map, { nodes: 0, until: end, units: options.units });
      } finally {
        atPoint.on = before;
      }
    };
    try {
      for (const [i, value] of [...cuts, undefined].entries()) {
        if (clock() >= until || pastWall())
          return;
        const split = value === undefined ? undefined : splitAt(value), cut = value === undefined ? undefined : { op: "<=", a: x(name), b: { op: "const", value } };
        if (split)
          path.set(canon(split), { lin: split, holds: true });
        const root = new Map(path), tails = options.saturate && value !== undefined ? cuts.filter((v) => v > value) : [];
        for (const v of tails) {
          const lin = splitAt(v);
          path.set(canon(lin), { lin, holds: true });
        }
        const prefix = [...conditions, ...cut ? [cut] : [], ...tails.map((v) => ({ op: "<=", a: x(name), b: { op: "const", value: v } }))];
        branches.push({ prefix, path: new Map(path), root, tails });
        if (shardControl.mode === "run" && value !== shardControl.op) {
          records.push(undefined);
          for (const v of tails)
            path.delete(canon(splitAt(v)));
          if (split) {
            path.set(canon(split), { lin: split, holds: false });
            conditions.push({ op: "not", x: cut });
          }
          continue;
        }
        if (value === undefined && fallback) {
          records.push({ ...fallback, path: new Map(path), from: fallbackPath });
          continue;
        }
        if (options.localModels) {
          at = initial;
          if (!rebuild())
            return;
        }
        let tree, source, from, indices = cert.insts.map((_, j) => j);
        const caseEnd = Math.min(until, clock() + Math.max(600, (until - clock()) / (cuts.length + 1 - i - (fallback ? 1 : 0))));
        const claim = packet.goal.hyps.at(-1), rowDependent = activeWriteKey(m, path) !== undefined && rowPairs(m, cert, path, claim).length > 0;
        tree = rowDependent ? undefined : fieldCase(m, goal, cert, claim, path, Math.min(caseEnd, clock() + 150), (e) => options.trace?.({ value, ...e }));
        if (tree) {
          source = goal;
          from = new Map(path);
        }
        const guard = actionGuard(m, name, value);
        if (!tree && guard) {
          const events = [], begun = clock(), derived = guardCases(m, packet.decls, goal, cert, guard, caseEnd, events, 0, path, { deferCheck: true, claim: packet.goal.hyps.at(-1), memo, conditional: true });
          for (const event of events)
            options.trace?.({ value, ...event });
          options.trace?.({ value, stage: "case-derivations", ms: Math.round(clock() - begun), proposed: !!derived });
          if (derived) {
            tree = derived;
            source = goal;
            from = new Map(path);
          }
        }
        const selected = !tree && selectedCase(m, laws, at, cert, packet, path, caseEnd, build, options);
        if (!tree)
          packet = build(at);
        if (selected) {
          const kept = new Set(selected.indices), slim = { ...cert, insts: cert.insts.filter((_, j) => kept.has(j)) };
          at = seedCountWitnessFlags(m, at, [{ decls: packet.decls, cert: slim }], true);
          tree = selected.tree;
          source = selected.goal;
          from = new Map(path);
          indices = selected.indices;
        }
        for (let round = 0;!tree && round < 6 && clock() < caseEnd && !pastWall(); round++) {
          const part = { name: goal.name, hyps: [...prefix, ...goal.hyps] }, start = clock(), q = seq(part, Math.min(caseEnd, clock() + (options.queryMs ?? 200)));
          options.trace?.({ value, stage: "query", round, hyps: part.hyps.length, ms: Math.round(clock() - start), outcome: "tree" in q ? "tree" : q.stuck, core: q.core?.length });
          if (!("tree" in q) && q.why === REFUTED && q.core?.length && q.core.length <= (options.coreLimit ?? Infinity)) {
            const core = { name: goal.name, hyps: q.core.map((j) => part.hyps[j]) }, out = coreGrow(core, caseEnd);
            options.trace?.({ value, stage: "core", hyps: core.hyps.length, outcome: "tree" in out ? "tree" : out.stuck });
            if ("tree" in out) {
              tree = out.tree;
              source = core;
            }
          }
          if (tree || "tree" in q || q.stuck !== "sat" || !q.witness)
            break;
          const proposed = modelInstances(m, laws, at, part, q.witness, 8);
          const next = proposed && independentCountInstances(m, laws, at, proposed, cert.insts.map((i) => i.wit));
          if (!next)
            break;
          at = next;
          if (!rebuild())
            return;
        }
        if (!tree && clock() < caseEnd && !pastWall()) {
          const part = { name: goal.name, hyps: [...prefix, ...goal.hyps] }, out = grow(part, new Map, { nodes: 0, until: caseEnd, units: options.units });
          options.trace?.({ value, stage: "grow", outcome: "tree" in out ? "tree" : out.stuck });
          if ("tree" in out) {
            tree = out.tree;
            source = part;
          }
        }
        records.push(tree && source ? { goal: source, tree, path: new Map(path), indices, ...from ? { from } : {} } : undefined);
        if (records.at(-1))
          shardControl.finish(records.at(-1), {});
        if (options.localModels)
          for (const [n, terms] of Object.entries(at))
            merged[n] = [...merged[n] ?? [], ...terms.slice(initial[n]?.length ?? 0)];
        for (const v of tails)
          path.delete(canon(splitAt(v)));
        if (split) {
          path.set(canon(split), { lin: split, holds: false });
          conditions.push({ op: "not", x: cut });
        }
      }
      if (options.localModels) {
        at = merged;
        if (!rebuild())
          return;
      }
      const missing = records.flatMap((r, i) => r ? [] : [i]);
      for (const [j, i] of missing.entries()) {
        if (shardControl.mode === "run" && cuts[i] !== shardControl.op)
          continue;
        lemmaRecorder.phase = "retry";
        if (clock() >= until || pastWall())
          break;
        const { prefix, path: p } = branches[i], part = { name: goal.name, hyps: [...prefix, ...goal.hyps] };
        const end = Math.min(until, clock() + (until - clock()) / (missing.length - j)), guard = actionGuard(m, name, cuts[i]), events = [];
        const derived = guard && guardCases(m, packet.decls, goal, cert, guard, end, events, 0, p, { deferCheck: true, claim: packet.goal.hyps.at(-1), memo, conditional: true });
        for (const event of events)
          options.trace?.({ value: cuts[i], ...event });
        if (derived) {
          records[i] = { goal, tree: derived, path: p, from: p, indices: cert.insts.map((_, j) => j) };
          continue;
        }
        const out = grow(part, new Map, { nodes: 0, until: end, units: options.units });
        if ("tree" in out)
          records[i] = { goal: part, tree: out.tree, path: p, indices: cert.insts.map((_, j) => j) };
      }
      shardControl.finish(records[cuts.indexOf(shardControl.op)], {});
      if (records.some((r) => !r))
        return;
      const kept = new Set(records.flatMap((r) => r?.indices ?? [])), discard = new Set(cert.insts.filter((_, i) => !kept.has(i)).map((c) => c.wit));
      activeCert = { ...cert, insts: cert.insts.filter((_, i) => kept.has(i)) };
      at = withoutCountWitnesses(m, laws, at, discard);
      if (!rebuild())
        return;
      options.trace?.({ stage: "count-cases-certificate", before: cert.insts.length, after: activeCert.insts.length });
      const trees = records.map((r, i) => {
        let tree = r && (hasConditionalProof(r.tree) ? transportConditionalProof(r.goal, goal, r.tree, r.from ?? new Map, r.path, Math.min(wallAt(), performance.now() + Math.max(0, until - clock()) * 10)) : widen(r.goal, goal, r.tree, {}, r.from ?? new Map, r.path));
        if (!tree)
          return;
        const { root, tails } = branches[i];
        for (let j = tails.length - 1;j >= 0; j--) {
          const before = new Map(root);
          for (const v of tails.slice(0, j)) {
            const lin = splitAt(v);
            before.set(canon(lin), { lin, holds: true });
          }
          const upper = [...before.keys()].indexOf(canon(splitAt(cuts[i]))), bad = before.size;
          if (upper < 0)
            return;
          tree = { split: splitAt(tails[j]), yes: tree, no: { leaf: [{ kind: "input", index: upper }, { kind: "input", index: bad }, { kind: "combine", a: 0, b: 1, ma: 1, mb: 1 }] } };
        }
        return tree;
      });
      let tree = trees.at(-1);
      for (let i = cuts.length - 1;i >= 0; i--)
        tree = tree && trees[i] ? { split: splitAt(cuts[i]), yes: trees[i], no: tree } : undefined;
      const combined = tree && (hasConditionalProof(tree) ? collectConditionalCertificate(goal, tree, Math.min(wallAt(), performance.now() + Math.max(0, until - clock()) * 10)) : { tree, lemmas: undefined });
      const result = combined && { ...activeCert, ...combined };
      return result && (options.deferCheck || checkMC(packet.goal.hyps, packet.decls, result)) ? { instances: at, cert: result } : undefined;
    } finally {
      atPoint.on = previous;
    }
  });
}

// core/counts.ts
var lazyMode = env.GDP_COUNTS_LAZY ?? "wide";
var pool2 = Number(env.GDP_COUNTS_POOL ?? 1000);
var v2 = (name) => ({ op: "var", name });
var k2 = (value) => ({ op: "const", value });
var json = (t) => JSON.stringify(t);
var one2 = k2(1);
var zero2 = k2(0);
function reads2(t0, map, out = new Map, more) {
  const go = (x) => {
    if (more && !more())
      return false;
    if (!x || typeof x !== "object")
      return true;
    const o = x;
    if (o.op === "get" && map(o.map))
      out.set(json([o.map, o.key]), [o.map, o.key]);
    for (const y of Object.values(o))
      if (!go(y))
        return false;
    return true;
  };
  go(t0);
  return out;
}
var mentions2 = (t, name) => json(t).includes(`"name":${json(name)}`);
function certFor(goal, decls, wide = false, most = wide ? 24 : 10, more, structured = true) {
  const tick = more ?? (() => true), byMap = new Map(decls.map((d) => [d.map, d])), last = goal.hyps.at(-1), lastText = json(last);
  const own = (t) => t.op === "const" || t.op === "var" && lastText.includes(`"name":${json(t.name)}`);
  const all0 = [...reads2(goal.hyps, (mp) => byMap.has(mp), new Map, more).values()], inLast = [...reads2(last, (mp) => byMap.has(mp), new Map, more).keys()];
  const rank = ([mp, t]) => inLast.includes(json([mp, t])) ? 0 : own(t) ? 1 : 2;
  const rs = all0.sort((x, y) => rank(x) - rank(y));
  for (const [mp, t] of [...rs]) {
    if (!tick())
      break;
    if (mp.endsWith("#") && byMap.has(mp.slice(0, -1)) && !rs.some(([m2, t2]) => m2 === mp.slice(0, -1) && json(t2) === json(t)))
      rs.push([mp.slice(0, -1), t]);
  }
  const once = new Set, keyless = (mp) => {
    const d = byMap.get(mp);
    return !mentions2([d.below, d.body], d.j);
  };
  const rs1 = rs.filter(([mp]) => !keyless(mp) || !once.has(mp) && !!once.add(mp));
  const named = rs1.map(([mp, t], i) => ["r" + "$" + i, mp, t]), bound = (r) => json(byMap.get(r[1]).below);
  const insts = [], wits = [], cap = most, initialCap = wide ? Math.min(10, cap) : cap;
  const add = (terms, unit, below) => {
    const w = "w" + "$" + insts.length;
    wits.push(w);
    insts.push({ wit: w, below, terms, unit });
  };
  const post = (r) => r[1].endsWith("#"), ranked = (r) => rank([r[1], r[2]]) <= 1;
  initial: {
    for (const c of named)
      if (post(c))
        for (const a of named) {
          if (!!more && insts.length >= initialCap || !tick())
            break initial;
          if (a !== c && !post(a) && bound(a) === bound(c))
            add([[1, a[0]], [-1, c[0]]], 0, byMap.get(c[1]).below);
        }
    for (const [i, a] of named.entries())
      for (const [j, c] of named.entries()) {
        if (!!more && insts.length >= initialCap || !tick())
          break initial;
        if (i < j && (ranked(a) || ranked(c)) && bound(a) === bound(c) && !post(a) && !post(c))
          add([[1, a[0]], [1, c[0]]], -1, byMap.get(a[1]).below);
      }
    for (const [i, a] of named.entries())
      for (const [j, c] of named.entries()) {
        if (!!more && insts.length >= initialCap || !tick())
          break initial;
        if (i < j && !(ranked(a) || ranked(c)) && bound(a) === bound(c) && !post(a) && !post(c))
          add([[1, a[0]], [1, c[0]]], -1, byMap.get(a[1]).below);
      }
    for (const c of named)
      if (post(c) && rank([c[1], c[2]]) === 0)
        for (const a of named)
          for (const d of named) {
            if (!!more && insts.length >= initialCap || !tick())
              break initial;
            if (a !== d && !post(a) && !post(d) && keyless(a[1]) && keyless(d[1]) && bound(a) === bound(c) && bound(d) === bound(c))
              add([[1, a[0]], [-1, d[0]], [-1, c[0]]], 0, byMap.get(c[1]).below);
          }
  }
  if (wide) {
    insts.splice(10);
    wits.splice(10);
    pairs:
      for (const a of named)
        for (const c of named) {
          if (!!more && insts.length >= cap || !tick())
            break pairs;
          if (a !== c && bound(a) === bound(c) && !(post(c) && !post(a)))
            add([[1, a[0]], [-1, c[0]]], 0, byMap.get(a[1]).below);
        }
    for (const a of named) {
      if (!!more && insts.length >= cap || !tick())
        break;
      add([[1, a[0]]], 0, byMap.get(a[1]).below);
    }
    if (cap > 24) {
      for (const a of named) {
        if (!!more && insts.length >= cap || !tick())
          break;
        add([[1, a[0]]], -1, byMap.get(a[1]).below);
      }
      const had = new Set(insts.map((i) => json([i.terms, i.unit])));
      meets:
        for (const [i, a] of named.entries())
          for (const [j, c] of named.entries()) {
            if (!!more && insts.length >= cap || !tick())
              break meets;
            if (i < j && bound(a) === bound(c) && post(a) === post(c) && !had.has(json([[[1, a[0]], [1, c[0]]], -1])))
              add([[1, a[0]], [1, c[0]]], -1, byMap.get(a[1]).below);
          }
    }
    const cs = structured && insts.length < cap ? countsForReads(decls, named) : undefined;
    if (cs && tick()) {
      const facts = proposeCountFacts(cs, goal, { maxFacts: Math.min(cap, 256), reserved: wits });
      for (const q of facts.insts) {
        if (!!more && insts.length >= cap || !tick())
          break;
        if (q.terms.length >= 3)
          add(q.terms, q.unit, q.below);
      }
      const heads = named.filter((r) => ranked(r)).sort((a, b) => Number(post(b)) - Number(post(a)));
      const carried = named.filter((r) => !post(r) && keyless(r[1]));
      const pairs = heads.flatMap((a) => carried.filter((b) => b !== a && bound(a) === bound(b)).map((b) => [a[0], b[0]]));
      for (const q of proposeCountUnions(cs, pairs, Math.min(cap, 128))) {
        if (!!more && insts.length >= cap || !tick())
          break;
        add(q.terms, q.unit, q.below);
      }
    }
  }
  const picks = [];
  const memberKeys = (pattern, term, key) => {
    if (pattern.op === "var")
      return pattern.name === key ? [term] : [];
    if (pattern.op !== term.op)
      return [];
    const p = pattern, t = term;
    return ["a", "b", "key", "then", "else"].flatMap((k) => p[k] && t[k] ? memberKeys(p[k], t[k], key) : []);
  };
  if (wide)
    for (const r of named) {
      if (!tick())
        break;
      const d = byMap.get(r[1]), at = [...reads2(d.body, () => true, new Map, more).values()].filter(([, key]) => mentions2(key, d.key));
      if (!at.length)
        continue;
      const candidates = [...reads2(goal.hyps, (mp) => at.some(([p]) => p === mp), new Map, more).values()].flatMap(([mp, t]) => at.filter(([p]) => p === mp).flatMap(([, pattern]) => memberKeys(pattern, t, d.key)));
      const gs = [...new Map(candidates.map((t) => [json(t), t])).values()].filter((t) => !mentions2(t, d.key));
      const ws = insts.slice(0, cap).filter((i) => i.terms.some(([, x]) => x === r[0])).map((i) => v2(i.wit)), ts0 = [...gs.slice(0, 3), ...ws.slice(0, 3), ...gs.slice(3), ...ws.slice(3)];
      const ts = [...new Map(ts0.map((t) => [json(t), t])).values()].slice(0, 6);
      for (const t of ts)
        picks.push([r[0], [t]]);
      for (let i = 0;i < ts.length; i++)
        for (let j = i + 1;j < ts.length; j++)
          picks.push([r[0], [ts[i], ts[j]]]);
      if (ts.length > 2)
        picks.push([r[0], ts]);
    }
  const loose = named.some((r) => !insts.slice(0, 10).some((i) => i.terms.some(([, x]) => x === r[0])));
  return { reads: named, insts: insts.slice(0, cap), wits: wits.slice(0, cap), picks, loose };
}

// research/track-m/section18-codec.ts
function pack(data) {
  const goals = [], ids = new Map;
  const body = JSON.stringify(data, (_k, v) => {
    if (v && typeof v.name === "string" && Array.isArray(v.hyps)) {
      let id = ids.get(v);
      if (id === undefined) {
        id = goals.length;
        goals.push(v);
        ids.set(v, id);
      }
      return { $goal: id };
    }
    return v;
  });
  return '{"data":' + body + ',"goals":' + JSON.stringify(goals) + `}
`;
}

// research/track-m/section18-run.ts
var [file, opText, out, mode = "observe"] = process.argv.slice(2);
var op = Number(opText);
if (!file || !out || !Number.isInteger(op))
  throw Error("PACKET OP OUT [observe|control]");
var p = JSON.parse(readFileSync(file, "utf8"));
var { m, laws, at, cert, packet, context, options } = p;
var law = laws.find((l) => packet.goal.name.startsWith(l.name));
var index = laws.indexOf(law);
for (const [i, t] of p.columns.entries())
  if (termColumn(t) !== `\u27E6${i}\u27E7`)
    throw Error("column restoration failed");
mkdirSync(out, { recursive: true });
lemmaRecorder.reset(m, law.name, op, mode === "observe");
shardControl.mode = "run";
shardControl.op = op;
shardControl.capture = () => {};
var result;
var done = {};
shardControl.finish = (x) => {
  result = x;
  throw done;
};
var start = performance.now();
var work2 = fullWork();
var allowance = 5000;
var wallAllowance = 4800;
var events = [];
var error;
try {
  withWall(start + wallAllowance, () => counted(fullRate, () => proveCountCases(m, laws, at, cert, clock() + allowance, (next) => {
    const g = countedObligations(m, laws, { [law.name]: next }, index).find((x) => x.goal.name.endsWith("@step"));
    if (!g)
      throw Error("missing step");
    return g;
  }, { ...options, trace: (e) => events.push(e), propose: (g, ds) => focusCountCert(m, ds, certFor(g, ds, true, 1000), { carried: context.carried ?? undefined, structural: false, frames: true, algebraic: true, requestFrames: true, copyFrames: true, targets: context.targets, claim: g.hyps.at(-1) }) }), true));
} catch (e) {
  if (e !== done)
    error = String(e);
}
var searchUnits = (fullWork() - work2) / fullRate;
var searchWallMs = performance.now() - start;
var auditStart = performance.now();
var checked3 = !!result && checkConditionalProof(result.goal, result.tree, result.from ?? result.path);
var audit = lemmaRecorder.audit();
var output = { ...audit, researchOnly: true, engine: p.revision, law: law.name, op, mode, allowance, wallAllowance, productionLocalCeilings: true, t12: false, closed: checked3, verdict: checked3 ? "closed" : "unknown", searchUnits, searchWallMs, auditWallMs: performance.now() - auditStart, error, events };
Object.assign(output, { root: lemmaRecorder.roots[0], stateFields: Object.keys(m.state) });
var columns = [];
for (let i = 0;; i++) {
  const term = columnTerm(`\u27E6${i}\u27E7`);
  if (term === undefined)
    break;
  columns.push(term);
}
writeFileSync(join2(out, "result.json"), pack({ ...output, columns }));
console.log(JSON.stringify({ ...output, frames: undefined, results: output.results.map((x) => ({ id: x.id, kind: x.kind, sourceChecked: x.sourceChecked, targetChecked: x.targetChecked, eligible: x.eligible, units: x.units })), events: undefined }));
if (error)
  process.exitCode = 1;
