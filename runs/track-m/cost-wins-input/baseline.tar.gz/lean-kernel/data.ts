// A datatype law's cyclic proof (core/data.ts) as a theorem about the datatype as declared. Untrusted: Lean checks
// everything this writes. The export (after the proof's facts and nodes, emit.ts's cyclicToLean) is, in a namespace of
// the item's own:
//   - each datatype as a Lean `inductive` (its constructors in core/data.ts's order, fields `Nat` or a datatype), its
//     tag, size and fields as functions, and a bijection with the naturals (`enc`, `dec`, `dec_enc`, `enc_dec`: those of
//     no field their tag, the rest z + m·q + r, q the fields packed by Data.lean's tupk); a group declared together in
//     `mutual` blocks (its inductives, then its sizes, codes, decodings and the two inverses), its decoding well-founded
//     by (group size + 1)·n + its order (core/data.ts's weakOrder: a datatype decoding n at fields up to n after those)
//   - each function by pattern matching, as written (Lean checks the recursion is structural; functions calling each
//     other in one `mutual` block); a well-founded one (core/data.ts's `termination`) with `termination_by` its measure
//     (Data.lean's `Lx`, ordered by `lexLt`, where it has several components) and `decreasing_by` omega, each match's
//     equation named (`match _h1 : x with`) so the decrease reads the case, an if's condition read as Lean gives it
//   - the model: each map of the encoding as the meaning the facts say it has (a function's map at a key: the function
//     at the arguments the key pairs, decoded, its value encoded)
//   - that every fact of the proof holds of the model, each by unfolding and cases on the values it reads
//   - the law, about the Lean definitions, from cyclic_sound at the law's node
import type {Cyclic} from '../kernel/cyclic.ts'
import {type Ctor, type Data, type DataLaw, type FieldSort, type Fn, type Measure, type Program, type X, type Y, ctorMap, divMap, fieldMap, isDataField, modMap, negMap, posMap, sizeMap, tagMap, weakOrder, whenOf} from '../core/data.ts'

// The folds a measure's components read (core/data.ts's weighted sizes).
const foldsOf = (m: Measure): string[] => m.comps.flatMap(c => (c.fold ? [c.fold.fn] : []))
const name = (s: string) => s.replace(/#(\d+)$/, '_$1').replace(/[^A-Za-z0-9_']/g, '_')
// The function parameters a function reads, through those it calls.
function paramsOf(p: Program): Map<string, string[]> {
  const out = new Map<string, string[]>()
  const of = (f: Fn): string[] => {
    const had = out.get(f.name)
    if (had) return had
    out.set(f.name, [])
    const own = new Set<string>()
    const walk = (t: unknown): void => { if (!t || typeof t !== 'object') return; if (Array.isArray(t)) { t.forEach(walk); return } const o = t as Record<string, unknown>; if (o.op === 'apply') own.add(o.param as string); if (o.op === 'call' && o.fn !== f.name) { const g = p.fns.find(h => h.name === o.fn); if (g) of(g).forEach(x => own.add(x)) } for (const v of Object.values(o)) walk(v) }
    walk(f.body())
    const list = p.params.filter(x => own.has(x))
    out.set(f.name, list)
    return list
  }
  p.fns.forEach(of)
  return out
}

export function dataLean(id: string, law: DataLaw, p: Program, proof: Cyclic, node: number, theorem: string): (ix: (name: string) => number, mx: (map: string) => number) => string {
  return (ix, mx) => {
    const fparams = paramsOf(p)
    const dataOf = (n: string) => p.datas.find(d => d.name === n)!
    const sortLean = (s: unknown) => (s === 'nat' ? 'Nat' : s === 'bool' ? 'Bool' : s === 'int' ? 'Int' : (s as Data).name)
    // An integer's code (core/data.ts's zigzag), and back: Z.enc and Z.dec, defined below where the program reads one.
    const encOf = (s: unknown, v: string) => (s === 'nat' || s === 'bool' ? v : s === 'int' ? `Z.enc ${v}` : `${(s as Data).name}.enc ${v}`)
    // Within a well-founded function's body: its matches' equations, numbered.
    let hyps: {n: number} | undefined
    const hyp = () => (hyps ? `_h${++hyps.n} : ` : '')
    // Terms.
    const lx = (x: X, names: Map<string, string>): string => {
      switch (x.op) {
        case 'var': return names.get(x.name) ?? name(x.name)
        case 'nat': return String(x.value)
        case 'add': return `(${lx(x.a, names)} + ${lx(x.b, names)})`
        case 'sub': return `(${lx(x.a, names)} - ${lx(x.b, names)})`
        case 'min': case 'max': return `(${x.op} ${lx(x.a, names)} ${lx(x.b, names)})`
        case 'mul': return `(${x.k} * ${lx(x.a, names)})`
        case 'prod': return `(${lx(x.a, names)} * ${lx(x.b, names)})`
        case 'mod': case 'imod': return `(${lx(x.a, names)} % ${x.k})`
        case 'div': case 'idiv': return `(${lx(x.a, names)} / ${x.k})`
        case 'int': return `(${x.value} : Int)`
        case 'iadd': return `(${lx(x.a, names)} + ${lx(x.b, names)})`
        case 'isub': return `(${lx(x.a, names)} - ${lx(x.b, names)})`
        case 'ineg': return `(-${lx(x.a, names)})`
        case 'imul': return `((${x.k} : Int) * ${lx(x.a, names)})`
        case 'ofnat': return `((${lx(x.a, names)} : Nat) : Int)`
        case 'if': return `(if ${ly(x.c, names)} then ${lx(x.then, names)} else ${lx(x.else, names)})`
        case 'bool': return ly(x.c, names)
        case 'apply': return `(${name(x.param)} ${lx(x.arg, names)})`
        case 'size': return `(${x.data}.size ${lx(x.of, names)})`
        case 'call': return `(${x.fn}${(fparams.get(x.fn) ?? []).map(q => ` ${name(q)}`).join('')}${x.args.map(a => ` ${lx(a, names)}`).join('')})`
        case 'ctor': { const d = dataOf(x.data), c = d.ctors[x.ctor]!; return x.args.length ? `(${d.name}.${c.name}${x.args.map(a => ` ${lx(a, names)}`).join('')})` : `${d.name}.${c.name}` }
        case 'natmatch': return `(match ${hyp()}${lx(x.of, names)} with | 0 => ${lx(x.zero, names)} | ${name(x.pred)} + 1 => ${lx(x.succ, names)})`
        case 'match': {
          const d = dataOf(x.data)
          return `(match ${hyp()}${lx(x.of, names)} with ${x.cases.map((c, j) => `| .${d.ctors[j]!.name}${c.binds.map(b => ` ${name(b)}`).join('')} => ${lx(c.body, names)}`).join(' ')})`
        }
      }
    }
    const ly = (y: Y, names: Map<string, string>): string => {
      switch (y.op) {
        case '<': case '<=': case '=': return `(decide (${lx(y.a, names)} ${y.op === '<=' ? '≤' : y.op} ${lx(y.b, names)}))`
        case 'i<': case 'i<=': return `(decide (${lx(y.a, names)} ${y.op === 'i<=' ? '≤' : '<'} ${lx(y.b, names)}))`
        case 'and': return `(${y.xs.map(z => ly(z, names)).join(' && ')})`
        // (in a well-founded function's body, a condition's choice as the if it is: its calls' decreases read the condition)
        case 'or': { const w = hyps ? whenOf(y) : undefined; return w ? `(if ${ly(w.c, names)} then ${ly(w.a, names)} else ${ly(w.b, names)})` : `(${y.xs.map(z => ly(z, names)).join(' || ')})` }
        case 'not': return `(!${ly(y.x, names)})`
        case 'is': return `(decide (${y.data}.tag ${lx(y.of, names)} = ${y.ctor}))`
        case 'holds': return lx(y.x, names)
      }
    }
    // The law as a proposition.
    const lp = (y: Y, names: Map<string, string>): string => {
      switch (y.op) {
        case '<': case '<=': case '=': return `${lx(y.a, names)} ${y.op === '<=' ? '≤' : y.op} ${lx(y.b, names)}`
        case 'i<': case 'i<=': return `${lx(y.a, names)} ${y.op === 'i<=' ? '≤' : '<'} ${lx(y.b, names)}`
        case 'and': return y.xs.map(z => `(${lp(z, names)})`).join(' ∧ ')
        case 'or': return y.xs.length === 2 && y.xs[0]!.op === 'not' ? `(${lp(y.xs[0]!.x, names)}) → (${lp(y.xs[1]!, names)})` : y.xs.map(z => `(${lp(z, names)})`).join(' ∨ ')
        case 'not': return `¬(${lp(y.x, names)})`
        case 'is': return `${y.data}.tag ${lx(y.of, names)} = ${y.ctor}`
        case 'holds': return `${lx(y.x, names)} = true`
      }
    }
    const out: string[] = [`namespace ${id}`, 'open Kern', '']
    // Datatypes, their parts and their codes, a group (declared together) at a time: its inductives, and each family of
    // definitions over it (sizes, codes, decoding, the two inverses) in one `mutual` block when it has several.
    const groups: Data[][] = []
    for (const d of p.datas) { const last = groups.at(-1); if (last && last[0]!.group === d.group) last.push(d); else groups.push([d]) }
    const block = (ds: Data[], each: (d: Data) => string[]): string[] => (ds.length > 1 ? ['mutual', ...ds.flatMap(each), 'end'] : ds.flatMap(each))
    const fieldT = (f: {sort: FieldSort}) => (f.sort === 'nat' ? 'Nat' : f.sort === 'int' ? 'Int' : f.sort.data)
    const inG = (d: Data, f: {sort: FieldSort}) => isDataField(f.sort) && d.group.includes(f.sort.data)
    const fieldEnc = (f: {sort: FieldSort}, v: string) => (f.sort === 'nat' ? v : f.sort === 'int' ? `Z.enc ${v}` : `${f.sort.data}.enc ${v}`)
    const fieldDec = (f: {sort: FieldSort}, v: string) => (f.sort === 'nat' ? v : f.sort === 'int' ? `(Z.dec ${v})` : `(${f.sort.data}.dec ${v})`)
    // The integers' codes, where the program reads an integer: a bijection with the naturals, as a datatype's.
    const usesInt = p.ints
    if (usesInt) out.push('abbrev Z := Int', 'def Z.enc (z : Int) : Nat := (2 * z).toNat + (-2 * z - 1).toNat',
      'def Z.dec (n : Nat) : Int := if n % 2 = 0 then ((n / 2 : Nat) : Int) else -((n / 2 : Nat) : Int) - 1',
      '@[simp] theorem Z.dec_enc (z : Int) : Z.dec (Z.enc z) = z := by unfold Z.dec Z.enc; split <;> omega',
      '@[simp] theorem Z.enc_dec (n : Nat) : Z.enc (Z.dec n) = n := by unfold Z.dec Z.enc; split <;> omega',
      '-- The code core/data.ts writes for a value p − n (codeOfPair), read back.',
      '@[simp] theorem Z.dec_pair (p n : Nat) : Z.dec (2 * (p - n) + (2 * (n - p) - 1)) = (p : Int) - n := by unfold Z.dec; split <;> omega',
      '@[simp] theorem Z.dec_two (p : Nat) : Z.dec (2 * p) = p := by unfold Z.dec; split <;> omega', '')
    const pat = (d: Data, j: number, used: (i: number) => string | undefined) => `.${d.ctors[j]!.name}${d.ctors[j]!.fields.map((_, i) => ` ${used(i) ?? '_'}`).join('')}`
    for (const ds of groups) {
      const mutualG = ds.length > 1, order = mutualG ? weakOrder(ds) : new Map<string, number>()
      // Decoding n reads fields at codes at most (n − z) / m: below n, or (a weak datatype) at most n, whose measure then
      // numbers it after the group's datatypes its fields name.
      const measure = (d: Data) => (mutualG ? `${ds.length + 1} * n + ${order.get(d.name)!}` : 'n')
      const inductive = (d: Data) => [`inductive ${d.name} where`, ...d.ctors.map(c => `  | ${c.name}${c.fields.map(f => ` (${f.name} : ${fieldT(f)})`).join('')} : ${d.name}`)]
      if (mutualG) out.push(...block(ds, inductive), `deriving instance DecidableEq for ${ds.map(d => d.name).join(', ')}`, '')
      else out.push(...inductive(ds[0]!), 'deriving DecidableEq', '')
      for (const d of ds) out.push(`def ${d.name}.tag : ${d.name} → Nat`, ...d.ctors.map((_, j) => `  | ${pat(d, j, () => undefined)} => ${j}`))
      out.push(...block(ds, d => [`def ${d.name}.size : ${d.name} → Nat`, ...d.ctors.map((c, j) => `  | ${pat(d, j, i => (inG(d, c.fields[i]!) ? `x${i}` : undefined))} => 1${c.fields.flatMap((f, i) => (inG(d, f) ? [` + ${fieldT(f)}.size x${i}`] : [])).join('')}`)]))
      // (a size is at least 1: what a well-founded decrease by a field reads of the other fields)
      for (const d of ds) out.push(`theorem ${d.name}.size_pos (x : ${d.name}) : 0 < ${d.name}.size x := by cases x <;> simp only [${d.name}.size] <;> omega`)
      const z = (d: Data) => d.nullary, m = (d: Data) => d.ctors.length - d.nullary
      const codeOf = (c: Ctor) => `tupk [${c.fields.map((f, i) => fieldEnc(f, `x${i}`)).join(', ')}]`
      out.push(...block(ds, d => [`def ${d.name}.enc : ${d.name} → Nat`, ...d.ctors.map((c, j) => (j < z(d) ? `  | ${pat(d, j, () => undefined)} => ${j}` : `  | ${pat(d, j, i => `x${i}`)} => ${z(d)} + ${m(d)} * ${codeOf(c)} + ${j - z(d)}`))]))
      for (const d of ds) for (const [j, c] of d.ctors.entries()) for (const [i, f] of c.fields.entries()) out.push(`def ${d.name}.${c.name}_${f.name} : ${d.name} → Nat`, ...d.ctors.map((_, j2) => (j2 === j ? `  | ${pat(d, j2, i2 => (i2 === i ? 'v' : undefined))} => ${fieldEnc(f, 'v')}` : `  | ${pat(d, j2, () => undefined)} => 0`)))
      // dec: those of no field by their number, the rest by z + m·q + r.
      const q = (d: Data) => `((n - ${z(d)}) / ${m(d)})`
      const recCalls = (d: Data) => d.ctors.flatMap(c => c.fields.flatMap((f, i) => (inG(d, f) ? [[c.fields.length, i]] : [])))
      const datCalls = (d: Data) => d.ctors.flatMap(c => c.fields.flatMap((f, i) => (f.sort !== 'nat' ? [[c.fields.length, i, isDataField(f.sort) ? f.sort.data : 'Z'] as const] : [])))
      const wf = (d: Data) => (ds.some(x => recCalls(x).length) ? [`termination_by ${measure(d)}`, ...(recCalls(d).length ? [`decreasing_by all_goals first ${recCalls(d).map(([kk, i]) => `| (have := tup_le ${kk} ${i} ${q(d)}; omega)`).join(' ')}`] : [])] : [])
      out.push(...block(ds, d => {
        const build = (j: number) => { const c = d.ctors[j]!; return `.${c.name}${c.fields.map((f, i) => { const t = `(tup ${q(d)} ${c.fields.length} ${i})`; return ` ${fieldDec(f, t)}` }).join('')}` }
        const nullary = (j: number): string => (j === z(d) - 1 ? `.${d.ctors[j]!.name}` : `if n = ${j} then .${d.ctors[j]!.name} else ${nullary(j + 1)}`)
        const rest = (r: number): string => (r === m(d) - 1 ? build(z(d) + r) : `if h${r + 1} : (n - ${z(d)}) % ${m(d)} = ${r} then ${build(z(d) + r)} else ${rest(r + 1)}`)
        return [`def ${d.name}.dec (n : Nat) : ${d.name} :=\n  ${z(d) ? `if h0 : n < ${z(d)} then ${nullary(0)} else ` : ''}${m(d) ? rest(0) : `.${d.ctors[0]!.name}`}`, ...wf(d)]
      }), '')
      // dec (enc x) = x, by structural induction; enc (dec n) = n, by well-founded recursion on n.
      out.push(...block(ds, d => [`theorem ${d.name}.dec_enc : ∀ x : ${d.name}, ${d.name}.dec (${d.name}.enc x) = x`, ...d.ctors.flatMap((c, j) => {
        if (j < z(d)) return [`  | ${pat(d, j, () => undefined)} => by rw [${d.name}.dec]; simp [${d.name}.enc]`]
        const code = codeOf(c), full = `${z(d)} + ${m(d)} * ${code} + ${j - z(d)}`
        const ihs = c.fields.flatMap((f, i) => (inG(d, f) ? [`have ih${i} := ${fieldT(f)}.dec_enc x${i}`] : []))
        return [`  | ${pat(d, j, i => `x${i}`)} => by`, `    rw [${d.name}.dec]`, ...ihs.map(h => `    ${h}`),
          `    have e1 : (${full} - ${z(d)}) / ${m(d)} = ${code} := by omega`, `    have e2 : (${full} - ${z(d)}) % ${m(d)} = ${j - z(d)} := by omega`,
          // (normalized as the goal will be: a constructor of one field's code, tupk [a], is a itself there)
          `    try simp only [tupk, tup, Nat.add_sub_cancel, Nat.add_sub_cancel_left] at e1 e2`,
          `    simp [${d.name}.enc, e1, e2, tupk, tup${c.fields.flatMap((f, i) => (inG(d, f) ? [`, ih${i}`] : [])).join('')}]`]
      })]))
      for (const d of ds) {
        const D = d.name
        out.push(`@[simp] theorem ${D}.dec_enc' (x : ${D}) : ${D}.dec (${D}.enc x) = x := ${D}.dec_enc x`,
          `@[simp] theorem ${D}.enc_inj (a b : ${D}) : ${D}.enc a = ${D}.enc b ↔ a = b := ⟨fun h => by rw [← ${D}.dec_enc a, h, ${D}.dec_enc], fun h => h ▸ rfl⟩`)
        for (let j = 0; j < z(d); j++) out.push(`@[simp] theorem ${D}.dec_${j} : ${D}.dec ${j} = .${d.ctors[j]!.name} := by rw [${D}.dec]; simp`, `@[simp] theorem ${D}.enc_${j} : ${D}.enc .${d.ctors[j]!.name} = ${j} := rfl`)
      }
      out.push(...block(ds, d => [`theorem ${d.name}.enc_dec (n : Nat) : ${d.name}.enc (${d.name}.dec n) = n := by`, `  rw [${d.name}.dec]`, `  repeat' split`, `  all_goals (try simp only [${d.name}.enc])`,
        ...datCalls(d).map(([kk, i, F]) => `  all_goals (try rw [${F}.enc_dec (tup ${q(d)} ${kk} ${i})])`),
        `  all_goals (first | omega | (simp [tupk, tup] <;> omega))`, ...wf(d)]), '')
    }
    // The values of a datatype a body's matches bind, by their Lean names.
    const bindsOf = (body: X): [string, Data][] => {
      const out2: [string, Data][] = []
      const go = (t: unknown): void => { if (!t || typeof t !== 'object') return; if (Array.isArray(t)) { t.forEach(go); return } const o = t as X; if (o.op === 'match') { const d = dataOf(o.data); o.cases.forEach((c, j) => c.binds.forEach((b, i) => { const fs = d.ctors[j]!.fields[i]!.sort; if (isDataField(fs)) out2.push([name(b), dataOf(fs.data)]) })) } for (const v of Object.values(o)) go(v) }
      go(body)
      return out2
    }
    // The functions, as declared: those of a ring (calling each other) in one `mutual` block, where its last is.
    const fnDef = (f: Fn) => {
      const names = new Map(f.params.map(q => [`${f.name}.${q.name}`, name(q.name)]))
      const m = f.decreases === undefined ? f.measure : undefined
      // (nested recursion read through an invariant, Data.lean's wf_fix_inv_unique: `termination_by` can't read a call's
      // value, research/termination/Nested.lean defines such a function through the theorem by hand)
      if (f.decreases === undefined && p.fns.some(g => f.ring.includes(g.name) && g.decreases === undefined && g.termination?.invariant)) throw new Error(`${f.name}: nested recursion through an invariant isn't exported to Lean yet`)
      hyps = m && {n: 0}
      const body = lx(f.body(), names)
      hyps = undefined
      const head = `def ${f.name}${(fparams.get(f.name) ?? []).map(q => ` (${name(q)} : Nat → Nat)`).join('')}${f.params.map(q => ` (${name(q.name)} : ${sortLean(q.sort)})`).join('')} : ${sortLean(f.ret)} :=\n  ${body}`
      if (!m) return head
      // The measure, each component Σ coef·size + c (its negative part subtracted, as the kernel reads it).
      const comp = (c: Measure['comps'][number]) => {
        // (an integer's size: Int.toNat, as core/data.ts's measureI reads it)
        const term = (i: number) => { const q = f.params[i]!, t = q.sort === 'nat' ? name(q.name) : q.sort === 'int' ? `(${name(q.name)}).toNat` : `(${(q.sort as Data).name}.size ${name(q.name)})`, k = Math.abs(c.coef[i]!); return k === 1 ? t : `${k} * ${t}` }
        const pos = [...c.coef.flatMap((k, i) => (k > 0 ? [term(i)] : [])), ...(c.c > 0 ? [String(c.c)] : [])], neg = [...c.coef.flatMap((k, i) => (k < 0 ? [term(i)] : [])), ...(c.c < 0 ? [String(-c.c)] : [])]
        // (a fold's value, core/data.ts's weighted size: the function defined for it, before this one)
        if (c.fold) pos.push(`(${c.fold.fn} ${name(f.params[c.fold.of]!.name)})`)
        const sum = (ts: string[]) => (ts.length ? ts.join(' + ') : '0')
        return neg.length ? `(${sum(pos)} - (${sum(neg)}))` : `(${sum(pos)})`
      }
      // (the folds a measure reads unfolded with the sizes)
      const sizes = [...p.datas.map(d => `, ${d.name}.size`), ...foldsOf(m).map(g => `, ${g}`)].join(''), lemmas = decLemmas(f)
      const withLemmas = lemmas.length ? ` | (${lemmas.map(l => `have := @${l.name}`).join('; ')}; simp_all [lexLt${sizes}] <;> omega)` : ''
      // each value of a datatype the body names (a parameter, a field a match binds) at least 1 in size, where it is in scope
      const named: [string, Data][] = [...f.params.flatMap(q => (typeof q.sort === 'object' ? [[name(q.name), q.sort as Data] as [string, Data]] : [])), ...bindsOf(f.body())]
      const pos = named.length ? ` | (${named.map(([v, d]) => `(try have := ${d.name}.size_pos ${v})`).join('; ')}; simp_all [lexLt${sizes}] <;> omega)` : ''
      return `${head}\ntermination_by ${m.comps.length === 1 ? comp(m.comps[0]!) : `Lx.mk [${m.comps.map(comp).join(', ')}]`}\ndecreasing_by all_goals first | (simp_all [lexLt${sizes}] <;> omega) | omega${withLemmas}${pos}`
    }
    // (a well-founded function's decrease lemmas before it, or before its ring's `mutual` block)
    const lemmasBefore = (fs: Fn[]) => fs.flatMap(f => (f.decreases === undefined && f.measure ? decLemmas(f) : []).map(l => `${l.text}\n`))
    // A well-founded function's obligations that read other functions (a call on a filter of the tail), each a lemma
    // about the Lean definitions before it, by induction on the variable the kernel's proof inducted on (where it did),
    // then the definitions unfolded, each if split, omega.
    // A size law an obligation's proof used (core/data.ts's sizeLaws): a lemma about the function it reads, by functional
    // induction on its first variable (else plain induction), each case unfolded, split, omega; the obligation's theorem
    // then has it at each of its variables of the law's sorts.
    const decLemmas = (f: Fn): {name: string, text: string}[] => (f.termination?.obligations ?? []).flatMap((o, i) => {
      if (!JSON.stringify(o.law.holds).includes('"op":"call"')) return []
      const names = new Map(o.law.vars.map(v => [v.name, name(v.name)]))
      // (the functions f reaches outside its ring, and the folds its measure reads: those defined before it, a function
      // after it not yet in scope)
      const reach = new Set<string>(), go = (g: string) => { if (reach.has(g)) return; reach.add(g); walk(p.fns.find(h => h.name === g)?.body(), t => { if (t.op === 'call') go(t.fn as string) }) }
      go(f.name)
      if (f.measure) foldsOf(f.measure).forEach(go)
      const on = o.scheme?.match(/ on ([^,]+)/)?.[1], fnSimp = p.fns.filter(g => reach.has(g.name) && !f.ring.includes(g.name)).map(g => g.name).join(', ')
      const sizeSimp = p.datas.map(d => `${d.name}.size`).join(', ')
      // (omega, else the hypotheses simplified with the goal first: a lexicographic disjunction whose first part is decided)
      const close = `(try simp only [${fnSimp}] at *) <;> (repeat' split) <;> (try simp only [${sizeSimp}] at *) <;> first | omega | (simp_all [${sizeSimp}] <;> omega)`
      const laws = (o.lemmaLaws ?? []).map((l, j) => {
        const lnames = new Map(l.vars.map(v => [v.name, name(v.name)])), id = `${f.name}_dec${i + 1}_law${j + 1}`
        let g: string | undefined
        walk(l.holds, t => { if (t.op === 'call' && !g) g = t.fn as string })
        const v0 = name(l.vars.find(v => typeof v.sort === 'object')?.name ?? l.vars[0]!.name), simp = `simp_all [${[g, ...fnSimp.split(', ')].filter(Boolean).join(', ')}, ${sizeSimp}]`
        const others = l.vars.filter(v => name(v.name) !== v0).map(v => lnames.get(v.name)!)
        // (a function of several arguments by its own recursion on all of them: a merge's, on both heaps)
        const all = l.vars.map(v => lnames.get(v.name)!), joint = all.length > 1 ? [`induction ${all.join(', ')} using ${g}.induct`] : []
        const tries = [`induction ${v0} using ${g}.induct`, ...joint, `induction ${v0}`, ...(others.length ? [`induction ${v0} generalizing ${others.join(' ')}`] : [])]
        // (an if the definition's case reads split, its sizes unfolded again)
        const text = `theorem ${id}${l.vars.map(v => ` (${lnames.get(v.name)} : ${sortLean(v.sort)})`).join('')} :\n    ${lp(l.holds, lnames)} := by\n  first ${tries.map(t => `| (${t} <;> ${simp} <;> (repeat' split) <;> (try simp_all [${sizeSimp}]) <;> omega)`).join(' ')}`
        // at every tuple of the obligation's variables of the law's sorts
        const at = l.vars.reduce<string[][]>((acc, v) => acc.flatMap(a => o.law.vars.filter(w => sortLean(w.sort) === sortLean(v.sort)).map(w => [...a, names.get(w.name)!])), [[]]).slice(0, 16)
        return {id, text, haves: at.map(as => `(have := ${id} ${as.join(' ')})`)}
      })
      // (and each value of a datatype the obligation names at least 1 in size: a halving's bound reads it)
      const haves = [...laws.flatMap(l => l.haves), ...(laws.length ? o.law.vars.flatMap(v => (typeof v.sort === 'object' ? [`(have := ${(v.sort as Data).name}.size_pos ${names.get(v.name)})`] : [])) : [])]
      return [...laws.map(l => ({name: l.id, text: l.text})), {name: `${f.name}_dec${i + 1}`, text: `theorem ${f.name}_dec${i + 1}${o.law.vars.map(v => ` (${name(v.name)} : ${sortLean(v.sort)})`).join('')} :\n    ${lp(o.law.holds, names)} := by\n  ${haves.length ? `${haves.join('; ')}; ` : ''}${on && names.has(on) ? `induction ${names.get(on)} <;> ` : ''}first | omega | (${close})`}]
    })
    const walk = (t: unknown, fn: (o: Record<string, unknown>) => void): void => { if (!t || typeof t !== 'object') return; if (Array.isArray(t)) { t.forEach(x => walk(x, fn)); return } fn(t as Record<string, unknown>); for (const v of Object.values(t)) walk(v, fn) }
    // (the folds a measure reads, and the folds they call, first: each is structural and calls only folds before it)
    const folds = new Set<string>()
    const addFold = (g: string) => { if (folds.has(g)) return; folds.add(g); walk(p.fns.find(h => h.name === g)?.body(), t => { if (t.op === 'call' && t.fn !== g) addFold(t.fn as string) }) }
    for (const f of p.fns) if (f.decreases === undefined && f.measure) foldsOf(f.measure).forEach(addFold)
    const fnsInOrder = [...p.fns.filter(f => folds.has(f.name)), ...p.fns.filter(f => !folds.has(f.name))]
    for (const [i, f] of fnsInOrder.entries()) {
      const ring = fnsInOrder.filter(g => f.ring.includes(g.name))
      if (ring.length < 2) { out.push(...lemmasBefore([f]), fnDef(f)); continue }
      if (fnsInOrder.slice(i + 1).some(g => f.ring.includes(g.name))) continue
      out.push(...lemmasBefore(ring), 'mutual', ...ring.map(fnDef), 'end')
    }
    out.push('')
    // The model: each map the proof reads, as its meaning.
    const params = p.params.map(name)
    const pk = (k: string, n: number): string[] => (n === 1 ? [k] : [...pk(`(unpk ${k}).1`, n - 1), `(unpk ${k}).2`])
    const arms: string[] = []
    const arm = (map: string, body: string) => { let j: number; try { j = mx(map) } catch { return } if (j >= 0) arms.push(`  | ${j} => ${body}`) }
    for (const d of p.datas) {
      const D = d.name
      arm(tagMap(D), `${D}.tag (${D}.dec k)`); arm(sizeMap(D), `${D}.size (${D}.dec k)`)
      for (const [j, c] of d.ctors.entries()) {
        c.fields.forEach((f, i) => arm(fieldMap(d, j, i), `${D}.${c.name}_${f.name} (${D}.dec k)`))
        if (c.fields.length) { const as = pk('k', c.fields.length); arm(ctorMap(d, j), `${D}.enc (${D}.${c.name}${c.fields.map((f, i) => ` ${fieldDec(f, as[i]!)}`).join('')})`) }
      }
    }
    for (const f of p.fns) {
      const as = pk('k', f.params.length), call = `(${f.name}${(fparams.get(f.name) ?? []).map(q => ` ${name(q)}`).join('')}${f.params.map((q, i) => (q.sort === 'nat' ? ` ${as[i]}` : q.sort === 'bool' ? ` (${as[i]} = 1)` : q.sort === 'int' ? ` (Z.dec ${as[i]})` : ` (${(q.sort as Data).name}.dec ${as[i]})`)).join('')})`
      arm(f.name, f.ret === 'nat' ? call : f.ret === 'bool' ? `if ${call} then 1 else 0` : encOf(f.ret, call))
    }
    // Division by a constant: Lean's own / and %.
    for (const k2 of p.divisors) { arm(divMap(k2), `k / ${k2}`); arm(modMap(k2), `k % ${k2}`) }
    // An integer's code read as its value's two parts.
    if (p.ints) { arm(posMap, '(Z.dec k).toNat'); arm(negMap, '(-(Z.dec k)).toNat') }
    for (const q of p.params) arm(q, `${name(q)} k`)
    out.push(`noncomputable def model${params.map(q => ` (${q} : Nat → Nat)`).join('')} : Nat → Nat → Nat := fun m k =>\n  match m with\n${arms.join('\n')}\n  | _ => 0`, '')
    // Every fact holds of the model: each key a value (a datatype's, by its code), unfolded, the values' cases.
    const M = `(model${params.map(q => ` ${q}`).join('')})`
    const fnSimp = p.fns.map(f => f.name).join(', ')
    const dataSimp = p.datas.flatMap(d => [`${d.name}.tag`, `${d.name}.size`, ...d.ctors.flatMap(c => c.fields.map(f => `${d.name}.${c.name}_${f.name}`))]).join(', ')
    const sortOfKey = (fact: string, i: number): string => {
      const [kind, what] = [fact.split(' ')[0]!, fact.slice(fact.indexOf(' ') + 1)]
      if (kind === 'shape' || kind === 'eta') return what
      if (kind === 'ctor') { for (const d of p.datas) for (const [j, c] of d.ctors.entries()) if (ctorMap(d, j) === what) { const f = c.fields[i]!; return f.sort === 'nat' ? 'nat' : f.sort === 'int' ? 'Z' : f.sort.data } }
      if (kind === 'fn') { const f = p.fns.find(g => g.name === what)!; const s = f.params[i]!.sort; return s === 'nat' || s === 'bool' ? 'nat' : s === 'int' ? 'Z' : (s as Data).name }
      return 'nat'
    }
    const proofs = proof.facts.map((f, i) => {
      const kind = f.name.split(' ')[0]!
      const ks = `[${f.keys.map(ix).join(', ')}]`
      const head = `  · -- ${f.name}\n    simp only [evalC, evalE${f.keys.map(key => `, override_at ${ks} ${ix(key)} (by decide)`).join('')}]`
      if (kind === 'nullary') return `${head}\n    simp [model, ${dataSimp}]`
      if (kind === 'arith') return `${head}\n    (try simp [model]) <;> omega`
      if (kind === 'zcode') return `${head}\n    simp [model]\n    unfold Z.dec\n    split <;> (try simp) <;> omega`
      if (kind === 'cong') {
        const n = f.keys.length / 2
        return `${head}\n${f.keys.slice(0, n).map((key, q) => `    by_cases h${q} : vals ${ix(key)} = vals ${ix(f.keys[n + q]!)}`).join('\n')}\n    all_goals simp_all`
      }
      const keys = f.keys.map((key, q) => ({v: ix(key), s: sortOfKey(f.name, q), x: `k${q}`}))
      const obtain = keys.filter(x => x.s !== 'nat').map(x => `    obtain ⟨${x.x}, h${x.x}⟩ : ∃ y : ${x.s}, vals ${x.v} = ${x.s}.enc y := ⟨${x.s}.dec (vals ${x.v}), (${x.s}.enc_dec _).symm⟩`)
      const rw = keys.filter(x => x.s !== 'nat').map(x => `h${x.x}`)
      const depth = 2
      const casePat = (D: string, dd: number): string => { const d = dataOf(D); return dd <= 0 ? '_' : d.ctors.map(c => (c.fields.length ? `⟨${c.fields.map(fl => (isDataField(fl.sort) ? casePat(fl.sort.data, dd - 1) : '_')).join(', ')}⟩` : '_')).join(' | ') }
      // A function recursing on a natural: that argument as 0 or m + 1 (where its match is decided).
      // (a well-founded one: each natural it matches on)
      const fnOfFact = kind === 'fn' ? p.fns.find(g => g.name === f.name.slice(3)) : undefined
      const natSplit = !fnOfFact ? [] : fnOfFact.decreases !== undefined ? (fnOfFact.params[fnOfFact.decreases]!.sort === 'nat' ? [fnOfFact.decreases] : [])
        : fnOfFact.measure ? fnOfFact.params.flatMap((q, j) => (q.sort === 'nat' && JSON.stringify(fnOfFact.body()).includes(`"op":"natmatch","of":{"op":"var","name":${JSON.stringify(`${fnOfFact.name}.${q.name}`)}}`) ? [j] : [])) : []
      const cases = [...natSplit.map((j, q) => `rcases hn${q || ''} : vals ${keys[j]!.v} with _ | m${q || ''}`), ...keys.filter(x => x.s !== 'nat' && x.s !== 'Z').map(x => `rcases ${x.x} with ${casePat(x.s, depth)}`)]
      void i
      return `${head}\n${obtain.join('\n')}${obtain.length ? '\n' : ''}    simp [${[...rw, 'model', 'unpk_fst', 'unpk_snd', 'unpk_sq_fst', 'unpk_sq_snd', 'unpk_sqb_fst', 'unpk_sqb_snd'].join(', ')}]\n${cases.length ? `    ${cases.join(' <;> ')}\n` : ''}    all_goals (simp [${[fnSimp, dataSimp].filter(Boolean).join(', ')}])\n    all_goals (try split) <;> (try simp_all) <;> (try omega)\n    all_goals (try split) <;> (try simp_all) <;> (try omega)\n    all_goals (try (intros; simp_all))${usesInt ? '\n    all_goals (simp only [Z.enc] at *; (repeat\' split) <;> omega)' : ''}`
    })
    out.push(`theorem facts_hold${params.map(q => ` (${q} : Nat → Nat)`).join('')} (env : Nat → Nat) : FactsHold ${id}_facts env ${M} := by`,
      `  intro fa hfa vals`, `  simp only [${id}_facts, _root_.List.mem_cons, _root_.List.not_mem_nil, or_false] at hfa`,
      `  rcases hfa with ${proof.facts.map(() => 'rfl').join(' | ')}`, ...proofs, '')
    // The law, about the definitions.
    const vars = law.vars, lnames = new Map(vars.map(x => [x.name, name(x.name)]))
    const env = vars.reduceRight((acc, x) => `if i = ${ix(x.name)} then ${encOf(x.sort, name(x.name))} else ${acc}`, '0')
    const nd = `${id}_node${node}`
    out.push(`theorem ${theorem}${params.map(q => ` (${q} : Nat → Nat)`).join('')}${vars.map(x => ` (${name(x.name)} : ${sortLean(x.sort)})`).join('')} :\n    ${lp(law.holds, lnames)} := by`,
      `  have h := ${id}_sound ${M} (fun i => ${env}) (facts_hold${params.map(q => ` ${q}`).join('')} _) _ ${nd}_mem (by simp [${nd}_hyps, ${id}_hyps${node}])`,
      `  rw [${nd}_concl] at h`,
      `  simp [${id}_concl${node}, evalC, evalE, model, unpk_fst, unpk_snd, unpk_sq_fst, unpk_sq_snd, unpk_sqb_fst, unpk_sqb_snd] at h`,
      `  first | ${usesInt ? 'omega | ' : ''}simpa using h | grind | (intros; simp_all <;> omega)`, '', `end ${id}`)
    return out.join('\n')
  }
}
