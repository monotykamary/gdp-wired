# The extractor's Python reader (core/extract-py.ts): a module read through Python's own parser (ast) and lowered
# into the shared step IR (core/extract-step.ts's SModule, as JSON on stdout), which one TypeScript executor runs into
# the rule. Nothing here decides what is in the subset beyond the syntax: a construct the IR has no node for becomes
# {"e": "no"} or {"s": "no"} with the reason, refused by the executor only where a step reaches it. The record types
# arguments carry are read from the repository's own modules (their class annotations, never run).
#
#   python3 -I core/py/reader.py '{"root": <repo>, "file": <file>, "names": [<classes or functions>]}'
import ast, builtins, contextlib, functools, importlib, io, json, os, sys, types

BUILTINS = {'min', 'max', 'abs', 'len', 'int', 'float', 'bool', 'str', 'isinstance', 'round', 'sum', 'any', 'all', 'print', 'repr', 'getattr', 'setattr', 'hasattr', 'type', 'list', 'dict', 'set', 'tuple', 'sorted', 'range', 'zip', 'enumerate'}
# Library functions the executor knows (their meaning, not their code).
KNOWN = {'time.time', 'time.monotonic', 'time.perf_counter', 'datetime.datetime.now', 'datetime.timedelta', 'dateutil.relativedelta.relativedelta', 'math.floor', 'math.ceil', 'math.isfinite', 'math.isnan', 'math.isinf', 'threading.Lock', 'threading.RLock', 'asyncio.Lock'}
# The heads of a subscripted type an alias may stand for (`Mode = Literal[...]`).
TYPE_HEADS = {'Literal', 'Optional', 'Union', 'Final', 'Annotated', 'dict', 'Dict', 'Mapping', 'MutableMapping', 'defaultdict', 'OrderedDict', 'list', 'List', 'Sequence',
              'set', 'Set', 'frozenset', 'FrozenSet', 'AbstractSet', 'MutableSet'}
TRANSPARENT = {'staticmethod', 'classmethod', 'property', 'dataclass', 'dataclasses.dataclass', 'override', 'typing.override', 'abstractmethod'}

@functools.lru_cache(maxsize=256)
def source_name(file, root):
  # Stable within a repository, distinct across equal basenames, and shared with the runtime check's source IDs.
  return os.path.relpath(os.path.realpath(file), os.path.realpath(root)).replace(os.sep, '/')

def where(file, n, root):
  return f"{source_name(file, root)}:{getattr(n, 'lineno', 0)}:{getattr(n, 'col_offset', 0) + 1}"

def text(n):
  try: s = ast.unparse(n)
  except Exception: s = type(n).__name__
  s = ' '.join(s.split())
  return s if len(s) <= 60 else s[:57] + '...'

def dotted(n):
  if isinstance(n, ast.Name): return n.id
  if isinstance(n, ast.Attribute):
    b = dotted(n.value)
    return f"{b}.{n.attr}" if b else None
  return None

def mentioned(n):
  """The names a node the subset doesn't read mentions (the variables it may read or write)."""
  return sorted({x.id for x in ast.walk(n) if isinstance(x, ast.Name)})

def injected(d):
  """A parameter's default that marks it an injected dependency: FastAPI's Depends(...), dependency-injector's Provide[...]."""
  f = d.func if isinstance(d, ast.Call) else d.value if isinstance(d, ast.Subscript) else None
  return (dotted(f) or '').split('.')[-1] in ('Depends', 'Provide', 'Inject') if f is not None else False

def missing(q):
  """Why the attribute path q (a module's, `logging.getLo`) fails where it runs, or None: the module object's own method
  (`m.__init__`), or a name a module of Python's own library doesn't have (that module imported to look: the code
  imports it too)."""
  parts = q.split('.')
  for i, n in enumerate(parts[1:], 1):
    if n.startswith('__') and callable(getattr(types.ModuleType, n, None)): return f"{'.'.join(parts[:i + 1])}: the module object's own method (its machinery, outside the subset)"
  if parts[0] not in getattr(sys, 'stdlib_module_names', ()) or parts[0] in ('this', 'antigravity', '__main__'): return None
  try:
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()): o = importlib.import_module(parts[0])
    for i, n in enumerate(parts[1:], 1):
      if hasattr(o, n): o = getattr(o, n); continue
      if not isinstance(o, types.ModuleType): return None
      try:
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()): o = importlib.import_module('.'.join(parts[:i + 1]))
      except ImportError: return f"{'.'.join(parts[:i + 1])}: {'.'.join(parts[:i])} has no {n} (an AttributeError where it runs)"
  except Exception: return None
  return None

class Repo:
  """The repository's modules, parsed once each, for the classes an annotation names."""
  def __init__(self, root):
    self.root, self.trees = root, {}
  def path_of(self, mod):
    base = os.path.join(self.root, *mod.split('.'))
    for p in (base + '.py', os.path.join(base, '__init__.py')):
      if os.path.isfile(p): return p
    return None
  def tree(self, path):
    if path not in self.trees:
      try:
        with open(path, encoding='utf-8') as f: self.trees[path] = ast.parse(f.read(), path)
      except Exception: self.trees[path] = None
    return self.trees[path]
  def module_name(self, path):
    rel = os.path.relpath(path, self.root)[:-3].replace(os.sep, '.')
    return rel[:-9] if rel.endswith('.__init__') else rel

def resolve_from(mod_name, is_pkg, node):
  """The absolute module an `from X import ...` names, relative ones too."""
  if not node.level: return node.module
  parts = mod_name.split('.')
  base = parts if is_pkg else parts[:-1]
  base = base[: len(base) - (node.level - 1)] if node.level > 1 else base
  return '.'.join(base + ([node.module] if node.module else []))

class Module:
  """One module's names: its imports, classes, functions and constants."""
  def __init__(self, repo, path):
    self.repo, self.path, self.tree = repo, path, repo.tree(path)
    self.name = repo.module_name(path)
    self.is_pkg = path.endswith('__init__.py')
    self.imports, self.classes, self.funcs, self.consts = {}, {}, {}, {}
    for n in (self.tree.body if self.tree else []):
      self.scan(n)
    # (the module's variables a function rebinds, `global x`: no constant, every call shares them; and the names the
    # module binds at its top level and in its classes' bodies, or may through `from m import *`: past them and a
    # function's own, a name is a NameError where it runs)
    walk = list(ast.walk(self.tree)) if self.tree else []
    self.rebound = {g for x in walk if isinstance(x, ast.Global) for g in x.names}
    self.star = any(isinstance(x, ast.ImportFrom) and any(a.name == '*' for a in x.names) for x in walk)
    self.bound, todo = set(self.rebound), list(self.tree.body if self.tree else [])
    while todo:
      x = todo.pop()
      if isinstance(x, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)): self.bound.add(x.name)
      if isinstance(x, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda, ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)): continue
      if isinstance(x, ast.Name) and not isinstance(x.ctx, ast.Load): self.bound.add(x.id)
      if isinstance(x, (ast.Import, ast.ImportFrom)): self.bound |= {(a.asname or a.name).split('.')[0] for a in x.names}
      if isinstance(x, (ast.ExceptHandler, ast.MatchAs, ast.MatchStar)) and x.name: self.bound.add(x.name)
      if isinstance(x, ast.MatchMapping) and x.rest: self.bound.add(x.rest)
      todo.extend(x.body if isinstance(x, ast.ClassDef) else ast.iter_child_nodes(x))
  def scan(self, n):
    if isinstance(n, ast.Import):
      for a in n.names: self.imports[(a.asname or a.name).split('.')[0]] = ('module', a.name if a.asname else a.name.split('.')[0])
    elif isinstance(n, ast.ImportFrom):
      m = resolve_from(self.name, self.is_pkg, n)
      for a in n.names: self.imports[a.asname or a.name] = ('name', m, a.name)
    elif isinstance(n, ast.ClassDef): self.classes[n.name] = n
    elif isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)): self.funcs[n.name] = n
    elif isinstance(n, (ast.Assign, ast.AnnAssign)):
      targets = n.targets if isinstance(n, ast.Assign) else [n.target]
      for t in targets:
        if isinstance(t, ast.Name) and n.value is not None: self.consts[t.id] = n.value
    elif type(n).__name__ == 'TypeAlias' and isinstance(n.name, ast.Name): self.consts[n.name.id] = n.value  # `type X = ...` (3.12)
    elif isinstance(n, ast.If):
      # `if TYPE_CHECKING:` imports and aliases: what the names are for the types (its else, `X = Any`, yields to it).
      for m in n.orelse + n.body: self.scan(m)

class Reader:
  def __init__(self, root, file):
    self.repo = Repo(root)
    self.mod = Module(self.repo, os.path.abspath(file))
    self.file = os.path.abspath(file)
    self.recs, self.funcs = {}, {}
    self.local_stack = []
    self.caught = []  # (the names the handlers being read bind their exceptions to)
    self.based, self.supers, self.defs, self.local_imps = set(), [], {}, []  # (the bases read as bases; the bases of the class whose method is read)
    self.class_mros, self.class_attrs, self.class_bound = {}, {}, {}
    self.class_fields, self.class_methods, self.class_rets = {}, {}, {}
    self.class_collections = {}

  # --- types -------------------------------------------------------------------------------------------------------
  def find_class(self, mod, name, depth=0):
    """A class a module names, through its imports (re-exports too): (module, ClassDef) or None."""
    if depth > 6 or mod is None: return None
    if name in mod.classes: return (mod, mod.classes[name])
    imp = mod.imports.get(name)
    if imp and imp[0] == 'name':
      p = self.repo.path_of(imp[1])
      if p:
        sub = Module(self.repo, p) if p != mod.path else mod
        return self.find_class(sub, imp[2], depth + 1)
    if name in mod.consts and isinstance(mod.consts[name], ast.Name):  # an alias: X = Y
      return self.find_class(mod, mod.consts[name].id, depth + 1)
    return None
  def const_map(self, v, mod, p):
    """A module's constant mapping of string keys to constants (a dict literal, or MappingProxyType of one): the dict
    literal itself, made where it is read (a write to it is a write to no variable, refused)."""
    if isinstance(v, ast.Call) and (dotted(v.func) or '').split('.')[-1] == 'MappingProxyType' and len(v.args) == 1 and not v.keywords: v = v.args[0]
    if not isinstance(v, ast.Dict) or not v.keys: return None
    if not all(isinstance(k, ast.Constant) and isinstance(k.value, str) for k in v.keys): return None
    if not all(isinstance(x, ast.Constant) and isinstance(x.value, (str, int, bool)) for x in v.values): return None
    return {'e': 'dict', 'keys': [self.expr(k, mod) for k in v.keys], 'vals': [self.expr(x, mod) for x in v.values], 'const': True, 'p': p}
  def find_const(self, mod, name, p, depth=0):
    """A constant mapping another module of the repository defines, through its imports (re-exports too)."""
    imp = mod.imports.get(name)
    if depth > 6 or not imp or imp[0] != 'name': return None
    path = self.repo.path_of(imp[1])
    if not path: return None
    sub = Module(self.repo, path) if path != mod.path else mod
    if imp[2] in sub.consts: return self.const_map(sub.consts[imp[2]], sub, p)
    return self.find_const(sub, imp[2], p, depth + 1)
  def ret_of(self, modname, name, depth=0):
    """The declared result type of a function a module of the repository defines (through its re-exports), or None."""
    p = self.repo.path_of(modname) if modname else None
    if depth > 6 or not p: return None
    m = Module(self.repo, p) if p != self.mod.path else self.mod
    f = m.funcs.get(name)
    if f is not None: return self.ty(f.returns, m) if f.returns is not None else None
    imp = m.imports.get(name)
    if imp and imp[0] == 'name': return self.ret_of(imp[1], imp[2], depth + 1)
    return None
  def class_constants(self, cdef):
    """Own scalar literals and every name that shadows a base's literal. Mutable values are not constants."""
    values, bound, collections, final_methods = {}, set(), set(), set()
    static = not cdef.keywords and not cdef.decorator_list
    for n in cdef.body:
      if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
        names = {n.name}
      elif isinstance(n, (ast.Assign, ast.AnnAssign, ast.AugAssign)):
        targets = n.targets if isinstance(n, ast.Assign) else [n.target]
        names = {x.id for t in targets for x in ast.walk(t) if isinstance(x, ast.Name) and isinstance(x.ctx, ast.Store)} if not isinstance(n, ast.AnnAssign) or n.value is not None else set()
      elif isinstance(n, ast.Pass) or isinstance(n, ast.Expr) and isinstance(n.value, ast.Constant):
        continue
      else:
        # Control flow, imports and dynamic class-body code may shadow any earlier literal.
        values.clear()
        collections.clear()
        static = False
        continue
      bound.update(names)
      for name in names:
        values.pop(name, None)
        collections.discard(name)
        final_methods.discard(name)
      if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)): final_methods.add(n.name)
      target = n.targets[0] if isinstance(n, ast.Assign) and len(n.targets) == 1 else n.target if isinstance(n, ast.AnnAssign) else None
      value = n.value if isinstance(n, (ast.Assign, ast.AnnAssign)) else None
      if isinstance(target, ast.Name) and isinstance(value, ast.Constant) and isinstance(value.value, (int, float, str, bool, type(None))) and not isinstance(value.value, bytes):
        values[target.id] = value.value
      if isinstance(target, ast.Name) and isinstance(value, (ast.List, ast.Tuple, ast.Dict, ast.Set)):
        collections.add(target.id)
    return values, bound, static, collections, final_methods

  def class_mro(self, q, bases):
    """Python's C3 order, or no inherited constants if a base/order is not known."""
    if len(set(bases)) != len(bases) or any(self.class_mros.get(b) is None for b in bases): return None
    seqs = [list(self.class_mros[b]) for b in bases] + [list(bases)]
    order = [q]
    while any(seqs):
      seqs = [s for s in seqs if s]
      head = next((s[0] for s in seqs if not any(s[0] in t[1:] for t in seqs)), None)
      if head is None: return None
      order.append(head)
      for s in seqs:
        if s and s[0] == head: s.pop(0)
    return order

  def qualified(self, mod, node):
    n = dotted(node)
    if not n: return ''
    h, *tail = n.split('.')
    imp = mod.imports.get(h)
    if not imp: return n
    return '.'.join(([imp[1], imp[2]] if imp[0] == 'name' else [imp[1]]) + tail)
  def orm_kind(self, mod, cdef, seen=None):
    seen = set() if seen is None else seen
    tag = (mod.name, cdef.name)
    if tag in seen: return None
    seen.add(tag)
    for b in cdef.bases:
      q = self.qualified(mod, b)
      if q == 'django.db.models.Model': return 'django'
      if q in ('sqlalchemy.orm.DeclarativeBase', 'sqlalchemy.orm.decl_api.DeclarativeBase'): return 'sqlalchemy'
      name = dotted(b)
      v = mod.consts.get(name)
      if isinstance(v, ast.Call) and self.qualified(mod, v.func) in ('sqlalchemy.orm.declarative_base', 'sqlalchemy.ext.declarative.declarative_base'): return 'sqlalchemy'
      hit = self.find_class(mod, name) if name else None
      if hit:
        k = self.orm_kind(*hit, seen)
        if k: return k
    return None
  def orm_base_safe(self, mod, base, framework, seen=None):
    """Admit only framework bases and empty declarative scaffolding, never a mixin/MRO we omit."""
    q = self.qualified(mod, base)
    if framework == 'django': return q == 'django.db.models.Model'
    if q in ('sqlalchemy.orm.DeclarativeBase', 'sqlalchemy.orm.decl_api.DeclarativeBase'): return True
    name = dotted(base)
    v = mod.consts.get(name)
    if isinstance(v, ast.Call) and self.qualified(mod, v.func) in ('sqlalchemy.orm.declarative_base', 'sqlalchemy.ext.declarative.declarative_base'):
      return not v.args and not v.keywords
    hit = self.find_class(mod, name) if name else None
    if not hit: return False
    bm, cls = hit
    seen = set() if seen is None else seen
    key = (bm.name, cls.name)
    if key in seen or cls.decorator_list or cls.keywords: return False
    seen.add(key)
    for n in cls.body:
      if isinstance(n, ast.Pass) or (isinstance(n, ast.Expr) and isinstance(n.value, ast.Constant) and isinstance(n.value.value, str)): continue
      if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name) and n.targets[0].id == '__abstract__' and isinstance(n.value, ast.Constant) and n.value.value is True: continue
      return False
    return bool(cls.bases) and all(self.orm_base_safe(bm, b, framework, seen) for b in cls.bases)
  def orm_field(self, node, mod, framework):
    target = node.targets[0] if isinstance(node, ast.Assign) and len(node.targets) == 1 else node.target if isinstance(node, ast.AnnAssign) else None
    if not isinstance(target, ast.Name) or not isinstance(node.value, ast.Call): return None
    call = node.value; q = self.qualified(mod, call.func)
    kw = {k.arg: k.value for k in call.keywords}
    true = lambda n: isinstance(kw.get(n), ast.Constant) and kw[n].value is True
    if framework == 'django':
      if not q.startswith('django.db.models.'): return None
      kind = q.rsplit('.', 1)[-1]
      types = {'AutoField': 'int', 'BigAutoField': 'int', 'SmallAutoField': 'int', 'IntegerField': 'int', 'BigIntegerField': 'int', 'SmallIntegerField': 'int', 'PositiveIntegerField': 'int', 'PositiveSmallIntegerField': 'int', 'PositiveBigIntegerField': 'int', 'BooleanField': 'bool', 'CharField': 'str', 'TextField': 'str'}
      t = {'k': types[kind]} if kind in types else {'k': 'opaque', 'why': 'ORM field ' + q + ' is outside the subset'}
      if kind == 'DateTimeField': t = {'k': 'int', 'unit': 'datetime-utc'}
      nullable = true('null')
    elif q in ('sqlalchemy.Column', 'sqlalchemy.orm.mapped_column'):
      ty = next((a for a in call.args if not isinstance(a, ast.Constant)), None)
      tq = self.qualified(mod, ty.func if isinstance(ty, ast.Call) else ty)
      types = {'Integer': 'int', 'BigInteger': 'int', 'SmallInteger': 'int', 'Boolean': 'bool', 'String': 'str', 'Text': 'str'}
      kind = tq.rsplit('.', 1)[-1]
      t = {'k': types[kind]} if tq.startswith('sqlalchemy.') and kind in types else None
      ann = node.annotation if isinstance(node, ast.AnnAssign) else None
      if t is None and q == 'sqlalchemy.orm.mapped_column' and isinstance(ann, ast.Subscript) and self.qualified(mod, ann.value) == 'sqlalchemy.orm.Mapped': t = self.ty(ann.slice, mod)
      if tq == 'sqlalchemy.DateTime':
        aware = isinstance(ty, ast.Call) and any(k.arg == 'timezone' and isinstance(k.value, ast.Constant) and k.value.value is True for k in ty.keywords)
        t = {'k': 'int', 'unit': 'datetime-utc' if aware else 'datetime-naive'}
      t = t or {'k': 'opaque', 'why': 'ORM column ' + (tq or q) + ' is outside the subset'}
      nullable = true('nullable') or ('nullable' not in kw and q == 'sqlalchemy.Column' and not true('primary_key'))
    else: return None
    if nullable and t['k'] != 'opt': t = {'k': 'opt', 'of': t}
    return {'name': target.id, 't': t, 'primary': true('primary_key')}
  def rec_of(self, mod, cdef, base=False):
    """A class as a record type: its fields (annotations, its bases' first), its methods (to resolve calls). A class
    of the file, or a base of one (another module's too: its methods are the class's own), has its methods read."""
    q = f"{mod.name}.{cdef.name}"
    if q in self.recs and not (base and self.recs[q] and None in self.recs[q]['methods'].values() and q not in self.based):
      return q
    if base: self.based.add(q)
    self.defs[q] = (mod, cdef)
    self.recs[q] = None  # (being read)
    fields, methods, bases, kinds, rets = [], {}, [], set(), {}
    own_fields, own_methods, own_rets = {}, {}, {}
    cattrs, bound, static, collections, final_methods = self.class_constants(cdef)
    collections = {name: q for name in collections}
    orm = self.orm_kind(mod, cdef)
    if orm: static = False
    for b in cdef.bases:
      bn = dotted(b.value if isinstance(b, ast.Subscript) else b)
      if orm: continue  # ORM inheritance is schema, never an ordinary constructor.
      if bn in ('TypedDict', 'typing.TypedDict', 'typing_extensions.TypedDict'): kinds.add('typeddict'); static = False; continue
      if bn in ('BaseModel', 'pydantic.BaseModel'): kinds.add('pydantic'); static = False; continue
      if bn in ('Protocol', 'typing.Protocol', 'ABC', 'abc.ABC'): kinds.add('protocol'); static = False; continue
      if bn in ('Generic', 'object', 'Exception'):
        if bn != 'object': static = False
        continue
      hit = self.find_class(mod, bn.split('.')[-1]) if bn else None
      if hit:
        bq = self.rec_of(*hit, base=base or mod.path == self.file)
        if bq and self.recs.get(bq):
          br = self.recs[bq]
          bases.append(bq)
          kinds |= set(br.get('kinds', []))
          for f in br['fields']:
            if not any(g['name'] == f['name'] for g in fields): fields.append(f)
          for m, fid in br['methods'].items(): methods[m] = fid
          rets.update(br.get('rets', {}))
      elif bn:
        kinds.add('outside-base:' + bn)
        static = False
    dataclass = any((dotted(d.func if isinstance(d, ast.Call) else d) or '').split('.')[-1] == 'dataclass' for d in cdef.decorator_list)
    frozen = any(isinstance(d, ast.Call) and any(k.arg == 'frozen' and isinstance(k.value, ast.Constant) and k.value.value for k in d.keywords) for d in cdef.decorator_list)
    # (a dataclass whose == is its fields' unless eq=False says it is identity)
    if any(isinstance(d, ast.Call) and any(k.arg == 'eq' and not (isinstance(k.value, ast.Constant) and k.value.value is True) for k in d.keywords) for d in cdef.decorator_list): kinds.add('eq-identity')
    total = not any(k.arg == 'total' and isinstance(k.value, ast.Constant) and k.value.value is False for k in cdef.keywords)
    # The fields its __init__ sets: annotated there, or set from an annotated argument (a class of another module whose
    # fields aren't declared on the class).
    init = next((n for n in reversed(cdef.body) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == '__init__'), None) if '__init__' in final_methods else None
    if init is not None:
      anns = {x.arg: x.annotation for x in init.args.args + init.args.kwonlyargs if x.annotation is not None}
      for n in ast.walk(init):
        t = None
        if isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Attribute) and isinstance(n.target.value, ast.Name) and n.target.value.id == 'self':
          name, t = n.target.attr, self.ty(n.annotation, mod)
        elif isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Attribute) and isinstance(n.targets[0].value, ast.Name) and n.targets[0].value.id == 'self':
          v = n.value
          if isinstance(v, ast.Name) and v.id in anns: name, t = n.targets[0].attr, self.ty(anns[v.id], mod)
          elif isinstance(v, ast.BoolOp) and isinstance(v.op, ast.Or) and isinstance(v.values[0], ast.Name) and v.values[0].id in anns and not (isinstance(v.values[-1], ast.Constant) and v.values[-1].value is None):
            # `x or DEFAULT`: the argument's type, never None
            name, t = n.targets[0].attr, self.ty(anns[v.values[0].id], mod)
            if t['k'] == 'opt': t = t['of']
        if t is not None:
          own_fields[name] = {'name': name, 't': t, 'init': True}
          fields = [g for g in fields if g['name'] != name] + [own_fields[name]]
    for n in cdef.body:
      of = self.orm_field(n, mod, orm) if orm else None
      if of:
        fields = [g for g in fields if g['name'] != of['name']] + [of]
        own_fields[of['name']] = of
      if not of and isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name):
        ann = n.annotation
        if dotted(ann.value if isinstance(ann, ast.Subscript) else ann) in ('ClassVar', 'typing.ClassVar'): continue
        f = {'name': n.target.id, 't': self.ty(ann, mod)}
        if n.value is not None: f['dflt'] = self.expr(n.value, mod)
        fields = [g for g in fields if g['name'] != f['name']] + [f]
        own_fields[f['name']] = f
      elif isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
        if n.returns is not None:
          rets[n.name] = own_rets[n.name] = self.ty(n.returns, mod)
        else:
          rets.pop(n.name, None)
          own_rets.pop(n.name, None)
        if mod.path == self.file or base:
          fid = f"{q}.{n.name}"
          # (a base's method read where its module is: its positions in its own file, super() its own bases')
          file, self.file, sup, self.supers, dfn, self.defining = self.file, mod.path, self.supers, bases, getattr(self, 'defining', None), q
          try: self.funcs[fid] = self.func(n, mod, cdef.name, fid)
          finally: self.file, self.supers, self.defining = file, sup, dfn
          methods[n.name] = own_methods[n.name] = fid
        else: methods[n.name] = own_methods[n.name] = None  # another module's method: not read
    # Only the last runtime binding is callable. An annotation without a value
    # does not bind; an assignment after a method removes its stale metadata.
    for name in bound - final_methods:
      methods.pop(name, None)
      own_methods.pop(name, None)
      rets.pop(name, None)
      own_rets.pop(name, None)
    self.class_attrs[q], self.class_bound[q] = cattrs, bound
    self.class_collections[q] = collections
    self.class_fields[q], self.class_methods[q], self.class_rets[q] = own_fields, own_methods, own_rets
    order = self.class_mro(q, bases) if static else None
    self.class_mros[q] = order
    if order is not None:
      cattrs, methods, rets, selected_fields, collections = {}, {}, {}, {}, {}
      for owner in reversed(order):
        # Only declarations belong to an owner. A flattened base record can
        # select an ancestor too early in a diamond, or the wrong direct base.
        for name in self.class_bound[owner]:
          cattrs.pop(name, None)
          collections.pop(name, None)
          methods.pop(name, None)
          rets.pop(name, None)
        cattrs.update(self.class_attrs[owner])
        collections.update(self.class_collections[owner])
        methods.update(self.class_methods[owner])
        rets.update(self.class_rets[owner])
        selected_fields.update(self.class_fields[owner])
      fields = list(selected_fields.values())
    # A scalar selected by attribute lookup also shadows an inherited method/property of that name.
    for name in cattrs:
      methods.pop(name, None)
      rets.pop(name, None)
    r = {'name': q, 'short': cdef.name, 'fields': fields, 'methods': methods, 'bases': bases, 'mro': order, 'declared': sorted(bound), 'p': where(mod.path, cdef, self.repo.root), 'cattrs': cattrs, 'classCollections': collections,
         'kinds': sorted(kinds | ({'dataclass'} if dataclass else set()) | ({'frozen'} if frozen else set()) | (set() if total else {'partial'})),
         'own': mod.path == self.file, 'module': mod.name, **({'rets': rets} if rets else {})}
    if orm:
      keys = [f['name'] for f in fields if f.pop('primary', False)]
      if not keys and orm == 'django':
        keys = ['id']; fields.insert(0, {'name': 'id', 't': {'k': 'int'}})
      why = '' if len(keys) == 1 else 'ORM requires one explicit primary key'
      if any(not self.orm_base_safe(mod, b, orm) for b in cdef.bases): why = 'inherited ORM schema or behavior is outside the table boundary'
      if cdef.decorator_list or cdef.keywords: why = 'decorated ORM classes or custom metaclasses are outside the table boundary'
      # Plain display bodies are not erased: explicit calls still read their bodies.
      # Implicit conversions of these records are refused by the step reader.
      def display(n):
        return isinstance(n, ast.FunctionDef) and n.name in ('__str__', '__repr__') and not n.decorator_list and len(n.args.posonlyargs + n.args.args) == 1 and not (n.args.defaults or n.args.kwonlyargs or n.args.vararg or n.args.kwarg)
      if any(isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and (n.decorator_list or (n.name.startswith('__') and not display(n))) for n in cdef.body): why = 'decorated ORM methods or custom magic methods are outside the table boundary'
      if any(isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'objects' for t in n.targets) for n in cdef.body): why = 'custom ORM managers are outside the table boundary'
      r['orm'] = {'framework': orm, 'key': keys[0] if len(keys) == 1 else '', 'why': why}
    self.recs[q] = r
    return q
  def ty(self, a, mod):
    if a is None: return {'k': 'any'}
    if isinstance(a, ast.Constant):
      if a.value is None: return {'k': 'none'}
      if isinstance(a.value, str):
        try: return self.ty(ast.parse(a.value, mode='eval').body, mod)
        except SyntaxError: return {'k': 'opaque', 'why': a.value}
    if isinstance(a, ast.BinOp) and isinstance(a.op, ast.BitOr):
      return self.union([self.ty(a.left, mod), self.ty(a.right, mod)], a)
    if isinstance(a, ast.Subscript):
      head = (dotted(a.value) or '').split('.')[-1]
      args = a.slice.elts if isinstance(a.slice, ast.Tuple) else [a.slice]
      if head in ('Optional',): return self.union([self.ty(args[0], mod), {'k': 'none'}], a)
      if head == 'Union': return self.union([self.ty(x, mod) for x in args], a)
      if head in ('Final', 'Annotated', 'ReadOnly', 'Required', 'NotRequired'): return self.ty(args[0], mod)
      if head == 'Literal':
        if all(isinstance(x, ast.Constant) and isinstance(x.value, str) for x in args): return {'k': 'choice', 'values': [x.value for x in args]}
        return {'k': 'opaque', 'why': f"{text(a)}: a Literal of other than strings"}
      if head in ('dict', 'Dict', 'Mapping', 'MutableMapping', 'defaultdict', 'OrderedDict') and len(args) == 2:
        return {'k': 'map', 'key': self.ty(args[0], mod), 'val': self.ty(args[1], mod), 'py': head}
      if head in ('list', 'List', 'Sequence'): return {'k': 'list', 'of': self.ty(args[0], mod)}
      # (a set: a map of its keys alone, each held or not)
      if head in ('set', 'Set', 'frozenset', 'FrozenSet', 'AbstractSet', 'MutableSet') and len(args) == 1: return {'k': 'map', 'key': self.ty(args[0], mod), 'val': {'k': 'none'}, 'set': True, 'py': head}
      return {'k': 'opaque', 'why': f"{text(a)}"}
    n = dotted(a)
    if self.qualified(mod, a) == 'sqlalchemy.orm.Session': return {'k': 'opaque', 'why': '$orm-session'}
    if n in ('int',): return {'k': 'int'}
    if n in ('float',): return {'k': 'float'}
    if n in ('bool',): return {'k': 'bool'}
    if n in ('str',): return {'k': 'str'}
    if n in ('bytes', 'bytearray'): return {'k': 'str', 'bytes': True}  # (a string of bytes: set and compared, never equal to a str)
    if n in ('None',): return {'k': 'none'}
    if n in ('Final', 'Any', 'typing.Any', 'object'): return {'k': 'any'}
    if n in ('dict', 'Dict'): return {'k': 'opaque', 'why': f"{n} with no key and value types"}
    if n in ('threading.Lock', 'asyncio.Lock', 'Lock'): return {'k': 'lock'}
    al = self.alias_of(mod, n) if n and '.' not in n else None
    if al: return self.ty(al[1], al[0])
    if n:
      hit = self.find_class(mod, n.split('.')[-1]) if '.' not in n or n.split('.')[0] in mod.imports else None
      if hit:
        q = self.rec_of(*hit)
        if q: return {'k': 'rec', 'name': q}
      return {'k': 'opaque', 'why': f"{n}, a type outside the files read"}
    return {'k': 'opaque', 'why': text(a)}
  def const_value(self, mod, v):
    """A constant's value, through constants bound to other constants' names (LONG = IDLE)."""
    for _ in range(6):
      if isinstance(v, ast.Name) and v.id in mod.consts and v.id not in mod.classes and v.id not in mod.funcs: v = mod.consts[v.id]
      else: break
    return v
  def module_const(self, mod, x):
    """`m.NAME` where m is a module of the repository (imported whole, or `from pkg import m`) and NAME one of its
    constants bound to a literal (a number, a string, a bool, None): that literal, else None."""
    if not isinstance(x.value, ast.Name): return None
    imp = mod.imports[x.value.id]
    q = imp[1] if imp[0] == 'module' else f"{imp[1]}.{imp[2]}"
    path = self.repo.path_of(q)
    if not path or path == mod.path: return None
    sub = Module(self.repo, path)
    v = self.const_value(sub, sub.consts.get(x.attr))
    lit = isinstance(v, ast.Constant) or (isinstance(v, ast.UnaryOp) and isinstance(v.op, ast.USub) and isinstance(v.operand, ast.Constant))
    return self.expr(v, mod) if lit and not isinstance(getattr(v, 'value', getattr(getattr(v, 'operand', None), 'value', None)), bytes) else None
  def alias_of(self, mod, name, depth=0):
    """A type alias a module names, through its imports: `Mode = Literal["a", "b"]`, `Key = int | str`, `X: TypeAlias = ...`,
    `type X = ...`: (module, the type it stands for), or None (a class, or a constant that is no type)."""
    if depth > 6 or mod is None or name in mod.classes: return None
    v = mod.consts.get(name)
    if v is not None:
      typing = isinstance(v, ast.Subscript) and (dotted(v.value) or '').split('.')[-1] in TYPE_HEADS
      return (mod, v) if typing or (isinstance(v, ast.BinOp) and isinstance(v.op, ast.BitOr)) else None
    imp = mod.imports.get(name)
    if imp and imp[0] == 'name':
      p = self.repo.path_of(imp[1])
      if p and p != mod.path: return self.alias_of(Module(self.repo, p), imp[2], depth + 1)
    return None
  def union(self, ts, a):
    none = any(t['k'] == 'none' for t in ts)
    rest = [t for t in ts if t['k'] != 'none']
    flat = []
    for t in rest:
      if t['k'] == 'opt': none = True; t = t['of']
      if t not in flat: flat.append(t)
    if len(flat) == 2 and {t['k'] for t in flat} == {'int', 'float'}: flat = [{'k': 'float'}]
    if len(flat) != 1: return {'k': 'opaque', 'why': f"{text(a)}: a union of several types"}
    return {'k': 'opt', 'of': flat[0]} if none else flat[0]

  # --- functions ---------------------------------------------------------------------------------------------------
  def func(self, n, mod, cls, fid):
    self.local_stack.append(set(self.locals_of(n)))
    # (the names the function imports in its body: an exception class raised there resolves through them)
    imps = {}
    for x in ast.walk(n):
      if isinstance(x, ast.ImportFrom):
        m = resolve_from(mod.name, mod.is_pkg, x)
        for a in x.names: imps[a.asname or a.name] = ('name', m, a.name)
    self.local_imps.append(imps)
    try:
      a = n.args
      params = []
      pos = a.posonlyargs + a.args
      dflts = [None] * (len(pos) - len(a.defaults)) + list(a.defaults)
      for i, (x, d) in enumerate(zip(pos, dflts)):
        params.append({'name': x.arg, 't': self.ty(x.annotation, mod), **({'dflt': self.expr(d, mod)} if d is not None else {}), **({'inject': True} if injected(d) else {})})
      for x, d in zip(a.kwonlyargs, a.kw_defaults):
        params.append({'name': x.arg, 't': self.ty(x.annotation, mod), 'kw': True, **({'dflt': self.expr(d, mod)} if d is not None else {}), **({'inject': True} if injected(d) else {})})
      decs = [self.decorator(d) for d in n.decorator_list]
      static = any(d['name'] in ('staticmethod',) for d in decs)
      if cls and not static and params: params[0]['self'] = True
      if a.vararg: params.append({'name': a.vararg.arg, 't': {'k': 'opaque', 'why': '*args'}, 'star': 1})
      if a.kwarg: params.append({'name': a.kwarg.arg, 't': {'k': 'opaque', 'why': '**kwargs'}, 'star': 2})
      body = self.block(n.body, mod)
      return {'id': fid, 'name': n.name, **({'cls': cls} if cls else {}), 'p': where(self.file, n, self.repo.root), 'span': [source_name(self.file, self.repo.root), n.lineno, n.end_lineno],
              'params': params, 'ret': self.ty(n.returns, mod), 'body': body, 'async': isinstance(n, ast.AsyncFunctionDef), 'decorators': decs, 'static': static}
    finally:
      self.local_stack.pop()
      self.local_imps.pop()
  def decorator(self, d):
    f = d.func if isinstance(d, ast.Call) else d
    return {'name': dotted(f) or text(f), 'text': text(d), 'p': where(self.file, d, self.repo.root)}
  def locals_of(self, fn):
    out = {x.arg for x in fn.args.posonlyargs + fn.args.args + fn.args.kwonlyargs}
    if fn.args.vararg: out.add(fn.args.vararg.arg)
    if fn.args.kwarg: out.add(fn.args.kwarg.arg)
    for n in ast.walk(fn):
      if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store): out.add(n.id)
      if isinstance(n, (ast.Import, ast.ImportFrom)):
        for a in n.names: out.add((a.asname or a.name).split('.')[0])
    return out
  # --- statements --------------------------------------------------------------------------------------------------
  def block(self, ss, mod):
    out = []
    for s in ss:
      for r in self.stmt(s, mod):
        if r.get('s') == 'no' and 'names' not in r: r['names'] = mentioned(s)
        out.append(r)
    return out
  def stmt(self, s, mod):
    p = where(self.file, s, self.repo.root)
    E = lambda x: self.expr(x, mod)
    if isinstance(s, ast.Expr):
      if isinstance(s.value, ast.Constant) and (isinstance(s.value.value, str) or s.value.value is Ellipsis): return []  # a docstring, or `...`
      # (a bare yield: where a context manager made by @contextmanager runs the body of the with)
      if isinstance(s.value, ast.Yield) and s.value.value is None: return [{'s': 'yield', 'p': p}]
      return [{'s': 'expr', 'p': p, 'x': E(s.value)}]
    if isinstance(s, ast.Pass): return []
    if isinstance(s, (ast.Assign, ast.AnnAssign)):
      # (a declaration, `x: int`; of a field or an item, `o.f: int`, its object evaluated, and the item's index)
      if s.value is None: return [] if isinstance(s.target, ast.Name) else [{'s': 'expr', 'p': p, 'x': E(y)} for y in ([s.target.value] + ([s.target.slice] if isinstance(s.target, ast.Subscript) else []))]
      targets = s.targets if isinstance(s, ast.Assign) else [s.target]
      x = E(s.value)
      ann = self.ty(s.annotation, mod) if isinstance(s, ast.AnnAssign) else None
      out = []
      for t in targets: out.append({'s': 'set', 'p': p, 'to': self.target(t, mod), 'x': x, **({'t': ann} if ann and ann['k'] != 'any' else {})})
      return out
    if isinstance(s, ast.AugAssign):
      op = self.binop(s.op)
      t = self.target(s.target, mod)
      return [{'s': 'set', 'p': p, 'to': t, 'x': {'e': 'bin', 'op': op, 'x': self.expr(s.target, mod), 'y': E(s.value), 'p': p, 'text': text(s)} if op else {'e': 'no', 'why': f"{text(s)}: {type(s.op).__name__} (outside the subset)", 'p': p}}]
    if isinstance(s, ast.If):
      return [{'s': 'if', 'p': p, 'c': E(s.test), 'then': self.block(s.body, mod), 'else': self.block(s.orelse, mod)}]
    if isinstance(s, ast.Return): return [{'s': 'ret', 'p': p, **({'x': E(s.value)} if s.value is not None else {})}]
    if isinstance(s, ast.Raise):
      # (the class raised and its bases; a bare raise, or of the exception a handler caught, a re-raise)
      x = s.exc.func if isinstance(s.exc, ast.Call) else s.exc
      re = x is None or (isinstance(x, ast.Name) and x.id in self.caught)
      cls = None if re else self.exc_class(x, mod)
      return [{'s': 'fail', 'p': p, 'why': f"raise {text(s.exc) if s.exc else ''}".strip(), **({'x': E(s.exc)} if s.exc else {}), **({'reraise': True} if re else {}),
               **({'cls': cls[0], **({'open': True} if cls[1] else {})} if cls else {})}]
    if isinstance(s, ast.Assert):
      return [{'s': 'if', 'p': p, 'c': E(s.test), 'then': [], 'else': [{'s': 'fail', 'p': p, 'why': f"assert {text(s.test)}"}]}]
    if isinstance(s, (ast.With, ast.AsyncWith)):
      items = [{'x': E(i.context_expr), **({'as': self.target(i.optional_vars, mod)} if i.optional_vars is not None else {})} for i in s.items]
      return [{'s': 'with', 'p': p, 'items': items, 'body': self.block(s.body, mod), 'async': isinstance(s, ast.AsyncWith)}]
    if isinstance(s, ast.Delete):
      return [{'s': 'del', 'p': p, 'x': self.target(t, mod)} for t in s.targets]
    if isinstance(s, (ast.Import, ast.ImportFrom)):
      names = {}
      for a in s.names:
        if isinstance(s, ast.Import): names[(a.asname or a.name).split('.')[0]] = {'mod': a.name if a.asname else a.name.split('.')[0]}
        else:
          m = resolve_from(self.mod.name, self.mod.is_pkg, s)
          ret = self.ret_of(m, a.name)
          names[a.asname or a.name] = {'mod': m, 'name': a.name, **({'ret': ret} if ret else {})}
      return [{'s': 'import', 'p': p, 'names': names}]
    # (a loop over a collection: a fold, where it is over a list the request carries; a while loop isn't one)
    if isinstance(s, ast.For): return [{'s': 'for', 'p': p, 'to': self.target(s.target, mod), 'over': E(s.iter), 'body': self.block(s.body, mod), 'els': self.block(s.orelse, mod)}]
    if isinstance(s, ast.Continue): return [{'s': 'continue', 'p': p}]
    if isinstance(s, ast.Break): return [{'s': 'break', 'p': p}]
    # (a while loop: read where its passes take the first items of the state's ordered collections, as a fold)
    if isinstance(s, ast.While): return [{'s': 'while', 'p': p, 'c': E(s.test), 'body': self.block(s.body, mod), 'els': self.block(s.orelse, mod)}]
    if isinstance(s, ast.AsyncFor): return [{'s': 'no', 'p': p, 'why': "a loop (async for)"}]
    if type(s).__name__ == 'TryStar': return [{'s': 'no', 'p': p, 'why': 'try/except* (exception groups)'}]
    if isinstance(s, ast.Try):
      hs = []
      for h in s.handlers:
        ts = [] if h.type is None else h.type.elts if isinstance(h.type, ast.Tuple) else [h.type]
        cs = [self.exc_class(t, mod) for t in ts]
        self.caught.append(h.name)
        try: body = self.block(h.body, mod)
        finally: self.caught.pop()
        hs.append({'p': where(self.file, h, self.repo.root), 'names': [c[0][0] for c in cs], **({'any': True} if h.type is None else {'mro': cs[0][0], 'raise': [mod.name, text(ts[0])]}),
                   **({'open': True} if cs and cs[0][1] else {}), **({'as': h.name} if h.name else {}), 'body': body})
      return [{'s': 'try', 'p': p, 'body': self.block(s.body, mod), 'handlers': hs, 'els': self.block(s.orelse, mod), 'fin': self.block(s.finalbody, mod)}]
    if isinstance(s, (ast.Global, ast.Nonlocal)): return [{'s': 'no', 'p': p, 'why': f"{type(s).__name__.lower()} (a variable every call shares)"}]
    if isinstance(s, ast.Match): return [{'s': 'no', 'p': p, 'why': 'match'}]
    if isinstance(s, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)): return [{'s': 'no', 'p': p, 'why': f"a {'class' if isinstance(s, ast.ClassDef) else 'function'} defined in a function (a closure)"}]
    return [{'s': 'no', 'p': p, 'why': f"{type(s).__name__} (a statement outside the subset)"}]
  def exc_class(self, x, mod, depth=0):
    """A class an except or a raise names: its qualified name then its bases' ([names], open: some the reader can't know)."""
    d = dotted(x)
    if d is None or depth > 8: return [text(x)], True
    head, *rest = d.split('.')
    local = self.local_imps[-1].get(head) if self.local_imps and depth == 0 and head not in mod.imports else None
    if not rest and head not in mod.imports and head not in mod.classes and not local:
      b = getattr(builtins, head, None)
      if isinstance(b, type) and issubclass(b, BaseException): return [f"builtins.{c.__name__}" for c in b.__mro__ if c is not object], False
    hit = self.find_class(mod, head) if not rest else None
    imp = mod.imports.get(head) or local
    if hit is None and imp:
      q = f"{imp[1]}.{imp[2]}" if imp[0] == 'name' else imp[1]
      q = '.'.join([q, *rest])
      sub = self.repo.path_of(q.rpartition('.')[0])
      hit = self.find_class(Module(self.repo, sub), q.rpartition('.')[2]) if sub else None
      if hit is None: return [q], True
    if hit is None: return [d], True
    cm, cdef = hit
    out, op = [f"{cm.name}.{cdef.name}"], False
    for b in cdef.bases:
      bs, bo = self.exc_class(b, cm, depth + 1)
      out += [n for n in bs if n not in out]; op = op or bo
    return out, op
  def target(self, t, mod):
    p = where(self.file, t, self.repo.root)
    if isinstance(t, ast.Name): return {'e': 'var', 'n': t.id, 'p': p}
    if isinstance(t, ast.Attribute): return {'e': 'get', 'x': self.expr(t.value, mod), 'f': t.attr, 'p': p, 'text': text(t)}
    if isinstance(t, ast.Subscript): return {'e': 'idx', 'x': self.expr(t.value, mod), 'i': self.expr(t.slice, mod), 'p': p, 'text': text(t)}
    if isinstance(t, (ast.Tuple, ast.List)): return {'e': 'tuple', 'xs': [self.target(x, mod) for x in t.elts], 'p': p}
    return {'e': 'no', 'why': f"{text(t)}: an assignment to other than a name, a field or an item", 'p': p}

  # --- expressions -------------------------------------------------------------------------------------------------
  def binop(self, op):
    return {ast.Add: '+', ast.Sub: '-', ast.Mult: '*', ast.FloorDiv: '//', ast.Mod: '%', ast.Div: '/'}.get(type(op))
  def name(self, n, mod, p):
    """What a name is where it is read: a local, a constant, a function or class of the module, an import, a builtin."""
    if self.local_stack and n in self.local_stack[-1]: return {'e': 'var', 'n': n, 'p': p}
    if n in mod.rebound: return {'e': 'no', 'why': f"{n}: a module variable a function rebinds (global {n}), shared by every call", 'p': p}
    if n in mod.funcs: return {'e': 'fn', 'id': n, 'p': p}
    if n in mod.classes:
      q = self.rec_of(mod, mod.classes[n])
      return {'e': 'cls', 'rec': q, 'p': p}
    if n in mod.imports:
      imp = mod.imports[n]
      if imp[0] == 'module': return {'e': 'ext', 'q': imp[1], 'text': n, 'patch': {'mod': mod.name, 'path': [n]}, 'p': p}
      hit = self.find_class(mod, n)
      if hit: return {'e': 'cls', 'rec': self.rec_of(*hit), 'q': f"{imp[1]}.{imp[2]}", 'patch': {'mod': mod.name, 'path': [n]}, 'p': p}
      cm = self.find_const(mod, n, p)
      if cm: return cm
      ret = self.ret_of(imp[1], imp[2])
      return {'e': 'ext', 'q': f"{imp[1]}.{imp[2]}", 'text': n, 'patch': {'mod': mod.name, 'path': [n]}, 'p': p, **({'ret': ret} if ret else {})}
    if n in mod.consts:
      v = mod.consts[n]
      # (a constant bound to another constant's name, LONG = IDLE: that one's value, a few deep)
      for _ in range(6):
        if isinstance(v, ast.Name) and v.id in mod.consts and v.id != n and v.id not in mod.classes and v.id not in mod.funcs: v = mod.consts[v.id]
        else: break
      if isinstance(v, ast.Constant) or (isinstance(v, ast.UnaryOp) and isinstance(v.operand, ast.Constant)): return self.expr(v, mod)
      cm = self.const_map(v, mod, p)
      if cm: return cm
      # (a logger, logging.getLogger(...): its calls never raise, logging handles its handlers' errors itself)
      if isinstance(v, ast.Call) and (dotted(v.func) or '') in ('logging.getLogger', 'getLogger'):
        return {'e': 'ext', 'q': f"{mod.name}.{n}", 'text': n, 'patch': {'mod': mod.name, 'path': [n]}, 'global': True, 'nothrow': True, 'p': p}
      return {'e': 'ext', 'q': f"{mod.name}.{n}", 'text': n, 'patch': {'mod': mod.name, 'path': [n]}, 'global': True, 'p': p}
    if n in ('True', 'False', 'None'): return self.expr(ast.Constant({'True': True, 'False': False, 'None': None}[n]), mod)
    if n in BUILTINS: return {'e': 'builtin', 'n': n, 'p': p}
    if n not in mod.bound and not mod.star and not hasattr(builtins, n) and not (n.startswith('__') and n.endswith('__')):
      return {'e': 'no', 'why': f"{n}: a name the module doesn't define, import or bind (a NameError where it runs)", 'raises': True, 'p': p}
    return {'e': 'ext', 'q': n, 'text': n, 'p': p}
  def expr(self, x, mod):
    r = self.expr1(x, mod)
    if r.get('e') == 'no' and 'names' not in r: r['names'] = mentioned(x)
    return r
  def expr1(self, x, mod):
    p = where(self.file, x, self.repo.root)
    E = lambda y: self.expr(y, mod)
    if isinstance(x, ast.Constant):
      v = x.value
      if isinstance(v, bool): return {'e': 'bool', 'v': v, 'p': p}
      if isinstance(v, int): return {'e': 'int', 'v': str(v), 'p': p}
      if isinstance(v, float):
        if v.is_integer() and abs(v) < 2 ** 53: return {'e': 'int', 'v': str(int(v)), 'float': True, 'p': p}
        return {'e': 'no', 'why': f"{text(x)}: a float that isn't whole (a binary fraction)", 'p': p}
      if isinstance(v, str): return {'e': 'str', 'v': v, 'p': p}
      if v is None: return {'e': 'none', 'p': p}
      return {'e': 'no', 'why': f"{text(x)}: a constant outside the subset", 'p': p}
    if isinstance(x, ast.Name): return self.name(x.id, mod, p)
    if isinstance(x, ast.Attribute):
      if isinstance(x.value, ast.Call) and isinstance(x.value.func, ast.Name) and x.value.func.id == 'super':
        args, owner = x.value.args, getattr(self, 'defining', None)
        valid = not args or (len(args) == 2 and all(isinstance(a, ast.Name) for a in args) and owner and args[0].id == owner.rsplit('.', 1)[-1] and args[1].id == 'self')
        if not owner or not valid or x.value.keywords:
          return {'e': 'no', 'why': f"{text(x)}: super outside its defining instance method", 'p': p}
        # Resolve after this owner in the receiver's MRO, not in the owner's
        # direct bases: cooperative super may dispatch to a sibling mixin.
        return {'e': 'get', 'x': {'e': 'var', 'n': 'self', 'p': p}, 'f': x.attr, 'superFrom': owner, 'p': p, 'text': text(x)}
      d = dotted(x)
      base = d.split('.')[0] if d else None
      q = self.qualified(mod, x)
      if q in KNOWN and not (self.local_stack and base in self.local_stack[-1]): return {'e': 'lib', 'q': q, 'p': p}
      # (a literal constant of another module of the repository, `boat.BRING_UP`: its value, as the module's own
      # constants are read; what the module is set to at import, the check importing it as it ships)
      lit = self.module_const(mod, x) if d and base in mod.imports and not (self.local_stack and base in self.local_stack[-1]) else None
      if lit is not None: return {**lit, 'p': p}
      if d and base in mod.imports and mod.imports[base][0] == 'module' and not (self.local_stack and base in self.local_stack[-1]):
        q = mod.imports[base][1] + d[len(base):]
        if q in KNOWN: return {'e': 'lib', 'q': q, 'p': p}
        why = missing(q) if not self.repo.path_of(q.split('.')[0]) else None
        if why: return {'e': 'no', 'why': why, 'raises': True, 'p': p}
        ret = self.ret_of(q.rpartition('.')[0], q.rpartition('.')[2])
        return {'e': 'ext', 'q': q, 'text': d, 'patch': {'mod': mod.name, 'path': d.split('.')}, 'p': p, **({'ret': ret} if ret else {})}
      return {'e': 'get', 'x': E(x.value), 'f': x.attr, 'p': p, 'text': text(x)}
    if isinstance(x, ast.BinOp):
      op = self.binop(x.op)
      if not op: return {'e': 'no', 'why': f"{text(x)}: {type(x.op).__name__} (outside the subset)", 'p': p}
      return {'e': 'bin', 'op': op, 'x': E(x.left), 'y': E(x.right), 'p': p, 'text': text(x)}
    if isinstance(x, ast.UnaryOp):
      if isinstance(x.op, ast.USub): return {'e': 'neg', 'x': E(x.operand), 'p': p}
      if isinstance(x.op, ast.UAdd): return E(x.operand)
      if isinstance(x.op, ast.Not): return {'e': 'not', 'x': E(x.operand), 'p': p}
      return {'e': 'no', 'why': f"{text(x)}: a bit operation", 'p': p}
    if isinstance(x, ast.BoolOp): return {'e': 'and' if isinstance(x.op, ast.And) else 'or', 'xs': [E(v) for v in x.values], 'p': p}
    if isinstance(x, ast.Compare):
      ops = {ast.Lt: '<', ast.LtE: '<=', ast.Gt: '>', ast.GtE: '>=', ast.Eq: '==', ast.NotEq: '!=', ast.Is: 'is', ast.IsNot: 'is not', ast.In: 'in', ast.NotIn: 'not in'}
      parts, left = [], x.left
      for op, right in zip(x.ops, x.comparators):
        parts.append({'e': 'cmp', 'op': ops[type(op)], 'x': E(left), 'y': E(right), 'p': p, 'text': text(x)})
        left = right
      return parts[0] if len(parts) == 1 else {'e': 'and', 'xs': parts, 'p': p}
    if isinstance(x, ast.IfExp): return {'e': 'ite', 'c': E(x.test), 'a': E(x.body), 'b': E(x.orelse), 'p': p}
    if isinstance(x, ast.Await): return {'e': 'await', 'x': E(x.value), 'p': p}
    if isinstance(x, ast.Call):
      f = E(x.func)
      if f.get('e') == 'ext' and f.get('q') in KNOWN: f = {'e': 'lib', 'q': f['q'], 'p': f['p']}
      # (a class of the repository made here: its methods read, its __init__ the code that makes it)
      if f.get('e') == 'cls' and f['rec'] in self.defs and self.recs.get(f['rec']) and not self.recs[f['rec']]['own']:
        r0 = self.recs[f['rec']]
        if not any(k.startswith('outside-base') or k in ('pydantic', 'typeddict', 'protocol') for k in r0['kinds']): self.rec_of(*self.defs[f['rec']], base=True)
      # any, all or sum of one generator: a loop over its collection (a fold), its value the accumulator's
      g = x.args[0] if len(x.args) == 1 and not x.keywords and isinstance(x.args[0], (ast.GeneratorExp, ast.ListComp)) else None
      if g and f.get('e') == 'builtin' and f.get('n') in ('any', 'all', 'sum') and len(g.generators) == 1 and not g.generators[0].is_async:
        c = g.generators[0]
        return {'e': 'fold', 'f': f['n'], 'to': self.target(c.target, mod), 'over': E(c.iter), 'x': E(g.elt), 'ifs': [E(i) for i in c.ifs], 'p': p, 'text': text(x)}
      args = [E(a) if not isinstance(a, ast.Starred) else {'e': 'no', 'why': f"{text(a)}: *args", 'p': p} for a in x.args]
      kw = [[k.arg, E(k.value)] if k.arg else ['**', {'e': 'no', 'why': f"**{text(k.value)}", 'p': p}] for k in x.keywords]
      return {'e': 'call', 'f': f, 'args': args, 'kw': kw, 'p': p, 'text': text(x)}
    if isinstance(x, ast.Subscript): return {'e': 'idx', 'x': E(x.value), 'i': E(x.slice), 'p': p, 'text': text(x)}
    if isinstance(x, ast.Dict):
      if any(k is None for k in x.keys): return {'e': 'no', 'why': f"{text(x)}: a dict spread", 'p': p}
      return {'e': 'dict', 'keys': [E(k) for k in x.keys], 'vals': [E(v) for v in x.values], 'p': p}
    if isinstance(x, ast.Tuple): return {'e': 'tuple', 'xs': [E(v) for v in x.elts], 'p': p}
    if isinstance(x, ast.JoinedStr):
      parts = []
      for v in x.values:
        if isinstance(v, ast.Constant): parts.append(v.value)
        elif isinstance(v, ast.FormattedValue): parts.append({'x': E(v.value), 'plain': v.conversion == -1 and v.format_spec is None})
      return {'e': 'fstr', 'parts': parts, 'p': p, 'text': text(x)}
    if isinstance(x, ast.List): return {'e': 'list', 'xs': [E(v) for v in x.elts], 'p': p}
    if isinstance(x, (ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)): return {'e': 'no', 'why': f"{text(x)}: a comprehension (a loop)", 'p': p}
    if isinstance(x, ast.Lambda):
      # (read as a key function where one is taken, min/max(xs, key=lambda o: ...); anywhere else refused, a closure)
      a = x.args
      if a.vararg or a.kwarg or a.kwonlyargs or a.defaults or a.posonlyargs or len(a.args) != 1: return {'e': 'no', 'why': f"{text(x)}: a lambda (a closure)", 'p': p}
      ps = [y.arg for y in a.args]
      self.local_stack.append((self.local_stack[-1] if self.local_stack else set()) | set(ps))
      try: body = E(x.body)
      finally: self.local_stack.pop()
      return {'e': 'lambda', 'params': ps, 'x': body, 'p': p, 'text': text(x)}
    return {'e': 'no', 'why': f"{text(x)}: {type(x).__name__} (outside the subset)", 'p': p}

def main():
  req = json.loads(sys.argv[1])
  r = Reader(req['root'], req['file'])
  mod = r.mod
  if mod.tree is None:
    print(json.dumps({'error': f"{req['file']} doesn't parse"})); return
  out = {'lang': 'python', 'file': os.path.basename(r.file), 'path': r.file, 'module': mod.name, 'root': os.path.abspath(req['root']), 'entries': [],
         # (the module's constants bound to literals, as the code reads them: a law may name them too)
         'consts': {k: v.value for k, v in ((k, r.const_value(mod, v)) for k, v in mod.consts.items() if k not in mod.rebound) if isinstance(v, ast.Constant) and isinstance(v.value, (int, float, str, bool)) and not (isinstance(v.value, float) and not v.value.is_integer())}}
  for n in req['names'] or list(mod.classes):
    if n in mod.classes: out['entries'].append({'k': 'class', 'rec': r.rec_of(mod, mod.classes[n])})
    elif n in mod.funcs:
      r.local_stack = []
      r.funcs[n] = r.func(mod.funcs[n], mod, None, n)
      out['entries'].append({'k': 'func', 'id': n})
    else: out['entries'].append({'k': 'missing', 'name': n})
  # The module's other functions, for the calls the entries make (each read once).
  for n, f in mod.funcs.items():
    if n not in r.funcs: r.funcs[n] = r.func(f, mod, None, n)
  out['recs'] = {k: v for k, v in r.recs.items() if v}
  # The executor's own failures' bases, and the class a stub raises for a handler of every exception.
  out['kinds'] = {n: [f"builtins.{c.__name__}" for c in getattr(builtins, n).__mro__ if c is not object] for n in ('KeyError', 'TypeError', 'AttributeError', 'ZeroDivisionError', 'ValueError', 'UnboundLocalError', 'RuntimeError', 'OverflowError')}
  out['exc'] = {'mro': ['builtins.Exception', 'builtins.BaseException'], 'raise': ['builtins', 'Exception']}
  out['lists'] = True
  out['funcs'] = r.funcs
  print(json.dumps(out))

if __name__ == '__main__':
  main()
