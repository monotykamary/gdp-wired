# The Python side of the extractor's check (core/extract-step.ts's checkStep): the module imported as it ships, its
# object made, set to a state, called with the rule's requests and read back, one JSON line a request over two named
# pipes. What the caller stated is enforced here: an answered call stubbed with the request's input, a store given as
# one that keeps what is set, the clock read as the request's time. Line events count the branch arms reached.
#
#   python3 core/py/harness.py <in-fifo> <out-fifo>
import asyncio, builtins, dataclasses, datetime, importlib, inspect, json, os, sys, types
import time as time_module

NOW = [0]
CUR = {}
EFF = {}
HIT = set()
S = {}

def datetime_in(v, unit):
  epoch = datetime.datetime(1970, 1, 1, tzinfo=datetime.timezone.utc if unit == 'datetime-utc' else None)
  return epoch + datetime.timedelta(milliseconds=int(v))

def enc_num(v):
  if isinstance(v, datetime.datetime):
    epoch = datetime.datetime(1970, 1, 1, tzinfo=datetime.timezone.utc if v.tzinfo is not None else None)
    delta = v - epoch
    return str(delta.days * 86400000 + delta.seconds * 1000 + delta.microseconds // 1000) if delta.microseconds % 1000 == 0 else '?:sub-millisecond datetime'
  if isinstance(v, bool): return v
  if isinstance(v, int): return str(v)
  if isinstance(v, float):
    return str(int(v)) if v.is_integer() and abs(v) < 2 ** 63 else f"f:{v!r}"
  return f"?:{type(v).__name__}"

def tag(v):
  if v is None or isinstance(v, bool): return v
  if isinstance(v, (int, float)): return {'n': enc_num(v)}
  if isinstance(v, str): return {'s': v}
  return {'o': type(v).__name__}

class Inert:
  """A value of a type outside the subset the rule never reads: any attribute an inert value, a call a no-op."""
  def __getattr__(self, n):
    if n.startswith('__'): raise AttributeError(n)
    return Inert()
  def __call__(self, *a, **k):
    async def noop(): return None
    return noop()

def resolve(q):
  mod, _, name = q.rpartition('.')
  return getattr(importlib.import_module(mod), name)

class Inert:
  """An attribute of a store the rule leaves out (a registry the constructor adds to): its calls do nothing."""
  def __getattr__(self, name):
    if name.startswith('__'): raise AttributeError(name)
    return Inert()
  def __call__(self, *a, **k): return None

class FakeStore:
  """A store as the caller stated it: get, set and delete over a dict that keeps what is set (no expiry)."""
  def __init__(self, decl, name=None):
    self.data, self.name = {}, name
    for path, v in (decl.get('attrs') or {}).items():
      o, parts = self, path.split('.')
      for p in parts[:-1]:
        if p not in vars(o): setattr(o, p, types.SimpleNamespace())
        o = getattr(o, p)
      setattr(o, parts[-1], v)
    # (an attribute the rule leaves out, a registry the constructor adds to: inert, its calls doing nothing)
    for i in S.get('inert') or []:
      if i['store'] != name: continue
      o, parts = self, i['path'].split('.')
      for p in parts[:-1]:
        if p not in vars(o): setattr(o, p, types.SimpleNamespace())
        o = getattr(o, p)
      if parts[-1] not in vars(o): setattr(o, parts[-1], Inert())
    asyncs = decl.get('async') or {}
    def mk(kind, name):
      # (the key by position, or as key= or name=, redis-py's; nx and xx as redis-py's: True where it set, else None)
      kk = lambda a, k: k.get('key', k.get('name', a[0] if a else None))
      def get(*a, **k): return self.data.get(kk(a, k))
      def set_(*a, **k):
        key = kk(a, k); val = k.get('value', a[1] if len(a) > 1 else None)
        if (k.get('nx') and key in self.data) or (k.get('xx') and key not in self.data): return None
        self.data[key] = val
        if k.get('nx') or k.get('xx'): return True
      def delete(*a, **k): self.data.pop(kk(a, k), None)
      # (add: set where the key holds nothing, True where it set; incr: by amount, absent as 0, the new number)
      def add(*a, **k):
        key = kk(a, k)
        if key in self.data: return False
        self.data[key] = k.get('value', a[1] if len(a) > 1 else None)
        return True
      def incr(*a, **k):
        key = kk(a, k); self.data[key] = (self.data.get(key) or 0) + k.get('amount', a[1] if len(a) > 1 else 1)
        return self.data[key]
      f0, key = {'get': get, 'set': set_, 'delete': delete, 'add': add, 'incr': incr}[kind], f"{self.name}.{name}"
      # (where the request says the operation raises, inside a try that catches it)
      def f(*a, **k):
        r = (CUR.get(key) or {}).get('raise')
        if r is not None and raises_here(key): raise raised(r)
        return f0(*a, **k)
      if asyncs.get(name):
        async def af(*a, **k): return f(*a, **k)
        return af
      return f
    own = set()
    for kind, dflt in (('get', ['get', 'async_get_cache', 'get_cache']), ('set', ['set', 'async_set_cache', 'set_cache']), ('delete', ['delete', 'delete_cache', 'async_delete_cache']), ('add', []), ('incr', [])):
      for m in decl.get(kind) or dflt: setattr(self, m, mk(kind, m)); own.add(m)
    # (a method left out: nothing, as the rule takes it; any other is no method of this store, and fails)
    for m in decl.get('skip') or []:
      async def anop(*a, **k): return None
      setattr(self, m, (lambda *a, **k: anop()) if asyncs.get(m) else (lambda *a, **k: None))
    # (an injected dependency's other methods: each answered by the request's input; one left out does nothing, and
    # raises where the request says, as its get, set and delete do)
    for a in S.get('answers') or []:
      if a['patch'].get('store') != name: continue
      if not a['patch'].get('path'):
        if os.environ.get('GDP_HARNESS_LOG'):
          with open(os.environ['GDP_HARNESS_LOG'], 'a') as f: f.write(f"a store's answer with no method: {json.dumps(a)[:400]}\n")
        continue
      m = a['patch']['path'][-1]
      if a['patch'].get('store') == name and a.get('effect'):
        def rec(key, is_async):
          def f(*x, **k): EFF[key] = True
          async def af(*x, **k): EFF[key] = True
          return af if is_async else f
        setattr(self, m, rec(a['key'], a['async']))
      elif a['patch'].get('store') == name and not (a.get('pass') and m in own): setattr(self, m, stub(a['key'], a['async'], (lambda *x, **k: None) if a.get('pass') else None))

ORM_VALIDATED = set()

class ORMTable:
  """Only the persistence boundary is faked; methods execute on the real model class.
  Reads detach copies, and save snapshots a row. No schema or database is created.
  """
  def __init__(self, leaf):
    self.leaf, self.meta, self.data = leaf, leaf['orm'], {}
    self.cls = resolve(self.meta['rec'])
    self.key = self.meta['key']
    if self.cls not in ORM_VALIDATED:
      access = {'__getattribute__', '__getattr__', '__setattr__', '__delattr__'}
      if self.meta['framework'] == 'django':
        from django.db.models import Model, Manager
        # Display methods are retained, never replaced by persistence stubs. The
        # reader refuses implicit object display, including discarded results.
        methods = ({n for n, v in vars(Model).items() if inspect.isfunction(v) or isinstance(v, (staticmethod, classmethod, property))} - {'__str__', '__repr__'}) | access
        unsafe = any(inspect.getattr_static(self.cls, n, None) is not inspect.getattr_static(Model, n, None) for n in methods) or type(self.cls.objects) is not Manager
      else:
        from sqlalchemy.orm.decl_base import _declarative_constructor
        manager = self.cls._sa_class_manager
        unsafe = manager.original_init is not _declarative_constructor or self.cls.__init__ is not manager.new_init or any(inspect.getattr_static(self.cls, n, None) is not inspect.getattr_static(object, n, None) for n in access)
      if unsafe: raise ValueError('custom or inherited ORM persistence behavior is outside the table boundary')
      ORM_VALIDATED.add(self.cls)
  def install(self):
    if self.meta['framework'] == 'django': self.cls.objects = self
    table = self
    def save(row, *args, **kw):
      if args or kw: raise ValueError('ORM save options outside boundary')
      table.data[getattr(row, table.key)] = {f['name']: getattr(row, f['name']) for f in table.meta['fields']}
    def delete(row, *args, **kw):
      if args or kw: raise ValueError('ORM delete options outside boundary')
      key = getattr(row, table.key)
      n = int(key in table.data)
      table.data.pop(key, None)
      setattr(row, table.key, None)
      return n, {table.cls._meta.label: n}
    self.cls.save = save
    self.cls.delete = delete
  def lookup(self, kw):
    if len(kw) != 1: raise ValueError('one primary key required')
    name, value = next(iter(kw.items()))
    if name not in ('pk', self.key): raise ValueError('non-key filter')
    return value
  def get(self, **kw):
    key = self.lookup(kw)
    if key not in self.data: raise self.cls.DoesNotExist()
    return self.cls(**self.data[key])
  def create(self, **kw):
    from django.db import IntegrityError
    key = kw[self.key]
    if key in self.data: raise IntegrityError('duplicate primary key')
    row = self.cls(**kw)
    row.save()
    return row
  def filter(self, **kw):
    table, key = self, self.lookup(kw)
    class Query:
      def exists(self): return key in table.data
      def first(self): return table.cls(**table.data[key]) if key in table.data else None
      def delete(self):
        n = int(key in table.data)
        table.data.pop(key, None)
        return n, {table.cls._meta.label: n}
    return Query()

class ORMSession:
  def __init__(self): self.loaded, self.added, self.data = [], [], {}
  def table(self, cls):
    return next(t for t in OBJ_STORES.values() if isinstance(t, ORMTable) and t.cls is cls)
  def get(self, cls, key):
    table = self.table(cls)
    if key not in table.data: return None
    row = cls(**table.data[key]); self.loaded.append((row, False))
    return row
  def add(self, row):
    if any(r is row for r, _ in self.loaded): return
    self.added.append(row)
    self.loaded.append((row, False))
  def delete(self, row):
    self.loaded = [(r, d) for r, d in self.loaded if r is not row]
    self.loaded.append((row, True))
  def commit(self):
    pending = set()
    for row in self.added:
      table = self.table(type(row)); key = getattr(row, table.key)
      if key in table.data or (table, key) in pending: raise ValueError('duplicate primary key')
      pending.add((table, key))
    for row, deleted in self.loaded:
      table = self.table(type(row))
      if deleted: table.data.pop(getattr(row, table.key), None)
      else: table.data[getattr(row, table.key)] = {f['name']: getattr(row, f['name']) for f in table.meta['fields']}
    self.loaded.clear()

def orm_snapshot(table):
  out = {}
  for key, row in table.data.items():
    cell = {}
    for field in table.meta['fields']:
      name, t = field['name'], field['t']
      if name == table.key: continue
      value = row[name]
      if t['k'] == 'opt':
        cell[name + '_has'] = value is not None
        t = t['of']
      if value is None: value = '' if t['k'] == 'str' else False if t['k'] == 'bool' else 0
      cell[name] = value if t['k'] in ('str', 'bool', 'choice') else enc_num(value)
    out[str(key)] = cell
  return out

def orm_restore(table, cells):
  table.data.clear()
  for key, cell in cells.items():
    key = int(key) if table.leaf['key'] == 'num' else key
    row = {table.key: key}
    for field in table.meta['fields']:
      name, t = field['name'], field['t']
      if name == table.key: continue
      optional = t['k'] == 'opt'
      if optional: t = t['of']
      row[name] = None if optional and not cell[name + '_has'] else datetime_in(cell[name], t['unit']) if t.get('unit', '').startswith('datetime-') else int(cell[name]) if t['k'] == 'int' else cell[name]
    table.data[key] = row

def build(spec, stores):
  if 'in' in spec:
    v = spec['in']
    if spec.get('time'): return datetime_in(v, spec['time'])
    if spec.get('bytes') and isinstance(v, str): return v.encode('latin-1')
    return float(v) if spec.get('float') and isinstance(v, int) and not isinstance(v, bool) else v
  if spec.get('none'): return None
  if spec.get('inert'): return {} if spec.get('dict') else Inert()
  if 'store' in spec:
    name = spec['store']
    if name not in stores: stores[name] = ORMSession() if S['stores'].get(name, {}).get('ormSession') else FakeStore(S['stores'].get(name, {}), name)
    return stores[name]
  if 'list' in spec: return [build(x, stores) for x in spec['list']]
  if 'rec' in spec:
    cls = resolve(spec['rec'])
    f = {k: build(v, stores) for k, v in spec['f'].items()}
    return make_rec(cls, f)
  raise ValueError(f"an argument spec {spec}")

SUBS = {}
def make_rec(cls, f):
  # A record of the inputs the rule reads: every other field inert (the code may read it, the rule claims nothing of it).
  if hasattr(cls, 'model_construct'):
    fields = getattr(cls, 'model_fields', {}) or {}
    rest = {n: Inert() for n, fi in fields.items() if n not in f and getattr(fi, 'is_required', lambda: False)()}
    return cls.model_construct(**rest, **f)
  if getattr(cls, '__annotations__', None) is not None and isinstance(cls, type) and issubclass(cls, dict): return dict(f)
  if dataclasses.is_dataclass(cls):
    o = object.__new__(cls)
    for k, v in f.items(): object.__setattr__(o, k, v)
    return o
  sub = SUBS.get(cls)
  if sub is None:
    try: sub = SUBS[cls] = type(cls.__name__, (cls,), {'__getattr__': lambda self, n: Inert() if not n.startswith('__') else object.__getattribute__(self, n), '__module__': cls.__module__})
    except TypeError: sub = SUBS[cls] = cls
  o = object.__new__(sub)
  for k, v in f.items(): setattr(o, k, v)
  return o

def fixed_args(spec_list, inputs):
  """Arguments from their specs, the string inputs kept strings where the leaf is a string."""
  out = {}
  for name, spec in spec_list:
    if spec.get('dflt'): continue
    out[name] = build(spec, OBJ_STORES)
  return out

OBJS = {}
OBJ_STORES = {}

def walk(o, path):
  for p in path: o = o[p] if isinstance(o, dict) else getattr(o, p)
  return o

def put(o, path, v):
  parent = walk(o, path[:-1])
  if isinstance(parent, dict): parent[path[-1]] = v
  elif dataclasses.is_dataclass(parent) and getattr(type(parent), '__dataclass_params__', None) and type(parent).__dataclass_params__.frozen: object.__setattr__(parent, path[-1], v)
  else: setattr(parent, path[-1], v)

def tpl_match(tpl, key):
  pre, _, post = tpl.partition('{}')
  if not isinstance(key, str) or not key.startswith(pre) or not key.endswith(post) or len(key) < len(pre) + len(post): return None
  return key[len(pre): len(key) - len(post)] if '{}' in tpl else ('' if key == tpl else None)

def owns(l, key):
  """The part of a store's key a leaf's template takes, where no more specific template of the store takes it (the
  templates name distinct keys: "{}:lock" keys aren't "{}" ones)."""
  h = tpl_match(l['tpl'], key)
  if h is None: return None
  for m in S['leaves']:
    if m.get('store') == l['store'] and m is not l and len(m['tpl']) > len(l['tpl']) and tpl_match(m['tpl'], key) is not None: return None
  return h

def state_of(obj, stores):
  s = {}
  for l in S['leaves']:
    k = l['kind']
    if k == 'frame': continue
    if l.get('orm'):
      s[l['name']] = orm_snapshot(stores[l['name']])
      continue
    if l.get('store'):
      st = stores.get(l['store'])
      cells = {}
      for key, v in (st.data.items() if st else []):
        h = owns(l, key)
        if h is None: continue
        if l.get('json'):
          # (a JSON record: its fields kept, an optional one beside whether the key holds a value; strings left out)
          d, c = json.loads(v), {}
          for f in l['json']:
            if f.get('out'): continue
            x = d.get(f['name']) if f.get('opt') else d[f['name']]
            if f.get('opt'): c[f['name'] + '_has'] = x is not None
            c[f['name']] = (x if x is not None else (f['vals'][0] if f.get('choice') else 0)) if f.get('choice') else enc_num(0 if x is None else x)
          cells[h] = c
        else: cells[h] = {'value': v if l.get('choice') else (v.decode('latin-1') if isinstance(v, (bytes, bytearray)) else v) if l.get('str') else enc_num(int(v) if isinstance(v, bool) else v)}
      s[l['name']] = cells
      continue
    v = walk(obj, l['path'])
    if k == 'none': s[l['name']] = v is None
    elif k == 'num': s[l['name']] = '0' if v is None else enc_num(v)
    elif k in ('str', 'choice'): s[l['name']] = '' if v is None else v.decode('latin-1') if isinstance(v, (bytes, bytearray)) else v
    elif k == 'bool': s[l['name']] = False if v is None else v
    elif k == 'map':
      cells = {}
      # (a list: its items by their places, 0 first)
      for key, x in (enumerate(v or []) if l.get('ordered') else ((k, None) for k in v or ()) if l.get('set') else (v or {}).items()):
        if l.get('set'): cells[str(key)] = {}
        elif l.get('fields'): cells[str(key)] = {f['name']: (lambda y: y if f.get('choice') else enc_num(y))(x[f['name']] if isinstance(x, dict) else getattr(x, f['name'])) for f in l['fields']}
        else: cells[str(key)] = {'value': enc_num(x)}
      s[l['name']] = cells
  # A store's key no template names: the code keeps state the rule has no place for.
  for name, st in stores.items():
    if isinstance(st, ORMTable): continue
    tpls = [l['tpl'] for l in S['leaves'] if l.get('store') == name]
    for key in st.data:
      if not any(tpl_match(t, key) is not None for t in tpls): raise ValueError(f"the store {name} holds {key!r}, a key no template of the rule names")
  return s

def is_bytes(l):
  t = l.get('t') or {}
  return bool((t.get('of') if t.get('k') == 'opt' else t).get('bytes'))

def num_in(x, flt):
  return float(int(x)) if flt else int(x)

def set_state(obj, stores, state):
  for l in S['leaves']:
    k = l['kind']
    if k in ('frame', 'none'): continue
    v = state.get(l['name'])
    if l.get('orm'):
      orm_restore(stores[l['name']], v or {})
      continue
    if l.get('store'):
      st = stores[l['store']]
      pre, _, post = l['tpl'].partition('{}')
      for key in [kk for kk in st.data if owns(l, kk) is not None]: del st.data[key]
      for h, c in (v or {}).items():
        at = pre + h + post if '{}' in l['tpl'] else l['tpl']
        if l.get('json'): st.data[at] = json.dumps({f['name']: (c[f['name']] if f.get('choice') else num_in(c[f['name']], False)) for f in l['json'] if not f.get('out') and (not f.get('opt') or c.get(f['name'] + '_has'))})
        else: st.data[at] = c['value'] if l.get('choice') or l.get('str') else num_in(c['value'], l.get('float'))
      continue
    if k == 'num':
      t = l.get('t') or {}
      if t.get('k') == 'opt': t = t['of']
      put(obj, l['path'], datetime_in(v, t['unit']) if t.get('unit', '').startswith('datetime-') else num_in(v, l.get('float')))
    elif k in ('str', 'choice', 'bool'): put(obj, l['path'], v.encode('latin-1') if k == 'str' and is_bytes(l) and isinstance(v, str) else v)
    elif k == 'map':
      d = {}
      for key, c in (v or {}).items():
        kk = int(key) if l.get('key') == 'num' else key
        if l.get('set'): d[kk] = True
        elif l.get('fields'):
          d[kk] = make_rec(resolve(l['cls']), {f['name']: (num_in(c[f['name']], f.get('float')) if isinstance(c[f['name']], str) and not f.get('choice') else c[f['name']]) for f in l['fields']})
        else: d[kk] = num_in(c['value'], l.get('float')) if isinstance(c['value'], str) else c['value']
      put(obj, l['path'], [d[kk] for kk in sorted(d)] if l.get('ordered') else set(d) if l.get('set') else d)
  for l in S['leaves']:
    if l['kind'] == 'none' and state.get(l['name']) is True: put(obj, l['path'], None)

def frames(obj):
  out = {}
  if obj is None: return out
  for l in S['leaves']:
    if l['kind'] == 'frame' and not l.get('cls'):
      try:
        v = walk(obj, l['path'])
        out['.'.join(l['path'])] = json.dumps(v, sort_keys=True)
      except Exception: pass
  return out

REAL = {}
def tracer(frame, event, arg):
  f = frame.f_code.co_filename
  if f not in REAL: REAL[f] = S['sources'].get(os.path.realpath(f))
  source = REAL[f]
  if source is not None:
    def local(fr, ev, a):
      if ev == 'line': HIT.add((source, fr.f_lineno))
      return local
    return local
  return None

class Clock:
  def __init__(self, real): self.real = real
  def time(self): return float(NOW[0])
  def monotonic(self): return float(NOW[0])
  def perf_counter(self): return float(NOW[0])
  def __getattr__(self, n): return getattr(self.real, n)

class _Now(datetime.datetime):
  """datetime.datetime with now() the request's time (local, naive, as the code's own now())."""
  @classmethod
  def now(cls, tz=None):
    if tz is None and (time_module.timezone != 0 or time_module.altzone != 0):
      raise ValueError('naive datetime clocks require a UTC process timezone')
    return datetime.datetime.fromtimestamp(NOW[0], tz)
  # (where it is seen anyway, a type read while the clock is pinned, pydantic's: a datetime)
  @classmethod
  def __get_pydantic_core_schema__(cls, source, handler): return handler(datetime.datetime)

# The clock the repository's modules read (time.time(), datetime.now()) made the request's time, only while the code
# runs (making the object, a call): a module's names are its own again between, so a framework that reads them, an
# annotation or a route's types, sees the real datetime; a module made while the clock was pinned put back too.
CLOCKS = {'root': None, 'n': -1, 'pins': [], 'depth': 0}
def scan_clocks():
  if len(sys.modules) == CLOCKS['n']: return
  CLOCKS['n'] = len(sys.modules)
  dtm = CLOCKS.get('dtm')
  if dtm is None:
    dtm = CLOCKS['dtm'] = types.SimpleNamespace(**{k: getattr(datetime, k) for k in dir(datetime) if not k.startswith('__')})
    dtm.datetime = _Now
  pins = []
  for m in list(sys.modules.values()):
    f = getattr(m, '__file__', None)
    if not f or not os.path.realpath(f).startswith(CLOCKS['root'] + os.sep): continue
    for n, v in list(vars(m).items()):
      if v is time_module or isinstance(v, Clock): pins.append((m, n, time_module, Clock(time_module)))
      elif v is datetime or v is dtm: pins.append((m, n, datetime, dtm))
      elif v is datetime.datetime or v is _Now: pins.append((m, n, datetime.datetime, _Now))
  CLOCKS['pins'] = pins

def put_clocks(fake):
  for m, n, real, f in CLOCKS['pins']: setattr(m, n, f if fake else real)

# (an import the code makes while it runs, a module of the repository first loaded then: run with the real clock, so
# what it copies or builds from the module's names is the real datetime, imports inside it too; the clock pinned
# again after the outermost, the new modules' names too)
REAL_IMPORT = builtins.__import__
def clock_import(*a, **k):
  if CLOCKS['depth'] == 0: put_clocks(False)
  CLOCKS['depth'] += 1
  try: return REAL_IMPORT(*a, **k)
  finally:
    CLOCKS['depth'] -= 1
    if CLOCKS['depth'] == 0: scan_clocks(); put_clocks(True)

class pinned:
  def __enter__(self):
    scan_clocks(); put_clocks(True)
    builtins.__import__ = clock_import
  def __exit__(self, *a):
    builtins.__import__ = REAL_IMPORT
    put_clocks(False); scan_clocks(); put_clocks(False)

def pin_clocks(root):
  CLOCKS['root'] = os.path.realpath(root)

def raises_here(key):
  """Whether a call left out raises here, as the request says: only at the sites the rule read it may raise (a call of
  the same callee elsewhere, outside a try that catches it, runs as it is)."""
  a = next((x for x in S.get('answers') or [] if x['key'] == key), None)
  if not a or not a.get('pass') or not a.get('at'): return True
  f = sys._getframe(1)
  while f is not None and os.path.realpath(f.f_code.co_filename) == os.path.realpath(__file__): f = f.f_back
  if f is None: return True
  here = os.path.relpath(os.path.realpath(f.f_code.co_filename), S['root']).replace(os.sep, '/')
  line = f.f_lineno
  for site in a['at']:
    parts = site['p'].rsplit(':', 2)
    file, l0 = parts[0], int(parts[1])
    l1 = int(site['end'].split(':')[0]) if site.get('end') and site['end'].split(':')[0].isdigit() else l0
    if file == here and l0 <= line <= l1: return True
  return False

def raised(r):
  """The exception a stub raises where the request says: the class a handler names, made without its arguments."""
  cls = eval(r[1], vars(importlib.import_module(r[0])))
  try: return cls('gdp: raised where the request says')
  except Exception:
    e = cls.__new__(cls); e.args = ('gdp: raised where the request says',); return e

def stub(key, is_async, orig=None):
  # (orig: a call left out, run as it is unless the request says it raises)
  def value(a_, k_):
    a = CUR.get(key)
    if a is not None and a.get('raise') is not None and raises_here(key): raise raised(a['raise'])
    if orig is not None: return orig(*a_, **k_)
    if a is None or a.get('none'): return None
    return build(a, {})
  if is_async:
    async def f(*a, **k):
      v = value(a, k)
      return (await v) if orig is not None and inspect.isawaitable(v) else v
    return f
  def g(*a, **k): return value(a, k)
  return g

def patch_target(p):
  mod = importlib.import_module(p['mod'])
  o = mod
  for part in p['path'][:-1]: o = getattr(o, part)
  return o, p['path'][-1]

def hello(req):
  def has_naive(v):
    if isinstance(v, dict):
      return v.get('unit') == 'datetime-naive' or v.get('time') == 'datetime-naive' or any(has_naive(x) for x in v.values())
    return isinstance(v, list) and any(has_naive(x) for x in v)
  if (req.get('naiveUtc') or has_naive(req)) and (time_module.timezone != 0 or time_module.altzone != 0):
    raise ValueError('stated naive datetime values require a UTC process timezone')
  S.update(req)
  S['path'] = os.path.realpath(req['path'])
  S['root'] = os.path.realpath(req['root'])
  # Only files the reader actually used, including imported bases; never arbitrary repository imports.
  S['sources'] = {os.path.realpath(os.path.join(S['root'], name)): name for name, _ in req['arms']}
  REAL.clear(); HIT.clear()
  sys.path.insert(0, req['root'])
  if os.environ.get('DJANGO_SETTINGS_MODULE'):
    import django
    django.setup()
  S['mod'] = importlib.import_module(req['module'])
  mod = S['mod']
  pin_clocks(req['root'])
  S['self_stubs'] = []
  for a in req['answers']:
    p = a['patch']
    # (an effect: a call recorded, nothing run, None returned)
    if a.get('effect'):
      def rec(key, is_async):
        def f(*x, **k): EFF[key] = True
        async def af(*x, **k): EFF[key] = True
        return af if is_async else f
      f = rec(a['key'], a['async'])
      if p.get('store'): continue
      if p.get('self'): S['self_stubs'].append((p['self'], {**a, 'effect_fn': f})); continue
      o, name = patch_target(p)
      raw = inspect.getattr_static(o, name, None)
      setattr(o, name, staticmethod(f) if isinstance(raw, staticmethod) else f)
      continue
    if p.get('store'): continue
    if p.get('self'): S['self_stubs'].append((p['self'], a))
    else:
      o, name = patch_target(p)
      raw = inspect.getattr_static(o, name, None)
      f = stub(a['key'], a['async'], getattr(o, name) if a.get('pass') else None)
      setattr(o, name, staticmethod(f) if isinstance(raw, staticmethod) else classmethod(lambda cls, *x, **k: f(*x, **k)) if isinstance(raw, classmethod) else f)
  S['cls'] = getattr(mod, req['cls'].rpartition('.')[2]) if req.get('cls') else None
  S['loop'] = asyncio.new_event_loop()
  asyncio.set_event_loop(S['loop'])
  return {'ok': True}

def make(args):
  global OBJ_STORES
  OBJ_STORES = {}
  for leaf in S['leaves']:
    if leaf.get('orm'): OBJ_STORES[leaf['name']] = ORMTable(leaf)
  for table in OBJ_STORES.values(): table.install()
  if S['cls'] is None: obj = types.SimpleNamespace()
  else:
    kw = fixed_args(args, {})
    sys.settrace(tracer)
    try:
      with pinned(): obj = run(S['cls'](**kw))
    finally: sys.settrace(None)
  for name, a in S['self_stubs']: obj.__dict__[name] = a['effect_fn'] if a.get('effect_fn') else stub(a['key'], a['async'], getattr(obj, name) if a.get('pass') else None)
  for name in S.get('inject') or []: setattr(obj, name, build({'store': name}, OBJ_STORES))
  # (fields stated: the object configured so after its constructor, as the claim says)
  for f, v in (S.get('fields') or {}).items(): setattr(obj, f, v)
  # (a module's object stated as a store: the store in its place, this object's while it runs)
  for g in S.get('globals') or []: build({'store': g['name']}, OBJ_STORES)
  set_globals(OBJ_STORES)
  i = len(OBJS) + 1
  OBJS[i] = (obj, OBJ_STORES)
  return i

def run(x):
  return S['loop'].run_until_complete(x) if inspect.isawaitable(x) else x

def set_globals(stores):
  for table in stores.values():
    if isinstance(table, ORMTable): table.install()
  for g in S.get('globals') or []: setattr(importlib.import_module(g['mod']), g['name'], stores[g['name']])

def call(req):
  obj, stores = OBJS[req['id']]
  global OBJ_STORES
  OBJ_STORES = stores
  set_globals(stores)
  NOW[0] = int(req.get('now') or 0)
  for store in stores.values():
    if isinstance(store, ORMSession): store.loaded.clear(); store.added.clear()
  CUR.clear(); CUR.update(req.get('answers') or {})
  EFF.clear()
  fn = getattr(obj, req['m']) if S['cls'] is not None else getattr(S['mod'], req['m'])
  try: kwargs = fixed_args(req['a'], {})
  except OverflowError as e:
    return {'outside': f'argument outside the declared runtime domain: {e}'}
  before = frames(obj if S['cls'] is not None else None)
  snap = state_of(obj, stores) if S.get('discard') and S['cls'] is not None else None
  sys.settrace(tracer)
  try:
    with pinned(): out = run(fn(**kwargs))
    err = None
  except Exception as e:
    out, err = None, f"{type(e).__name__}: {e}"[:300]
    # (GDP_HARNESS_LOG: each exception the code raised, with its traceback, appended there)
    if os.environ.get('GDP_HARNESS_LOG'):
      import traceback
      with open(os.environ['GDP_HARNESS_LOG'], 'a') as f: f.write(f"{req['m']} {json.dumps(req.get('answers'))}\n{traceback.format_exc()}\n")
  finally:
    sys.settrace(None)
  if err is not None and snap is not None: set_state(obj, stores, snap)
  after = frames(obj if S['cls'] is not None else None)
  for k in before:
    if after.get(k) != before[k]: return {'frame': k}
  return {'out': tag(out), **({'err': err} if err is not None else {}), **({'effects': dict(EFF)} if EFF else {})}

def main():
  fin = open(sys.argv[1], 'r'); fout = open(sys.argv[2], 'w')
  for line in fin:
    req = json.loads(line)
    op = req['op']
    try:
      if op in ('new', 'at'): NOW[0] = int(req.get('now') or 0)
      if op == 'hello': res = hello(req)
      elif op == 'new':
        try: res = {'id': make(req['a'])}
        except Exception as e:
          res = {'err': f"{type(e).__name__}: {e}"[:300]}
          if os.environ.get('GDP_HARNESS_LOG'):
            import traceback
            with open(os.environ['GDP_HARNESS_LOG'], 'a') as f: traceback.print_exc(file=f)
      elif op == 'at':
        try:
          i = make(req['a'])
          set_state(OBJS[i][0], OBJS[i][1], req['state'])
          res = {'id': i}
        except Exception as e: res = {'bad': f"{type(e).__name__}: {e}"[:300]}
      elif op == 'get':
        obj, stores = OBJS[req['id']]
        res = {'state': state_of(obj, stores)}
      elif op == 'call': res = call(req)
      elif op == 'coverage': res = {'hit': sorted(HIT)}
      else: res = {'error': f"no op {op}"}
    except Exception as e:
      res = {'error': f"{type(e).__name__}: {e}"[:500]}
    fout.write(json.dumps(res) + '\n'); fout.flush()

if __name__ == '__main__':
  main()
