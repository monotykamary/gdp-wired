// The generated JavaScript (compileJs, which updates its maps in place) against the interpreter (which copies them), on
// random machines whose map values read the other map and whose scalars read both, so a write seen before every read
// is done would show; and branches made with fork stay apart. FUZZ_SEED and FUZZ_SCALE shard it as kernel.test.ts.
import {expect, test} from 'bun:test'
import {type C, type E, type Machine, type State, compileJs, fastStep, interpret, loadJs, lcg} from './machine.ts'
import {distinctNames, sortedList} from '../examples/pairs.ts'

let seed = Number(process.env.FUZZ_SEED ?? 777)
const scale = Number(process.env.FUZZ_SCALE ?? 1)
const rand = (n: number) => { seed = lcg(seed); return Math.floor(seed / 2 ** 31 * n) }
const pick = <T>(xs: T[]): T => xs[rand(xs.length)]!
const names = ['p', 'a', 'b', 'z', 'y']
const term = (d: number): E => {
  const r = rand(d <= 0 ? 3 : 8)
  if (r === 0) return {op: 'var', name: pick(names)}
  if (r === 1) return {op: 'const', value: rand(4)}
  if (r === 2) return {op: 'get', map: pick(['A', 'B']), key: d <= 0 ? {op: 'var', name: pick(['a', 'b'])} : term(d - 1)}
  if (r === 3) return {op: 'add', a: term(d - 1), b: term(d - 1)}
  if (r === 4) return {op: 'sub', a: term(d - 1), b: term(d - 1)}
  if (r === 5) return {op: 'min', a: term(d - 1), b: term(d - 1)}
  if (r === 6) return {op: 'mul', k: 2, a: term(d - 1)}
  return {op: 'if', c: cond(d - 1), then: term(d - 1), else: term(d - 1)}
}
const cond = (d: number): C => {
  const r = rand(5)
  if (r === 3) return {op: 'not', x: cond(d)}
  if (r === 4 && d > 0) return {op: rand(2) ? 'and' : 'or', xs: [cond(d - 1), cond(d - 1)]}
  return {op: (['<', '<=', '='] as const)[rand(3)]!, a: term(d), b: term(d)}
}
const withFlag = (e: E): E => (rand(3) ? e : {op: 'if', c: {op: 'flag', name: 'f'}, then: e, else: term(0)})
function machine(): Machine {
  return {
    name: 'random', params: ['p'], inputs: ['a', 'b'], state: {z: {op: 'var', name: 'p'}, y: {op: 'const', value: 0}}, maps: {A: 0, B: 1},
    step: {
      flags: {f: cond(1)},
      state: {z: withFlag(term(2)), y: withFlag(term(2))},
      maps: {A: {key: rand(2) ? {op: 'var', name: 'a'} : term(1), value: withFlag(term(2))}, B: {key: rand(2) ? {op: 'var', name: 'a'} : term(1), value: withFlag(term(2))}},
    },
  }
}
const load = (m: Machine) => loadJs(m)
const cells = (st: State) => JSON.stringify(Object.fromEntries(Object.entries(st.maps).map(([name, map]) => [name, [...map.entries()].sort((x, y) => x[0] - y[0])])))
const same = (a: State, b: State) => { expect(a.scalars).toEqual(b.scalars); expect(cells(a)).toBe(cells(b)) }

test('the generated JavaScript steps as the interpreter does', () => {
  let steps = 0, forks = 0
  for (let trial = 0; trial < 2000 * scale; trial++) {
    const m = machine(), gen = load(m), run = interpret(m), fast = fastStep(m)!
    const params = {p: rand(4)}
    const input = () => ({a: rand(4), b: rand(4)})
    let st = run.init(params), g = gen.init(params)
    same(st, g)
    for (let i = 0; i < 1 + rand(30); i++) {
      const r = input(), f = fast(params, st, r)
      st = run.step(params, st, r), g = gen.step(params, g, r)
      same(st, g); same(st, f)
      steps++
    }
    // Two branches from one state: fork each, step them apart, then neither sees the other.
    const r1 = input(), r2 = input()
    const left = gen.step(params, gen.fork(g), r1), right = gen.step(params, gen.fork(g), r2)
    same(run.step(params, st, r1), left)
    same(run.step(params, st, r2), right)
    same(st, g)
    forks++
  }
  console.log(`compiled vs interpreted: ${steps.toLocaleString()} steps and ${forks.toLocaleString()} forks agree`)
}, 600_000)

test('fastStep forks only accepted requests, after all pre-state reads', () => {
  let copies = 0
  class WatchedMap extends Map<number, number> {
    override [Symbol.iterator]() { copies++; return super[Symbol.iterator]() }
  }
  const zero: E = {op: 'const', value: 0}
  const m: Machine = {name: 'deferred fork', params: [], inputs: ['take'], state: {}, maps: {A: 0, B: 0},
    assume: {op: '<', a: {op: 'var', name: 'take'}, b: {op: 'const', value: 1}},
    step: {maps: {A: {key: zero, value: {op: 'get', map: 'B', key: zero}}, B: {key: zero, value: {op: 'get', map: 'A', key: zero}}}}}
  const st: State = {scalars: {}, maps: {A: new WatchedMap([[0, 1]]), B: new WatchedMap([[0, 2]])}}
  const step = fastStep(m)!
  expect(() => step({}, st, {take: 2})).toThrow('fails the rule\'s assumption')
  expect(copies).toBe(0)
  const next = step({}, st, {take: 0})
  expect(copies).toBe(2)
  expect(next.maps.A!.get(0)).toBe(2)
  expect(next.maps.B!.get(0)).toBe(1)
  next.maps.A!.set(0, 99)
  expect(st.maps.A!.get(0)).toBe(1)
  expect(st.maps.B!.get(0)).toBe(2)
})

// A module declares only the runtime helpers it calls: a helper declared and never called is dead code in the caller's
// bundle (and a lint error there).
test('a compiled module declares only the helpers it calls', () => {
  const machines = [sortedList().machine, distinctNames().machine, ...Array.from({length: 200}, () => machine())]
  const seen = new Set<string>()
  for (const m of machines) {
    const js = compileJs(m), declared = [...js.matchAll(/^function (\$\w+)\(/gm)].map(x => x[1]!)
    for (const name of declared) {
      seen.add(name)
      expect(js.split(`${name}(`).length - 1, `${name} in ${m.name}`).toBeGreaterThan(1)
    }
  }
  expect(seen.has('$spread')).toBe(true)
})
