#!/usr/bin/env node
// gdp-wired's command line: a rule read from code in any language the extractor reads, its laws proven, with nothing
// written. A thin layer over the library: the front ends (core/extract*.ts, core/effect.ts) read the rule with its
// boundary inferred, core/laws.ts reads the laws stated in the code, the prover (core/dsl.ts's proveRule and
// proveSteps, with their search) proves them, and laws nobody stated are proposed from the rule's own comparisons.
//
//   gdp-wired check <file|dir>... [--entry X] [--methods a,b] [--failures kept] [--json] [--ms 10000] [--no-propose]
//
// The language is the file's (.py .rb .ex .java .kt .go .rs .swift .c .h .cpp .cc .hpp .ts .js .sol; a directory with go.mod
// or .go files is a Go package, with Cargo.toml a Rust crate, with Package.swift a Swift package); the options a rule needs (failures, onError, methods,
// answers, skip, stores) from the flags or from gdp.toml (configFor, below). Exit code: 0 when no law stated in
// the code is broken, 1 when one is, 2 when one couldn't be checked (the rule refused, or the law not read).
import type {Extraction, Name} from './extract.ts'
import {fiberRun} from './fiber-run.ts'
import {type SecurityCandidate, securityTemplates} from './security.ts'
import {type Verdict, proveLeadsTo, proveRule, proveSteps} from './dsl.ts'
import type {Law} from './machine.ts'
import {type Built, type Calendar, type Cite, LawError, type LawOpts, type LawText, buildLaw, buildLeadsTo, buildTwoRuns, citesIn, isLeadsTo, isTwoRuns, lawsIn, namesWithClock} from './laws.ts'
import {type TwoRunLaw, certify, proveTwoRuns} from './relational.ts'
import {type InEnv, contend, envOf, inEnv, shrinkRun} from './system.ts'

type FS = {existsSync: (p: string) => boolean, readFileSync: (p: string, e: string) => string, readdirSync: (p: string) => string[], statSync: (p: string) => {isDirectory: () => boolean},
  mkdirSync: (p: string, o: {recursive: boolean}) => unknown, writeFileSync: (p: string, s: string) => void}
type Path = {resolve: (...p: string[]) => string, dirname: (p: string) => string, join: (...p: string[]) => string, basename: (p: string) => string, extname: (p: string) => string, relative: (a: string, b: string) => string}
const proc = (globalThis as unknown as {process: {argv: string[], exitCode?: number, cwd: () => string, env: Record<string, string | undefined>, stdout: {write: (s: string) => void, isTTY?: boolean}, getBuiltinModule: (id: string) => unknown}}).process
const fs = proc.getBuiltinModule('node:fs') as FS, path = proc.getBuiltinModule('node:path') as Path
const out = (s = '') => proc.stdout.write(`${s}\n`)
// Color, plain ANSI: only on a terminal, never with --json, NO_COLOR (any value) or TERM=dumb; FORCE_COLOR turns it on.
// Uncolored, the text is the same byte for byte.
export const colors = (env: Record<string, string | undefined>, tty: boolean, json = false): boolean =>
  !json && (env.FORCE_COLOR !== undefined && !['0', 'false'].includes(env.FORCE_COLOR) ? true : env.NO_COLOR === undefined && env.TERM !== 'dumb' && tty)
let tint = false
const SGR = {green: 32, red: 31, yellow: 33, dim: 2}
const paint = (c: keyof typeof SGR, s: string | number) => (tint && s !== '' ? `\x1b[${SGR[c]}m${s}\x1b[0m` : String(s))
const VERDICT = {proven: 'green', broken: 'red', unknown: 'yellow', 'not read': 'yellow'} as const

// --- the options ---------------------------------------------------------------------------------------------------------
export type Opts = {entry?: string, mode?: 'standalone', methods?: string[], failures?: 'refuse' | 'kept', onError?: 'refuse' | 'discard', json?: boolean, ms: number, propose: boolean, root?: string,
  python?: string, clock?: string, cert?: string, [k: string]: unknown}
function args(argv: string[]): {cmd: string, targets: string[], o: Opts} {
  const o: Opts = {ms: 10_000, propose: true}, targets: string[] = []
  let cmd = ''
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]!
    if (a === '--json') o.json = true
    else if (a === '--no-propose') o.propose = false
    else if (a === '--security') o.security = true
    else if (a === '--require-review') o.requireReview = true
    else if (a.startsWith('--')) {
      const [k, inline] = a.slice(2).split('=') as [string, string | undefined], v = inline ?? argv[++i] ?? ''
      const key = k.replace(/-(\w)/g, (_, c: string) => c.toUpperCase())
      o[key] = key === 'methods' ? v.split(',') : key === 'ms' ? Number(v) : v
    } else if (!cmd) cmd = a
    else targets.push(a)
  }
  return {cmd, targets, o}
}

// --- the languages -------------------------------------------------------------------------------------------------------
export type Lang = 'python' | 'ruby' | 'elixir' | 'java' | 'kotlin' | 'go' | 'rust' | 'swift' | 'c' | 'cpp' | 'ts' | 'solidity'
const EXT: Record<string, Lang> = {'.py': 'python', '.rb': 'ruby', '.ex': 'elixir', '.exs': 'elixir', '.java': 'java', '.kt': 'kotlin', '.go': 'go', '.rs': 'rust', '.swift': 'swift', '.c': 'c', '.h': 'c',
  '.cpp': 'cpp', '.cc': 'cpp', '.cxx': 'cpp', '.hpp': 'cpp', '.ts': 'ts', '.mts': 'ts', '.tsx': 'ts', '.js': 'ts', '.mjs': 'ts', '.sol': 'solidity'}
const COMMENT: Record<Lang, string> = {python: '#', ruby: '#', elixir: '#', java: '//', kotlin: '//', go: '//', rust: '//', swift: '//', c: '//', cpp: '//', ts: '//', solidity: '//'}
export const LANG_NAME: Record<Lang, string> = {python: 'Python', ruby: 'Ruby', elixir: 'Elixir', java: 'Java', kotlin: 'Kotlin', go: 'Go', rust: 'Rust', swift: 'Swift', c: 'C', cpp: 'C++', ts: 'TypeScript', solidity: 'Solidity'}
// A target: the path a front end reads (a file, a Go package, a Rust crate), its language and the files its laws are in.
type Target = {lang: Lang, at: string, files: string[]}
function targetsOf(p: string): Target[] {
  const abs = path.resolve(p)
  if (!fs.existsSync(abs)) throw new Error(`${p}: no such file or directory`)
  const src = (d: string, ext: RegExp) => fs.readdirSync(d).filter(f => ext.test(f) && !/_test\.go$|\.test\.|_spec\./.test(f)).map(f => path.join(d, f))
  if (fs.statSync(abs).isDirectory()) {
    if (fs.existsSync(path.join(abs, 'Cargo.toml'))) return [{lang: 'rust', at: abs, files: rustFiles(abs)}]
    if (fs.existsSync(path.join(abs, 'Package.swift'))) return [{lang: 'swift', at: abs, files: swiftFiles(path.join(abs, 'Sources'))}]
    if (fs.existsSync(path.join(abs, 'go.mod')) || src(abs, /\.go$/).length) return [{lang: 'go', at: abs, files: src(abs, /\.go$/)}]
    return fs.readdirSync(abs).filter(f => EXT[path.extname(f)] && !/\.test\.|_test\.|_spec\.|\.d\.ts$/.test(f)).flatMap(f => targetsOf(path.join(abs, f)))
  }
  const lang = EXT[path.extname(abs)]
  if (!lang) throw new Error(`${p}: not a language gdp-wired reads (${Object.keys(EXT).join(' ')})`)
  if (lang === 'go') return [{lang, at: path.dirname(abs), files: src(path.dirname(abs), /\.go$/)}]
  if (lang === 'rust') { const crate = up(path.dirname(abs), d => fs.existsSync(path.join(d, 'Cargo.toml'))); return [{lang, at: crate ?? path.dirname(abs), files: crate ? rustFiles(crate) : [abs]}] }
  return [{lang, at: abs, files: [abs]}]
}
const swiftFiles = (d: string): string[] => (fs.existsSync(d) ? fs.readdirSync(d).flatMap(f => { const p = path.join(d, f); return fs.statSync(p).isDirectory() ? swiftFiles(p) : f.endsWith('.swift') ? [p] : [] }) : [])
const rustFiles = (crate: string): string[] => { const d = path.join(crate, 'src'); return fs.existsSync(d) ? fs.readdirSync(d).filter(f => f.endsWith('.rs')).map(f => path.join(d, f)) : [] }
// The nearest directory from `d` up where `ok` holds.
export function up(d: string, ok: (d: string) => boolean): string | undefined {
  for (let x = d; ; x = path.dirname(x)) { if (ok(x)) return x; if (path.dirname(x) === x) return undefined }
}

// A front end run on a target with the options (each loaded only when its language is read).
async function extractOne(t: Target, o: Record<string, unknown>): Promise<Extraction> {
  try { return await extractWith(t, o) } catch (e) {
    // (every front end is read through the TypeScript extractor's terms: the typescript package beside gdp-wired)
    if (/typescript/.test(String((e as Error).message)) && /find|resolve/i.test(String((e as Error).message))) throw new Error('the extractors need the typescript package beside gdp-wired: npx gdp-wired-cli check ... (gdp-wired with TypeScript beside it), or npm i -D gdp-wired typescript')
    throw e
  }
}
// A TypeScript file's relative imports, read beside it as TypeScript resolves them (two deep, at most 12 files), by their
// path from the file's directory: their classes and functions are the code's own, read and inlined, not another module's.
function relativeImports(entry: string): Record<string, string> {
  const out: Record<string, string> = {}, seen = new Set([entry]), queue: [string, number][] = [[entry, 1]], dir = path.dirname(entry)
  while (queue.length && Object.keys(out).length < 12) {
    const [from, depth] = queue.shift()!
    for (const m of fs.readFileSync(from, 'utf8').matchAll(/(?:\bfrom\s+|\bimport\s*\(\s*|\brequire\(\s*|^\s*import\s+)['"](\.{1,2}\/[^'"]+)['"]/gm)) {
      const base = path.join(path.dirname(from), m[1]!), bare = base.replace(/\.(js|jsx|mjs|cjs)$/, '')
      const hit = [base, ...['.ts', '.tsx', '.js', '.jsx', '.mjs'].map(x => `${bare}${x}`), ...['/index.ts', '/index.tsx', '/index.js'].map(x => `${base}${x}`)].find(c => fs.existsSync(c) && !fs.statSync(c).isDirectory())
      if (!hit || seen.has(hit) || Object.keys(out).length >= 12) continue
      seen.add(hit)
      out[path.relative(dir, hit)] = fs.readFileSync(hit, 'utf8')
      if (depth < 2) queue.push([hit, depth + 1])
    }
  }
  return out
}
async function extractWith(t: Target, o: Record<string, unknown>): Promise<Extraction> {
  const f = t.at, dir = path.dirname(f)
  switch (t.lang) {
    case 'python': {
      const {extractPython} = await import('./extract-py.ts')
      // (the repository's root: the project's (pyproject.toml, setup.py), else above the outermost package the file is
      // in; the Python of a virtualenv beside it)
      const root = (o.root as string | undefined) ?? up(dir, d => ['pyproject.toml', 'setup.py', 'setup.cfg'].some(m => fs.existsSync(path.join(d, m)))) ?? up(dir, d => !fs.existsSync(path.join(d, '__init__.py'))) ?? dir
      const venv = up(root, d => fs.existsSync(path.join(d, '.venv', 'bin', 'python')))
      return extractPython(f, {root, ...(venv ? {python: path.join(venv, '.venv', 'bin', 'python')} : {}), ...o})
    }
    case 'ruby': { const {extractRuby} = await import('./extract-rb.ts'); return extractRuby(f, {root: up(dir, d => path.basename(d) === 'lib') ?? dir, ...o}) }
    case 'elixir': { const {extractElixir} = await import('./extract-ex.ts'); return extractElixir(f, o) }
    case 'java': { const {extractJava} = await import('./extract-jvm.ts'); return extractJava(f, o) }
    case 'kotlin': { const {extractKotlin} = await import('./extract-jvm.ts'); return extractKotlin(f, o) }
    case 'go': { const {extractGo} = await import('./extract-go.ts'); return extractGo(f, o) }
    case 'rust': { const {extractRust} = await import('./extract-rs.ts'); return extractRust(f, o) }
    case 'swift': { const {extractSwift} = await import('./extract-swift.ts'); return extractSwift(f, o) }
    case 'c': case 'cpp': { const {extractC} = await import('./extract-c.ts'); return extractC(f, o, t.lang === 'cpp') }
    case 'solidity': { const {extractSolidity} = await import('./extract-sol.ts'); return extractSolidity(f, {root: up(dir, d => ['foundry.toml', 'hardhat.config.js', 'hardhat.config.ts', 'package.json'].some(m => fs.existsSync(path.join(d, m)))) ?? dir, ...o}) }
    case 'ts': {
      // (Effect and XState run on the package the file's own project has, imported here as the code imports it)
      const code = fs.readFileSync(f, 'utf8'), file = path.relative(proc.cwd(), f) || f, {createRequire} = proc.getBuiltinModule('node:module') as {createRequire: (p: string) => {resolve: (s: string) => string}}
      const own = async (spec: string) => { try { return await import(createRequire(f).resolve(spec)) as Record<string, unknown> } catch { return undefined } }
      if (o.mode === undefined && /from\s+['"]effect(\/\w+)?['"]/.test(code)) { const {extractEffect} = await import('./effect.ts'), effect = await own('effect'); return extractEffect(file, {...(effect ? {effect} : {}), ...o} as never) }
      if (o.mode === undefined && /from\s+['"]xstate['"]/.test(code) && /\bcreateMachine\b/.test(code)) { const {extractXState} = await import('./extract-xstate.ts'), xstate = await own('xstate'); return extractXState(file, {...(xstate ? {xstate} : {}), ...o} as never) as Extraction }
      const {extract} = await import('./extract.ts'), files = relativeImports(f)
      return extract(file, {...(Object.keys(files).length ? {files} : {}), ...o} as never)
    }
  }
}

// --- gdp.toml: the modelling choices of each rule, written once beside the code -------------------------------------------
// The nearest gdp.toml, pyproject.toml's [tool.gdp] or package.json's "gdp" from the code up: its top-level keys for
// every rule, [rules.<entry>] for one (failures, onError, methods, answers, skip, stores and their attrs, strict, root,
// python, ...: the front end's own options). TOML has no null: "None" (or "null", "nil") is one, Redis off.
//
//   failures = "kept"
//   [rules._PROXY_MaxIterationsHandler]
//   methods = ["async_pre_call_hook"]
//   stores.internal_usage_cache.attrs = {"dual_cache.redis_cache" = "None"}
type Config = {all: Record<string, unknown>, rules: Record<string, Record<string, unknown>>, at?: string}
export function configFor(from: string): Config {
  // (the first of the three in a directory that holds gdp's options)
  const holder = (d: string) => ['gdp.toml', 'pyproject.toml', 'package.json'].find(f => fs.existsSync(path.join(d, f)) && (f === 'gdp.toml' || (f === 'pyproject.toml' ? /^\[tool\.gdp\b/m : /"gdp"\s*:/).test(fs.readFileSync(path.join(d, f), 'utf8'))))
  const dir = up(from, d => !!holder(d))
  if (!dir) return {all: {}, rules: {}}
  const f = holder(dir)!
  const text = fs.readFileSync(path.join(dir, f), 'utf8')
  let c: Record<string, unknown>
  if (f === 'package.json') c = (JSON.parse(text) as {gdp?: Record<string, unknown>}).gdp ?? {}
  else if (f === 'pyproject.toml') {
    // (only its [tool.gdp...] tables, read as a gdp.toml's)
    let on = false
    c = (toml(text.split('\n').filter(l => { const h = /^\s*\[([^\]]*)\]/.exec(l); if (h) on = /^tool\.gdp\b/.test(h[1]!.trim()); return on }).join('\n')) as {tool?: {gdp?: Record<string, unknown>}}).tool?.gdp ?? {}
  } else c = toml(text)
  const {rules, ...all} = c as {rules?: Record<string, Record<string, unknown>>}
  return {all, rules: rules ?? {}, at: path.join(dir, f)}
}
// TOML's subset a gdp.toml needs: tables ([a.b."c.d"]), dotted and quoted keys, strings, integers, booleans, arrays and
// inline tables on one line, # comments.
export function toml(text: string): Record<string, unknown> {
  const root: Record<string, unknown> = {}
  let table = root
  const keys = (s: string): string[] => [...s.matchAll(/\s*(?:"((?:[^"\\]|\\.)*)"|'([^']*)'|([\w-]+))\s*(?:\.|$)/g)].map(m => m[1] ?? m[2] ?? m[3]!)
  const at = (o: Record<string, unknown>, ks: string[]) => ks.reduce((t, k) => (t[k] ??= {}) as Record<string, unknown>, o)
  // (a dotted key = value set in a table; what follows it)
  const pair = (s: string, into: Record<string, unknown>): string => {
    const eq = /^((?:"(?:[^"\\]|\\.)*"|'[^']*'|[\w.-]+|\s)+?)\s*=/.exec(s) ?? fail(`gdp.toml: can't read ${s.slice(0, 40)}`)
    const ks = keys(eq[1]!), [v, r] = value(s.slice(eq[0].length))
    at(into, ks.slice(0, -1))[ks.at(-1)!] = v
    return r
  }
  const value = (s: string): [unknown, string] => {
    s = s.trimStart()
    const str = /^"((?:[^"\\]|\\.)*)"|^'([^']*)'/.exec(s)
    if (str) { const v = str[1] !== undefined ? JSON.parse(`"${str[1]}"`) as string : str[2]!; return [['None', 'null', 'nil'].includes(v) ? null : v, s.slice(str[0].length)] }
    if (s[0] === '[' || s[0] === '{') {
      const arr = s[0] === '[', out: unknown[] = [], obj: Record<string, unknown> = {}
      s = s.slice(1)
      for (;;) {
        s = s.trimStart()
        if (s[0] === (arr ? ']' : '}')) return [arr ? out : obj, s.slice(1)]
        if (s[0] === ',') { s = s.slice(1); continue }
        if (arr) { const [v, r] = value(s); out.push(v); s = r } else s = pair(s, obj)
      }
    }
    const m = /^(true|false|-?\d+)/.exec(s) ?? fail(`gdp.toml: can't read ${s.slice(0, 40)}`)
    return [m[1] === 'true' ? true : m[1] === 'false' ? false : Number(m[1]), s.slice(m[0].length)]
  }
  for (const raw of text.split('\n')) {
    const l = raw.trim()
    if (!l || l.startsWith('#')) continue
    const h = /^\[([^\]]+)\]\s*(?:#.*)?$/.exec(l)
    if (h) { table = at(root, keys(h[1]!)); continue }
    const r = pair(l, table).trim()
    if (r && !r.startsWith('#')) fail(`gdp.toml: can't read ${l}`)
  }
  return root
}
const fail = (s: string): never => { throw new Error(s) }
// Two option objects merged, the second's winning (objects merged key by key: a store's attrs beside its methods).
const merge = (a: Record<string, unknown>, b: Record<string, unknown>): Record<string, unknown> => {
  const out = {...a}
  for (const [k, v] of Object.entries(b)) out[k] = v && typeof v === 'object' && !Array.isArray(v) && out[k] && typeof out[k] === 'object' && !Array.isArray(out[k]) ? merge(out[k] as Record<string, unknown>, v as Record<string, unknown>) : v
  return out
}

// --- one target: its rules, their laws -------------------------------------------------------------------------------------
type LawOut = {name: string, expr: string, where?: string, kind?: 'law' | 'step' | 'two runs' | 'leads to', from?: 'any', verdict: 'proven' | 'broken' | 'unknown' | 'not read', run?: string[], replayed?: string, why?: string, assumes?: string[], found?: string[], cites?: string[], cert?: string, ms: number}
export type RuleOut = {file: string, lang: string, entry?: string, ctor?: string, ok: boolean, refusals: {where: string, what: string}[], notes: string[], names: Name[], checked?: string, env?: string[],
  laws: LawOut[], proposed: LawOut[], brokenProposed?: number, source?: string,
  security?: (LawOut & Pick<SecurityCandidate, 'securityKind' | 'review'>)[]}

// The entries to read: the one given, else the one inferred; where several classes or structs qualify, each of them; a
// file of functions, each function a law is stated on.
// Every class or function a law is stated on is read too (a class that writes no state, a decision, among them): no law
// stated in the code is left without a rule to be proven on, or refused with why.
type ReadRule = {entry?: string, ctor?: string, x: Extraction}
// Each initializer is a separate scope, with its own original-code replay and laws. Never choose one
// overload on the caller's behalf or let a successful variant hide another variant's refusal.
async function expandInitializers(t: Target, o: Opts, laws: Scoped[], rows: ReadRule[]): Promise<ReadRule[]> {
  if (!rows.some(r => r.x.initializers)) return rows
  const {json: _j, ms: _m, propose: _p, clock: _c, cert: _t, from: _fr, env: _e, ...flags} = o
  void _j; void _m; void _p; void _c; void _t; void _fr; void _e
  const cfg = configFor(t.lang === 'go' || t.lang === 'rust' || fs.statSync(t.at).isDirectory() ? t.at : path.dirname(t.at))
  const {clock: _k, from: _f, env: _v, calendar: _cal, ...shared} = cfg.all
  void _k; void _f; void _v; void _cal
  const keep = [...new Set(laws.flatMap(l => l.expr.match(/[A-Za-z_]\w*(?:::[A-Za-z_]\w*)*/g) ?? []).flatMap(k => k.includes('::') ? [k, ...k.split('::')] : [k]))]
  const out: ReadRule[] = []
  for (const row of rows) {
    const variants = row.x.initializers
    if (!variants) { out.push(row); continue }
    const entry = row.entry ?? variants.name
    const opts = merge(merge({...shared, keep}, cfg.rules[entry] || {}), flags)
    // A rule-specific constructor choice discovered after entry inference still takes precedence.
    if (opts.ctor !== undefined) { out.push({entry, x: await extractOne(t, {...opts, entry: variants.entry})}); continue }
    for (const ctor of [...new Set(variants.selectors)]) {
      const x = await extractOne(t, {...opts, entry: variants.entry, ctor})
      x.notes.push(`initializer ${ctor}: separate scope; every initializer is required for coverage of the class`)
      out.push({entry, ctor, x})
    }
  }
  return out
}
async function rulesOf(t: Target, o: Opts, laws: Scoped[]): Promise<ReadRule[]> {
  const got = await rulesOf0(t, o, laws)
  if (o.entry) return expandInitializers(t, o, laws, got)
  // (a function that is a request of a rule read, a C file's globals', is read with it)
  const evs = (x: Extraction) => { const s = (x.model as {inputs?: {name: string, sort: {k: string, values?: string[]}}[]} | undefined)?.inputs?.find(v => v.name === (x.names ?? []).find(n => n.role === 'method')?.rule)?.sort; return s?.k === 'choice' ? s.values ?? [] : [] }
  const have = new Set(got.flatMap(r => [r.entry, r.x.model?.name, r.x.initializers?.name, ...(r.x.ok ? [...(r.x.names ?? []).map(n => n.method), ...evs(r.x)] : [])].filter((n): n is string => !!n)))
  const more = [...new Set(laws.map(l => l.cls ?? l.fn).filter((n): n is string => !!n && !have.has(n)))]
  if (!more.length) return expandInitializers(t, o, laws, got)
  const {json: _j, ms: _m, propose: _p, clock: _c, cert: _t, from: _fr, env: _e, ...flags} = o
  void _j; void _m; void _p; void _c; void _t; void _fr
  const cfg = configFor(t.lang === 'go' || t.lang === 'rust' || fs.statSync(t.at).isDirectory() ? t.at : path.dirname(t.at))
  const {clock: _k, from: _f, env: _v, calendar: _cal, ...shared} = cfg.all
  void _k; void _f
  const keep = [...new Set(laws.flatMap(l => l.expr.match(/[A-Za-z_]\w*(?:::[A-Za-z_]\w*)*/g) ?? []).flatMap(k => (k.includes('::') ? [k, ...k.split('::')] : [k])))]
  const extra = await Promise.all(more.map(async entry => ({entry, x: await extractOne(t, {...merge(merge({...shared, keep}, cfg.rules[entry] || {}), flags), entry})})))
  // (the first rule, read with no entry named, kept only where it read something or nothing else was)
  return expandInitializers(t, o, laws, [...got.filter(r => r.x.ok || r.entry || !extra.length), ...extra])
}
async function rulesOf0(t: Target, o: Opts, laws: Scoped[]): Promise<{entry?: string, x: Extraction}[]> {
  const {json: _j, ms: _m, propose: _p, clock: _c, cert: _t, from: _fr, env: _e, ...flags} = o
  void _j; void _m; void _p; void _c; void _t; void _fr
  // (the options: gdp.toml's for every rule, then the rule's own, then the flags; a rule found with no entry named is
  // read again where gdp.toml has options of its own for it)
  const cfg = configFor(t.lang === 'go' || t.lang === 'rust' || fs.statSync(t.at).isDirectory() ? t.at : path.dirname(t.at))
  const {clock: _k, from: _f, env: _v, calendar: _cal, ...shared} = cfg.all
  void _f
  void _k
  // (the names the laws read, so an argument a law reads stays in the rule though the code ignores it)
  const keep = [...new Set(laws.flatMap(l => l.expr.match(/[A-Za-z_]\w*(?:::[A-Za-z_]\w*)*/g) ?? []).flatMap(k => (k.includes('::') ? [k, ...k.split('::')] : [k])))]
  const optsFor = (entry?: string) => merge(merge({...shared, keep}, (entry && cfg.rules[entry]) || {}), flags)
  const one = async (entry?: string) => {
    const x = await extractOne(t, {...optsFor(entry), ...(entry ? {entry} : {})}), found = x.model?.name
    return !entry && found && cfg.rules[found] ? {entry: found, x: await extractOne(t, {...optsFor(found), entry: found})} : {entry, x}
  }
  const given = o.entry ?? (cfg.all.entry as string | undefined)
  if (given) return [await one(given)]
  if (t.lang === 'ts' || t.lang === 'cpp') {
    const code = t.files.map(f => fs.readFileSync(f, 'utf8')).join('\n')
    const re = t.lang === 'cpp' ? /^\s*(?:class|struct)\s+(\w+)\s*(?::[^{]*)?\{/gm : /export\s+(?:default\s+)?(?:abstract\s+)?class\s+(\w+)|export\s+(?:const|function)\s+(\w+)/g
    // (C++: a class its source file defines methods of, `Alarm::detected(...) {`, declared in its header)
    const defs = t.lang === 'cpp' ? [...code.matchAll(/^[\w:<>*&\s]*?\b(\w+)::~?\w+\s*\([^;]*?\)\s*(?:const\s*)?(?::[^{;]*)?\{/gm)].map(m => m[1]!) : []
    const cands = [...new Set([...[...code.matchAll(re)].map(m => m[1] ?? m[2]!), ...defs])]
    const all = await Promise.all(cands.map(c => one(c)))
    const good = all.filter(r => r.x.ok)
    return good.length ? good : all.length ? all : [{x: {ok: false, refusals: [{where: t.at, what: 'no class or exported function to read: name the entry (--entry)'}], notes: []}}]
  }
  const first = await one()
  if (first.x.ok) return [first]
  // (refused with no entry named: the rules gdp.toml names that the code has, each with its options)
  // (a rule gdp.toml names, where the file defines a class, struct or function of that name: never a word of its prose)
  const named = Object.keys(cfg.rules).filter(k => t.files.some(f => new RegExp(`\\b(?:class|struct|def|defp|defmodule|module|fn|fun|func|function|interface|contract|object|impl|type|record|enum)\\s+(?:\\([^)]*\\)\\s*)?${k.replace(/[^\w]/g, '\\$&')}\\b`).test(fs.readFileSync(f, 'utf8'))))
  // (and each class the refusal names: gdp.toml's rules beside the file's others, not instead of them)
  const many = /several (?:classes|structs) (?:write their state|written by the file's functions) \(([^)]*)\)/.exec(first.x.refusals[0]?.what ?? '')?.[1]!.split(', ') ?? []
  const fns0 = [...new Set(laws.filter(l => !l.cls && l.fn).map(l => l.fn!))]
  if (named.length) return Promise.all([...new Set([...many, ...named, ...fns0])].map(k => one(k)))
  // (a contract's file names its contracts: refused with none named, the refusal is the rule's)
  if (t.lang === 'solidity') return [first]
  // (else each class the refusal names, and each function outside a class a law is stated on)
  const what = first.x.refusals[0]?.what ?? ''
  const several = /several (?:classes|structs) (?:write their state|written by the file's functions) \(([^)]*)\)/.exec(what)?.[1]!.split(', ') ?? []
  const fns = [...new Set(laws.filter(l => !l.cls && l.fn).map(l => l.fn!))]
  return several.length || fns.length ? Promise.all([...several, ...fns].map(c => one(c))) : [first]
}

// A law with where it sits in the code: the class (or struct, module) it is in and the function after it.
type Scoped = LawText & {cls?: string, fn?: string}
// (a class statement's name: its keyword at the start of a line, after modifiers; never a word in a comment)
const classAt = (line: string) => {
  const m = /^\s*(?:(?:export|default|public|private|protected|internal|abstract|final|sealed|open|data|static|partial|pub(?:\([^)]*\))?|unsafe)\s+)*(?:class|struct|actor|defmodule|module|object|impl(?:<[^>]*>)?|record|interface|contract)\s+([\w.:]+)|^\s*type\s+(\w+)\s+struct\b/.exec(line.replace(/(#|\/\/).*$/, ''))
  return m ? (m[1] ?? m[2])!.split(/[.:<]/).filter(Boolean).pop() : undefined
}
// (a type written like a call declares a value, never a function: `mapping(address => uint256) public balances;`, its
// parentheses closed, then a name (after modifiers) and `;` or `=`; a function's qualifiers (const, override, ...) are no
// name. A law on such a value is on no function, nor is one followed by another class's statement before any.)
const declares = (code: string, open: number) => {
  let d = 0, i = open
  for (; i < code.length; i++) { if (code[i] === '(') d++; else if (code[i] === ')' && --d === 0) break }
  const m = /^\s*(?:[A-Za-z_$][\w$]*\s+)*([A-Za-z_$][\w$]*)\s*(?:;|=(?![=>]))/.exec(code.slice(i + 1))
  return !!m && !/^(const|override|final|noexcept|volatile|default|delete)$/.test(m[1]!)
}
export function scoped(file: string): Scoped[] {
  const text = fs.readFileSync(file, 'utf8'), lines = text.split('\n')
  return lawsIn(text, path.basename(file)).map(l => {
    let cls: string | undefined, fn: string | undefined
    // (the nearest enclosing class statement: its keyword at the start of a line, after modifiers, never a word in a
    // docstring's or a comment's prose; in Python, at an indentation that encloses the law's)
    const indent = (x: string) => /^\s*/.exec(x)![0].length, lawIndent = indent(lines[l.line! - 1]!), py = file.endsWith('.py')
    for (let i = l.line! - 1; i >= 0 && !cls; i--) {
      const m = classAt(lines[i]!)
      if (m && (!py || indent(lines[i]!) < lawIndent)) cls = m
    }
    // (a law right above a class statement, past comments, blank lines and annotations, is that class's: a contract's,
    // a struct's, a class's, never its first member's; one indented inside a class above a class after it isn't)
    let above: string | undefined
    for (let i = l.line!; i < lines.length; i++) { if (/^\s*(\/\/|\/?\*|#|@|--|$)/.test(lines[i]!)) continue; above = indent(lines[i]!) >= lawIndent ? classAt(lines[i]!) : undefined; break }
    if (above) return {...l, cls: above}
    // (in TypeScript, a law right above a declaration of a value, a schedule's say, is that value's)
    let top = false
    if (/\.[cm]?[jt]sx?$/.test(file)) { let i = l.line!; while (i < lines.length && /^\s*(\/\/|\/?\*|$)/.test(lines[i]!)) i++; const d = /^(\s*)(?:export\s+)?(?:const|let|var)\s+(\w+)\s*[=:]/.exec(lines[i] ?? ''); if (d) { fn = d[2]; top = d[1] === '' } }
    let fnLine = -1
    let onValue = false
    for (let i = l.line! - 1; i < lines.length && !fn && !onValue; i++) { const code = i === l.line! - 1 ? lines[i]!.replace(/(#|\/\/|--).*$/, '') : lines[i]!; if (i >= l.line! && classAt(code)) break; const m = /\b(?:def|defp|fn|fun|func|function)\s+(?:\([^)]*\)\s*)?(?:self\.)?(\w+)|^\s*(?:(?:public|private|protected|static|final|synchronized|async|override|open|suspend|inline|virtual|const|[\w<>[\],?]+)\s+)*(?:(\w+)::)?(~?\w+)\s*\(/.exec(code); if (m && !m[1] && !m[2] && declares(code, m.index + m[0].length - 1)) onValue = true; else if (m && !/^(if|for|while|switch|return|catch|new)$/.test(m[1] ?? m[3]!)) { fn = m[1] ?? m[3]; fnLine = i; if (m[2]) { cls = m[2]; if (fn === m[2] || fn === `~${m[2]}`) { fn = undefined; break } } } }
    // (a Python function at the module's top level is in no class, whatever precedes it: the def the law sits on, not a
    // later one of the same name)
    // (likewise in every language where a definition at the line's start is outside any class: Ruby's, Elixir's, a
    // TypeScript, Kotlin, Swift or Rust free function; a Go func is its receiver's type's, or none)
    const at0 = fn && fnLine >= 0 ? lines[fnLine]! : ''
    // (a law indented inside a class's body, the class's last line, is the class's: a free function after the class
    // isn't what it sits on)
    if (fn && fnLine >= 0 && /\.(py|rb|ex|exs|ts|mts|tsx|js|mjs|kt|swift|rs)$/.test(file) && /^\S/.test(at0) && !/^\s*(?:class|struct|impl|module|defmodule|object|interface)\b/.test(at0)) {
      if (/^\S/.test(lines[l.line! - 1]!)) cls = undefined
      else if (cls) fn = undefined
    }
    if (fn && fnLine >= 0 && file.endsWith('.go')) { const rv = /^func\s+\(\s*\w*\s*\*?\s*(\w+)/.exec(at0); cls = rv ? rv[1] : /^func\s/.test(at0) ? undefined : cls }
    if (top) cls = undefined
    return {...l, ...(cls ? {cls} : {}), ...(fn ? {fn} : {})}
  })
}

export async function checkTarget(t: Target, o: Opts): Promise<RuleOut[]> {
  const laws = t.files.flatMap(scoped), cites = t.files.flatMap(f => citesIn(fs.readFileSync(f, 'utf8'), path.basename(f)))
  const rules = await rulesOf(t, o, laws)
  const outs: RuleOut[] = []
  // (the clock's unit, for durations in a law: the language's clock, or clock = "s" | "ms" in gdp.toml or --clock)
  const unit = o.clock ?? configFor(t.lang === 'go' || t.lang === 'rust' || fs.statSync(t.at).isDirectory() ? t.at : path.dirname(t.at)).all.clock ?? CLOCK[t.lang]
  const others = Object.fromEntries(rules.filter(r => r.x.ok && r.ctor === undefined).map(r => [r.entry ?? r.x.model?.name ?? '', r.x]))
  const cfg = configFor(t.lang === 'go' || t.lang === 'rust' || fs.statSync(t.at).isDirectory() ? t.at : path.dirname(t.at))
  const baseCtx: Ctx = {ms: o.ms, clock: unit === 's' ? 1 : unit === 'ms' ? 1000 : undefined, others, cites, cert: o.cert, file: path.relative(proc.cwd(), t.at) || t.at, ...(cfg.all.calendar ? {calendar: cfg.all.calendar as Calendar} : {})}
  for (const [initializerIndex, {entry, ctor, x: x0}] of rules.entries()) {
    // Different initial states must never overwrite one another's certificates.
    const ctx = ctor !== undefined && baseCtx.cert ? {...baseCtx, cert: path.join(baseCtx.cert, `initializer-${initializerIndex}`)} : baseCtx
    let x = x0
    const name = entry ?? (x.model?.name || undefined)
    // (a target that is the working directory, a crate's or a package's: `.`)
    const r: RuleOut = {file: path.relative(proc.cwd(), t.at) || '.', lang: LANG_NAME[t.lang], ...(name ? {entry: name} : {}), ...(ctor !== undefined ? {ctor} : {}), ok: x.ok, refusals: x.refusals, notes: x.notes, names: x.names ?? [], laws: [], proposed: [], ...(x.source ? {source: x.source} : {})}
    outs.push(r)
    // (the laws of this rule: all where it is the file's one, else those in its class or on it or its methods, and those
    // outside every class and function)
    // (and every request, one with no argument too: the method's choice)
    const ev0 = (x.model as {inputs?: {name: string, sort: {k: string, values?: string[]}}[]} | undefined)?.inputs?.find(v => v.name === (x.names ?? []).find(n => n.role === 'method')?.rule)?.sort
    const ms0 = new Set([...(x.names ?? []).map(n => n.method), ...(ev0?.k === 'choice' ? ev0.values ?? [] : [])])
    // (a law in a class is that class's alone, an entry named or not)
    // (a law on a function outside any class is that function's, where the file has a rule of its name, never a method
    // of another rule that shares the name)
    const fnRules = new Set(rules.map(r => r.entry ?? r.x.model?.name).filter(Boolean))
    const mine = rules.length === 1 ? laws.filter(l => !name || (l.cls ? l.cls === name : !l.fn || l.fn === name || ms0.has(l.fn))) : laws.filter(l => (!l.cls && !l.fn) || (l.cls ? l.cls === name : l.fn === name || (ms0.has(l.fn) && !fnRules.has(l.fn))))
    if (!x.ok || !x.rule) { r.laws = mine.map(l => ({name: l.name, expr: l.expr, where: l.where, verdict: 'not read', why: 'the rule was refused', ms: 0})); continue }
    // (an Effect service's primitives: the lemmas of their use proven first, each proven one beside every law)
    if ((x as {lemmas?: unknown[]}).lemmas?.length) { const {withLemmas} = await import('./effect.ts'), w = withLemmas(x, {ms: Math.max(o.ms, 30_000)}); x = w.x; r.notes = [...r.notes, ...w.proven.map(n => `lemma proven, beside every law: ${n}`), ...w.unproven.map(n => `lemma not proven (left out): ${n}`)] }
    const ev = x.evidence
    if (ev) r.checked = `checked against ${'probes' in ev ? `the code: ${ev.requests} requests from the start, ${ev.fromStates} from drawn states, ${ev.probes.steps} from the prover's witnesses` : `XState's own actor: ${(ev as unknown as {events: number}).events} events`}${ev.coverage.arms ? `, ${ev.coverage.hit} of ${ev.coverage.arms} branch arms` : ''}${'startsOutside' in ev && ev.startsOutside ? `; ${ev.startsOutside} starts whose constructor passes 2^53 - 1 left out (outside the rule's numbers: the claim is for starts within them)` : ''}`
    // (the rule's methods: the choice of method where it has several, else the one each name says)
    const evSort = x.model?.inputs.find(v => v.name === x.model?.event)?.sort
    const methods = new Set([...(x.names ?? []).filter(n => n.method).map(n => n.method!), ...(evSort?.k === 'choice' ? evSort.values : [])])
    const stated = mine.map(l => ({...l, ...(l.fn && methods.has(l.fn) ? {method: l.fn} : {})}))
    const proven: unknown[] = []
    // (the environment the code runs in: --env, gdp.toml's env for the rule or every rule, or a `gdp: env` comment in
    // its class: every call at once at its isolation level, keys that expire, retries; its laws lifted to it)
    const words = (o.env as string | undefined) ?? (name ? cfg.rules[name]?.env as string | string[] | undefined : undefined) ?? envTags(t.files, name) ?? cfg.all.env as string | string[] | undefined
    let sys: InEnv | undefined
    if (words) {
      try {
        const m = x.rule!.machine, stores = [...new Set((x.names ?? []).filter(n => n.map?.store && n.rule).map(n => n.rule))].map(b => Object.keys(m.maps ?? {}).filter(k => k === b || k.startsWith(`${b}.`))).filter(c => c.length)
        const own = Object.keys(m.state).filter(k => (x.names ?? []).some(n => (n.role === 'failed' || n.role === 'result') && ((n.rule && (k === n.rule || k.startsWith(`${n.rule}$`))) || k === n.none)))
        const ev = (x.names ?? []).find(n => n.role === 'method'), evSort = x.model?.inputs.find(v => v.name === x.model?.event)?.sort
        const failedVar = (x.names ?? []).find(n => n.role === 'failed')?.rule
        // (a flow the laws state where the env doesn't: at most one call between a and b is the flow a then b, a and a a
        // call of a alone, holding once it did its work)
        const env = envOf(words), bw = mine.map(l => /^at\s+most\s+one\s+call\s+between\s+([\w.]+)\s+and\s+([\w.]+)$/i.exec(l.expr.trim())).find(Boolean)
        if (!env.flow && bw) env.flow = bw[1] === bw[2] ? [bw[1]!] : [bw[1]!, bw[2]!]
        sys = inEnv(x.rule!, env, {stores, own, ...(ev && evSort?.k === 'choice' ? {method: {name: ev.rule, values: evSort.values}} : {}), ...(failedVar ? {failed: failedVar} : {}), args: (x.names ?? []).filter(n => n.role === 'input' && n.method && n.rule).map(n => ({method: n.method!, code: n.code, rule: n.rule})),
          oks: [...(x.names ?? []).filter(n => n.role === 'result' && n.method && x.model?.state.find(v => v.name === n.rule)?.sort.k === 'bool').map(n => ({method: n.method!, rule: n.rule})),
            // (a method that makes an effect did its work where it made it: a charge, a handled message)
            ...Object.entries((x as {read?: {effectsOf?: Record<string, string[]>}}).read?.effectsOf ?? {}).flatMap(([method, vs]) => vs.map(rule => ({method, rule})))]})
        r.env = sys.models.map(md => `${md.name}: ${md.assumes}`)
      } catch (e) {
        const why = `the environment: ${(e as Error).message}`
        r.laws = mine.map(l => ({name: l.name, expr: l.expr, where: l.where, verdict: 'not read', why, ms: 0}))
        // Opt-in security checking must not silently succeed when there are no stated laws
        // and the requested attacker/concurrency model could not be constructed.
        if (o.security) { r.ok = false; r.refusals.push({where: t.at, what: why}) }
        continue
      }
    }
    // (a law is known by its name: a name stated twice in one rule is refused, both times)
    const twice = (l: LawText) => stated.filter(m => m.name === l.name).map(m => m.where)
    // (from = "any": every law proven from every state the laws allow, not only those a run from the start reaches, for
    // code that steps the rule from states it is handed (a restart's, a stored one): the laws about states proven
    // together as one inductive set, then each law of a step from every state they allow; none rests on what the
    // search found)
    const from = ((o.from as string | undefined) ?? (name ? cfg.rules[name]?.from as string | undefined : undefined) ?? cfg.all.from as string | undefined) === 'any' ? 'any' as const : undefined
    const kindOf = (l: LawText): string => { if (isTwoRuns(l.expr)) return 'two'; if (isLeadsTo(l.expr)) return 'leads'; try { return buildLaw(x, l, ctx).kind } catch { return 'bad' } }
    const rank = (l: LawText) => ({law: 0, leads: 2}[kindOf(l)] ?? 1)
    const order = [...stated.keys()].sort((a, b) => rank(stated[a]!) - rank(stated[b]!))
    // (from any state, the laws about states as one inductive set: the largest the stated ones make, each law the
    // kernel's step breaks taken out in turn (Houdini), the others proven together; one taken out is judged alone)
    const inductive = from && x.rule && !sys ? houdini(x, stated.filter(m => twice(m).length === 1 && kindOf(m) === 'law'), o.ms, ctx) : undefined
    const outsOf: LawOut[] = []
    for (const i of order) {
      const l = stated[i]!
      outsOf[i] = twice(l).length > 1 ? {name: l.name, expr: l.expr, where: l.where, verdict: 'not read' as const, why: `a law of this name is stated twice (${twice(l).join(', ')}): a law is known by its name`, ms: 0}
        : sys ? proveInEnv(x, l, o.ms, proven as Law[], {...ctx, sys, entry: name}) : prove(x, l, o.ms, proven, {...ctx, entry: name, ...(from ? {from, inductive, together: stated.filter(m => twice(m).length === 1 && kindOf(m) === 'law' && inductive!.has(m.name))} : {})})
    }
    r.laws = outsOf
    if (o.security) {
      // Deliberately separate from accepted policy and from heuristic proposals that hide broken guesses.
      // Do not pass previously proven candidates as hypotheses; use the same environment/replay as stated laws.
      const candidates = securityTemplates(x), until = Date.now() + o.ms
      r.security = candidates.map(l => ({...(Date.now() >= until
        ? {name: l.name, expr: l.expr, verdict: 'unknown' as const, why: 'security proposal budget exhausted', ms: 0}
        : sys ? proveInEnv(x, l, Math.max(1, Math.min(2000, until - Date.now())), [], {...ctx, sys, entry: name, cert: undefined})
        : prove(x, l, Math.max(1, Math.min(2000, until - Date.now())), [], {...ctx, entry: name, cert: undefined})),
        securityKind: l.securityKind, review: l.review,
        where: `${l.method ? `above ${l.method}: ` : ''}${COMMENT[t.lang]} gdp: law ${l.name}: ${l.expr}`}))
      r.notes.push('security candidates require policy review; arbitrary requests in arbitrary order, values within the extracted types; bind identity/roles to authentication, not caller claims')
    }
    if (o.propose && x.model) { const p = propose(x, t.lang, o, proven, new Set(stated.map(l => l.expr.replace(/\s+/g, '')))); r.proposed = p.shown; r.brokenProposed = p.broken }
  }
  // (every law stated is accounted for: one that no rule took is reported not read, with why, never dropped)
  const told = new Set(outs.flatMap(r => r.laws.map(l => l.where)))
  const lost = laws.filter(l => !told.has(l.where))
  if (lost.length) outs.push({file: path.relative(proc.cwd(), t.at) || '.', lang: LANG_NAME[t.lang], entry: [...new Set(lost.map(l => l.cls ?? l.fn ?? '(the file)'))].join(', '), ok: false,
    refusals: [{where: t.at, what: 'laws no rule read'}], notes: [], names: [], proposed: [],
    laws: lost.map(l => ({name: l.name, expr: l.expr, where: l.where, verdict: 'not read' as const, why: `no rule read for it (${l.cls ? `class ${l.cls}` : l.fn ? `function ${l.fn}` : 'the file'}): name its entry (--entry, or [rules.<entry>] in gdp.toml)`, ms: 0}))})
  // (a citation of no law stated in the target: refused, as a law not read is)
  const named = new Set(laws.map(l => l.name))
  for (const c of cites.filter(c => !named.has(c.law))) outs[0]?.laws.push({name: c.law, expr: '', where: c.where, verdict: 'not read', why: `a citation of no law stated here (gdp: cite <law name>: <clause>): ${c.text}`, ms: 0})
  return outs
}
// The unit of each language's clock (Date.now() and a Clock's millis count milliseconds; time.time(), DateTime.diff in
// seconds and Instant's as_secs count seconds); the others say it in gdp.toml (clock = "s" or "ms").
const CLOCK: Partial<Record<Lang, string>> = {python: 's', elixir: 's', rust: 's', ts: 'ms', java: 'ms', kotlin: 'ms'}
type Ctx = {sys?: InEnv, ms: number, clock?: number, calendar?: Calendar, others: Record<string, Extraction>, cites: Cite[], cert?: string, file: string, entry?: string, from?: 'any', together?: LawText[], inductive?: Set<string>}
// The largest set of these laws that is inductive from every state they allow together: each law whose step the
// kernel breaks taken out, the rest tried again.
function houdini(x: Extraction, ls: LawText[], ms: number, opts: LawOpts): Set<string> {
  let set = ls.flatMap(l => { try { const b = buildLaw(x, l, opts); return b.kind === 'law' ? [{l, law: b.law as Law}] : [] } catch { return [] } })
  for (let i = 0; i <= ls.length && set.length; i++) {
    let v: Verdict
    try { v = proveRule(x.rule!, [...(x.invariants ?? []), ...set.map(s => s.law)], {search: {ms}, from: 'any'}) } catch { return new Set() }
    if (v.proven && v.checked && !v.assumes) return new Set(set.map(s => s.l.name))
    const bad = set.find(s => v.goal === s.l.name || v.goal?.startsWith(`${s.l.name} @`))
    if (!bad) return new Set()
    set = set.filter(s => s !== bad)
  }
  return new Set()
}

// A law proven: an invariant with the rule's own invariants beside it, a step law with them and the invariants proven
// so far (each holds in every reachable state, so the step laws may assume them); a law about two runs with the rule's
// invariants holding of each run (core/relational.ts). Its citations go beside it, and with --cert <dir> the proof, as
// an interchange document whose meta holds them.
// The rule a law is proven on: the extraction's, declaring the divisors the law reads that the code doesn't (x // k,
// x % k: floor division and remainder by a constant, known by their facts), its machine made again with them.
function ruleFor(x: Extraction, expr: string): Extraction {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const r = x.rule as any as {spec?: {arith?: Set<number>}, withDivisors: (...ks: number[]) => unknown} | undefined
  if (!r) return x
  const ks = [...expr.matchAll(/(?:\/\/|%)\s*(\d+)/g)].map(m => Number(m[1])).filter(k => k >= 1)
  return ks.length ? {...x, rule: r.withDivisors(...ks) as never} : x
}
function prove(x0: Extraction, l: LawText, ms: number, proven: unknown[], ctx?: Ctx): LawOut {
  const x = ruleFor(x0, l.expr)
  const t0 = Date.now(), cites = ctx?.cites.filter(c => c.law === l.name).map(c => c.text) ?? []
  const base = {name: l.name, expr: l.expr, ...(l.where ? {where: l.where} : {}), ...(cites.length ? {cites} : {})}
  const inv = x.invariants ?? [], search = {search: {ms}, ...(ctx?.from ? {from: ctx.from} : {})}
  // (whenever <from>, later <to>: proven with the rule's invariants and the laws proven so far, each helpful request fair)
  if (isLeadsTo(l.expr)) {
    let lt: unknown
    try { lt = buildLeadsTo(x, l, {clock: ctx?.clock}) } catch (e) { if (e instanceof LawError) return {...base, verdict: 'not read', why: (e as Error).message, ms: 0}; throw e }
    let v: Verdict
    try { v = proveLeadsTo(x.rule! as never, [...inv, ...proven] as never, lt as never, {ms}) } catch (e) { return {...base, kind: 'leads to', verdict: 'unknown', why: (e as Error).message, ms: Date.now() - t0} }
    return {...base, kind: 'leads to', verdict: v.proven && v.checked ? 'proven' : 'unknown', ...(v.proven && v.checked ? {} : {why: [v.goal, v.stuck, v.why].filter(Boolean).join('; ') || 'not proven'}), ms: Date.now() - t0}
  }
  let b: Built | undefined, two: TwoRunLaw | undefined
  // (a law that can't be built is not read, with why: never the whole check aborted)
  try { if (isTwoRuns(l.expr)) two = buildTwoRuns(x, l, ctx?.others); else b = buildLaw(x, l, ctx ?? {}) } catch (e) { return {...base, verdict: 'not read', why: (e as Error).message, ms: 0} }
  const kind = two ? 'two runs' as const : b!.kind
  let v: Verdict & {given?: Law[]}
  // (from any state, a law about states outside the inductive set: false from the start (a run), or true there and
  // needing a law beside it to hold from every state the laws allow)
  if (ctx?.from && ctx.inductive && b?.kind === 'law' && !ctx.inductive.has(l.name)) {
    let r: Verdict
    try { r = proveRule(x.rule!, [...inv, b.law], {search: {ms}}) } catch (e) { return {...base, kind: 'law', verdict: 'unknown', why: (e as Error).message, ms: Date.now() - t0} }
    if (r.run) return {...base, kind: 'law', verdict: 'broken', run: runOf(x, r.run), ms: Date.now() - t0}
    return {...base, kind: 'law', verdict: 'unknown', why: r.proven && r.checked ? `true in every state a run from the start reaches, not inductive from every state the laws allow (from = "any"): state the law it needs beside it${r.found?.laws?.length ? `: ${r.found.laws.map(f => f.text).join('; ')}` : ''}` : r.why ?? r.stuck ?? 'not proven', ...(r.found?.laws?.length ? {found: r.found.laws.map(f => f.text)} : {}), ms: Date.now() - t0}
  }
  // (from any state: a law about states proven with the others stated beside it, as one inductive set)
  const beside = (): Law[] => (ctx?.together ?? []).filter(m => m.name !== l.name).flatMap(m => { try { const y = buildLaw(x, m, ctx ?? {}); return y.kind === 'law' ? [y.law] : [] } catch { return [] } })
  try { v = two ? proveTwoRuns(two, {...search, invariants: [two.sides[0] === x.rule ? inv : (ctx?.others && Object.values(ctx.others).find(o => o.rule === two!.sides[0])?.invariants) ?? [], inv]}) : b!.kind === 'law' ? proveRule(x.rule!, [...inv, ...(ctx?.from ? beside() : []), b!.law], search) : proveSteps(x.rule!, [...inv, ...proven] as never, [b!.law], search) }
  catch (e) { return {...base, kind, verdict: 'unknown', why: (e as Error).message, ms: Date.now() - t0} }
  // (from any state: a step that breaks the law from a state the laws allow refutes it, reachable or not; the run that
  // reaches one from the start, where the search from the start finds it, is shown with it)
  if (ctx?.from && !v.proven && !v.run && v.stuck === 'sat' && v.witness && b) {
    try { const r = b.kind === 'law' ? proveRule(x.rule!, [...inv, b.law], {search: {ms}}) : proveSteps(x.rule!, [...inv, ...proven] as never, [b.law], {search: {ms}}); if (r.run) v = {...v, run: r.run} } catch { /* the state stands alone */ }
    if (!v.run) v = {...v, why: `broken from a state the laws allow (from = "any"), no run from the start found reaching it`}
  }
  const brokenAt = !!(ctx?.from && !v.proven && !v.run && v.stuck === 'sat' && v.witness)
  let verdict: LawOut['verdict'] = v.proven && v.checked && !(ctx?.from && v.assumes) ? 'proven' : v.run || brokenAt ? 'broken' : 'unknown', replayed: string | undefined
  if (ctx?.from && v.proven && v.assumes) v.why = `proven only in states a run from the start reaches (from = "any" asks for every state the laws allow): it needs ${v.assumes.laws.join('; ') || 'k-induction'}`
  // (a run the front end replays on the code: broken only where the code runs it so)
  if (verdict === 'broken' && x.replay && v.run && !two) { const r = x.replay(v.run, b!.law); if (r.ok) replayed = r.what; else { verdict = 'unknown'; v.why = `a run breaks it in the rule, not on the code: ${r.what}` } }
  // (a state the laws allow from which a step breaks the law, no run from the start reaching it: shown, not a break)
  const at = !v.run && v.witness && !two ? (x.names ?? []).filter(n => n.rule && n.rule in v.witness! && n.role !== 'const').map(n => `${label(n)} = ${shownValue(x, n.rule, v.witness!, n.none)}`) : []
  if (verdict === 'proven' && b?.kind === 'law') proven.push(b.law)
  const found = v.found?.laws?.map(f => f.text)
  let cert: string | undefined
  if (verdict === 'proven' && ctx?.cert) {
    const more = v.found?.laws?.map(f => f.law) ?? []
    const meta = {producer: 'gdp-wired check', file: ctx.file, ...(ctx.entry ? {entry: ctx.entry} : {}), law: l.name, expr: l.expr, ...(l.where ? {where: l.where} : {}), cites}
    const doc = v.k ? undefined : two ? certify(two.rule, [...v.given ?? [], ...more, ...two.laws], two.stepLaws, meta)
      : b!.kind === 'law' ? certify(x.rule!, [...inv, ...more, b!.law], [], meta) : certify(x.rule!, [...inv, ...proven as Law[], ...more], [b!.law], meta)
    if (doc) { fs.mkdirSync(ctx.cert, {recursive: true}); cert = path.join(ctx.cert, `${[ctx.entry ?? path.basename(ctx.file), l.name].join('.').replace(/[^\w.-]+/g, '-')}.json`); fs.writeFileSync(cert, JSON.stringify(doc)) }
  }
  return {...base, kind, verdict, ...(ctx?.from && verdict === 'proven' ? {from: 'any' as const} : {}), ...(replayed ? {replayed} : {}), ...(v.run && verdict === 'broken' ? {run: two ? pairRunOf(x, v.run, two) : runOf(x, v.run)} : {}), ...(verdict === 'unknown' || (verdict === 'broken' && !v.run) ? {why: [v.why ?? v.stuck ?? 'not proven', ...(at.length ? [`a state the laws allow where a step breaks it, no run from the start found reaching it: ${at.join(', ')}`] : [])].join('; ')} : {}),
    ...(v.run && !two ? {assumes: assumedOf(x, v.run)} : {}), ...(found?.length ? {found} : {}), ...(cert ? {cert} : {}), ms: Date.now() - t0}
}
// A law of a rule in its environment (core/system.ts's inEnv): built on the rule as the code's names read it, then
// lifted to every call at once; proven of the system, a run shown as the calls' steps.
function proveInEnv(x: Extraction, l: LawText, ms: number, proven: Law[], ctx: Ctx & {sys: InEnv}): LawOut {
  const t0 = Date.now(), sys = ctx.sys, base = {name: l.name, expr: l.expr, ...(l.where ? {where: l.where} : {})}
  if (isLeadsTo(l.expr) || isTwoRuns(l.expr)) return {...base, verdict: 'not read', why: `a ${isLeadsTo(l.expr) ? 'leads-to' : 'two-run'} law is not lifted to the environment (state it of the rule with no env)`, ms: 0}
  // (at most one call between a and b: a flow's mutual exclusion, its leases running out where their keys expire)
  const bw = /^at\s+most\s+one\s+call\s+between\s+([\w.]+)\s+and\s+([\w.]+)$/i.exec(l.expr.trim())
  let b: Built
  try { b = bw ? {kind: 'law', law: sys.between(l.name, bw[1]!, bw[2]!)} : buildLaw(x, l, ctx) } catch (e) { return {...base, verdict: 'not read', why: (e as Error).message, ms: 0} }
  const inv = (x.invariants ?? []).map(sys.law)
  let v: Verdict, law: Law | ReturnType<InEnv['step']>
  try {
    if (b.kind === 'law') { law = bw ? b.law as Law : sys.law(b.law as Law); v = proveRule(sys.rule, [...inv, law], {search: {ms}}) }
    else { law = sys.step(b.law); v = proveSteps(sys.rule, [...inv, ...proven], [law as never], {search: {ms}}) }
  } catch (e) { return {...base, kind: b.kind, verdict: 'unknown', why: (e as Error).message, ms: Date.now() - t0} }
  // (not proven and no run: calls contending with one request, a run the search's own draws seldom make)
  if (!(v.proven && v.checked) && !v.run) { const run = contend(sys, law!, {ms: Math.min(ms, 10_000)}); if (run) v = {...v, run: run as never} }
  const verdict: LawOut['verdict'] = v.proven && v.checked ? 'proven' : v.run ? 'broken' : 'unknown'
  if (verdict === 'proven' && b.kind === 'law') proven.push(law as Law)
  const found = v.found?.laws?.map(f => f.text)
  return {...base, kind: b.kind, verdict, ...(v.run && verdict === 'broken' ? {run: sysRunOf(x, sys, shrinkRun(sys.rule, law!, v.run))} : {}), ...(verdict === 'unknown' ? {why: v.why ?? v.stuck ?? 'not proven'} : {}), ...(found?.length ? {found} : {}), ms: Date.now() - t0}
}
// A run of the system as each call's steps: a call begins with its request, reads, commits; a store's key expires.
function sysRunOf(x: Extraction, sys: InEnv, run: NonNullable<Verdict['run']>): string[] {
  const pcs = new Map<unknown, number>(), done = (sys.commit ?? 0) + 1, out: string[] = []
  const params = Object.keys(run.params).length ? runOf(x, {params: run.params, trace: []}) : []
  // (calls numbered in the order they begin; a store by the code's name)
  const ids = new Map<unknown, number>(), n = (p: unknown) => { if (!ids.has(p)) ids.set(p, ids.size + 1); return ids.get(p)! }
  const store = (map: string) => (x.names ?? []).find(m => m.rule === map)?.code ?? map
  for (const q of run.trace as Record<string, unknown>[]) {
    const a = q[sys.act]
    if (!(a === 0 || a === sys.part)) { out.push(`a key of the store expires (key #${String(q['key$'])})`); continue }
    const call = runOf(x, {params: {}, trace: [q]}).at(-1)!
    if (!sys.id) { out.push(call); continue }
    const p = q[sys.id], pc = pcs.get(p) ?? 0
    if (!sys.commit) { out.push(`call ${n(p)}: ${call}`); continue }
    if (pc >= done) continue
    pcs.set(p, pc === 0 ? (sys.level === 'snapshot' || sys.commit === 1 ? sys.commit! : 1) : pc === sys.commit && sys.flow ? 0 : pc + 1)
    out.push(pc === 0 ? `call ${n(p)} begins ${call}` : pc === sys.commit ? `call ${n(p)} commits` : `call ${n(p)} reads ${store(sys.reads[pc - 1]!)}`)
  }
  return [...params, ...out]
}
// The environment a `gdp: env <words>` comment states: one in the rule's class (or naming none, the file's).
const ENV = /(?:#|\/\/|--|%|\/\*|^\s*\*)\s*gdp:\s*env\s+(.+?)\s*(?:\*\/)?\s*$/
function envTags(files: string[], name?: string): string | undefined {
  for (const f of files) {
    const lines = fs.readFileSync(f, 'utf8').split('\n')
    for (const [i, l] of lines.entries()) {
      const m = ENV.exec(l)
      if (!m) continue
      // (a tag right above a class statement is that class's, else the class it is in)
      let cls: string | undefined
      for (let j = i + 1; j < lines.length; j++) { if (/^\s*(\/\/|\/?\*|#|@|$)/.test(lines[j]!)) continue; cls = classAt(lines[j]!); break }
      for (let j = i; j >= 0 && !cls; j--) cls = classAt(lines[j]!)
      if (!cls || !name || cls === name) return m[1]
    }
  }
  return undefined
}
// Two runs as calls of the code: each request once, the values the two runs take apart as `a | b`, and the run b leaves
// out (isolation's: the others' calls) marked.
function pairRunOf(x: Extraction, run: NonNullable<Verdict['run']>, two: TwoRunLaw): string[] {
  const sideOf = (vars: Record<string, unknown>, p: string): Record<string, unknown> => Object.fromEntries(Object.entries(vars).flatMap(([k, val]) => (k.startsWith(p) ? [[k.slice(2), val]] : /^[ab]_/.test(k) ? [] : [[k, val]])))
  const a = runOf(x, {params: sideOf(run.params, 'a_') as Record<string, number>, trace: run.trace.map(q => sideOf(q, 'a_'))})
  const b = runOf(x, {params: sideOf(run.params, 'b_') as Record<string, number>, trace: run.trace.map(q => sideOf(q, 'b_'))})
  const tenant = 'tenant' in run.params && !two.shared.every(n => n !== 'tenant') ? [`B is ${run.params.tenant} (run b takes only B's calls)`] : []
  return [...tenant, ...a.map((s, i) => (s === b[i] ? s : `${s}  |  ${b[i]}`))]
}
// What a refutation assumes of the answers inferred (core/extract-step.ts's `assumed`), at the run's last request.
function assumedOf(x: Extraction, run: NonNullable<Verdict['run']>): string[] {
  const last = run.trace.at(-1) as Record<string, unknown> | undefined, out: string[] = []
  for (const n of (x.names ?? []).filter(m => m.role === 'answer')) {
    if (!last || !(n.rule in last)) continue
    const how = (x as {read?: {answers: {key: string, how?: string, sort: string}[]}}).read?.answers.find(a => a.key === n.code)
    if (how?.how) out.push(`assumes ${n.code.split('.').pop()}(...) may return ${shownValue(x, n.rule, last, n.none)} (${how.how}: any ${how.sort})`)
  }
  return out
}

// --- runs in the code's terms --------------------------------------------------------------------------------------------
type KindLike = {decode: (n: string, v: Record<string, number>) => unknown}
function kindOf(x: Extraction, rule: string): KindLike | undefined {
  const r = x.rule as unknown as {parts: {params: [string, KindLike][], inputs: [string, KindLike][]}, kindsOfState: () => [string, KindLike][]}
  return [...r.parts.params, ...r.parts.inputs, ...r.kindsOfState()].find(([n]) => n === rule)?.[1]
}
function shownValue(x: Extraction, rule: string, vars: Record<string, unknown>, none?: string): string {
  if (none && (vars[none] === 1 || vars[none] === true)) return 'None'
  const k = kindOf(x, rule)
  try { const v = k ? k.decode(rule, vars as Record<string, number>) : vars[rule]; return typeof v === 'string' ? JSON.stringify(v) : String(v) }
  catch { return `a string (#${String(vars[rule])})` }
}
// A run as calls of the code: the constructor's arguments, then each request (the method, its arguments by the code's
// names, the answers and the clock), the last the one that breaks the law.
export function runOf(x: Extraction, run: NonNullable<Verdict['run']>): string[] {
  if (x.fibers?.length) {
    const plain = {...x, fibers: undefined}
    return [...runOf(plain, {params: run.params, trace: []}), ...fiberRun(x, run, q => runOf(plain, {params: {}, trace: [q]}).at(-1)!)]
  }
  const names = namesWithClock(x), code = (n: Name) => n.code
  const ps = names.filter(n => n.role === 'param' && n.rule && n.rule in run.params)
  const lines = ps.length ? [`made with ${ps.map(n => `${code(n)} = ${shownValue(x, n.rule, run.params, n.none)}`).join(', ')}`] : []
  const ev = names.find(n => n.role === 'method')
  for (const req of run.trace as Record<string, unknown>[]) {
    const m = ev ? String(kindOf(x, ev.rule)?.decode(ev.rule, req as Record<string, number>) as string | undefined ?? '') : names.find(n => n.method)?.method ?? ''
    // (an object the caller gives: None, or its fields read; a field of an object that is None not shown)
    const none = (n: Name) => !!n.none && (req[n.none] === 1 || req[n.none] === true)
    const objs = names.filter(n => n.role === 'input' && n.method === m && !n.rule && n.none && n.none in req)
    const as = names.filter(n => n.role === 'input' && n.method === m && (n.rule ? n.rule in req : none(n)) && !objs.some(o => none(o) && n.code.startsWith(`${o.code}.`)))
    const call = `${m || 'step'}(${as.map(n => `${code(n)}=${n.rule ? shownValue(x, n.rule, req, n.none) : 'None'}`).join(', ')})`
    const extra = names.filter(n => (n.role === 'answer' || n.role === 'clock') && n.rule in req).map(n => `${label(n)} = ${shownValue(x, n.rule, req, n.none)}`)
    lines.push(extra.length ? `${call} with ${extra.join(', ')}` : call)
  }
  return lines
}

// --- laws proposed: the rule's own comparisons, as laws in the code's terms ----------------------------------------------
// From each comparison, min or max of the step between a number of the state and another number of the state or the
// params, or two fields of one map's cells: that one is at most the other (both ways); an integer of the state never
// below 0; a number of the state that never goes down, or up. Each proven or broken by the prover; the broken ones only
// counted (they are guesses, not claims).
function propose(x: Extraction, lang: Lang, o: Opts, proven: unknown[], stated: Set<string>): {shown: LawOut[], broken: number} {
  const m = x.rule!.machine, names = x.names ?? [], model = x.model!
  const nums = new Set([...model.state, ...model.params].filter(v => v.sort.k === 'num' && !model.outputs.includes(v.name) && v.name !== 'made_at').map(v => v.name))
  const state = new Set(model.state.filter(v => nums.has(v.name)).map(v => v.name))
  // (the code's name for a variable, or the rule's where the code's names another first)
  const codeOf = (rule: string): string => { const n = names.find(y => y.rule === rule && (y.role === 'state' || y.role === 'param')); if (!n) return rule; const first = names.find(y => y.code === n.code && (y.role === 'state' || y.role === 'param')); return first === n ? n.code : rule }
  const base = (v: string) => v.replace(/\$neg$/, '')
  const sides = (e: unknown): Set<string> => { const s = new Set<string>(); JSON.stringify(e, (k, v) => { if (k === 'name' && typeof v === 'string') s.add(base(v)); if (k === 'map' && typeof v === 'string') s.add(base(v)); return v }); return s }
  const pairs = new Set<string>()
  JSON.stringify(m.step, (_, v) => {
    if (v && typeof v === 'object' && ['<', '<=', 'min', 'max'].includes((v as {op?: string}).op ?? '') && 'a' in v && 'b' in v) {
      const a = sides((v as {a: unknown}).a), b = sides((v as {b: unknown}).b)
      for (const p of a) for (const q of b) if (p !== q) { pairs.add(`${p}\0${q}`); pairs.add(`${q}\0${p}`) }
    }
    return v
  })
  const cands: LawText[] = []
  const add = (name: string, expr: string) => { if (!stated.has(expr.replace(/\s+/g, '')) && !cands.some(c => c.expr === expr)) cands.push({name, expr}) }
  for (const pq of pairs) {
    const [p, q] = pq.split('\0') as [string, string]
    if (state.has(p) && nums.has(q)) add(`${codeOf(p)} stays at most ${codeOf(q)}`, `${codeOf(p)} <= ${codeOf(q)}`)
    const mp = /^(.+)\.(\w+)$/.exec(p), mq = /^(.+)\.(\w+)$/.exec(q)
    if (mp && mq && mp[1] === mq[1] && mp[2] !== mq[2] && mp[2] !== 'has' && mq[2] !== 'has') {
      const map = names.find(n => n.rule === mp[1] && n.map)
      if (map && map.map!.fields.includes(mp[2]!) && map.map!.fields.includes(mq[2]!)) add(`every ${map.code}'s ${mp[2]} stays at most its ${mq[2]}`, `forall k in ${map.code}: ${map.code}[k].${mp[2]} <= ${map.code}[k].${mq[2]}`)
    }
  }
  for (const v of state) {
    if (`${v}$neg` in m.state) add(`${codeOf(v)} is never negative`, `${codeOf(v)} >= 0`)
    add(`${codeOf(v)} never changes`, `${codeOf(v)} == old(${codeOf(v)})`)
    add(`${codeOf(v)} never goes down`, `${codeOf(v)} >= old(${codeOf(v)})`)
    add(`${codeOf(v)} never goes up`, `${codeOf(v)} <= old(${codeOf(v)})`)
  }
  const shown: LawOut[] = [], until = Date.now() + Math.max(5000, o.ms * 2)
  let broken = 0
  const fixed = new Set<string>()
  for (const c of cands.slice(0, 40)) {
    if (Date.now() > until) break
    const v = /^(.+) never (?:changes|goes (?:down|up))$/.exec(c.name)?.[1]
    if (v && fixed.has(v)) continue
    const r = prove(x, c, Math.min(o.ms, 2000), proven)
    if (r.verdict === 'broken' || r.verdict === 'not read') broken++
    else { shown.push({...r, where: `${COMMENT[lang]} gdp: law ${c.name}: ${c.expr}`}); if (v && r.verdict === 'proven' && c.name.endsWith('changes')) fixed.add(v) }
  }
  return {shown, broken}
}

// The laws `check` proposes for an extraction with nothing stated, each proven (`shown`: those not broken by a run).
export const proposedLaws = (x: Extraction, lang: Lang, ms = 2000): {shown: LawOut[], broken: number} => propose(x, lang, {ms, propose: true}, [], new Set())

// --- printing ------------------------------------------------------------------------------------------------------------
const ROLE: Record<Name['role'], string> = {state: 'state', param: 'made with', input: 'request', answer: 'answered', result: 'result', failed: 'failed', method: 'method', clock: 'clock', const: 'constant'}
function printRule(r: RuleOut, o: Opts) {
  out(`${r.file}${r.entry ? `: ${r.entry}` : ''}${r.ctor !== undefined ? ` [ctor ${r.ctor}]` : ''} (${r.lang})`)
  if (!r.ok) {
    for (const f of r.refusals) out(`  ${paint('yellow', `refused at ${f.where}:`)} ${f.what}`)
  } else {
    if (r.checked) out(`  ${paint('dim', r.checked)}`)
    if (r.env) { out('  in its environment (every call at once; the laws below are about these runs):'); for (const e of r.env) out(`    ${e}`) }
    const inferred = r.notes.filter(n => /inferred|tagged|left out|answered|injected|the entry/.test(n))
    for (const n of inferred.slice(0, 12)) out(`  ${n}`)
    out(`  ${paint('dim', 'names (the code\'s, then the rule\'s):')}`)
    const w = Math.min(36, Math.max(...r.names.map(n => label(n).length), 8))
    for (const n of r.names) out(`    ${paint('dim', `${label(n).padEnd(w)}  ${ROLE[n.role].padEnd(9)} ${n.rule}${n.none ? `${n.rule ? ', ' : ''}None: ${n.none}` : ''}${n.map ? ` (cells: ${n.map.fields.join(', ')}${n.map.tpl ? `; key ${JSON.stringify(n.map.tpl)}` : ''})` : ''}${n.role === 'const' ? String(n.value) : ''}`)}`)
  }
  const law = (l: LawOut, proposed: boolean) => {
    out(`    ${paint(VERDICT[l.verdict], l.verdict)}${' '.repeat(Math.max(0, 9 - l.verdict.length))}${l.name}${l.from ? ' (from any state)' : ''}${proposed ? '' : `  ${paint('dim', `(${l.where})`)}`}`)
    if (!proposed && l.verdict !== 'proven') out(`             ${l.expr}`)
    for (const c of l.cites ?? []) out(`             cites: ${c}`)
    if (l.cert) out(`             ${paint('dim', `certificate: ${l.cert}`)}`)
    if (l.run) for (const [i, s] of l.run.entries()) out(`             ${i === 0 ? 'run: ' : '     '}${paint('red', s)}`)
    if (l.replayed) out(`             ${l.replayed}`)
    for (const a of l.assumes ?? []) out(`             ${a}`)
    if (l.found) out(`             proven with what the search found: ${l.found.join('; ')}`)
    if (l.why && l.verdict !== 'proven') out(`             ${l.why}`)
    if (proposed) out(`             ${l.where}`)
  }
  if (r.laws.length) { out('  laws stated in the code:'); for (const l of r.laws) law(l, false) }
  if (r.security) {
    out('  security candidates (NOT accepted policy; review the requirement and authentication boundary):')
    for (const l of r.security) law(l, true)
    out('    Candidates do not affect the exit code. State reviewed candidates as gdp: law comments.')
  }
  if (r.proposed.length || r.brokenProposed) {
    out('  laws proposed (nothing written; state one with the comment under it):')
    for (const l of r.proposed) law(l, true)
    if (r.brokenProposed) out(`    (${r.brokenProposed} more proposed and broken by a run: not shown)`)
  }
  if (r.ok && !r.laws.length) out(`  no law stated: write one as \`${COMMENT[(Object.keys(LANG_NAME) as Lang[]).find(k => LANG_NAME[k] === r.lang)!]} gdp: law <name>: <expr>\` over the names above`)
  void o
  out()
}
const label = (n: Name) => (n.role === 'answer' ? `${n.code.split('.').pop()}(...)` : n.role === 'input' && n.method ? `${n.method}(${n.code})` : n.role === 'result' && n.method ? `${n.method}() result` : n.code)

const USAGE = `gdp-wired check <file|dir>... [--entry X] [--mode standalone] [--methods a,b] [--failures kept] [--on-error discard] [--json] [--ms 10000] [--no-propose] [--clock s|ms] [--cert <dir>] [--from any] [--require-review] [--security]
gdp-wired draft <file> --clause <text> | --clause-file <file> --cite <ref> [--llm <command> | --answer <file>] [--by <who>]

Reads the rule in each file (Python, Ruby, Elixir, Java, Kotlin, Go, Rust, Swift, C, C++, TypeScript, Effect, XState), checks it
against the code by running both, proves the laws stated in the code (\`# gdp: law <name>: <expr>\`, \`// gdp: law ...\`,
@GdpLaw("<name>: <expr>")) and proposes others. Laws about two runs: \`<secret> never reaches <fields>\`, \`isolated by <argument>\`,
\`agrees with <Class>\`; a duration over the clock: \`now - t < 30 days\`, \`now - t <= 10 business days\` (the calendar: [calendar] in gdp.toml);
the clause a law answers: \`gdp: cite <law name>: <clause>\` (drafted from the clause's text by \`draft\`, marked unreviewed until a person signs it);
--cert <dir> writes each proven law's certificate (its meta the citations); --from any (or from = "any" in gdp.toml, for every
rule or one) proves every law from every state the laws allow, for code that steps the rule from states it is handed. Exit code: 1 when a stated law is broken, 2 when
one couldn't be checked.
--security proposes authorization, tenant-write isolation, workflow, quota and ledger candidates over the code's names.
Candidates require policy review, show broken runs too, and do not affect the exit code. Arbitrary input identities are
not authenticated identities. State the intended policy with gdp: law comments; use gdp: env for concurrent isolation.`

// Every target's rules and their laws, and the exit code (1: a stated law broken; 2: one not checked).
export async function check(targets: string[], given: Partial<Opts> = {}, each?: (r: RuleOut) => void): Promise<{rules: RuleOut[], exit: number}> {
  const o: Opts = {ms: 10_000, propose: true, ...given}, all: RuleOut[] = []
  for (const p of targets) for (const t of targetsOf(p)) { const rs = await checkTarget(t, o); all.push(...rs); if (each) rs.forEach(each) }
  const stated = all.flatMap(r => r.laws)
  return {rules: all, exit: stated.some(l => l.verdict === 'broken') ? 1 : stated.some(l => l.verdict === 'not read') || o.security && all.some(r => !r.ok) ? 2 : 0}
}
// --- draft: laws from a clause, for a person to review ----------------------------------------------------------------
// gdp-wired draft <file> --clause <text> | --clause-file <f> --cite <ref> [--llm <command> | --answer <file>] [--by <who>]:
// the question (core/draft.ts) printed, or asked of the command (on its stdin) or read from an answer, each law it
// proposes read over the code's names, the comments to paste printed with where they go.
async function draft(target: string, o: Opts): Promise<number> {
  const {draftComments, draftPrompt, parseDraft, vetDrafts} = await import('./draft.ts')
  const clause = (o.clause as string | undefined) ?? (o.clauseFile ? fs.readFileSync(o.clauseFile as string, 'utf8') : undefined), cite = (o.cite as string | undefined) ?? 'the clause'
  if (!clause) { out('gdp-wired draft: --clause <text> or --clause-file <file>'); return 2 }
  const t = targetsOf(target)[0]!, rules = await rulesOf(t, {...o, propose: false}, []), x = rules.find(r => r.x.ok)?.x
  if (!x) { out(`gdp-wired draft: no rule read from ${target}: ${rules[0]?.x.refusals[0]?.what ?? ''}`); return 2 }
  const prompt = draftPrompt(x, clause, cite)
  let answer: string
  if (o.answer) answer = fs.readFileSync(o.answer as string, 'utf8')
  else if (o.llm) {
    const {spawnSync} = proc.getBuiltinModule('node:child_process') as {spawnSync: (c: string, a: string[], o: object) => {stdout: string, status: number | null}}
    const p = spawnSync('sh', ['-c', o.llm as string], {input: prompt, encoding: 'utf8', maxBuffer: 1 << 26})
    if (p.status !== 0) { out(`gdp-wired draft: ${o.llm as string} exited ${p.status}`); return 2 }
    answer = p.stdout
  } else { out(prompt); return 0 }
  const cfg = configFor(t.lang === 'go' || t.lang === 'rust' || fs.statSync(t.at).isDirectory() ? t.at : path.dirname(t.at)), unit = o.clock ?? cfg.all.clock ?? CLOCK[t.lang]
  const {kept, refused} = vetDrafts(x, parseDraft(answer), {clock: unit === 's' ? 1 : unit === 'ms' ? 1000 : undefined, ...(cfg.all.calendar ? {calendar: cfg.all.calendar as Calendar} : {})})
  const by = (o.by as string | undefined) ?? (o.llm ? (o.llm as string).split(/\s+/)[0]! : 'an answer given'), c = COMMENT[t.lang]
  out(`${kept.length} laws drafted from ${cite}, each to be reviewed by a person (then [reviewed-by: <name>, <date>] in place of [unreviewed ...]):`)
  for (const d of kept) { out(`\n  ${d.method ? `on the line above ${d.method}` : 'in the class (a law of every state)'}:`); for (const l of draftComments(c, d, cite, by)) out(`    ${l}`) }
  for (const r of refused) out(`\n  refused: ${r.d.name}: ${r.d.expr}\n    ${r.why}`)
  return kept.length ? 0 : 2
}

// Every target's rules and their laws, and the exit code (1: a stated law broken; 2: one not checked, or with
// --require-review, one cited unreviewed).
export async function main(argv: string[]): Promise<number> {
  const {cmd, targets, o} = args(argv)
  if (cmd === 'draft' && targets.length === 1) return draft(targets[0]!, o)
  if (cmd !== 'check' || !targets.length) { out(USAGE); return cmd === 'help' || cmd === '--help' || cmd === '-h' || !cmd ? 0 : 2 }
  tint = colors(proc.env, !!proc.stdout.isTTY, !!o.json)
  const {rules: all, exit: code0} = await check(targets, o, o.json ? undefined : r => printRule(r, o))
  const stated = all.flatMap(r => r.laws)
  const {reviewOf} = await import('./draft.ts'), unreviewed = stated.filter(l => (l.cites ?? []).some(c => reviewOf(c) === 'unreviewed'))
  const code = code0 === 0 && o.requireReview && unreviewed.length ? 2 : code0
  if (o.json) out(JSON.stringify({rules: all.map(({source: _s, ...r}) => r), exit: code}, null, 1))
  else if (stated.length) {
    const n = (v: LawOut['verdict']) => stated.filter(l => l.verdict === v).length
    out(`${paint('green', n('proven'))} of ${stated.length} stated laws proven, ${paint('red', n('broken'))} broken, ${paint('yellow', n('unknown'))} unknown, ${paint('yellow', n('not read'))} not read`)
    if (unreviewed.length) out(`${paint('yellow', unreviewed.length)} cited unreviewed (drafted, no person's sign-off yet: [reviewed-by: <name>, <date>])${o.requireReview ? ': refused by --require-review' : ''}: ${unreviewed.map(l => l.name).join('; ')}`)
  }
  return code
}

if (import.meta.url === `file://${proc.argv[1]}` || /\/(cli\.(ts|js)|gdp-wired)$/.test(proc.argv[1] ?? '')) {
  main(proc.argv.slice(2)).then(c => { proc.exitCode = c }, e => { out(`gdp-wired: ${(e as Error).message}`); proc.exitCode = 2 })
}
