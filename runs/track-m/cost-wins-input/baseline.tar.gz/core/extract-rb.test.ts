// The Ruby front end (core/extract-rb.ts): rules read from Ruby through Prism, each checked against the Ruby code it
// was read from (core/rb/harness.rb). The adversarial cases: Ruby's truth (0 and "" are true), / and % of negatives
// (floor), a field nil until it is set, symbols as choices, a method's last expression as its result, raise, loops.
// Skipped where ruby (3.3 or later, with Prism) isn't installed.
import {expect, test} from 'bun:test'
import {execFileSync} from 'node:child_process'
import {mkdtempSync, writeFileSync} from 'node:fs'
import {tmpdir} from 'node:os'
import {proveSteps, yes} from './dsl.ts'
import {type RbOptions, extractRuby} from './extract-rb.ts'

const hasRuby = (() => { try { execFileSync('ruby', ['-e', 'require "prism"'], {stdio: 'ignore'}); return true } catch { return false } })()
const t = hasRuby ? test : test.skip
const rb = (code: string, entry: string, more: Partial<RbOptions> = {}) => {
  const dir = mkdtempSync(`${tmpdir()}/gdp-rbcase-`), file = `${dir}/case.rb`
  writeFileSync(file, code)
  return extractRuby(file, {entry, root: dir, check: {runs: 30, depth: 6, states: 60}, ...more})
}
const ok = (x: ReturnType<typeof rb>) => {
  if (!x.ok) throw new Error(`refused: ${JSON.stringify(x.refusals)}\n${x.source ?? ''}`)
  expect(x.evidence!.mismatch).toBeUndefined()
  expect(x.evidence!.requests).toBeGreaterThan(0)
  return x
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const step = (x: ReturnType<typeof rb>, name: string, then: (b: any, a: any) => any, when: (b: any) => any) => {
  const r = x.rule! as never as {stepLaw: (n: string, t: unknown, w: unknown) => never}
  const v = proveSteps(r as never, x.invariants ?? [], [r.stepLaw(name, then, when)])
  if (!v.proven) throw new Error(`${name}: ${JSON.stringify({goal: v.goal, witness: v.witness})}`)
}

t('a counter with a limit: Ruby\'s truth (0 is true), a field nil until it is set, the last expression as the result', () => {
  const x = ok(rb(`
class Limiter
  attr_reader :count
  def initialize(limit)
    @limit = limit
    @count = 0
  end
  def hit
    return false if @count >= @limit
    @count += 1
    @last = @count
    true
  end
  def seen?
    @last ? true : false
  end
  def reset
    @count = 0
    @last = nil
  end
end`, 'Limiter', {methods: ['hit', 'seen?', 'reset']}))
  // (0 is true in Ruby: seen? after a reset is false only because @last is nil)
  step(x, 'a hit within the limit counts', (b, a) => a.count.eq(b.count.plus(1)), b => b.method.is('hit').and(b.limit.gt(b.count)))
  step(x, 'seen? is whether a hit was counted since the reset', (b, a) => a.seen_p_result.iff(b.last_none.not()), b => b.method.is('seen?'))
})

t('/ and % of a negative floor, as Ruby\'s do; symbols are a choice; case/when on them', () => {
  const x = ok(rb(`
class Meter
  def initialize
    @half = 0
    @rest = 0
    @mode = :idle
  end
  def split(k)
    @half = k / 2
    @rest = k % 2
  end
  def set(m)
    case m
    when :idle then @mode = :idle
    when :busy then @mode = :busy
    else raise ArgumentError, "mode"
    end
  end
end`, 'Meter', {methods: ['split', 'set']}))
  expect(x.source).toContain("oneOf('idle', 'busy')")
  step(x, 'the half and the rest make k again', (b, a) => a.half.plus(a.half).plus(a.rest).eq(b.split_k), b => b.method.is('split'))
})

t('refused where it leaves the subset, each with why', () => {
  const loop = rb(`
class L
  def initialize; @n = 0; end
  def go; 3.times { @n += 1 }; end
end`, 'L', {methods: ['go']})
  expect(loop.ok).toBe(false)
  expect(loop.refusals[0]!.what).toMatch(/a block/)
  const fdiv = rb(`
class F
  def initialize; @x = 0; end
  def go(k); @x = k / 2.0; end
end`, 'F', {methods: ['go']})
  expect(fdiv.ok).toBe(false)
  expect(fdiv.refusals[0]!.what).toMatch(/float/)
})

t('the boundary inferred: another class\'s call left out or answered (tagged: Ruby states no types), a store injected, the entry', () => {
  const x = ok(rb(`
module Metrics
  def self.count(*) = nil
end
module Quota
  def self.bonus(user) = user.length % 3
end
class Gate
  def initialize(cache, cap)
    @cache = cache
    @cap = cap
  end
  def hit(user = "")
    Metrics.count("hit", user)
    n = (@cache.get("hits:#{user}") || 0) + Quota.bonus(user) # gdp: answer int
    @cache.set("hits:#{user}", n)
    raise "over" if n > @cap
    n
  end
end
`, undefined as never, {failures: 'kept'}))
  const notes = x.notes.join('\n')
  expect(notes).toMatch(/the entry inferred: Gate/)
  expect(notes).toMatch(/Metrics.count .*left out \(inferred/)
  expect(notes).toMatch(/Quota.bonus .*answered by the request \(tagged/)
  expect(notes).toMatch(/Gate\(cache\): an injected dependency \(inferred/)
  step(x, 'admitted only within the cap', (_b, a) => a.failed.not().implies(a.cache_hits.at(_b.user.id).value.atMost(a.cap_)), () => yes)
})

t('begin/rescue/else/ensure and a method\'s own rescue: another class\'s call may raise what a rescue catches, a raise by its class', () => {
  const x = ok(rb(`
module Remote
  def self.ping(*) = nil
  def self.log(*) = nil
end
class Full < IndexError; end
class Gate
  def initialize(cap)
    @cap = cap
    @n = 0
    @errors = 0
  end
  def hit(k)
    begin
      Remote.ping(k)
      raise Full if @n >= @cap
      @n += 1
    rescue KeyError
      return -2
    rescue IndexError
      return -1
    rescue => e
      @errors += 1
      return 0
    else
      @n += 0
    ensure
      Remote.log(k)
    end
    @n
  end
  def soft
    Remote.ping(1)
    @n
  rescue
    @errors += 1
    0
  end
end
`, 'Gate', {failures: 'kept'}))
  expect(x.source).toContain("ping_raises: oneOf('none', 'KeyError', 'IndexError', 'StandardError')")
  step(x, 'errors only where ping raised a StandardError', (b, a) => a.errors.gt(b.errors).implies(b.ping_raises.is('StandardError')), b => b.method.is('hit'))
  step(x, 'never past its cap but by a raise', (b, a) => a.n.gt(b.n).implies(b.cap_.gt(b.n)), () => yes)
  step(x, 'soft counts an error only where ping raised', (b, a) => a.errors.gt(b.errors).implies(b.soft_ping_raises), b => b.method.is('soft'))
})

// The adversarial round (research/langs/adversarial): no false checked proof; what reaches the rule's state, refused.
import {cases as advCases, judge, ADV} from '../research/langs/adversarial/cases.test-lib.ts'
for (const c of advCases('Ruby')) t(`adversarial ${c.id}: ${c.attack}`, () => judge(c, extractRuby(`${ADV}${c.file}`, {entry: 'Meter', root: ADV, check: {runs: 30, depth: 6, states: 60}})))

// The reader fuzz's misreads (core/extract-fuzz.ts): a call of a constant nothing defines.
t('a call of a constant nothing under the root defines: refused (a NameError where it runs)', () => {
  const r = rb(`
module Mextrics
  def self.count(*) = nil
end
class Gate
  def initialize(cap)
    @cap = cap
    @n = 0
  end
  def hit(user = "")
    Metrics.count("hit", user)
    @n += 1
  end
end
`, 'Gate')
  expect(r.ok).toBe(false)
  expect(r.refusals[0]!.what).toMatch(/Metrics, a constant nothing under the root defines \(a NameError where it runs\)/)
})

t('arithmetic on other code\'s value left out (-nil raises): read, so refused where nothing states its type', () => {
  const r = rb(`
module Remote
  def self.log(*) = nil
end
class Gate
  def initialize(cap)
    @cap = cap
    @n = 0
  end
  def hit(k)
    - Remote.log(k)
    @n += 1
  end
end
`, 'Gate')
  expect(r.ok).toBe(false)
  expect(r.refusals.map(x => x.what).join('; ')).toMatch(/Remote.log/)
})

t('a module of the files read: a method it doesn\'t define, or one whose body calls what nothing defines; a local read before it is set is nil; another class\'s arguments evaluated', () => {
  const gate = (line: string, mod = 'def self.count(*) = nil') => rb(`
module Metrics
  ${mod}
end
class Gate
  def initialize(cap)
    @cap = cap
    @n = 0
  end
  def hit(user = "")
    ${line}
    @n += 1
  end
end
`, 'Gate')
  expect(gate('Metrics.log(user)').refusals.map(x => x.what).join('; ')).toMatch(/Metrics defines no log \(a NoMethodError where it runs\)/)
  expect(gate('Metrics.count(user)', 'def self.count(*) = nxil').refusals.map(x => x.what).join('; ')).toMatch(/Metrics.count calls nxil, which nothing defines/)
  expect(gate('Metrics.count(initialize)').ok).toBe(false)
  const x = ok(rb(`
class Limiter
  def initialize(limit)
    @limit = limit
    @count = 0
  end
  def hit
    count += 1
    @count += 1
  end
end
`, 'Limiter', {failures: 'kept'}))
  expect(x.source).toMatch(/failed/)
})
