// The extractor's shared step IR and its executor: one structure for every language read through a native reader.
// A reader (core/py/reader.py: Python's own `ast`) lowers a module into the IR below, as JSON; this file executes the
// steps symbolically into the Model core/extract-read.ts defines (the TypeScript and Go front ends' own), and
// core/extract.ts's fromModel prints, builds and checks it. The check is core/extract-check.ts's `drive`: the code's
// side is a harness in the code's own language (core/py/harness.py) spoken to in JSON lines, which makes the object,
// sets it to a state, calls it with the rule's requests and prints every state. Nothing here is trusted: the rule is
// adopted only where the run of both agrees, and what the subset doesn't read is refused where a step reaches it.
//
// Where a language's semantics differ, the IR says so with explicit operations (the reader chooses them): an integer
// type's width and what it does past its range (`int`: none for an unbounded one, Python's; wrap, trap or ub for
// fixed ones, a later reader's), division's rounding (floor for Python's // and %, trunc for C's, Go's and Rust's),
// truthiness (`truthy`), a missing value (`none`, `opt`), a failure (`fail`: an exception, a panic, an error value,
// each the step's refusal or, with failures: 'kept', its result).
//
// The code's boundary, inferred unless `strict` (research/langs/DESIGN.md, "The boundary inferred"), each statement
// printed in the notes and enforced by the check; what the caller states wins:
//   answers: a call of other code whose result is an input of the request (the check stubs it with that input).
//            Inferred where its value is read, over its declared result type;
//   skip:    a call left out (logging, an alert, a context manager): its value is kept only where nothing the rule
//            keeps reads it, and the check runs it as it is. Inferred where nothing reads it;
//   stores:  an object of other code held as a key-value store (a cache client): its get and set methods read and
//            write a map of the state, one per key template; its expiry, eviction and replication are left out, and the
//            check gives the code a store that keeps what is set. Inferred for an injected dependency called by a key.
// Other code given a reference to the rule's state is refused unless stated; the module's own functions the subset
// can't read, writing none of the state, are taken as other code; `gdp: skip | answer [type] | strict` comments say
// it in the code.
import * as I from './extract-ir.ts'
import type {B, K, L, N} from './extract-ir.ts'
import {type Arg, type Event, type Layout, type Fold, type LeastRead, type MapDecl, type Model, Refusal, type Term, type Var, mergeOps, mergeWrites} from './extract-read.ts'
import {type Extraction, type Name, fromModel} from './extract.ts'
import type {Rule} from './dsl.ts'
import {type Sorts, nonneg} from './extract-print.ts'
import {type CodeSide, type Coverage, type Evidence, type Snap, HarnessFailure, Outside, constantsOf, draw, drive, evalTerm, noEvidence, retried, tiesIn} from './extract-check.ts'

// --- the IR (what a reader emits) -----------------------------------------------------------------------------------
export type SType =
  // (mod: a width past the rule's numbers, 2^256 say, as a variable of the state the step never writes, any value at
  // least 2: an unsigned value is below it, and a law proven for every value is proven for the width's own)
  | {k: 'int', bits?: number, signed?: boolean, unit?: string, atomic?: string, lock?: string, rs?: string, mod?: string} | {k: 'float' | 'bool' | 'str' | 'none' | 'any' | 'lock', atomic?: string, lock?: string, bytes?: boolean}
  | {k: 'choice', values: string[], discs?: number[], enum?: string, sym?: boolean} | {k: 'opt', of: SType} | {k: 'res', of: SType}
  | {k: 'rec', name: string} | {k: 'map', key: SType, val: SType, set?: boolean} | {k: 'list', of: SType} | {k: 'opaque', why: string}
// (store: a method of an injected dependency, stubbed on the object the check gives)
export type Patch = {mod?: string, path?: string[], self?: string, store?: string}
export type SX = {e: string, p: string, text?: string, [k: string]: unknown}
export type SS = {s: string, p: string, [k: string]: unknown}
// (inject: marked as an injected dependency by the language's own means, Spring's @Autowired, FastAPI's Depends)
export type SParam = {name: string, t: SType, dflt?: SX, kw?: boolean, self?: boolean, star?: number, inject?: boolean}
export type SFunc = {id: string, name: string, cls?: string, p: string, span: [string, number, number], params: SParam[], ret: SType, body: SS[], async?: boolean, static?: boolean, decorators: {name: string, text: string, p: string}[],
  // (a function inlined by id, Go's: its receiver's local, its results' count, why it can't be called: before the
  // recursion check, or after it)
  recv?: string, results?: number, why?: string, late?: string}
// (rets: the declared result types of its methods, another module's class's too: an inferred answer's type)
export type SRec = {initializers?: string[], orm?: {framework: 'django' | 'sqlalchemy' | 'prisma' | 'typeorm', key: string, why?: string}, name: string, short: string, fields: {name: string, t: SType, dflt?: SX, inject?: boolean}[], methods: Record<string, string | null>, kinds: string[], own: boolean, module: string, p: string, rets?: Record<string, SType>, cattrs?: Record<string, number | string | boolean | null>, mro?: string[] | null, declared?: string[], classCollections?: Record<string, string>}
export type SModule = {lang: string, file: string, path: string, module: string, root: string, consts?: Record<string, number | string | boolean>, entries: ({k: 'class', rec: string} | {k: 'func', id: string} | {k: 'missing', name: string})[], recs: Record<string, SRec>, funcs: Record<string, SFunc>, enums?: Record<string, {values: string[], discs: number[], data: boolean}>, error?: string,
  // false: a condition the path takes is kept whole (a negated disjunction not split into its parts: Go's reader's);
  // 'nil-false': only nil and false are false (Ruby's), not Python's truthiness
  split?: boolean, truth?: 'nil-false',
  // false: the check can't stub a call (an answer, stated or inferred, is refused where it would be one)
  stubs?: boolean,
  // The bases of the failures the executor raises, by their names in `what` ("(a KeyError)"), qualified; and the class
  // a stub raises for a handler of every exception other code raises (its bases, and how the harness names it)
  kinds?: Record<string, string[]>, exc?: {mro: string[], raise: unknown},
  // true: the check's harness makes a list an argument carries (a list[T] read as one the request carries)
  lists?: boolean}
// A handler of a try: the classes it names (qualified), or every one (`any`); the bases of its first (open: some the
// reader can't know), and how a stub raises it (the harness's own reference); the exception's local; its body.
export type Handler = {p?: string, any?: boolean, names: string[], mro?: string[], open?: boolean, raise?: unknown, as?: string, body: SS[]}
// A raise's kind: its class and bases (open: not all known); null: a panic or a trap, which no handler catches.
type Kind = {mro: string[], open?: boolean} | null | undefined
// (depth: the frames inlined when it opened; a raise from deeper reaches its handler with that frame's locals)
type Try = {hs: Handler[], to: [Path, number, Kind][], ws: B[], depth: number}

// (skip: methods left out, which the check's store does nothing for; any method it isn't told of fails there)
// values: what a key template's keys hold, where it isn't the store's `value`: a choice of string literals, or a JSON text
// of a record (json.dumps of a dict), its fields' types (int, bool, a choice, each `| None` for a key it may lack; str
// fields are left out, read as values outside the subset). apart: the templates name distinct keys (stated: a key of
// one never has the form of another's, as "{}" and "{}:lock" might).
export type StoreVal = 'int' | 'float' | 'str' | string[] | {json: Record<string, string | string[]>}
export type StoreDecl = {ormSession?: boolean, get?: string[], set?: string[], delete?: string[], add?: string[], incr?: string[], skip?: string[], value?: 'int' | 'float' | 'str', attrs?: Record<string, null | boolean | number | string>, async?: Record<string, boolean>,
  values?: Record<string, StoreVal>, apart?: boolean,
  // nothrow: its calls taken not to raise inside a try (stated: the store's failures left to the system's environment
  // model, core/system.ts's STORE_FAILS, not each call's input)
  nothrow?: boolean}
// A stored record's field: its name, whether it may be absent (or None), its literals, whether it is left out (a str).
type JField = {name: string, opt?: boolean, choice?: boolean, vals?: string[], out?: boolean}
export type StepOptions = {
  // The class, or the functions (each a request), and the methods read (by default the public ones). With no entry,
  // the module's one class whose public methods write its state, and those methods.
  entry?: string | string[], methods?: string[],
  answers?: Record<string, string>, skip?: string[], stores?: Record<string, StoreDecl>,
  // Calls of other code that are effects (a charge, a published message, a handler's work): each step says whether it
  // made each (an output, `<name>.called`), the check stubbing the callee and reporting its calls. Also `gdp: effect`.
  effects?: string[],
  // Calls of other code the check replaces by one that does nothing and returns None (a client made from a URL in the
  // constructor, its field a stated store): left out, never run.
  stubs?: string[],
  // true: the boundary only as stated (answers, skip, stores), nothing inferred: any other call of other code refused
  strict?: boolean,
  // A failure (an exception, a panic) is the step's refusal (the default), or its result kept: the step taken, the
  // state as it was, `failed` true (to state laws about when the code refuses).
  failures?: 'refuse' | 'kept',
  onError?: 'refuse' | 'discard',
  domains?: Record<string, 'nat' | 'int'>,
  // The types of arguments the code doesn't declare, by name ('str', 'int', 'bool', 'int | None', a choice of literals).
  types?: Record<string, string>,
  // The request's arguments (by the code's names) kept in the rule though no term reads them: a law about the request
  // may read one the code ignores ("a wait counts only when start_failed", of code that never looks at it)
  keep?: string[],
  // Constructor arguments taken at their defaults (the claim is for objects made so): the fields the constructor sets
  // to them, which no method read writes, are constants of the rule, not its state.
  defaults?: string[],
  // Fields of the object held at these values after its constructor (stated: the claim is for objects so configured,
  // as other code may configure them): constants of the rule, a method writing one refused.
  fields?: Record<string, null | boolean | number | string>,
  // The methods' scalar arguments one input a type and place (the k-th of a type in every method), not one a method: a
  // law over a map the methods key by them reads fewer keys (ERC-20's sum, 3 not 6).
  share?: boolean,
  check?: {runs?: number, depth?: number, states?: number, seed?: number, bound?: number, probes?: boolean | 'writes'}
}

// --- values ---------------------------------------------------------------------------------------------------------
// An integer type's width (0: unbounded) and sign: where a number is one, its operations' overflow is the type's.
// (`name`: the type's name in the code, for the notes; `t`: the reader's own index of it)
// (`ub`: past its range is undefined behavior, C's and C++'s signed overflow: refused where it may be, never wrapped)
// (`mod`: an unsigned width past the rule's numbers, its 2^bits the state variable named: the type's values below it)
export type IntTy = {bits: number, signed: boolean, name?: string, t?: number, ub?: boolean, mod?: string}
// A number (with the comparison it is the sign of, x.Cmp(y); with the string it is the length of, read only against 0).
// (a value made of bit operations with constants on one value x: (x & A) ^ B, x at least 0 below 2^w; every such operation
// composes into one form, so a bit of the result is a bit of x, never of a sum of x's bits)
type Bits = {x: N, A: number, B: number, w: number}
// Bitwise and, or and xor of two naturals below 2^53 (JavaScript's operators stop at 32 bits).
const and = (a: number, b: number): number => { let out = 0; for (let p = 1; a > 0 && b > 0; p *= 2, a = Math.floor(a / 2), b = Math.floor(b / 2)) if (a % 2 && b % 2) out += p; return out }
const or = (a: number, b: number): number => a + b - and(a, b)
const xor = (a: number, b: number): number => a + b - 2 * and(a, b)

type V =
  | {t: 'num', e: N, ty?: IntTy, cmp?: [N, N], slen?: K, bits?: Bits} | {t: 'bool', e: B} | {t: 'str', e: K} | {t: 'choice', e: L}
  | {t: 'none'} | {t: 'opt', has: B, v: V}
  | {t: 'ref', id: string} | {t: 'cell', map: string, key: K}
  // A string made by a format with one hole (a store's key): its template and the hole's value.
  | {t: 'fmt', tpl: string, k: K}
  // (firm: a value merged only with itself, refused where a path would make it another; Go's)
  // (ask: the value of a call of other code left out by inference, answered by the next run where it is read)
  // (sink: a field the rule leaves out that the code may write, a C float's: written as the code writes it, never kept)
  | {t: 'opaque', why: string, firm?: boolean, ask?: string, sattr?: {store: string, path: string}, sink?: boolean}
  // (ret: the callee's declared result type; recv: the object its method is called on)
  | {t: 'ext', q: string, text: string, patch?: Patch, ret?: SType, recv?: V, nothrow?: boolean}
  | {t: 'fn', id: string, self?: V, caps?: Map<string, V>} | {t: 'cls', rec: string, patch?: Patch} | {t: 'builtin', n: string} | {t: 'lib', q: string}
  | {t: 'sattr', store: string, path: string}
  // A value read by its fields (Python's, by value): a dict literal of string keys ('$dict', a key maybe absent an opt
  // whose has is its presence), its JSON text ('$json'), a datetime ('$dt': f.ms, milliseconds since the epoch), a
  // timedelta ('$td': f.ms), a timestamp ('$ts': f.ms, its seconds times 1000).
  | {t: 'val', ty: string, f: Map<string, V>}
  | {t: 'tuple', xs: V[]} | {t: 'lock'}
  // A Result: Ok(v) where ok holds, Err(e) where it doesn't.
  | {t: 'res', ok: B, v: V, e: V}
  // A pointer by cases; a record by value; an error value (nil or not); nil; a map or a list of the heap, a list with an
  // item pushed or popped (put back only in its own place).
  | {t: 'ptr', to: Ptr} | {t: 'struct', ty: string, f: Map<string, V>} | {t: 'err', is: B} | {t: 'nil'}
  | {t: 'map', id: string} | {t: 'list', id: string} | {t: 'push', id: string, x: V} | {t: 'pop', id: string}
type CellWrite = {key: K, has: B, vals: Map<string, V>, on?: B}
// A collection a while loop's passes take items of by an order (Stepper.whileRank): the pass's item (K, held where
// `exists`, its fields `view`), the run's cells at the pass (how many are out, whether the next is held and its
// fields), its held keys in the order as a list the request carries (ord) and each one's place there (rk).
type Ranking = {name: string, id: string, decl: MapDecl, K: {op: 'num', e: N}, exists: B, view: Map<string, V>, cur: Map<string, V>, a: N, ld: B, ord: string, rk: string,
  order?: {by: (k: K) => {e: N, desc?: boolean}[], sig: string}}
// (a while loop whose first item is read from the other end: its passes run back from the last)
class Backward extends Error {}
// (a while loop whose first item is read by an order other than the collection's places: its passes over that order)
class Ranked extends Error {}
type Ptr = {k: 'nil'} | {k: 'obj', id: string, path: string[]} | {k: 'phi', c: B, a: Ptr, b: Ptr}
type ListOp = {op: 'push', x: V, when: B} | {op: 'pop', when: B} | {op: 'set', i: N, x: V, when: B}
type Place = {k: 'local', id: string, path: string[]} | {k: 'heap', ptr: V, path: string[]} | {k: 'blank'}
// How a field of a record the caller gives is made where it is first read.
export type Recipe = {k: 'num' | 'bool' | 'str', ty?: IntTy} | {k: 'big'} | {k: 'no', why: string}
type Origin = 'state' | 'input' | 'fresh'
type Obj =
  | {k: 'rec', ty: string, f: Map<string, V>, origin: Origin, lazy?: string, moved?: boolean, orm?: {table: string, key: K, session?: string, loaded?: boolean, deleted?: boolean}}
  // (w: the step's last write; pre: the writes at other keys before it, in order: a scalar map's, keyed by numbers)
  // (ew: a write at every key, its terms over k$, before the others: a while loop's passes over the collection)
  | {k: 'map', decl: MapDecl, val?: SType, nil?: B, w?: CellWrite, pre?: CellWrite[], ew?: CellWrite, origin: Origin}
  | {k: 'store', name: string}
  | {k: 'big', v: N, origin: Origin} | {k: 'list', decl: MapDecl, ops: ListOp[], origin: Origin}
// (locks held, and those deferred to the return)
// (cont: a path a continue ends, carried out as a break is, to its loop)
// (eff: the effects (calls of other code counted, `gdp: effect`) this path made)
type Path = {pc: B[], locals: Map<string, V>, heap: Map<string, Obj>, called: string[], locks: string[], defers: string[], cont?: true, eff?: Map<string, B>}
type Flow = {live?: Path, rets: [Path, V][], brk?: Path[], ft?: Path}
export type {V as StepValue, Path as StepPath, Obj as StepObj, Ptr as StepPtr}
// A string that is one of a choice's literals on every path (a literal, or literals by a condition): the choice's.
const asChoice = (k: K, vs: string[]): L | undefined => { if (k.op === 'slit') return vs.includes(k.value) ? I.llit(k.value, vs) : undefined; if (k.op !== 'kite') return undefined; const a = asChoice(k.a, vs), b = asChoice(k.b, vs); return a && b ? I.lite(k.c, a, b) : undefined }
// What the harness is told: where each leaf of the state is, how each argument is made, what each stub answers.
export type Leaf = {orm?: {rec: string, key: string, framework: string, fields: {name: string, t: SType}[]}, t?: SType, name: string, path: string[], kind: 'num' | 'bool' | 'str' | 'choice' | 'none' | 'map' | 'frame', float?: boolean, set?: boolean, cls?: string, fields?: {name: string, float?: boolean, choice?: boolean}[], key?: 'num' | 'str', store?: string, tpl?: string, ordered?: boolean, str?: boolean,
  // (a store's JSON records, or its choice of literals: what the harness decodes and encodes)
  json?: JField[], choice?: boolean}
// (list: a list the request carries, its items made by `item` (a record's fields, as read; or its one value))
export type PArg = {k: 'in', time?: string, name: string, float?: boolean, sym?: boolean, bytes?: boolean, z?: Raw} | {k: 'opt', none: string, v: PArg} | {k: 'rec', cls: string, f: [string, PArg][]} | {k: 'inert', dict?: boolean} | {k: 'store', name: string} | {k: 'dflt'}
  | {k: 'list', name: string, item: PArg}
// (how: 'inferred' from the callee's declared type, or 'tagged' by a gdp: comment; stated where absent)
// (at: the calls answered, each from its position to its end, `line:col`; ty: the call's type in the code's language)
// (raises: the input saying whether the call raises, and which handler's class (cls, by the choice's values after
// 'none'); pass: a call left out, the stub running it unless it raises)
export type Answer = {key: string, patch: Patch, async: boolean, inputs: {name: string, none?: string, float?: boolean, time?: string}, sort: string, how?: string, at?: {p: string, end?: string, span?: [number, number]}[], ty?: string, fit?: boolean,
  raises?: {name: string, cls: unknown[], m: string}[], pass?: boolean, effect?: boolean, quiet?: boolean}
// (inject: the fields the harness sets to the store it gives, after the constructor: a field injected by a framework)
export type StepRead = {ints: Record<string, IntTy>, madeAt?: string, naiveUtc?: boolean, model: Model, leaves: Leaf[], args: Record<string, [string, PArg][]>, answers: Answer[], ctor: [string, PArg][], kept: boolean, arms: [string, number][], cls?: string, stores: Record<string, StoreDecl>, results: Record<string, 'none' | 'scalar' | 'maybe'>, inject?: string[], globals?: {name: string, mod: string}[], effectsOf?: Record<string, string[]>, inert?: {store: string, path: string}[], edges?: B[]}

const where = (x: {p: string}) => x.p || '?'
const refuse = (x: {p: string} | string, what: string): never => { throw new Refusal(typeof x === 'string' ? x : where(x), what) }
const RESERVED = new Set(['rule', 'nat', 'int', 'bool', 'when', 'min', 'max', 'all', 'any', 'not', 'yes', 'no', 'lit', 'str', 'record', 'oneOf', 'intern', 'Int', 'forall', 'everyKey'])
const keyV = (v: V | Obj): string => JSON.stringify(v, (_, x) => (x instanceof Map ? [...x.entries()] : x))
const LANG: Record<string, string> = {go: 'Go', rust: 'Rust', python: 'Python', c: 'C', cpp: 'C++', ruby: 'Ruby', elixir: 'Elixir', java: 'Java', kotlin: 'Kotlin'}
const tyName = (ty?: IntTy) => (ty ? (ty.bits ? `${ty.signed ? 'i' : 'u'}${ty.bits}` : ty.signed ? 'an Instant' : 'a Duration') : 'the number')
const constOf = (v: V): number | undefined => (v.t === 'num' && v.e.op === 'const' ? v.e.v : undefined)
// The key a least key's where and by are read at (the printed rule's `.least`'s argument).
const LEAST_KEY = 'kl$'

// The sorts a type string names (an answer's): int, float, bool, str, a choice of quoted strings, each `| None`.
function sortOfText(s: string, at: string, lang: string): {t: SType} {
  const parts = s.split('|').map(x => x.trim()).filter(Boolean), none = parts.includes('None'), rest = parts.filter(x => x !== 'None')
  const one = (): SType => {
    if (rest.length && rest.every(x => /^['"].*['"]$/.test(x))) return {k: 'choice', values: rest.map(x => x.slice(1, -1))}
    if (rest.length !== 1) return refuse(at, `the answer type ${JSON.stringify(s)} (int, float, bool, str or quoted strings, each with | None)`)
    const k = rest[0]!
    if (k === 'int' || k === 'float' || k === 'bool' || k === 'str') return {k}
    if (k === 'datetime' || k === 'datetime-naive' || k === 'datetime-utc') {
      if (lang !== 'python') return refuse(at, 'stated datetime values are supported only by the Python harness')
      return {k: 'int', unit: k === 'datetime-utc' ? k : 'datetime-naive'}
    }
    // (a fixed width, a compiled language's: u32, i64, usize, uint8, int32)
    const w = /^(u|i|uint|int)(8|16|32|64|128|size)$/.exec(k)
    if (w) return {k: 'int', bits: w[2] === 'size' ? 64 : Number(w[2]), signed: !w[1]!.startsWith('u')}
    return refuse(at, `the answer type ${JSON.stringify(s)} (int, float, bool, str or quoted strings, each with | None)`)
  }
  const t = one()
  return {t: none ? {k: 'opt', of: t} : t}
}

// --- the boundary inferred (types) ---------------------------------------------------------------------------------
// What a reading infers over its runs: the calls answered (their value read) and the module's own functions cut
// (their bodies outside the subset, writing none of the rule's state). Each refused run adds one, until a run reads.
export type Inferred = {answers: Map<string, SType>, cut: Map<string, string>}
type Tag = {k: 'skip' | 'answer' | 'strict' | 'effect', arg: string}
const TAG_DECO = /(?:^|\.)gdp[._]?(skip|answer|strict|effect)$/i
// A call at the boundary: its key (an answer's input is named after its last part), what it is, its patch for the
// check, its declared result, the module's own function it is (cut), its object, its tag, and the refusal it was.
type Bound = {key: string, name: string, patch?: Patch, ret?: SType, own?: string, recv?: V, tag?: Tag, refusal: string, args?: false}
type Pend = Bound & {why: string, at: string, end?: string}
// A refusal as it leaves each function inlined: the function and its parameters holding the rule's state.
type Framed = Refusal & {frames?: {id: string, roots: string[]}[]}
// A type an answer takes: a scalar, or one with None.
const answerable = (t: SType): boolean => { const i = t.k === 'opt' ? t.of : t; return i.k === 'int' || i.k === 'float' || i.k === 'bool' || i.k === 'str' || i.k === 'choice' }
const typeText = (t: SType): string => (t.k === 'opt' ? `${typeText(t.of)} | None` : t.k === 'choice' ? t.values.map(v => JSON.stringify(v)).join(' | ') : t.k)
// A store's method by its name: one that reads, writes or deletes a key (async_, _cache and camel case aside).
// add: a set where the key holds nothing, its result whether it set (memcached's add, SET NX, put_if_empty); incr: the
// key's number raised by an amount (1 by default), absent counted 0, its result the new number (Redis's INCR).
type StoreOp = 'get' | 'set' | 'delete' | 'add' | 'incr'
const KEYED: Record<string, StoreOp> = Object.fromEntries([
  ...['add', 'setnx', 'putifempty', 'putifabsent', 'addifabsent'].map(n => [n, 'add']),
  ...['incr', 'incrby', 'increment', 'incrementby'].map(n => [n, 'incr']),
  ...['get', 'getcache', 'find', 'findbyid', 'fetch', 'load', 'lookup', 'read'].map(n => [n, 'get']),
  ...['set', 'setcache', 'put', 'save', 'store', 'write', 'upsert'].map(n => [n, 'set']),
  ...['delete', 'deletecache', 'remove', 'deletebyid', 'del', 'evict', 'invalidate'].map(n => [n, 'delete'])])
const keyShape = (m: string): StoreOp | undefined => KEYED[m.replace(/^async_?|_?async$/gi, '').replace(/[_-]/g, '').toLowerCase()]

// --- the executor ---------------------------------------------------------------------------------------------------
export class Stepper {
  readonly vars = new Map<string, Var>()
  readonly inputs: Var[] = []
  readonly params: Var[] = []
  readonly notes = new Set<string>()
  readonly refusals: B[] = []
  fails: B[] = []
  failPaths: Path[] = []
  readonly maps: MapDecl[] = []
  readonly answers = new Map<string, Answer>()
  readonly arms = new Set<string>()
  readonly hints = new WeakMap<object, string>()
  readonly lazy = new Map<string, {prefix: string, ty: string, args: [string, PArg][], vals: Map<string, V>}>()
  // The lists the request carries (maps by place), those a step reads, and the loops over lists read as folds.
  readonly seqs: MapDecl[] = []
  readonly used = new Set<string>()
  readonly folds: Fold[] = []
  // (inside a fold's pass: the tries outside it, hidden, and how deep)
  hidden = 0
  inFold = 0
  // (inside a while loop's pass: the collection it takes first items of, from which end; empty: the pass after they ran
  // out; drainSetup: an order read over the state before the step)
  drain?: {i: N, back: boolean, entry: Path, map?: {name: string, id: string}, dir?: boolean, empty?: string, rank?: Map<string, Ranking>, run?: string}
  drainSetup = 0
  drainAgain = false
  readonly initHeap = new Map<string, Obj>()
  readonly storeMaps = new Map<string, {store: string, tpl: string, id: string, decl: MapDecl, json?: JField[], choice?: boolean}>()
  // The least keys the step reads (an ordered collection's first or last item, its min or max by a key), each once.
  readonly leasts: LeastRead[] = []
  frames: string[] = []
  fieldNames = new Set<string>()
  readonly frozen = new Set<string>()
  // (the values of constructor arguments taken at their defaults: a field holding one is a constant)
  readonly atDefault = new Set<V>()
  // Each fixed-width variable's type (a number read from it overflows as the type does), and its range.
  readonly ints = new Map<string, IntTy>()
  readonly paramsOut: B[] = []
  now?: Var
  madeAt?: Var
  method = ''
  fresh = 0
  init = false
  // (inf: the boundary inferred so far, where the reading infers one; none: only what the caller states)
  constructor(readonly mod: SModule, readonly opts: StepOptions, readonly inf?: Inferred) {}

  rec(name: string, at: {p: string}): SRec { return this.mod.recs[name] ?? refuse(at, `${name}: a type the reader didn't read`) }
  newVar(name: string, sort: Var['sort'], role: Var['role'], note?: string, own = true): Var {
    let n = name.replace(/^[_@]+/, '').replace(/\?/g, '_p').replace(/!/g, '').replace(/[^\w$]/g, '_') || 'x'
    if (/^\d/.test(n)) n = `_${n}`
    // (a constructor's argument named as a field it sets: the field keeps the name, the argument is the initial one)
    if (role === 'param' && this.fieldNames.has(n)) n = `${n}0`
    while (this.vars.has(n) || RESERVED.has(n)) n = `${n}_`
    const v: Var = {name: n, sort, role, ...(note ? {note} : {})}
    // (not own: a name the rule's builders declare, a carried list's, kept from the others)
    if (!own) { this.vars.set(n, v); return v }
    this.vars.set(n, v)
    if (role === 'input') this.inputs.push(v)
    if (role === 'param') this.params.push(v)
    return v
  }
  valueOf(v: Var): V {
    const ty = this.ints.get(v.name)
    return v.sort.k === 'num' ? {t: 'num', e: I.nvar(v.name), ...(ty ? {ty} : {})} : v.sort.k === 'bool' ? {t: 'bool', e: I.bvar(v.name)} : v.sort.k === 'choice' ? {t: 'choice', e: {op: 'var', name: v.name, values: v.sort.values}} : {t: 'str', e: {op: 'svar', name: v.name}}
  }
  // A scalar sort, or why the type isn't one.
  scalar(t: SType): Var['sort'] | undefined {
    return t.k === 'int' || t.k === 'float' ? {k: 'num'} : t.k === 'bool' ? {k: 'bool'} : t.k === 'str' ? {k: 'str'} : t.k === 'choice' ? {k: 'choice', values: t.values} : undefined
  }
  why(t: SType): string {
    if (t.k === 'opaque') return t.why
    if (t.k === 'any') return 'a value of no type the code states'
    if (t.k === 'list') return 'a list (lists are outside the Python subset)'
    if (t.k === 'map') return t.set ? 'a set' : 'a dict'
    return t.k
  }
  // An input of a type: its variables, the value, and how the harness makes it.
  input(name: string, t: SType, at: {p: string}, p: Path, role: Var['role'] = 'input'): [V, PArg] {
    if (t.k === 'opaque' && t.why === '$orm-session' && role === 'input') {
      this.storeDecls.set(name, {ormSession: true})
      return [{t: 'ext', q: `orm-session:${name}`, text: name}, {k: 'store', name}]
    }
    const s = this.scalar(t)
    if (s) { const v = this.newVar(name, s, role); this.typed(v, t, role); return [this.timeField(this.valueOf(v), t, true, at), {k: 'in', name: v.name, z: zeroRaw(s), ...(t.k === 'int' && t.unit?.startsWith('datetime-') ? {time: t.unit} : {}), ...(t.k === 'float' ? {float: true} : {}), ...(t.k === 'choice' && t.sym ? {sym: true} : {}), ...(t.k === 'str' && t.bytes ? {bytes: true} : {})}] }
    if (t.k === 'opt') {
      if (t.of.k === 'rec') {
        const none = this.newVar(`${name}_none`, {k: 'bool'}, role, `whether ${name} is None`)
        const [v, a] = this.input(name, t.of, at, p, role)
        return [{t: 'opt', has: I.not(I.bvar(none.name)), v}, {k: 'opt', none: none.name, v: a}]
      }
      const inner = this.scalar(t.of)
      if (!inner) return refuse(at, `${name}: an optional ${this.why(t.of)}`)
      const v = this.newVar(name, inner, role, `0 where ${name} is None`), none = this.newVar(`${name}_none`, {k: 'bool'}, role, `whether ${name} is None`)
      this.typed(v, t.of, role, t.of.k === 'int' && t.of.unit?.startsWith('datetime-') ? I.and(this.sel, I.not(I.bvar(none.name))) : this.sel)
      return [{t: 'opt', has: I.not(I.bvar(none.name)), v: this.timeField(this.valueOf(v), t.of, true, at)}, {k: 'opt', none: none.name, v: {k: 'in', name: v.name, z: zeroRaw(inner), ...(t.of.k === 'int' && t.of.unit?.startsWith('datetime-') ? {time: t.of.unit} : {}), ...(t.of.k === 'float' ? {float: true} : {}), ...(t.of.k === 'str' && t.of.bytes ? {bytes: true} : {})}}]
    }
    if (t.k === 'none') return [{t: 'none'}, {k: 'dflt'}]
    // A list the request carries, of any length: a map by place (as a list of the state is), each place below its
    // length holding an item, of the scalar fields of its records (or its one value).
    if (t.k === 'list' && role === 'input' && this.mod.lists && (this.scalar(t.of) || t.of.k === 'rec')) {
      const n = this.newVar(name, {k: 'num'}, 'input', undefined, false).name, id = `in:${n}`, sc = this.scalar(t.of)
      this.newVar(`${n}_len`, {k: 'num'}, 'input', `the length of ${name}`, false)
      const fs = sc ? [{name: 'value', t: t.of}] : this.rec((t.of as {name: string}).name, at).fields.filter(x => this.scalar(x.t))
      const decl: MapDecl = {name: n, key: 'num', fields: fs.map(x => ({name: x.name, sort: this.scalar(x.t)!, role: 'input' as const})), scalar: !!sc, js: 'Map', carried: true}
      this.seqs.push(decl)
      p.heap.set(id, {k: 'map', decl, val: t.of, origin: 'input'})
      const arg = (x: {name: string, t: SType}): PArg => ({k: 'in', name: x.name, ...(x.t.k === 'float' ? {float: true} : {})})
      return [{t: 'ref', id}, {k: 'list', name: n, item: sc ? arg(fs[0]!) : {k: 'rec', cls: (t.of as {name: string}).name, f: fs.map(x => [x.name, arg(x)])}}]
    }
    if (t.k === 'rec' && role === 'input') {
      // An object the caller gives: its fields read are inputs, each made where it is first read.
      const id = `in:${name}:${this.fresh++}`, args: [string, PArg][] = []
      p.heap.set(id, {k: 'rec', ty: t.name, f: new Map(), origin: 'input', lazy: name})
      this.lazy.set(id, {prefix: name, ty: t.name, args, vals: new Map()})
      return [{t: 'ref', id}, {k: 'rec', cls: t.name, f: args}]
    }
    // A value of another type: kept only where nothing the rule keeps reads it (the harness gives an inert one).
    // (a dict of no stated types: an empty one, as JSON takes it, where the code serializes it)
    return [{t: 'opaque', why: `${name}: ${this.why(t)}`}, t.k === 'opaque' && /^dict\b/.test(t.why) ? {k: 'inert', dict: true} : {k: 'inert'}]
  }
  // A fixed-width integer variable: its type, and (for a request) a value outside it refused: the claim is for the
  // type's values.
  intTy(t: SType): IntTy | undefined { return t.k === 'int' && t.bits !== undefined ? {bits: t.bits, signed: t.signed ?? true, ...(t.mod ? {mod: t.mod} : {})} : undefined }
  // (bytes: a string of the rule's that is never equal to a str, as Python's b"x" != "x")
  bytesVars = new Set<string>()
  // (the request's arguments kept though no term reads them: opts.keep)
  kept = new Set<string>()
  typed(v: Var, t: SType | IntTy, role: Var['role'], sel = this.sel) {
    if ('k' in t && t.k === 'int' && t.unit?.startsWith('datetime-') && role !== 'state') {
      const out = I.or(I.cmp('<', I.nvar(v.name), I.num(-62_135_596_800_000)), I.cmp('<', I.num(253_402_300_799_999), I.nvar(v.name)))
      if (role === 'param') this.paramsOut.push(I.and(sel, out)); else this.refusals.push(I.and(sel, out))
    }
    if ('k' in t && t.k === 'str' && t.bytes) this.bytesVars.add(v.name)
    const ty = 'k' in t ? this.intTy(t) : t
    if (!ty) return
    this.ints.set(v.name, ty)
    const [lo, hi] = rangeOf(ty)
    if (role === 'state') return
    const x = I.nvar(v.name)
    // (a value of a symbolic width: an input at or past it refused, a param's the precondition's)
    if (ty.mod) { const out = I.or(I.cmp('<', x, I.num(0)), I.cmp('<=', I.nvar(ty.mod), x)); if (role === 'param') this.paramsOut.push(out); else this.refusals.push(I.and(sel, out)); return }
    // (a constructor's argument outside its type: no object is made with one, the rule's precondition says so)
    if (role === 'param') { const out = I.or(...(Number.isFinite(lo) ? [I.cmp('<', x, I.num(lo))] : []), ...(Number.isFinite(hi) ? [I.cmp('<', I.num(hi), x)] : [])); if (!(out.op === 'const' && !out.v)) this.paramsOut.push(out); return }
    if (Number.isFinite(hi)) this.refusals.push(I.and(sel, I.cmp('<', I.num(hi), x)))
    if (Number.isFinite(lo) && lo < 0) this.refusals.push(I.and(sel, I.cmp('<', x, I.num(lo))))
    else if (!ty.signed) this.refusals.push(I.and(sel, I.cmp('<', x, I.num(0))))
  }
  sel: B = I.T
  // (StepOptions.share: each shared input by its type and place, made at its first method)
  shared = new Map<string, [V, PArg]>()
  // The clock: one input a step.
  clock(at: {p: string}, p: Path): [V, Path] {
    // (read again in the step: the same time, as the check's clock gives it; the step taken to run within one tick)
    if (p.called.includes('$now')) this.notes.add(`the clock read more than once in a step (${at.p}): each read is the request's one time (assumes a step runs within one tick of the clock)`)
    // (in the constructor, the time the object is made: a param)
    if (this.init) { this.madeAt ??= this.newVar('made_at', {k: 'num'}, 'param', 'Date.now() (here time.time()): the time the object is made'); return [{t: 'num', e: I.nvar(this.madeAt.name)}, {...p, called: [...p.called, '$now']}] }
    this.now ??= this.newVar('now', {k: 'num'}, 'input', 'Date.now() (here the clock, time.time()): the time of the request, an input')
    return [{t: 'num', e: I.nvar(this.now.name)}, {...p, called: [...p.called, '$now']}]
  }

  // --- paths ----------------------------------------------------------------------------------------------------------
  // (inside a try, every path is also outside the raises its handlers caught before it: no path goes on past a raise)
  cond(p: Path): B { return this.tries.length ? I.and(...p.pc, ...this.tries.flatMap(t => t.ws.map(I.not))) : I.and(...p.pc) }
  // (a negated disjunction as its negated parts, so a later test of one of them is decided)
  assume(p: Path, c: B): Path { if (this.mod.split === false) return c.op === 'const' && c.v ? p : {...p, pc: [...p.pc, c]}; const cs = c.op === 'not' && c.x.op === 'or' ? c.x.xs.map(I.not) : c.op === 'and' ? c.xs : [c]; const kept = cs.filter(x => !(x.op === 'const' && x.v)); return kept.length ? {...p, pc: [...p.pc, ...kept]} : p }
  // A failure of the code where c holds on this path (an exception raised): the step's refusal, or its result.
  // (kind: the class raised and its bases, where it isn't the executor's own named in `what`, "(a KeyError)")
  fail(p: Path, c: B, at: {p: string}, what: string, kind = this.kindOf(what, at)) {
    const w = I.and(this.cond(p), c)
    if (w.op === 'const' && !w.v) return
    if (this.tries.length) { const h = this.catcher(kind, at); if (h) return this.raise(p, c, w, h, kind, at) }
    if (this.init) { this.fails.push(w); return }
    // (a crash, Swift's trap: the process ends, so nothing sees what the step wrote before it; the check's harness keeps
    // the state as it was)
    const crash = !!(at as {crash?: boolean}).crash
    // Failures kept with what the step wrote before them (the caller sees both): the path goes on to the step's end.
    if (this.opts.failures === 'kept' && this.opts.onError !== 'discard') {
      if (crash && this.changed(p)) refuse(at, `${what} after the state is written: a crash, after which the state is as it was (onError: 'discard' says so of every failure)`)
      this.failPaths.push(this.assume(p, this.tries.length ? w : c)); this.fails.push(w); this.notes.add(`${this.method}: ${what} (${at.p}) is the step's failure, kept as its result (with what the step wrote before it)`); return
    }
    if (!crash) this.unwritten(p, at, what)
    this.fails.push(w)
    this.notes.add(`${this.method}: ${what} (${at.p}) is ${this.opts.failures === 'kept' ? 'the step\'s failure, kept as its result' : 'the step\'s refusal'}`)
  }
  // A failure after the step wrote the state: refused, but where the caller drops what a failed call wrote.
  // --- exceptions caught ---------------------------------------------------------------------------------------------
  // The tries the path is in (innermost last): each one's handlers, the paths raised to each (with the raise's kind),
  // and the conditions they were raised under; `handling`, the kinds each handler being run caught (a bare re-raise's).
  tries: Try[] = []
  handling: Kind[][] = []
  // (the tries around each context manager of other code entered, taken as transparent)
  cms: number[] = []
  kindOf(what: string, at: {p: string}): Kind {
    if ((at as {crash?: boolean}).crash || /\(a panic\)$/.test(what)) return null
    const m = /\(an? ([A-Z]\w*)\)$/.exec(what), b = m && this.mod.kinds?.[m[1]!]
    return b ? {mro: b} : undefined
  }
  // The handler a raise of this kind goes to, the innermost try's first that names one of its classes (or any), or none
  // (the step's failure); one that may or may not (a kind of bases unknown, or none named) is refused, unless `loose`.
  catcher(k: Kind, at: {p: string}, loose = false): [Try, number] | undefined {
    if (k === null) return undefined
    for (let j = this.tries.length - 1; j >= 0; j--) {
      for (const [i, h] of this.tries[j]!.hs.entries()) {
        if (h.any || (k && h.names.some(n => k.mro.includes(n)))) return [this.tries[j]!, i]
        if ((!k || k.open) && !loose) refuse(at, `${k ? `a raise of ${k.mro[0]}, whose bases the reader doesn't know` : 'a failure the reader names no class for'}, inside a try whose handler names ${h.names.join(', ')}`)
      }
    }
    return undefined
  }
  // A raise (where c holds; w on this path) caught: its path goes to the handler, and no path of the try goes on past it.
  // (through a context manager of other code taken as transparent, which may suppress it: refused)
  raise(p: Path, c: B, w: B, [t, i]: [Try, number], k: Kind, at: {p: string}) {
    if (this.cms.some(b => this.tries.indexOf(t) < b)) refuse(at, 'a raise through a context manager of other code (which may suppress it) to a handler around it')
    // (raised in a function the try's frame called: the handler runs in that frame, with its locals at the call)
    const locals = this.frameLocals.length > t.depth ? this.frameLocals[t.depth]! : p.locals
    t.to.push([{...this.assume(p, c), locals, pc: [...p.pc, ...this.tries.flatMap(x => x.ws.map(I.not)), c]}, i, k]); t.ws.push(w) }
  // (each inlined frame's caller's locals at its call, outermost first)
  readonly frameLocals: Map<string, V>[] = []
  tryStmt(s: SS, p: Path): Flow {
    const hs = s.handlers as Handler[], fin = (s.fin as SS[] | undefined) ?? [], t: Try = {hs, to: [], ws: [], depth: this.frameLocals.length}, f0 = this.fails.length, outer = this.tries.map(x => x.ws.length)
    this.tries.push(t)
    let body: Flow
    try { body = this.block(s.body as SS[], p) } finally { this.tries.pop() }
    // (every way out of the body is past the raises its handlers caught)
    const out = (q: Path): Path => (t.ws.length ? this.assume(q, I.not(I.or(...t.ws))) : q)
    const rets: [Path, V][] = body.rets.map(([q, v]) => [out(q), v]), brk = (body.brk ?? []).map(out), lives: Path[] = []
    const add = (f: Flow) => { rets.push(...f.rets); brk.push(...(f.brk ?? [])); if (f.live) lives.push(f.live) }
    for (const [i, h] of hs.entries()) {
      const to = t.to.filter(x => x[1] === i)
      if (!to.length) continue
      this.arm(h.body)
      const q = this.joinSome(to.map(x => x[0]), s)!
      this.handling.push(to.map(x => x[2]))
      try { add(this.block(h.body, h.as ? {...q, locals: new Map(q.locals).set(h.as, {t: 'opaque', why: `${h.as}: the exception caught`})} : q)) } finally { this.handling.pop() }
    }
    if (body.live) add(this.block((s.els as SS[] | undefined) ?? [], out(body.live)))
    let live = this.join(lives, s)
    if (fin.length) {
      // (finally on every way out: run where the try ends and on each return; a failure's way out through it is refused)
      if (deep(fin, o => o.s === 'ret' || o.s === 'fail' || o.s === 'break' || o.s === 'try')) refuse(s, 'a finally that returns, raises or breaks')
      // (a raise an outer handler catches, from the body or a handler, goes out through it too)
      const past = this.tries.some((x, j) => x.ws.length > outer[j]!)
      if (this.fails.length > f0 || brk.length || past) refuse(s, `finally on ${brk.length ? 'a break' : past ? 'a raise' : 'a failure'}'s way out of its try`)
      const fl = (q: Path): Path | undefined => { const f = this.block(fin, q); return f.live }
      if (live) live = fl(live)
      for (const r of rets) r[0] = fl(r[0]) ?? r[0]
    }
    return {...(live ? {live} : {}), rets, ...(brk.length ? {brk} : {})}
  }
  // --- loops over a list the request carries, read as folds -----------------------------------------------------------
  // The body runs once, at a pass i$: the item there (its fields cells of the list's carried maps), and each local the
  // body sets that is set before it a running value (a cell of the loop's own list, at i$). Its step is what the pass
  // makes of them: each running value at i$ + 1, and whether the pass ended the loop (a return, a break, a failure or a
  // refusal of the step), with what it returned. Every request is assumed to carry the running values its items make
  // (Model's folds: the start at 0, the step at every i$ below the length), so after the loop each one is its cell at
  // the length: exact for every length, no pass unrolled. A pass that writes the state, reads an answer (one a pass) or
  // raises out of the loop to a try around it is refused.
  // A list a loop may run over: one the request carries (every place below its length held) or one of the state (its
  // places up to its last, each where it holds an item: its least key's, read in the state before the step).
  // (carried: only one the request carries, whose length is an input: its len() and its truth)
  listOf(v: V, p: Path, at: SX, carried = false): {id: string, o: Extract<Obj, {k: 'map'}>, len: N, held: (k: K) => B} | undefined {
    const o = v.t === 'ref' ? p.heap.get(v.id) : undefined
    if (o?.k !== 'map' || !(o.decl.carried || (!carried && o.decl.ordered && o.origin === 'state'))) return undefined
    this.used.add(o.decl.name)
    if (o.decl.carried) return {id: (v as {id: string}).id, o, len: I.nvar(`${o.decl.name}_len`), held: () => I.T}
    const last = this.least(o, at, k => this.baseCell(o.decl, k).has, k => [{e: (k as {e: N}).e, desc: true}])
    return {id: (v as {id: string}).id, o, len: I.nite(last.some, I.add(last.key, I.num(1)), I.num(0)), held: k => this.baseCell(o.decl, k).has}
  }
  forStmt(s: SS, p: Path): Flow {
    const why = (w: string) => refuse(s, `a loop over ${(s.over as SX).text ?? 'a value'}: ${w} (the subset reads a loop over a list the request carries, as a fold)`)
    let ov: V, q0: Path
    try { [ov, q0] = this.ev(s.over as SX, p) } catch (e) { if (e instanceof Refusal) { try { why(`${e.where}: ${e.what}`) } catch (r) { (r as Framed).frames = (e as Framed).frames; throw r } } throw e }
    const ls = this.listOf(ov, q0!, s.over as SX) ?? why(ov.t === 'opaque' ? ov.why : `a ${ov.t}`)
    if ((s.els as SS[] | undefined)?.length) return refuse(s, 'a loop\'s else')
    if (this.inFold) return refuse(s, 'a loop inside a loop\'s pass (one fold at a time)')
    const d = ls.o.decl, run = this.newVar(`${d.name}$${this.folds.length}`, {k: 'num'}, 'input', undefined, false).name, i = I.nvar(PASS), ik: K = {op: 'num', e: i}
    const own = assigned(s.body as SS[]), tv = s.to as SX
    if (deep(tv, o => o.e === 'var' && q0.locals.has(String(o.n)))) return refuse(s, 'a loop whose variable is a local set before it (after the loop it would hold the last item)')
    // The running values: the locals the body sets that are set before it.
    const fields: Var[] = [], init: Record<string, Term> = {}, locals = new Map(q0.locals)
    for (const n of [...own].filter(x => q0.locals.has(x))) {
      if (FLAGS.includes(n)) refuse(s, `${n}: a local the loop carries named as a fold's own values are`)
      const v0 = q0.locals.get(n)!, srt = sortOfV(v0) ?? refuse(s, `${n}: ${v0.t === 'opaque' ? v0.why : `a ${v0.t}`}, carried by the loop (the subset reads a loop's numbers, booleans and choices)`)
      fields.push({name: n, sort: srt, role: 'state'}); init[n] = termOfV(v0, s)
      locals.set(n, cellV(run, i, n, srt, v0.t === 'num' ? v0.ty : undefined))
    }
    // The item at the pass: its place's cell (its one value, for a list of scalars), where the place holds one.
    const held = ls.held(ik)
    let b0: Path = {...q0, pc: held.op === 'const' ? [] : [held], locals, cont: undefined}
    b0 = this.assign(tv, d.scalar ? this.baseCell(d, ik).vals.get('value')! : {t: 'cell', map: ls.id, key: ik}, s, b0)
    // One pass: the tries around the loop hidden (a raise out of a pass is the loop's), its failures and refusals its own.
    const saved = {tries: this.tries, fails: this.fails, failPaths: this.failPaths, refusals: this.refusals.length, edges: this.edges.length}
    this.hidden += this.tries.length; this.tries = []; this.fails = []; this.failPaths = []; this.inFold++
    let f: Flow
    try { f = this.block(s.body as SS[], b0) } finally { this.tries = saved.tries; this.hidden -= saved.tries.length; this.inFold-- }
    const F = I.or(...this.fails), Rf = I.or(...this.refusals.splice(saved.refusals))
    this.fails = saved.fails; this.failPaths = saved.failPaths
    if (this.edges.length > saved.edges) refuse(s, 'a loop whose passes reach the edge of a fixed-width type')
    const brks = (f.brk ?? []).filter(x => !x.cont), on = this.join([...(f.brk ?? []).filter(x => x.cont), ...(f.live ? [f.live] : [])], s), brk = this.join(brks, s)
    for (const e of [...(on ? [on] : []), ...(brk ? [brk] : []), ...f.rets.map(r => r[0])]) if (this.changedFrom(e, q0)) refuse(s, `a loop whose passes write the state (the subset reads a loop over a list as a fold of its locals)`)
    const pc = (x: Path) => I.and(...x.pc), R = I.or(...f.rets.map(([x]) => pc(x))), Br = I.or(...brks.map(pc))
    const no = (c: B) => c.op === 'const' && !c.v, ends = !(no(R) && no(Br) && no(F) && no(Rf))
    const at = (n: string, x: N = i) => cellV(run, x, n, fields.find(v => v.name === n)!.sort) as V & {e: B}
    const flag = (n: string, c: B) => { fields.push({name: n, sort: {k: 'bool'}, role: 'state'}); init[n] = {s: 'bool', e: I.F}; return c }
    const step: Record<string, Term> = {}, done: B = ends ? flag('__done', I.or(R, Br, F, Rf)) : I.F
    const doneAt: B = ends ? at('__done').e : I.F, idle = I.or(doneAt, I.not(held))
    for (const v of fields.filter(x => !FLAGS.includes(x.name))) {
      const val = (x?: Path) => x?.locals.get(v.name)
      const nx = brk && on ? this.ite(Br, val(brk)!, val(on)!, s) : val(brk) ?? val(on) ?? locals.get(v.name)!
      if (sortOfV(nx)?.k !== v.sort.k) refuse(s, `${v.name}: ${nx.t === 'opaque' ? nx.why : `a ${nx.t}`} after a pass of the loop`)
      step[v.name] = iteTerm(idle, termOfV(locals.get(v.name)!, s), termOfV(nx, s))
    }
    if (ends) step.__done = {s: 'bool', e: I.or(doneAt, I.and(held, done))}
    // (what a pass returned, where one did: kept, and the loop's value after it)
    let retV: V | undefined
    if (!no(R)) {
      retV = this.join(f.rets.map(([r, v]) => ({...r, locals: new Map([['__ret', v]])})), s)!.locals.get('__ret')!
      const srt = sortOfV(retV) ?? refuse(s, `a loop that returns ${retV.t === 'opaque' ? retV.why : `a ${retV.t}`} (the subset reads a loop's return of a number, a boolean or a choice)`)
      flag('__returned', R)
      step.__returned = {s: 'bool', e: I.or(at('__returned').e, I.and(I.not(idle), R))}
      fields.push({name: '__ret', sort: srt, role: 'state'}); init.__ret = termOfV(zeroOf(srt), s)
      step.__ret = iteTerm(I.and(I.not(idle), R), termOfV(retV, s), termOfV(at('__ret'), s))
    }
    if (!no(F)) { flag('__failed', F); step.__failed = {s: 'bool', e: I.or(at('__failed').e, I.and(I.not(idle), F))} }
    if (!no(Rf)) { flag('__refused', Rf); step.__refused = {s: 'bool', e: I.or(at('__refused').e, I.and(I.not(idle), Rf))} }
    this.folds.push({list: d.name, run, fields, init, step, len: ls.len, ...(d.carried ? {} : {state: true as const})})
    // After the loop: each running value its cell at the length.
    const end = (n: string) => at(n, ls.len)
    let q: Path = {...q0, locals: new Map(q0.locals), called: [...new Set([q0.called, ...f.rets.map(r => r[0].called), ...(on ? [on.called] : []), ...(brk ? [brk.called] : [])].flat())]}
    for (const v of fields) if (!FLAGS.includes(v.name)) q.locals.set(v.name, end(v.name))
    // (a pass that failed or refused: the loop's, and no path goes on past it)
    if (!no(F)) { if (this.tries.length) refuse(s, 'a failure in a loop inside a try'); this.fail(q, end('__failed').e, s, `a failure in a pass of the loop over ${d.name}`, null); q = this.assume(q, I.not(end('__failed').e)) }
    if (!no(Rf)) { this.refuseWhere(q, end('__refused').e, s, `a refusal in a pass of the loop over ${d.name}`); q = this.assume(q, I.not(end('__refused').e)) }
    if (no(R)) return {live: q, rets: []}
    const ret = q
    q = this.assume(q, I.not(end('__returned').e))
    return {live: q, rets: [[{...ret, pc: [...q0.pc, end('__returned').e]}, end('__ret')]]}
  }
  // --- while loops over the state's ordered collections, read as folds ------------------------------------------------
  // A while loop whose passes take the first item of one collection of the state in its own order (a list's places:
  // xs[0], pop(0), popleft(); a dict's keys: min(d), or from the other end: xs[-1], pop(), max(d)), each pass that goes
  // on taking it out, the last one (where the loop ends) free to keep it with its fields written. Then its passes are a
  // fold over the collection's keys in that order, as a for loop over the list is (core/extract-step.ts's forStmt): the
  // pass at a key holds its item, each pass where the condition holds runs the body, the first where it doesn't (or a
  // break, a return, a failure) ends the loop, and every request carries the run the passes compute. After the loop
  // each item the passes reached is as its pass left it (one write at every key); where the passes ran out of items
  // the condition is read once more with the collection empty. Exact for every number of items; refused: a pass that
  // keeps its item and goes on (the next would take it again), and any other write of the state in a pass.
  whileStmt(s: SS, p: Path, back = false): Flow {
    if ((s.els as SS[] | undefined)?.length) return refuse(s, 'a loop\'s else')
    if (this.inFold) return refuse(s, 'a loop inside a loop\'s pass (one fold at a time)')
    const q0 = p, i = I.nvar(PASS), body = s.body as SS[], own = assigned(body)
    const run = this.newVar(`loop$${this.folds.length}`, {k: 'num'}, 'input', undefined, false).name
    const cin: N = back ? I.add(i, I.num(1)) : i
    const fields: Var[] = [], init: Record<string, Term> = {}, locals = new Map(q0.locals)
    for (const n of [...own].filter(x => q0.locals.has(x))) {
      if (FLAGS.includes(n)) refuse(s, `${n}: a local the loop carries named as a fold's own values are`)
      const v0 = q0.locals.get(n)!, srt = sortOfV(v0) ?? refuse(s, `${n}: ${v0.t === 'opaque' ? v0.why : `a ${v0.t}`}, carried by the loop (the subset reads a loop's numbers, booleans and choices)`)
      fields.push({name: n, sort: srt, role: 'state'}); init[n] = termOfV(v0, s)
      locals.set(n, cellV(run, cin, n, srt, v0.t === 'num' ? v0.ty : undefined))
    }
    const at = (n: string, x: N) => cellV(run, x, n, fields.find(v => v.name === n)!.sort) as V & {e: B}
    const saved = {tries: this.tries, fails: this.fails, failPaths: this.failPaths, refusals: this.refusals.length, edges: this.edges.length}
    this.hidden += this.tries.length; this.tries = []; this.fails = []; this.failPaths = []; this.inFold++
    const dr: NonNullable<Stepper['drain']> = {i, back, entry: q0}
    this.drain = dr
    let f: Flow, c: B, b1: Path
    try {
      ;[c, b1] = this.truth(s.c as SX, {...q0, pc: [], locals, cont: undefined})
      f = c.op === 'const' && !c.v ? {rets: []} : this.block(body, this.assume(b1, c))
    } catch (e) {
      if (e instanceof Backward || e instanceof Ranked) { this.vars.delete(run); this.tries = saved.tries; this.hidden -= saved.tries.length; this.inFold--; this.drain = undefined; this.fails = saved.fails; this.failPaths = saved.failPaths; this.refusals.splice(saved.refusals); return e instanceof Ranked ? this.whileRank(s, p) : this.whileStmt(s, p, true) }
      throw e
    } finally { if (this.drain === dr) { this.tries = saved.tries; this.hidden -= saved.tries.length; this.inFold--; this.drain = undefined } }
    const d = dr.map ?? refuse(s, 'a while loop that takes no item of a collection of the state (the subset reads a loop over a list the request carries, or one whose passes take the first items of the state\'s list or dict)')
    const o0 = q0.heap.get(d.id) as Extract<Obj, {k: 'map'}>, held = this.baseCell(o0.decl, {op: 'num', e: i}).has
    // Each way out of a pass: what it wrote of its item (at the pass's key, nothing else of the state), and whether it
    // took it out; a pass that goes on (to the next) must have.
    const brks = (f.brk ?? []).filter(x => !x.cont), goes = [...(f.brk ?? []).filter(x => x.cont), ...(f.live ? [f.live] : [])]
    const itemOf = (e: Path): {w: B, has: B, vals: Map<string, V>} => {
      for (const [id, o] of e.heap) {
        const b = q0.heap.get(id)
        if (!b || b === o || !('origin' in o) || o.origin !== 'state' || keyV(o) === keyV(b)) continue
        if (id !== d.id) refuse(s, 'a loop whose passes write the state other than the items they take (the subset reads a loop over the state as its passes over a collection\'s items, each taking its own)')
      }
      const o = e.heap.get(d.id) as Extract<Obj, {k: 'map'}>
      if (o.pre?.length || (o.w && !I.same(o.w.key, {op: 'num', e: i}))) refuse(s, `a pass of the loop writes an item of ${d.name} other than the one it takes`)
      const base = this.baseCell(o0.decl, {op: 'num', e: i})
      return o.w ? {w: I.T, has: o.w.has, vals: o.w.vals} : {w: I.F, has: base.has, vals: base.vals}
    }
    // (a pass that keeps its item where the condition holds again: the code's next pass takes the same item, the rule's
    // the next one; the rule refuses there, which the check sees where the code reaches it)
    // (and a pass that keeps its item ends the loop: the code's next condition reads that item again, false or refused)
    let kept: B = I.F
    for (const e of goes) {
      const it = itemOf(e)
      if (it.has.op === 'const' && !it.has.v) continue
      kept = I.or(kept, I.and(...e.pc, it.has))
      this.drain = dr; this.drainAgain = true
      try { const [again] = this.truth(s.c as SX, e); const w = I.and(this.cond(e), it.has, again); if (!(w.op === 'const' && !w.v)) { this.refusals.push(w); this.notes.add(`${s.p}: a pass of the loop over ${d.name} that keeps its item where the condition holds again is refused (the next pass would take it again)`) } } finally { this.drain = undefined; this.drainAgain = false }
    }
    const F = I.or(...this.fails), Rf = I.or(...this.refusals.splice(saved.refusals))
    this.fails = saved.fails; this.failPaths = saved.failPaths
    if (this.edges.length > saved.edges) refuse(s, 'a loop whose passes reach the edge of a fixed-width type')
    const on = this.join(goes, s), brk = this.join(brks, s), retJ = this.join(f.rets.map(r => r[0]), s)
    const pc = (x: Path) => I.and(...x.pc), R = I.or(...f.rets.map(([x]) => pc(x))), Br = I.or(...brks.map(pc))
    const no = (x: B) => x.op === 'const' && !x.v
    const flag = (n: string) => { fields.push({name: n, sort: {k: 'bool'}, role: 'state'}); init[n] = {s: 'bool', e: I.F} }
    flag('__done')
    const doneIn = at('__done', cin).e, idle = I.or(doneIn, I.not(held)), runs = I.and(I.not(idle), c!)
    const step: Record<string, Term> = {}
    for (const v of fields.filter(x => !FLAGS.includes(x.name))) {
      const val = (x?: Path) => x?.locals.get(v.name)
      const nx = brk && on ? this.ite(Br, val(brk)!, val(on)!, s) : val(brk) ?? val(on) ?? locals.get(v.name)!
      if (sortOfV(nx)?.k !== v.sort.k) refuse(s, `${v.name}: ${nx.t === 'opaque' ? nx.why : `a ${nx.t}`} after a pass of the loop`)
      step[v.name] = iteTerm(runs, termOfV(nx, s), termOfV(locals.get(v.name)!, s))
    }
    step.__done = {s: 'bool', e: I.or(doneIn, I.and(I.not(idle), I.or(I.not(c!), R, Br, F, Rf, kept)))}
    // (the item each pass leaves: whether it wrote it, held or taken out, and its fields, at the pass's own place)
    const ways = [...(brk ? [[Br, brk] as const] : []), ...(retJ ? [[R, retJ] as const] : [])], lastOn = on ? itemOf(on) : undefined
    let item = lastOn ?? {w: I.F, has: I.F, vals: this.baseCell(o0.decl, {op: 'num', e: i}).vals}
    for (const [w, e] of ways) { const it = itemOf(e); item = {w: I.bite(w, it.w, item.w), has: I.bite(w, it.has, item.has), vals: new Map([...item.vals].map(([fn, v]) => [fn, this.ite(w, it.vals.get(fn)!, v, s)]))} }
    const wf = (n: string, srt: Var['sort'], t: Term) => { fields.push({name: n, sort: srt, role: 'state'}); init[n] = termOfV(zeroOf(srt), s); step[n] = t }
    wf('__w', {k: 'bool'}, {s: 'bool', e: I.and(runs, item.w)}); wf('__h', {k: 'bool'}, {s: 'bool', e: item.has})
    const like: [string, string][] = []
    for (const fd of o0.decl.fields) { wf(`__f__${fd.name}`, fd.sort, termOfV(item.vals.get(fd.name)!, s)); like.push([`__f__${fd.name}`, `${d.name}.${fd.name}`]) }
    let retV: V | undefined
    if (!no(R)) {
      retV = this.join(f.rets.map(([r, v]) => ({...r, locals: new Map([['__ret', v]])})), s)!.locals.get('__ret')!
      const srt = sortOfV(retV) ?? refuse(s, `a loop that returns ${retV.t === 'opaque' ? retV.why : `a ${retV.t}`} (the subset reads a loop's return of a number, a boolean or a choice)`)
      flag('__returned'); step.__returned = {s: 'bool', e: I.or(at('__returned', cin).e, I.and(runs, R))}
      fields.push({name: '__ret', sort: srt, role: 'state'}); init.__ret = termOfV(zeroOf(srt), s)
      step.__ret = iteTerm(I.and(runs, R), termOfV(retV, s), termOfV(at('__ret', cin), s))
    }
    if (!no(F)) { flag('__failed'); step.__failed = {s: 'bool', e: I.or(at('__failed', cin).e, I.and(runs, F))} }
    if (!no(Rf)) { flag('__refused'); step.__refused = {s: 'bool', e: I.or(at('__refused', cin).e, I.and(runs, Rf))} }
    // (the passes: the collection's places up to its last, as a for loop over it reads them)
    const last = this.least(o0, s as unknown as SX, k => this.baseCell(o0.decl, k).has, k => [{e: (k as {e: N}).e, desc: true}])
    const len = I.nite(last.some, I.add(last.key, I.num(1)), I.num(0)), end: N = back ? I.num(0) : len
    this.folds.push({list: d.name, run, fields, init, step, len, state: true, ...(back ? {back: true as const} : {}), loop: {like}})
    // After the loop: each running value its cell at the end, the collection as the passes left it.
    let q: Path = {...q0, locals: new Map(q0.locals), heap: new Map(q0.heap), called: [...new Set([q0.called, ...f.rets.map(r => r[0].called), ...(on ? [on.called] : []), ...(brk ? [brk.called] : [])].flat())]}
    for (const v of fields) if (!FLAGS.includes(v.name) && !v.name.startsWith('__')) q.locals.set(v.name, at(v.name, end))
    const k: N = I.nvar('k$'), ko: N = back ? k : I.add(k, I.num(1)), base = this.baseCell(o0.decl, {op: 'num', e: k})
    const wrote = (cellV(run, ko, '__w', {k: 'bool'}) as {e: B}).e
    q.heap.set(d.id, {...o0, ew: {key: {op: 'num', e: k}, has: I.bite(wrote, (cellV(run, ko, '__h', {k: 'bool'}) as {e: B}).e, base.has), vals: new Map([...base.vals].map(([fn, v]) => [fn, this.ite(wrote, cellV(run, ko, `__f__${fn}`, o0.decl.fields.find(x => x.name === fn)!.sort), v, s)]))}})
    const endDone = at('__done', end).e
    if (!no(F)) { if (this.tries.length) refuse(s, 'a failure in a loop inside a try'); this.fail(q, at('__failed', end).e, s, `a failure in a pass of the loop over ${d.name}`, null); q = this.assume(q, I.not(at('__failed', end).e)) }
    if (!no(Rf)) { this.refusals.push(I.and(this.cond(q), at('__refused', end).e)); q = this.assume(q, I.not(at('__refused', end).e)) }
    const rets: [Path, V][] = []
    if (!no(R)) { rets.push([{...q, pc: [...q0.pc, at('__returned', end).e]}, at('__ret', end)]); q = this.assume(q, I.not(at('__returned', end).e)) }
    // Where the passes ran out of items (none ended the loop): the condition once more, the collection empty.
    const ranOut = this.assume(q, I.not(endDone)), stopped = this.assume(q, endDone)
    this.drain = {i, back, entry: q0, empty: d.name}
    let g: Flow, c2: B, q2: Path
    try {
      ;[c2, q2] = this.truth(s.c as SX, ranOut)
      g = c2.op === 'const' && !c2.v ? {rets: []} : this.block(body, this.assume(q2, c2))
    } finally { this.drain = undefined }
    if (g.live || (g.brk ?? []).some(x => x.cont)) this.refuseWhere(g.live ?? (g.brk ?? []).find(x => x.cont)!, I.T, s, `the loop over ${d.name} goes on with it empty (it never ends)`)
    const after = this.join([stopped, ...(c2.op === 'const' && c2.v ? [] : [this.assume(q2, I.not(c2))]), ...(g.brk ?? []).filter(x => !x.cont)], s)
    return {...(after ? {live: after} : {}), rets: [...rets, ...g.rets]}
  }
  // A while loop whose passes take the first items of the state's lists by an order of their own (min or max by a
  // key, a heap's top): its passes are a fold of an unknown length, each one's item the one at its count in the order.
  // Every request carries the run (the locals, and for each list how many of its items the passes took out, whether
  // they hold the next and its fields as they left it), each list's held keys in the order (`ord`: increasing, each
  // held, and every held key at its place `rk`, the place's item tying it by the order), and the run is assumed to be
  // the one the passes compute: each pass's start where the condition holds and none ended the loop, the length the
  // first where not. After the loop, each list's items before the count are out and the one at it has the fields the
  // passes left (one write at every key). Two items that tie under the order are outside the claim (which of them comes
  // first is the code's: Python's list order, a heap's layout), an edge the check counts apart.
  whileRank(s: SS, p: Path): Flow {
    const q0 = p, run = this.newVar(`loop$${this.folds.length}`, {k: 'num'}, 'input', undefined, false).name, i = I.nvar(PASS)
    const body = s.body as SS[], own = assigned(body)
    const fields: Var[] = [], init: Record<string, Term> = {}, locals = new Map(q0.locals)
    for (const n of [...own].filter(x => q0.locals.has(x))) {
      if (FLAGS.includes(n)) refuse(s, `${n}: a local the loop carries named as a fold's own values are`)
      const v0 = q0.locals.get(n)!, srt = sortOfV(v0) ?? refuse(s, `${n}: ${v0.t === 'opaque' ? v0.why : `a ${v0.t}`}, carried by the loop (the subset reads a loop's numbers, booleans and choices)`)
      fields.push({name: n, sort: srt, role: 'state'}); init[n] = termOfV(v0, s)
      locals.set(n, cellV(run, i, n, srt, v0.t === 'num' ? v0.ty : undefined))
    }
    const at = (n: string, x: N = i) => cellV(run, x, n, fields.find(v => v.name === n)!.sort) as V & {e: B}
    const saved = {tries: this.tries, fails: this.fails, failPaths: this.failPaths, refusals: this.refusals.length, edges: this.edges.length}
    this.hidden += this.tries.length; this.tries = []; this.fails = []; this.failPaths = []; this.inFold++
    const dr: NonNullable<Stepper['drain']> = {i, back: false, entry: q0, rank: new Map(), run}
    this.drain = dr
    let f: Flow, c: B
    try {
      const [c0, b1] = this.truth(s.c as SX, {...q0, pc: [], locals, cont: undefined})
      c = c0
      f = c.op === 'const' && !c.v ? {rets: []} : this.block(body, this.assume(b1, c))
    } finally { this.tries = saved.tries; this.hidden -= saved.tries.length; this.inFold--; this.drain = undefined }
    const rk = dr.rank!
    // What a pass leaves of each list (each way out of it): the item taken out, or held with its fields; one that goes
    // on and keeps it where the condition holds again is refused (the code's next pass takes it again).
    const ends = [...(f.brk ?? []), ...(f.live ? [f.live] : []), ...f.rets.map(r => r[0])], goes = [...(f.brk ?? []).filter(x => x.cont), ...(f.live ? [f.live] : [])]
    for (const e of ends) {
      for (const [id, o] of e.heap) {
        const b = q0.heap.get(id)
        if (!b || b === o || !('origin' in o) || o.origin !== 'state' || keyV(o) === keyV(b)) continue
        const d = o.k === 'map' ? rk.get(o.decl.name) : undefined
        if (!d) refuse(s, 'a loop whose passes write the state other than the items they take (the subset reads a loop over the state as its passes over a collection\'s items, each taking its own)')
        if ((o as {pre?: unknown[]}).pre?.length) refuse(s, `a pass of the loop writes two items of ${d!.name}`)
      }
      for (const d of rk.values()) {
        const o = e.heap.get(d.id) as Extract<Obj, {k: 'map'}>
        if (o.w && !I.same(o.w.key, d.K)) refuse(s, `a pass of the loop writes an item of ${d.name} other than the first it takes`)
        const has = o.w ? o.w.has : d.exists, vals = o.w ? o.w.vals : d.view
        const out = I.and(d.exists, I.not(has)), held = I.and(d.exists, has), L = e.locals = new Map(e.locals)
        // (an item kept must keep the fields its order reads, or the order the run carries is no longer its: refused
        // where a pass changes one)
        if (o.w && d.order) for (const fn of orderFields(d.order.by, d.decl)) {
          const a = vals.get(fn)!, b = d.view.get(fn)!
          if (keyV(a) === keyV(b) || !('e' in a) || !('e' in b)) continue
          const w = I.and(this.cond(e), d.exists, I.not(a.t === 'num' && b.t === 'num' ? I.cmp('=', a.e, b.e) : a.t === 'bool' && b.t === 'bool' ? I.bite(a.e, b.e, I.not(b.e)) : I.F))
          if (!(w.op === 'const' && !w.v)) { this.refusals.push(w); this.notes.add(`${s.p}: a pass of the loop over ${d.name} that changes ${fn} (its order) of its item is refused`) }
        }
        L.set(`${d.name}__a`, {t: 'num', e: I.nite(out, I.add(d.a, I.num(1)), d.a)}); L.set(`${d.name}__ld`, {t: 'bool', e: held})
        for (const fd of d.decl.fields) L.set(`${d.name}__f__${fd.name}`, this.ite(held, vals.get(fd.name)!, d.cur.get(fd.name)!, s))
        if (goes.includes(e)) {
          this.drain = dr; this.drainAgain = true
          try { const [again] = this.truth(s.c as SX, e); const w = I.and(this.cond(e), held, again); if (!(w.op === 'const' && !w.v)) { this.refusals.push(w); this.notes.add(`${s.p}: a pass of the loop over ${d.name} that keeps its item where the condition holds again is refused (the next pass would take it again)`) } } finally { this.drain = undefined; this.drainAgain = false }
        }
      }
    }
    const F = I.or(...this.fails), Rf = I.or(...this.refusals.splice(saved.refusals))
    this.fails = saved.fails; this.failPaths = saved.failPaths
    if (this.edges.length > saved.edges) refuse(s, 'a loop whose passes reach the edge of a fixed-width type')
    if (!rk.size) refuse(s, 'a while loop that takes no item of a collection of the state')
    const like: [string, string][] = [], drains: NonNullable<NonNullable<Fold['loop']>['drains']> = [], kl: K = {op: 'num', e: I.nvar(LEAST_KEY)}
    for (const d of rk.values()) {
      const add = (n: string, srt: Var['sort'], t: Term) => { fields.push({name: n, sort: srt, role: 'state'}); init[n] = t }
      add(`${d.name}__a`, {k: 'num'}, {s: 'num', e: I.num(0)}); add(`${d.name}__ld`, {k: 'bool'}, {s: 'bool', e: I.F})
      for (const fd of d.decl.fields) { add(`${d.name}__f__${fd.name}`, fd.sort, termOfV(zeroOf(fd.sort), s)); like.push([`${d.name}__f__${fd.name}`, `${d.name}.${fd.name}`]) }
      const by = d.order ? this.rankOrder(d)(kl) : refuse(s, `${d.name}: a loop that reads its first item by no order`)
      drains.push({map: d.name, ord: d.ord, rk: d.rk, held: this.baseCell(d.decl, kl).has, by})
    }
    const brks = (f.brk ?? []).filter(x => !x.cont), on = this.join(goes, s), brk = this.join(brks, s)
    const pc = (x: Path) => I.and(...x.pc), R = I.or(...f.rets.map(([x]) => pc(x))), Br = I.or(...brks.map(pc))
    const no = (x: B) => x.op === 'const' && !x.v, stops = !(no(R) && no(Br) && no(F) && no(Rf))
    const flag = (n: string, x: B) => { fields.push({name: n, sort: {k: 'bool'}, role: 'state'}); init[n] = {s: 'bool', e: I.F}; return x }
    const step: Record<string, Term> = {}, done: B = stops ? flag('__done', I.or(R, Br, F, Rf)) : I.F
    const doneAt = (x: N): B => (stops ? at('__done', x).e : I.F)
    const retJ = this.join(f.rets.map(r => r[0]), s)
    for (const v of fields.filter(x => !FLAGS.includes(x.name))) {
      const val = (x?: Path) => x?.locals.get(v.name)
      const ways: [B, V][] = [...(brk && val(brk) ? [[Br, val(brk)!] as [B, V]] : []), ...(v.name.includes('__') && retJ && val(retJ) ? [[R, val(retJ)!] as [B, V]] : [])]
      let nx: V = val(on) ?? locals.get(v.name) ?? cellV(run, i, v.name, v.sort)
      for (const [w, x] of ways) nx = this.ite(w, x, nx, s)
      if (sortOfV(nx)?.k !== v.sort.k) refuse(s, `${v.name}: ${nx.t === 'opaque' ? nx.why : `a ${nx.t}`} after a pass of the loop`)
      step[v.name] = termOfV(nx, s)
    }
    if (stops) step.__done = {s: 'bool', e: done}
    if (!no(R)) {
      const retV = this.join(f.rets.map(([r, v]) => ({...r, locals: new Map([['__ret', v]])})), s)!.locals.get('__ret')!
      const srt = sortOfV(retV) ?? refuse(s, `a loop that returns ${retV.t === 'opaque' ? retV.why : `a ${retV.t}`} (the subset reads a loop's return of a number, a boolean or a choice)`)
      flag('__returned', R); step.__returned = {s: 'bool', e: R}
      fields.push({name: '__ret', sort: srt, role: 'state'}); init.__ret = termOfV(zeroOf(srt), s); step.__ret = termOfV(retV, s)
    }
    if (!no(F)) { flag('__failed', F); step.__failed = {s: 'bool', e: F} }
    if (!no(Rf)) { flag('__refused', Rf); step.__refused = {s: 'bool', e: Rf} }
    const len = I.nvar(this.newVar(`${run}_n`, {k: 'num'}, 'input', 'the passes of a loop (the run carries one more)').name)
    this.folds.push({list: [...rk.keys()].join(','), run, fields, init, step, len, loop: {like, cond: I.and(c!, I.not(doneAt(i))), drains, entry: I.and(this.sel, this.cond(q0))}})
    // After the loop: each running value its cell at the length; each list written at every key.
    let q: Path = {...q0, locals: new Map(q0.locals), heap: new Map(q0.heap), called: [...new Set([q0.called, ...f.rets.map(r => r[0].called), ...(on ? [on.called] : []), ...(brk ? [brk.called] : [])].flat())]}
    for (const v of fields) if (!FLAGS.includes(v.name) && !v.name.includes('__')) q.locals.set(v.name, at(v.name, len))
    for (const d of rk.values()) {
      const k: K = {op: 'num', e: I.nvar('k$')}, base = this.baseCell(d.decl, k), aN = (at(`${d.name}__a`, len) as {e: N}).e
      const place: N = {op: 'cell', map: d.rk, key: k, field: '$item'}
      const out = I.and(base.has, I.cmp('<', place, aN)), cur = I.and(at(`${d.name}__ld`, len).e, base.has, I.cmp('=', place, aN))
      const vals = new Map([...base.vals].map(([fn, v]) => [fn, this.ite(cur, at(`${d.name}__f__${fn}`, len), v, s)]))
      const o0 = q0.heap.get(d.id) as Extract<Obj, {k: 'map'}>
      q.heap.set(d.id, {...o0, ew: {key: k, has: I.and(base.has, I.not(out)), vals}})
    }
    if (!no(F)) { if (this.tries.length) refuse(s, 'a failure in a loop inside a try'); this.fail(q, at('__failed', len).e, s, 'a failure in a pass of the loop', null); q = this.assume(q, I.not(at('__failed', len).e)) }
    // (a pass the rule refuses: outside the claim (an item it keeps where the condition holds again, an order field it
    // changes), whatever the passes wrote)
    if (!no(Rf)) { this.refusals.push(I.and(this.cond(q), at('__refused', len).e)); q = this.assume(q, I.not(at('__refused', len).e)) }
    if (no(R)) return {live: q, rets: []}
    const ret = q
    q = this.assume(q, I.not(at('__returned', len).e))
    return {live: q, rets: [[{...ret, pc: [...q0.pc, at('__returned', len).e]}, at('__ret', len)]]}
  }
  // The order a list's passes take its items in: the order its first item is read by, part by part over the item's
  // cells at a key (no tie-breaking: two items that tie are an edge).
  rankOrder(d: Ranking): (k: K) => {e: N, desc?: boolean}[] {
    return k => { this.drainSetup++; try { return d.order!.by(k) } finally { this.drainSetup-- } }
  }
  // A list a pass of a while loop takes items of by an order: its item at the count of those taken out (in the order
  // the request carries its keys in), held where the count is below how many there are.
  rankOf(o: Extract<Obj, {k: 'map'}>, at: SX): Ranking {
    const dr = this.drain!, name = o.decl.name
    let d = dr.rank!.get(name)
    if (d) return d
    const id = [...this.initHeap].find(([, x]) => x.k === 'map' && x.decl === o.decl)?.[0] ?? refuse(at, `${at.text}: a collection of the state the reader didn't find`)
    const o0 = dr.entry.heap.get(id) as Extract<Obj, {k: 'map'}> | undefined
    if (o0?.w || o0?.pre?.length || o0?.ew) refuse(at, `${at.text}: a loop over ${name} after the step wrote it (the passes take its items in the state before the step)`)
    const ord = this.newVar(`${name}__ord`, {k: 'num'}, 'input', undefined, false).name, rk = this.newVar(`${name}__rk`, {k: 'num'}, 'input', undefined, false).name
    const cell = (n: string): {op: 'cell', map: string, key: K, field: string} => ({op: 'cell', map: dr.run!, key: {op: 'num', e: dr.i}, field: `${name}__${n}`})
    const a: N = cell('a'), ld: B = cell('ld'), K = {op: 'num' as const, e: {op: 'cell', map: ord, key: {op: 'num', e: a}, field: 'k'} as N}
    const exists = I.cmp('<', a, I.nvar(`${ord}_len`)), base = this.baseCell(o.decl, K)
    const cur = new Map(o.decl.fields.map(fd => [fd.name, cellV(dr.run!, dr.i, `${name}__f__${fd.name}`, fd.sort)]))
    const view = new Map(o.decl.fields.map(fd => [fd.name, this.ite(ld, cur.get(fd.name)!, base.vals.get(fd.name)!, at)]))
    d = {name, id, decl: o.decl, K, exists, view, cur, a, ld, ord, rk}
    dr.rank!.set(name, d)
    return d
  }
  // A least read of a list a while loop's passes take items of by an order: the pass's item; the order is the one the
  // item's key is first read by (a read of whether it is empty reads only whether there is one).
  rankLeast(o: Extract<Obj, {k: 'map'}>, at: SX, where: (k: K) => B, by: (k: K) => {e: N, desc?: boolean}[]): {key: N, some: B, held: B, where: (k: K) => B} {
    if (!o.decl.ordered) return refuse(at, `${at.text}: a dict read in a loop that takes the first items of a list by an order`)
    const d = this.rankOf(o, at), kk: K = {op: 'num', e: I.nvar(LEAST_KEY)}
    let w: B, parts: {e: N, desc?: boolean}[]
    this.drainSetup++
    try { w = where(kk); parts = by(kk) } finally { this.drainSetup-- }
    const sig = I.keyOf(parts)
    if (!I.same(w, this.baseCell(o.decl, kk).has)) refuse(at, `${at.text}: an item of ${d.name} by a condition, in a loop that takes its first items`)
    const empty = parts.length === 0
    return {get key(): N {
      if (empty && !d.order) return refuse(at, `${at.text}: ${d.name}'s first item by its places, in a loop that takes another list's items by an order`)
      if (!d.order) d.order = {by, sig}
      else if (d.order.sig !== sig) refuse(at, `${at.text}: ${d.name} read in two orders in a loop that takes its first items`)
      return d.K.e
    }, some: d.exists, held: d.exists, where}
  }
  // A least read of a collection a while loop's passes take items of: the pass's own item (its place or key), the
  // collection's own order only (the first from either end); in the pass after the passes ran out, none.
  drainLeast(o: Extract<Obj, {k: 'map'}>, at: SX, where: (k: K) => B, by: (k: K) => {e: N, desc?: boolean}[]): {key: N, some: B, held: B, where: (k: K) => B} {
    // (the list read again after the pass may have taken its item out: refused, the pass's item is the one it took; the
    // condition read once more at the pass's end is the next pass's, on the same item)
    if (!this.drainAgain && (o.pre?.length || (o.w && !(o.w.has.op === 'const' && o.w.has.v)))) return refuse(at, `${at.text}: ${o.decl.name} read again in a pass of the loop after the pass took its item out`)
    if (this.drain!.rank) return this.rankLeast(o, at, where, by)
    // (a dict's keys in order: the passes would run over every number up to the greatest key, refused)
    if (!o.decl.ordered) return refuse(at, `${at.text}: a dict's keys taken in order in a loop (the subset reads a loop over a list of the state)`)
    const dr = this.drain!, kk: K = {op: 'num', e: I.nvar(LEAST_KEY)}, name = o.decl.name
    let w: B, parts: {e: N, desc?: boolean}[]
    this.drainSetup++
    try { w = where(kk); parts = by(kk) } finally { this.drainSetup-- }
    const own = parts.length === 0 || (parts.length === 1 && I.same(parts[0]!.e, kk.e))
    const desc = parts.length === 1 && !!parts[0]!.desc
    if (dr.empty === name) return {get key(): N { return refuse(at, `${at.text}: the first item of ${name}, empty`) }, some: I.F, held: I.F, where}
    if (dr.empty) return refuse(at, `${at.text}: a collection read after a loop over another ran out of items`)
    if (!I.same(w, this.baseCell(o.decl, kk).has)) refuse(at, `${at.text}: an item of ${name} by a condition, in a loop whose passes take its first items`)
    if (dr.map && dr.map.name !== name) refuse(at, `${at.text}: a loop whose passes take items of two collections (${dr.map.name} and ${name}): the subset reads one`)
    if (!dr.map) {
      const id = [...this.initHeap].find(([, x]) => x.k === 'map' && x.decl === o.decl)?.[0] ?? refuse(at, `${at.text}: a collection of the state the reader didn't find`)
      const o0 = dr.entry.heap.get(id) as Extract<Obj, {k: 'map'}> | undefined
      if (o0?.w || o0?.pre?.length || o0?.ew) refuse(at, `${at.text}: a loop over ${name} after the step wrote it (the passes take its items in the state before the step)`)
      dr.map = {name, id}
    }
    const key = dr.i
    return {get key(): N {
      if (!own) { if (o.decl.ordered && !dr.dir) throw new Ranked(); return refuse(at, `${at.text}: a loop whose passes take ${name}'s items in an order other than its own (its places or keys) after reading them in it`) }
      if (desc !== dr.back) { if (dr.dir === undefined) throw new Backward(); return refuse(at, `${at.text}: ${name} taken from both ends in one loop`) }
      dr.dir = desc
      return key
    }, some: I.T, held: I.T, where}
  }
  // any, all or sum of a generator: the loop it is, its value an accumulator's (any: true at the first that is; all:
  // false at the first that isn't; sum: each added), the fold above.
  foldExpr(x: SX, p: Path): [V, Path] {
    const acc = `__fold${this.fresh++}`, at = x.p, n = (): SX => ({e: 'var', n: acc, p: at}), set = (y: SX): SS => ({s: 'set', p: at, to: n(), x: y})
    const k = (v: boolean): SX => ({e: 'bool', v, p: at}), f = String(x.f), y = x.x as SX
    const body: SS[] = f === 'any' ? [{s: 'if', p: at, c: y, then: [set(k(true)), {s: 'break', p: at}], else: []}] : f === 'all' ? [{s: 'if', p: at, c: y, then: [], else: [set(k(false)), {s: 'break', p: at}]}]
      : [set({e: 'bin', op: '+', x: n(), y, p: at, text: x.text})]
    const ifs = x.ifs as SX[], init: V = f === 'sum' ? {t: 'num', e: I.num(0)} : {t: 'bool', e: f === 'all' ? I.T : I.F}
    const fl = this.forStmt({s: 'for', p: at, to: x.to, over: x.over, body: ifs.length ? [{s: 'if', p: at, c: ifs.length > 1 ? {e: 'and', xs: ifs, p: at} : ifs[0]!, then: body, else: []}] : body}, {...p, locals: new Map(p.locals).set(acc, init)})
    const q = fl.live!, out = q.locals.get(acc)!, locals = new Map(q.locals)
    locals.delete(acc)
    return [out, {...q, locals}]
  }
  changedFrom(e: Path, p: Path): boolean {
    for (const [id, o] of e.heap) { const b = p.heap.get(id); if (b && b !== o && 'origin' in o && o.origin === 'state' && keyV(o) !== keyV(b)) return true }
    return false
  }
  // Paths that don't cover where they started (the raises to one handler) joined, keeping that one of them was taken.
  joinSome(ps: Path[], at: {p: string}): Path | undefined {
    const j = this.join(ps, at)
    if (!j || ps.length < 2) return j
    const k = j.pc.length, d = I.or(...ps.map(q => I.and(...q.pc.slice(k))))
    return d.op === 'const' && d.v ? j : {...j, pc: [...j.pc, d]}
  }
  // A call of other code inside a try that catches what it may raise: it returns, or raises what one handler of the
  // tries it is in catches (the innermost's first, up to one catching every exception other code raises), an input of
  // the request saying which (`<callee>_raises`), its stub raising the handler's class there.
  mayRaise(a: Answer, name: string, at: SX, p: Path): Path {
    if (!this.tries.length) return p
    const exc = this.mod.exc
    const outs: {t: Try, i: number, k: Kind, raise: unknown, n: string}[] = []
    for (let j = this.tries.length - 1, done = false; j >= 0 && !done; j--) {
      for (const [i, h] of this.tries[j]!.hs.entries()) {
        const k: Kind = h.any ? (exc ? {mro: exc.mro} : null) : h.mro ? {mro: h.mro, ...(h.open ? {open: true} : {})} : null
        if (!k || (h.any ? !exc : h.raise === undefined)) return refuse(at, `${at.text ?? name}: other code called inside a try whose handler ${h.any ? 'catches every exception' : `names ${h.names.join(', ')}`}, which the ${LANG[this.mod.lang] ?? this.mod.lang} check can't raise`)
        // (its class caught by an earlier handler: that one's outcome)
        const c = this.catcher(k, at, true)
        if (c && (c[0] !== this.tries[j] || c[1] !== i)) continue
        outs.push({t: this.tries[j]!, i, k, raise: h.any ? exc!.raise : h.raise, n: (h.any ? exc!.mro[0]! : h.names[0]!).split('.').pop()!})
        // (one catching the class other code raises catches every exception it raises: the last outcome)
        if (h.any || h.names.some(n => exc?.mro.includes(n))) { done = true; break }
      }
    }
    if (!outs.length) return p
    if (this.init) return refuse(at, `${at.text ?? name}: other code called inside a try in the constructor (whether it raises would be a param)`)
    if (p.called.includes(`${a.key}$raises`)) return refuse(at, `${at.text ?? name}: ${a.key} called twice in one step inside a try (whether it raises is one input a step)`)
    if (!a.patch && !a.at?.length) return refuse(at, `${at.text ?? name}: may raise inside a try that catches it, and the check can't stub it`)
    const short = a.key.split(/\.|::/).pop()!, vals = ['none', ...outs.map((o, i) => (outs.findIndex(x => x.n === o.n) === i ? o.n : `${o.n}_${i}`))]
    // (one input a method: each method's tries may catch it differently)
    let r = a.raises?.find(x => x.m === this.method)
    if (!r) {
      const v = this.newVar(a.raises?.length ? `${this.method}_${short}_raises` : `${short}_raises`, outs.length === 1 ? {k: 'bool'} : {k: 'choice', values: vals}, 'input', `whether ${name} raises${outs.length > 1 ? ', and what (the class each handler catches)' : ''}: other code called inside a try that catches it (assumed: it returns, or raises what a handler of the try catches)`)
      ;(a.raises ??= []).push(r = {name: v.name, cls: outs.map(o => o.raise), m: this.method})
      this.notes.add(`${name} (${at.p}): may raise inside a try that catches it (assumed: it returns, or raises ${outs.map(o => o.n).join(' or ')}); whether it raises is an input of the request, ${v.name}`)
    } else if (JSON.stringify(r.cls) !== JSON.stringify(outs.map(o => o.raise))) return refuse(at, `${at.text ?? name}: ${a.key} called inside tries that catch differently in one method`)
    const v = this.vars.get(r.name)!
    for (const [i, o] of outs.entries()) {
      const c = v.sort.k === 'bool' ? I.bvar(v.name) : I.is({op: 'var', name: v.name, values: vals}, vals[i + 1]!), w = I.and(this.cond(p), c)
      if (!(w.op === 'const' && !w.v)) this.raise(p, c, w, [o.t, o.i], o.k, at)
    }
    return {...p, called: [...p.called, `${a.key}$raises`]}
  }
  unwritten(p: Path, at: {p: string}, what: string) { if (this.opts.onError !== 'discard' && this.changed(p)) refuse(at, `${what} after the state is written (the caller would see the object changed and the call failed; with onError: 'discard' the caller is taken to drop what a failed call wrote)`) }
  changed(p: Path): boolean {
    for (const [id, o] of p.heap) {
      const i = this.initHeap.get(id)
      if (!i || ('origin' in o && o.origin !== 'state')) continue
      // (a write a condition makes, nx's, on a path where that condition is false: none)
      if (o.k === 'map' ? !!o.ew || (!!o.w && !(o.w.on && p.pc.some(c => I.same(c, I.not(o.w!.on!))))) || (!!o.nil && I.keyOf(o.nil) !== I.keyOf((i as typeof o).nil!)) : o.k === 'list' ? o.ops.length > 0 : keyV(o) !== keyV(i)) return true
    }
    return false
  }
  join(ps: Path[], at: {p: string}): Path | undefined {
    if (!ps.length) return undefined
    let acc = ps.at(-1)!
    for (let i = ps.length - 2; i >= 0; i--) acc = this.merge(ps[i]!, acc, at)
    return acc
  }
  merge(a: Path, b: Path, at: {p: string}): Path {
    let k = 0
    while (k < a.pc.length && k < b.pc.length && I.same(a.pc[k]!, b.pc[k]!)) k++
    const c = I.and(...a.pc.slice(k)), cb = I.and(...b.pc.slice(k))
    // (the two paths' own conditions: one or the other holds past the merge, which is no longer true where a path of
    // either left before it, a return or a break in a branch)
    const pc = [...a.pc.slice(0, k), ...(I.same(cb, I.not(c)) || I.same(c, I.not(cb)) || (c.op === 'const' && c.v) || (cb.op === 'const' && cb.v) ? [] : [I.or(c, cb)])]
    if (c.op === 'const') return c.v ? {...a, pc} : {...b, pc}
    if (a.locks.join() !== b.locks.join()) refuse(at, 'a mutex locked on one path and not on another')
    const locals = new Map<string, V>()
    for (const [n, x] of a.locals) { const y = b.locals.get(n); if (y) { try { locals.set(n, this.ite(c, x, y, at)) } catch (e) { if (!(e instanceof Refusal) || firm(x) || firm(y)) throw e; locals.set(n, {t: 'opaque', why: e.what}) } } }
    // (an object one path has not touched yet, a store's map made where first used: as it starts, on that path)
    const heap = new Map<string, Obj>()
    for (const [id, x] of a.heap) { const y = b.heap.get(id) ?? this.initHeap.get(id); heap.set(id, y ? this.mergeObj(c, x, y, at) : x) }
    for (const [id, y] of b.heap) if (!heap.has(id)) { const x = this.initHeap.get(id); heap.set(id, x ? this.mergeObj(c, x, y, at) : y) }
    const effs = new Set([...(a.eff?.keys() ?? []), ...(b.eff?.keys() ?? [])])
    const eff = effs.size ? new Map([...effs].map(e => [e, I.bite(c, a.eff?.get(e) ?? I.F, b.eff?.get(e) ?? I.F)])) : undefined
    return {pc, locals, heap, called: [...new Set([...a.called, ...b.called])], locks: a.locks, defers: [...new Set([...a.defers, ...b.defers])], ...(eff ? {eff} : {})}
  }
  mergeObj(c: B, a: Obj, b: Obj, at: {p: string}): Obj {
    if (a === b) return a
    if (a.k === 'big' && b.k === 'big') return {...a, v: I.nite(c, a.v, b.v)}
    if (a.k === 'rec' && b.k === 'rec') {
      const f = new Map<string, V>()
      for (const [n, x] of a.f) { const y = b.f.get(n); f.set(n, y ? this.ite(c, x, y, at) : x) }
      for (const [n, y] of b.f) if (!f.has(n)) f.set(n, y)
      return {...a, f, moved: a.moved || b.moved}
    }
    if (a.k === 'map' && b.k === 'map') {
      const base = (key: K) => this.baseCell(a.decl, key), ite = (c2: B, x: V, y: V) => this.ite(c2, x, y, at)
      // (a write at every key on one path or both: each key's cell by the condition, the other path's as it was)
      if (a.ew || b.ew) {
        const sig = (w?: CellWrite) => (w ? keyV({h: w.has, v: [...w.vals]} as never) : '')
        if ((a.w || a.pre?.length || b.w || b.pre?.length) && sig(a.ew) !== sig(b.ew)) return refuse(at, 'a collection a loop wrote at every key on one path and at one key on another')
        const k: K = {op: 'num', e: I.nvar('k$')}, ea: CellWrite = a.ew ?? {key: k, ...base(k)}, eb: CellWrite = b.ew ?? {key: k, ...base(k)}
        if (sig(ea) !== sig(eb)) return {...a, ew: {key: k, has: I.bite(c, ea.has, eb.has), vals: new Map([...ea.vals].map(([f, v]) => [f, ite(c, v, eb.vals.get(f)!)]))}}
        if (!a.w && !b.w) return {...a, ew: ea}
      }
      // (several keys written: both paths' writes padded to one length, each place by the condition)
      const [la, lb] = padWrites([[...(a.pre ?? []), ...(a.w ? [a.w] : [])], [...(b.pre ?? []), ...(b.w ? [b.w] : [])]], base) as [CellWrite[], CellWrite[]]
      if (la.length > 1) { const ws = la.map((x, i) => mergeWrites(c, x, lb[i], base, ite)!); return {...a, ...(a.nil ? {nil: I.bite(c, a.nil, b.nil!)} : {}), w: ws.at(-1)!, pre: ws.slice(0, -1)} }
      const w = mergeWrites(c, a.w, b.w, base, ite)
      return {...a, ...(a.nil ? {nil: I.bite(c, a.nil, b.nil!)} : {}), ...(w ? {w} : {})}
    }
    if (a.k === 'list' && b.k === 'list') return {...a, ops: mergeOps(c, a.ops, b.ops)}
    if (a.k === 'store' && b.k === 'store') return a
    return refuse(at, 'an object of two kinds by a condition')
  }
  // A value by cases.
  ite(c: B, a: V, b: V, at: {p: string}): V {
    if (c.op === 'const') return c.v ? a : b
    if (a === b) return a
    // (a number keeps its type)
    if (a.t === 'num' && b.t === 'num') return {t: 'num', e: I.nite(c, a.e, b.e), ...(a.ty ? {ty: a.ty} : {})}
    if (firm(a) || firm(b)) return this.iteFirm(c, a, b, at)
    if (keyV(a) === keyV(b)) return a
    if (a.t === 'opaque') return a
    if (b.t === 'opaque') return b
    if (a.t === 'bool' && b.t === 'bool') return {t: 'bool', e: I.bite(c, a.e, b.e)}
    if (a.t === 'str' && b.t === 'str') return {t: 'str', e: I.kite(c, a.e, b.e)}
    if (a.t === 'choice' && b.t === 'choice') return {t: 'choice', e: I.lite(c, a.e, b.e)}
    if (a.t === 'choice' && b.t === 'str' && b.e.op === 'slit') return this.ite(c, a, {t: 'choice', e: I.llit(b.e.value, lvalues(a.e))}, at)
    if (b.t === 'choice' && a.t === 'str' && a.e.op === 'slit') return this.ite(c, {t: 'choice', e: I.llit(a.e.value, lvalues(b.e))}, b, at)
    if (a.t === 'none' && b.t === 'none') return a
    if (a.t === 'none') return b.t === 'opt' ? {t: 'opt', has: I.and(I.not(c), b.has), v: b.v} : {t: 'opt', has: I.not(c), v: b}
    if (b.t === 'none') return a.t === 'opt' ? {t: 'opt', has: I.and(c, a.has), v: a.v} : {t: 'opt', has: c, v: a}
    if (a.t === 'opt' || b.t === 'opt') {
      const oa = a.t === 'opt' ? a : {has: I.T, v: a}, ob = b.t === 'opt' ? b : {has: I.T, v: b}
      return {t: 'opt', has: I.bite(c, oa.has, ob.has), v: this.ite(c, oa.v, ob.v, at)}
    }
    if (a.t === 'res' && b.t === 'res') {
      // (an Err's value, and an Ok's error, are no value: the other side's is taken)
      const no = (x: B) => x.op === 'const' && !x.v, yes = (x: B) => x.op === 'const' && x.v
      return {t: 'res', ok: I.bite(c, a.ok, b.ok), v: no(a.ok) ? b.v : no(b.ok) ? a.v : this.ite(c, a.v, b.v, at), e: yes(a.ok) ? b.e : yes(b.ok) ? a.e : this.ite(c, a.e, b.e, at)}
    }
    if (a.t === 'tuple' && b.t === 'tuple' && a.xs.length === b.xs.length) return {t: 'tuple', xs: a.xs.map((x, i) => this.ite(c, x, b.xs[i]!, at))}
    if (a.t === 'val' && b.t === 'val' && a.ty === b.ty) {
      // (a key on one path only: present where that path is taken)
      const f = new Map<string, V>(), absent = (x: V, has: B): V => (x.t === 'opt' ? {t: 'opt', has: I.and(has, x.has), v: x.v} : {t: 'opt', has, v: x})
      for (const [n, x] of a.f) { const y = b.f.get(n); f.set(n, y ? this.ite(c, x, y, at) : absent(x, c)) }
      for (const [n, y] of b.f) if (!a.f.has(n)) f.set(n, absent(y, I.not(c)))
      return {t: 'val', ty: a.ty, f}
    }
    // (a list the request carries on one path, another value on another: kept only where nothing reads it)
    if ([a, b].some(x => x.t === 'ref' && this.seqs.some(d => x.id === `in:${d.name}`))) return {t: 'opaque', why: 'a list the request carries on one path, another value on another'}
    if (a.t === 'ref' && b.t === 'ref') return refuse(at, 'one of two objects by a condition')
    return refuse(at, `a value that is a ${a.t} on one path and a ${b.t} on another`)
  }
  // Pointers, records by value, error values, nil, maps and lists: Go's merge (a firm value with another refused).
  iteFirm(c: B, a: V, b: V, at: {p: string}): V {
    if (a.t === 'err' && b.t === 'err') return {t: 'err', is: I.bite(c, a.is, b.is)}
    const asPtr = (v: V): Ptr | undefined => (v.t === 'ptr' ? v.to : v.t === 'nil' ? {k: 'nil'} : undefined)
    if ((a.t === 'ptr' || a.t === 'nil') && (b.t === 'ptr' || b.t === 'nil')) return {t: 'ptr', to: phiP(c, asPtr(a)!, asPtr(b)!)}
    if ((a.t === 'err' && b.t === 'nil') || (a.t === 'nil' && b.t === 'err')) return {t: 'err', is: I.bite(c, a.t === 'err' ? a.is : I.F, b.t === 'err' ? b.is : I.F)}
    if (a.t === 'struct' && b.t === 'struct') { const f = new Map<string, V>(); for (const [n, x] of a.f) f.set(n, this.ite(c, x, b.f.get(n)!, at)); return {t: 'struct', ty: a.ty, f} }
    if ((a.t === 'map' && b.t === 'map') || (a.t === 'list' && b.t === 'list')) { if (a.id === b.id) return a; return refuse(at, 'one of two maps or slices by a condition') }
    if (a.t === 'opaque' && b.t === 'opaque' && a.why === b.why) return a
    if (keyV(a) === keyV(b)) return a
    return refuse(at, `a value that is a ${a.t} on one path and a ${b.t} on another`)
  }
  baseCell(d: MapDecl, key: K): {has: B, vals: Map<string, V>} {
    const vals = new Map<string, V>(d.fields.map(f => [f.name, f.sort.k === 'num' ? {t: 'num', e: {op: 'cell', map: d.name, key, field: f.name}} : f.sort.k === 'str' ? {t: 'str', e: {op: 'cell', map: d.name, key, field: f.name}} : f.sort.k === 'choice' ? {t: 'choice', e: {op: 'cell', map: d.name, key, field: f.name, values: f.sort.values}} : {t: 'bool', e: {op: 'cell', map: d.name, key, field: f.name}}]))
    return {has: {op: 'cell', map: d.name, key, field: 'has'}, vals}
  }

  // A value that may be None, read where the path has decided which (after `if x is None: return`).
  narrow(v: V, p: Path): V {
    if (v.t !== 'opt') return v
    const c = this.cond(p)
    if (I.and(c, I.not(v.has)).op === 'const') return this.narrow(v.v, p)
    if (I.and(c, v.has).op === 'const') return {t: 'none'}
    return v
  }
  // --- conversions ----------------------------------------------------------------------------------------------------
  // Python's truthiness, made explicit: a later reader's `if` reads a boolean only.
  truthy(v: V, at: {p: string}, p?: Path): B {
    if (this.mod.truth === 'nil-false') return v.t === 'bool' ? v.e : v.t === 'none' ? I.F : v.t === 'opt' ? I.and(v.has, this.truthy(v.v, at, p)) : v.t === 'opaque' ? refuse(at, `${(at as SX).text ?? ''}: the truth of ${v.why}`) : I.T
    switch (v.t) {
      case 'bool': return v.e
      case 'num': return I.not(I.cmp('=', v.e, I.num(0)))
      case 'str': return I.not(I.keq(v.e, {op: 'slit', value: ''}))
      case 'choice': return lvalues(v.e).includes('') ? I.not(I.is(v.e, '')) : I.T
      case 'none': return I.F
      case 'opt': return I.and(v.has, this.truthy(v.v, at, p))
      // (a JSON text is never empty; a dict literal is as its keys)
      case 'val': return v.ty === '$dict' ? (v.f.size ? I.T : I.F) : v.ty === '$json' || v.ty === '$dt' ? I.T : refuse(at, `${(at as SX).text ?? ''}: the truth of a ${v.ty.slice(1)}`)
      case 'ref': {
        // (a list the request carries: whether it has an item)
        const cl = p && this.listOf(v, p, at as SX, true)
        if (cl) return I.cmp('<', I.num(0), cl.len)
        // An object is true unless its class (or a base) defines __bool__ or __len__; a dict's truth is whether it is
        // empty, which the subset doesn't read.
        const o = (p?.heap ?? this.initHeap).get(v.id)
        if (o?.k === 'store') return I.T
        if (o?.k === 'rec' && this.plainTruth(o.ty)) return I.T
        // (a list or a dict of the state: whether it holds an item, its least key's)
        if (o?.k === 'map' && o.origin === 'state') return p ? this.least(o, at as SX, k => this.baseCell(o.decl, k).has, () => []).some : refuse(at, `${(at as SX).text ?? ''}: the truth of a collection read with no step around it`)
        return refuse(at, `${(at as SX).text ?? ''}: the truth of ${o?.k === 'map' ? 'a dict (whether it is empty)' : 'an object whose class may define __bool__ or __len__'}`)
      }
      case 'cell': case 'fmt': case 'fn': case 'cls': case 'lock': return I.T
      case 'builtin': case 'ext': case 'lib': case 'opaque': case 'sattr': case 'tuple': case 'res': case 'ptr': case 'struct': case 'err': case 'nil': case 'map': case 'list': case 'push': case 'pop': break
    }
    return refuse(at, `${(at as SX).text ?? ''}: the truth of ${v.t === 'opaque' ? v.why : `a ${v.t}`}`)
  }
  plainTruth(ty: string): boolean {
    const r = this.mod.recs[ty]
    return !!r && !('__bool__' in r.methods) && !('__len__' in r.methods) && !r.kinds.includes('typeddict') && !r.kinds.some(k => k.startsWith('outside-base:'))
  }
  // A number, where the code reads one (a failure where it is None: Python raises a TypeError).
  numOf(v: V, at: SX, p: Path): N {
    if (v.t === 'num') return v.e
    if (v.t === 'opt') { this.fail(p, I.not(v.has), at, `${at.text ?? 'a value'} is None where a number is read (a TypeError)`); return this.numOf(v.v, at, p) }
    if (v.t === 'none') { this.fail(p, I.T, at, `${at.text ?? 'a value'} is None where a number is read (a TypeError)`); return I.num(0) }
    if (v.t === 'bool') return refuse(at, `${at.text}: a boolean read as a number`)
    return refuse(at, `${at.text ?? ''}: ${v.t === 'opaque' ? v.why : `a ${v.t} where a number is read`}`)
  }
  keyOf(v: V, at: SX): K {
    if (v.t === 'num') return {op: 'num', e: v.e}
    if (v.t === 'str') return v.e
    if (v.t === 'choice' && v.e.op === 'lit') return {op: 'slit', value: v.e.value}
    return refuse(at, `${at.text ?? ''}: a key of ${v.t === 'opaque' ? v.why : `a ${v.t}`} (a map's keys are integers or strings)`)
  }

  // --- the program ----------------------------------------------------------------------------------------------------
  func(id: string, at: {p: string}): SFunc { return this.mod.funcs[id] ?? refuse(at, `${id}: no function the reader read`) }
  // A function or a method inlined: its parameters bound, its body run, its returns joined.
  callFunc(f: SFunc, self: V | undefined, args: V[], kw: [string, V][], at: SX, p0: Path, awaited: boolean, caps?: Map<string, V>): [V, Path] {
    if (f.async && !awaited) return refuse(at, `${f.name}: a coroutine made and not awaited`)
    if (this.frames.includes(f.id)) return refuse(at, `${f.name}: a recursive call`)
    for (const d of f.decorators) {
      // (a law's decorator or annotation, @gdp_law("..."), states a law for core/laws.ts: nothing the method does)
      if (['staticmethod', 'classmethod', 'property', 'override', 'typing.override', 'abstractmethod'].includes(d.name) || (this.inf && TAG_DECO.test(d.name)) || /(?:^|\.)gdp[._]?law$/i.test(d.name)) continue
      if (this.skipped([d.name, d.text])) this.notes.add(`@${d.text} on ${f.name}: taken as transparent (skip)`)
      else if (this.inf && this.tagAt(d.p)?.k !== 'strict') this.notes.add(`@${d.text} on ${f.name}: taken as transparent (inferred: the check runs the method as decorated)`)
      else refuse(d, `@${d.text}: a decorator (one of other code changes what the method does; skip it to take it as transparent)`)
    }
    this.arm(f.body)
    const locals = new Map<string, V>()
    const ps = f.params.filter(x => !x.star)
    let i = 0, q = p0
    for (const pa of ps) {
      let v: V | undefined
      if ((pa as {cap?: boolean}).cap) v = caps?.get(pa.name) ?? refuse(at, `${f.name}: ${pa.name} not captured`)
      else if (pa.self && !f.static) v = self ?? (i < args.length ? args[i++] : refuse(at, `${f.name}: a method called without its object`))
      else if (!pa.kw && i < args.length) v = args[i++]
      else { const k = kw.find(([n]) => n === pa.name); if (k) v = k[1] }
      if (!v && pa.dflt) { const [d, q2] = this.ev(pa.dflt, q); v = d; q = q2 }
      if (!v) return refuse(at, `${f.name}(${pa.name}): an argument not given`)
      locals.set(pa.name, v)
    }
    if (i < args.length || kw.some(([n]) => !ps.some(x => x.name === n))) {
      if (f.params.some(x => x.star)) return refuse(at, `${f.name}: *args or **kwargs given`)
      return refuse(at, `${f.name}: more arguments than it takes`)
    }
    // The supported call supplies no variadic arguments (extra ones were
    // refused above). Python still binds *args and **kwargs to empty values;
    // leaving them unbound would invent an UnboundLocalError in the body.
    if (this.mod.lang === 'python') for (const pa of f.params.filter(x => x.star)) {
      locals.set(pa.name, pa.star === 1 ? {t: 'tuple', xs: []} : {t: 'val', ty: '$dict', f: new Map()})
      this.notes.add(`${f.name}: ${pa.star === 1 ? '*' : '**'}${pa.name} is empty (the modeled calls supply only the declared arguments)`)
    }
    const saved = q.locals
    this.frames.push(f.id); this.frameLocals.push(saved)
    let flow: Flow
    try { flow = this.block(f.body, {...q, locals}) } catch (e) {
      if (e instanceof Refusal && this.inf) ((e as Framed).frames ??= []).push({id: f.id, roots: [...locals].filter(([, v]) => this.stateRef(v, q)).map(([n]) => n)})
      throw e
    } finally { this.frames.pop(); this.frameLocals.pop() }
    // (a literal returned where the function declares a choice of literals, `-> Literal["a", "b"]`: the choice's)
    const rt = f.ret?.k === 'opt' ? f.ret.of : f.ret
    const asDeclared = (v: V): V => { const l = rt?.k === 'choice' && v.t === 'str' ? asChoice(v.e, rt.values) : undefined; return l ? {t: 'choice', e: l} : v }
    const rets: [Path, V][] = [...flow.rets, ...(flow.live ? [[flow.live, {t: 'none'} as V] as [Path, V]] : [])].map(([r, v]) => [r, asDeclared(v)])
    if (!rets.length) return [{t: 'none'}, {...q, pc: [...q.pc, I.F], locals: saved}]
    const joined = this.join(rets.map(([r, v]) => ({...r, locals: new Map([['$ret', v]])})), at)!, out = joined.locals.get('$ret')!
    // (other code's value left out, returned: where it is read and can't be answered, the innermost function that
    // returned it is what is cut)
    const o = out.t === 'opt' ? out.v : out
    if (this.inf && o.t === 'opaque' && o.ask && !this.returnedBy.has(o.why)) this.returnedBy.set(o.why, {id: f.id, roots: [...locals].filter(([, v]) => this.stateRef(v, q)).map(([n]) => n)})
    return [out, {...joined, locals: saved}]
  }

  // A branch arm the step runs: its first statement's line, counted by the harness's line events.
  arm(ss: SS[]) { const s0 = ss.find(x => x.s !== 'import' && !/:0:\d+$/.test(x.p)); if (s0) { const m = /^(.*):(\d+):\d+$/.exec(s0.p); if (m) this.arms.add(`${m[1]}:${m[2]}`) } }
  // --- statements -----------------------------------------------------------------------------------------------------
  block(ss: SS[], p: Path): Flow {
    let live: Path | undefined = p, ft: Path | undefined
    const rets: [Path, V][] = [], brk: Path[] = []
    for (const s of ss) {
      if (!live) break
      // (a path a failure ended inside an expression: nothing after it runs)
      if (dead(live)) { live = undefined; break }
      if (s.s === 'fallthrough') { ft = live; live = undefined; break }
      const f = this.stmt(s, live)
      rets.push(...f.rets)
      if (f.brk) brk.push(...f.brk)
      live = f.live
    }
    return {...(live ? {live} : {}), rets, ...(brk.length ? {brk} : {}), ...(ft ? {ft} : {})}
  }
  stmt(s: SS, p: Path): Flow {
    switch (s.s) {
      case 'expr': { const [, q] = this.ev(s.x as SX, p); return {live: q, rets: []} }
      case 'set': {
        // A local the subset can't compute, from an expression with no calls (nothing it could change): kept as a value
        // refused wherever the rule would read it.
        let r: [V, Path]
        try { r = this.ev(s.x as SX, p) } catch (e) { if (!(e instanceof Refusal) || (s.to as SX).e !== 'var' || !callFree(s.x as SX)) throw e; r = [{t: 'opaque', why: `${e.where}: ${e.what}`}, p] }
        return {live: this.assign(s.to as SX, r[0], s, r[1], s.t as SType | undefined), rets: []}
      }
      case 'if': {
        const sc = s.c as SX, both = !s.strict && (sc.e === 'and' || sc.e === 'or')
        const [cv, q] = both ? [undefined, p] : this.ev(sc, p)
        const [c0, q0] = both ? this.truth(sc, p) : [undefined, q]
        const c = c0 ?? (s.strict ? (cv!.t === 'bool' ? cv!.e : refuse({p: s.cp as string}, s.strict as string)) : this.truthy(cv!, sc, q))
        if (!(c.op === 'const' && !c.v)) this.arm(s.then as SS[])
        if (!(c.op === 'const' && c.v)) this.arm(s.else as SS[])
        const t = c.op === 'const' && !c.v ? undefined : this.block(s.then as SS[], this.assume(q0, c))
        const e = c.op === 'const' && c.v ? undefined : this.block(s.else as SS[], this.assume(q0, I.not(c)))
        const lives = [t?.live, e?.live].filter((x): x is Path => !!x)
        const live = this.join(lives, s), brk = [...(t?.brk ?? []), ...(e?.brk ?? [])]
        return {...(live ? {live} : {}), rets: [...(t?.rets ?? []), ...(e?.rets ?? [])], ...(brk.length ? {brk} : {})}
      }
      case 'ret': {
        if (s.xs || s.one || s.bare) {
          // (Go's: each result, one call's several, or the named results)
          let vs: V[] = [], q = p
          if (s.one) { const [v, q2] = this.ev(s.one as SX, q); if (v.t !== 'tuple') return refuse(s, String(s.why)); vs = v.xs; q = q2 }
          else if (s.bare) for (const id of s.bare as (string | null)[]) vs.push((id ? q.locals.get(id) : undefined) ?? refuse(s, 'a bare return of an unnamed result'))
          else for (const e of s.xs as SX[]) { const [v, q2] = this.ev(e, q); vs.push(v); q = q2 }
          return {rets: [[q, {t: 'tuple', xs: vs}]]}
        }
        if (!s.x) return {rets: [[p, {t: 'none'}]]}
        const [v, q] = this.ev(s.x as SX, p)
        return {rets: [[q, v]]}
      }
      case 'fail': {
        // (a class raised, with its bases; a bare re-raise, what its handler caught: one outer handler for all of it)
        let k: Kind = s.cls ? {mro: s.cls as string[], ...(s.open ? {open: true} : {})} : this.kindOf(String(s.why), s)
        if (s.reraise && this.tries.length) {
          const ks = this.handling.at(-1) ?? refuse(s, 'a bare raise outside a handler'), hs = ks.map(x => this.catcher(x, s))
          if (hs.some(h => h?.[0] !== hs[0]?.[0] || h?.[1] !== hs[0]?.[1])) refuse(s, 'a re-raise of exceptions outer handlers tell apart')
          k = ks[0]
        }
        // (inside a try, the exception's arguments are evaluated first: a failure there is raised instead)
        let q = p
        const x = s.x as SX | undefined
        if (this.tries.length && x?.e === 'call' && !s.reraise) for (const a of [...(x.args as SX[]), ...(x.kw as [string, SX][]).map(([, y]) => y)]) q = this.ev(a, q)[1]
        this.fail(q, I.T, s, String(s.why), k); return {rets: []}
      }
      case 'try': return this.tryStmt(s, p)
      case 'yield': {
        // (where a @contextmanager generator yields: the with's body, run in the frame of the with)
        const w = this.withBodies.at(-1)
        if (!w) return refuse(s, 'a yield (a generator, read only as a @contextmanager\'s)')
        this.withBodies.pop()
        let flow: Flow
        this.frameLocals.push(p.locals)
        try { flow = this.block(w.body, {...p, locals: w.locals}) } finally { this.withBodies.push(w); this.frameLocals.pop() }
        if (!flow.live) return {rets: []}
        return {live: {...flow.live, locals: p.locals, heap: new Map(flow.live.heap).set('$yielded', {k: 'rec', ty: '$yielded', f: new Map([['n', {t: 'bool', e: I.T}]]), origin: 'fresh'})}, rets: []}
      }
      case 'with': {
        const cm = this.generatorCM(s, p)
        if (cm) return cm
        // (a context manager of other code, taken as transparent: a raise inside it may be suppressed by it, so none
        // goes through it to a handler around it)
        let q = p, other = false
        for (const it of s.items as {x: SX, as?: SX}[]) {
          if (it.as) refuse(s, 'with ... as (a context manager\'s value)')
          if (it.x.e === 'call' && this.skipped(this.calleeNames(it.x))) { this.notes.add(`with ${it.x.text} (${it.x.p}): a context manager taken as transparent (skip)`); other = true; continue }
          const [v, q2] = this.ev(it.x, q)
          q = q2
          if (v.t === 'opaque' && v.ask) { this.notes.add(`with ${it.x.text} (${it.x.p}): a context manager of other code taken as transparent (inferred: the check runs it)`); other = true; continue }
          if (v.t !== 'lock') refuse(it.x, `with ${it.x.text}: a context manager (the subset reads a lock's, which makes the step atomic)`)
          this.notes.add(`${this.method}: the lock held (${it.x.p}): the step is atomic`)
        }
        if (!other) return this.block(s.body as SS[], q)
        this.cms.push(this.tries.length)
        try { return this.block(s.body as SS[], q) } finally { this.cms.pop() }
      }
      case 'del': {
        const t = s.x as SX
        if (t.e !== 'idx') return refuse(s, `del ${t.text}: of other than a dict's item`)
        const [m, q] = this.ev(t.x as SX, p), [k, q2] = this.ev(t.i as SX, q)
        return {live: this.mapDel(m, this.keyOf(k, t), t, q2, true), rets: []}
      }
      case 'import': {
        const locals = new Map(p.locals)
        for (const [n, x] of Object.entries(s.names as Record<string, {mod: string, name?: string, ret?: SType}>)) locals.set(n, {t: 'ext', q: x.name ? `${x.mod}.${x.name}` : x.mod, text: n, patch: {mod: x.mod, ...(x.name ? {path: [x.name]} : {})}, ...(x.ret ? {ret: x.ret} : {})})
        return {live: {...p, locals}, rets: []}
      }
      case 'no': return refuse(s, String(s.why))
      case 'panic': { let q = p; for (const a of s.args as SX[]) q = this.ev(a, q)[1]; this.refuseWhere(q, I.T, s, (s.what as string | undefined) ?? 'a panic'); return {rets: []} }
      case 'incdec': {
        const [pl, q] = this.place(s.to as SX, p), [v, q2] = this.read(pl, s, q)
        if (v.t !== 'num') return refuse(s, `${s.op as string} of a ${v.t}`)
        return {live: this.write(pl, this.arith(s.op === '++' ? '+' : '-', v, {t: 'num', e: I.num(1), ty: v.ty}, s, q2), s, q2), rets: []}
      }
      case 'opset': { const [pl, q] = this.place(s.to as SX, p), [x, q2] = this.read(pl, s, q), [y, q3] = this.ev(s.y as SX, q2); return {live: this.write(pl, this.binop(String(s.op), x, y, s, q3), s, q3), rets: []} }
      case 'mopset': { const at = s.at as SX, [m, q] = this.ev(at.m as SX, p), [k, q2] = this.ev(at.k as SX, q), cell = this.mapRead(m, k, at, q2), [y, q3] = this.ev(s.y as SX, q2); return {live: this.mapWrite(m, k, this.binop(String(s.op), cell.v, y, s, q3), at, q3), rets: []} }
      case 'assign': return {live: this.assignGo(s, p), rets: []}
      case 'switch': return this.switchGo(s, p)
      case 'break': return {rets: [], brk: [p]}
      case 'continue': return {rets: [], brk: [{...p, cont: true}]}
      case 'for': return this.forStmt(s, p)
      case 'while': return this.whileStmt(s, p)
      case 'defer': { const key = this.lockKey(s.pl as SX, p); if (!p.locks.includes(key)) refuse(s, `defer ${s.text as string} without its Lock first`); return {live: {...p, defers: [...p.defers, key]}, rets: []} }
    }
    return refuse(s, `a statement the subset doesn't read (${s.s})`)
  }
  // An assignment: to a local, to a field of an object, to a dict's item, or to a tuple of those.
  assign(to: SX, v: V, at: {p: string}, p: Path, t?: SType): Path {
    if (to.e === 'lock' || to.e === 'ref') return this.assign(to.x as SX, v, at, p, t)
    switch (to.e) {
      case 'var': {
        let x = v
        if (t && x.t === 'str' && t.k === 'choice' && x.e.op === 'slit') x = {t: 'choice', e: I.llit(x.e.value, t.values)}
        if (t && x.t === 'opaque' && this.scalar(t) === undefined) {} // (kept opaque)
        if (this.init && (to.n === 'self')) refuse(at, 'self rebound')
        return {...p, locals: new Map(p.locals).set(String(to.n), x)}
      }
      case 'tuple': {
        const xs = to.xs as SX[]
        if (v.t === 'opaque' && xs.every(y => y.e === 'var')) { let q = p; for (const y of xs) q = this.assign(y, v, at, q); return q }
        if (v.t !== 'tuple' || v.xs.length !== xs.length) return refuse(at, `${xs.length} names given ${v.t === 'tuple' ? `${v.xs.length} values` : `a ${v.t === 'opaque' ? v.why : v.t}`}`)
        let q = p
        xs.forEach((x, i) => { q = this.assign(x, v.xs[i]!, at, q) })
        return q
      }
      case 'get': {
        const [o, q] = this.ev(to.x as SX, p)
        return this.setField(o, String(to.f), v, to, q, t)
      }
      case 'idx': {
        const [m, q] = this.ev(to.x as SX, p), [k, q2] = this.ev(to.i as SX, q)
        if (m.t === 'val') {
          // (a record by value held in a local, or in one of its fields: the local made anew; a dict's key added)
          const ks = strLit(k)
          if (m.ty !== '$dict' || ks === undefined) return refuse(at, `${to.text}: a key set in ${m.ty === '$dict' ? 'a dict by a key not known here' : 'a value that is no dict'}`)
          if (!deep(to.x, o => o.e !== 'var' && o.e !== 'idx' && o.e !== 'str' && o.e !== 'get')) return this.assign(to.x as SX, {...m, f: new Map(m.f).set(ks, v)}, at, q2, undefined)
          return refuse(at, `${to.text}: a key set in a dict reached through a call`)
        }
        return this.mapSet(m, this.keyOf(k, to.i as SX), v, to, q2)
      }
    }
    return refuse(at, `${to.text ?? to.e}: ${to.e === 'no' ? String(to.why) : 'an assignment the subset doesn\'t read'}`)
  }
  setField(o: V, f: string, v: V, at: SX, p: Path, t?: SType): Path {
    if (o.t === 'opt') { this.fail(p, I.not(o.has), at, `${at.text}: a field of None set (an AttributeError)`); return this.setField(o.v, f, v, at, this.assume(p, o.has), t) }
    if (o.t === 'cell') {
      const m = p.heap.get(o.map) as Extract<Obj, {k: 'map'}>
      const vals = this.cellOf(m, o.key, p, at)
      if (!vals.vals.has(f)) return refuse(at, `${at.text}: no field ${f} in the map's records`)
      return this.writeCell(o.map, m, o.key, vals.has, new Map(vals.vals).set(f, this.fit(v, m.decl.fields.find(x => x.name === f)!, at)), at, p)
    }
    if (o.t !== 'ref') return refuse(at, `${at.text}: a field set on ${o.t === 'opaque' ? o.why : `a ${o.t}`}`)
    const obj = p.heap.get(o.id)
    if (obj?.k !== 'rec') return refuse(at, `${at.text}: a field set on other than an object`)
    if (obj.origin === 'input') return refuse(at, `${at.text}: writes an object the caller gave (the caller's, not the state)`)
    if (obj.moved) return refuse(at, `${at.text}: writes an object already put in a map (one object in two places)`)
    if (obj.origin === 'state' && !this.init && !obj.f.has(f)) return refuse(at, `${at.text}: a field the constructor doesn't set (the state's fields are the constructor's)`)
    const fieldType = this.mod.recs[obj.ty]?.fields.find(x => x.name === f)?.t
    v = this.timeField(v, fieldType, false, at)
    const old = obj.f.get(f)
    if (old?.t === 'opaque' && obj.origin === 'state' && !this.init) return refuse(at, `${at.text}: writes ${old.why}`)
    if (o.id === 'this' && this.frozen.has(f) && !this.init) return refuse(at, `${at.text}: writes a field the constructor sets to a constant (None of no type the code states, or other code's function)`)
    if (this.init && t) this.declared.set(`${o.id}.${f}`, t)
    // (a literal written to a field of a choice is the choice's)
    const ft = this.declared.get(`${o.id}.${f}`) ?? this.mod.recs[obj.ty]?.fields.find(x => x.name === f)?.t, ct = ft?.k === 'opt' ? ft.of : ft
    if (ct?.k === 'choice' && v.t === 'str') { const l = asChoice(v.e, ct.values); if (l) v = {t: 'choice', e: l} }
    const heap = new Map(p.heap).set(o.id, {...obj, f: new Map(obj.f).set(f, v)})
    return {...p, heap}
  }
  declared = new Map<string, SType>()
  // A value as a cell's field holds it (a string literal of a choice field as the choice).
  fit(v: V, f: Var, at: SX): V {
    if (f.sort.k === 'choice' && v.t === 'str' && v.e.op === 'slit') { if (!f.sort.values.includes(v.e.value)) refuse(at, `${JSON.stringify(v.e.value)} is not one of ${f.name}'s literals`); return {t: 'choice', e: I.llit(v.e.value, f.sort.values)} }
    // (a string that is a literal of the choice on every path)
    if (f.sort.k === 'choice' && v.t === 'str') { const l = asChoice(v.e, f.sort.values); if (l) return {t: 'choice', e: l} }
    if (f.sort.k === 'choice' && v.t !== 'choice') return refuse(at, `${at.text}: a ${v.t === 'opaque' ? v.why : v.t} set where one of ${f.sort.values.map(x => JSON.stringify(x)).join(', ')} is held`)
    if (f.sort.k === 'num' && v.t !== 'num') return refuse(at, `${at.text}: a ${v.t === 'opaque' ? v.why : v.t} set where a number is held`)
    if (f.sort.k === 'bool' && v.t !== 'bool') return refuse(at, `${at.text}: a ${v.t === 'opaque' ? v.why : v.t} set where a boolean is held`)
    return v
  }

  // --- maps -----------------------------------------------------------------------------------------------------------
  mapObj(m: V, at: SX, p: Path): [string, Extract<Obj, {k: 'map'}>] {
    if (m.t !== 'ref') return refuse(at, `${at.text}: an item of ${m.t === 'opaque' ? m.why : `a ${m.t}`}`)
    const o = p.heap.get(m.id)
    if (o?.k !== 'map') return refuse(at, `${at.text}: an item of other than a dict`)
    if (o.origin === 'input') return refuse(at, `${at.text}: a dict the caller gave`)
    return [m.id, o]
  }
  cellOf(o: Extract<Obj, {k: 'map'}>, key: K, _p: Path, _at: SX): {has: B, vals: Map<string, V>} {
    keyKind(o.decl, key, _at)
    let acc = this.baseCell(o.decl, key)
    // (an order read over the state before the step; in a while loop's pass, the collection only at the pass's key)
    if (this.drainSetup) return acc
    const rd = this.drain?.rank?.get(o.decl.name)
    if (rd && o.origin === 'state') { if (I.same(key, rd.K)) acc = {has: rd.exists, vals: rd.view}; else return refuse(_at, `${_at.text}: an item of ${o.decl.name} other than the first a pass of the loop takes (the subset reads a loop over the state as its passes' first items)`) }
    if (this.drain?.map?.name === o.decl.name && o.origin === 'state' && !this.drain.empty && !I.same(key, {op: 'num', e: this.drain.i})) return refuse(_at, `${_at.text}: an item of ${o.decl.name} other than the one a pass of the loop takes (the subset reads a loop over the state as its passes over a collection's items, each taking its own)`)
    if (o.ew) { const x = (key as {e?: N}).e ?? refuse(_at, `${_at.text}: a key of other than a number`), sub = (v: V): V => substV(v, 'k$', x); acc = {has: I.substN(o.ew.has, 'k$', x), vals: new Map([...o.ew.vals].map(([f, v]) => [f, sub(v)]))} }
    for (const w of [...(o.pre ?? []), ...(o.w ? [o.w] : [])]) { const same = I.keq(key, w.key), a = acc; acc = {has: I.bite(same, w.has, a.has), vals: new Map([...a.vals].map(([f, v]) => [f, this.ite(same, w.vals.get(f)!, v, _at)]))} }
    return acc
  }
  // A cell written: a second key of a scalar map keyed by numbers (a transfer's two accounts) after the first, any
  // earlier write of the same key dropped (this one is read through it).
  writeCell(id: string, o: Extract<Obj, {k: 'map'}>, key: K, has: B, vals: Map<string, V>, at: SX, p: Path): Path {
    keyKind(o.decl, key, at)
    if (o.w && !I.same(o.w.key, key)) {
      if (!o.decl.scalar || o.decl.key !== 'num') return refuse(at, `${at.text}: a second key of one map written in one step (the subset writes one a step, or several of a map of numbers or booleans keyed by numbers)`)
      return {...p, heap: new Map(p.heap).set(id, {...o, pre: [...(o.pre ?? []).filter(x => !I.same(x.key, key)), o.w], w: {key, has, vals}})}
    }
    return {...p, heap: new Map(p.heap).set(id, {...o, w: {key, has, vals}})}
  }
  mapGet(m: V, k: K, at: SX, p: Path, missing: 'fail' | 'none' | V): [V, Path] {
    const [id, o] = this.mapObj(m, at, p)
    void id
    const c = this.cellOf(o, k, p, at)
    const value = (): V => (o.decl.scalar ? c.vals.get('value')! : {t: 'cell', map: id, key: k})
    if (missing === 'fail') { this.fail(p, I.not(c.has), at, `${at.text}: a key the dict doesn't hold (a KeyError)`); return [value(), this.assume(p, c.has)] }
    if (missing === 'none') return [o.decl.scalar ? {t: 'opt', has: c.has, v: value()} : {t: 'opt', has: c.has, v: value()}, p]
    return [this.ite(c.has, value(), missing, at), p]
  }
  mapSet(m: V, k: K, v: V, at: SX, p: Path): Path {
    const [id, o] = this.mapObj(m, at, p)
    // (nz: a cell is held where it isn't zero, Solidity's mapping: a zero written is no cell)
    if (o.decl.scalar) { const x = this.fit(v, o.decl.fields[0]!, at); return this.writeCell(id, o, k, !at.nz ? I.T : x.t === 'num' ? I.not(I.cmp('=', x.e, I.num(0))) : x.t === 'bool' ? x.e : refuse(at, `${at.text}: a zero of a ${x.t}`), new Map([['value', x]]), at, p) }
    // A record put in: a fresh one (made here), its fields copied into the cell, the object no longer written apart.
    if (v.t === 'cell' && v.map === id && I.same(v.key, k)) return p
    if (v.t !== 'ref') return refuse(at, `${at.text}: a ${v.t === 'opaque' ? v.why : v.t} put in a dict of records`)
    const r = p.heap.get(v.id)
    if (r?.k !== 'rec' || r.origin !== 'fresh') return refuse(at, `${at.text}: an object put in a dict that isn't made here (one object in two places)`)
    const vals = new Map<string, V>()
    for (const f of o.decl.fields) vals.set(f.name, this.fit(r.f.get(f.name) ?? refuse(at, `${at.text}: the record has no ${f.name}`), f, at))
    const q = this.writeCell(id, o, k, I.T, vals, at, p)
    return {...q, heap: new Map(q.heap).set(v.id, {...r, moved: true})}
  }
  mapDel(m: V, k: K, at: SX, p: Path, strict: boolean): Path {
    const [id, o] = this.mapObj(m, at, p), c = this.cellOf(o, k, p, at)
    if (strict) this.fail(p, I.not(c.has), at, `${at.text}: a key the dict doesn't hold deleted (a KeyError)`)
    return this.writeCell(id, o, k, I.F, new Map([...c.vals].map(([f, v]) => [f, (v.t === 'num' ? {t: 'num', e: I.num(0)} : v.t === 'bool' ? {t: 'bool', e: I.F} : v.t === 'choice' ? {t: 'choice', e: I.llit(lvalues(v.e)[0]!, lvalues(v.e))} : o.decl.fields.find(x => x.name === f)?.sort.k === 'str' ? {t: 'str', e: {op: 'slit', value: ''}} : v) as V])), at, strict ? this.assume(p, c.has) : p)
  }
  mapDeclOf(name: string, t: SType, at: {p: string}): MapDecl {
    if (t.k !== 'map') return refuse(at, `${name}: ${this.why(t)}`)
    const key = t.key.k === 'int' ? 'num' : t.key.k === 'str' ? 'str' : refuse(at, `${name}: a dict keyed by ${this.why(t.key)} (keys are integers or strings)`)
    const cell = (n: string, ft: SType): Var => { const s = this.scalar(ft); if (!s || (s.k === 'str' && !(t as {sv?: boolean}).sv)) return refuse(at, `${name}: a dict of ${s?.k === 'str' ? 'strings' : this.why(ft)} (a cell holds integers, booleans and literals)`); return {name: n, sort: s, role: 'state'} }
    let fields: Var[], scalar = true
    // (a record's string field the module only ever sets to literals: a choice of them, said in the notes)
    const lits = (r: SRec, f: {name: string, t: SType}): SType => {
      if (f.t.k !== 'str') return f.t
      const vs = this.literalsOf(r, f.name)
      if (!vs) return f.t
      this.notes.add(`${r.short}.${f.name}: a string the module only sets to ${vs.map(x => JSON.stringify(x)).join(' or ')} (read as a choice of those)`)
      return {k: 'choice', values: vs}
    }
    // (a set: its keys alone, a cell held or not, as the TypeScript front end's Set)
    if (t.set) { fields = []; scalar = false }
    else if (t.val.k === 'rec') { const r = this.rec(t.val.name, at); fields = r.fields.map(f => cell(f.name, lits(r, f))); scalar = false }
    else fields = [cell('value', t.val)]
    const v = this.newVar(name, {k: 'num'}, 'state')
    const d: MapDecl = {name: v.name, key, fields, scalar, js: t.set ? 'Set' : 'Map'}
    this.maps.push(d)
    return d
  }

  // The literals a record's field is made with, where every construction of it in the module gives one (its default
  // too); undefined where one gives another value, or none is made.
  literalsOf(r: SRec, field: string): string[] | undefined {
    const i = r.fields.findIndex(f => f.name === field), out = new Set<string>()
    let ok = true, made = 0
    const lit = (x: SX | undefined) => { if (x?.e === 'str') out.add(String(x.v)); else ok = false }
    const visit = (o: unknown): void => {
      if (!ok || !o || typeof o !== 'object') return
      if (Array.isArray(o)) { o.forEach(visit); return }
      const x = o as SX
      if (x.e === 'call' && (x.f as SX | undefined)?.e === 'cls' && (x.f as SX).rec === Object.keys(this.mod.recs).find(k => this.mod.recs[k] === r)) {
        made++
        const args = x.args as SX[], kw = x.kw as [string, SX][]
        lit(i < args.length ? args[i] : kw.find(([n]) => n === field)?.[1] ?? r.fields[i]!.dflt)
      }
      for (const v of Object.values(o)) visit(v)
    }
    visit(this.mod.funcs)
    return ok && made && out.size ? [...out].sort() : undefined
  }
  // --- ordered collections (core/dsl.ts's least) -----------------------------------------------------------------------
  // The least key of a map of the state where `where` holds, least by `by` and then by the key itself (a list's order:
  // the first of those that tie), as the rule's least key (Model.leasts): the rule's runtimes find it in the state
  // before the step, so one read after the step wrote the map is refused. Each least read once, however often.
  // (`held`: whether there is one, with `where` at its key, which it implies: what a path that takes it knows)
  least(o: Extract<Obj, {k: 'map'}>, at: SX, where: (k: K) => B, by: (k: K) => {e: N, desc?: boolean}[]): {key: N, some: B, held: B, where: (k: K) => B} {
    // (in a while loop's pass, a collection of the state it takes first items of: the pass's item)
    if (this.drain && o.origin === 'state' && (o.decl.ordered || o.decl.key === 'num') && !this.drainSetup) return this.drainLeast(o, at, where, by)
    if (o.w || o.ew) return refuse(at, `${at.text}: the first, last, least or greatest item of a collection the step has written (the rule reads it in the state before the step)`)
    const kk: K = {op: 'num', e: I.nvar(LEAST_KEY)}, w = where(kk), b = [...by(kk), {e: I.nvar(LEAST_KEY)}], sig = I.keyOf({map: o.decl.name, w, b})
    let l = this.leasts.find(x => I.keyOf({map: x.map, w: x.where, b: x.by}) === sig)
    if (!l) {
      let name = `${o.decl.name}_least${this.leasts.length + 1}`
      while (this.vars.has(name)) name = `${name}_`
      // (whether there is one is the same for every order over the same keys: one condition, so a path that took one
      // knows the others)
      const same = this.leasts.find(x => x.map === o.decl.name && I.keyOf(x.where) === I.keyOf(w))
      l = {name, some: same?.some ?? `${name}$some`, map: o.decl.name, key: LEAST_KEY, where: w, by: b}
      this.leasts.push(l)
    }
    const key = I.nvar(l.name), some = I.bvar(l.some)
    return {key, some, held: I.and(some, where({op: 'num', e: key})), where}
  }
  // Whether the path already takes c: each of its conjuncts one of the path's conditions (or decided). A failure
  // where c doesn't hold then never happens there (a least key's item is held where the path took it).
  holds(p: Path, c: B): boolean {
    if (c.op === 'not' && c.x.op === 'and') return c.x.xs.some(x => this.holds(p, I.not(x)))
    if (c.op === 'or') return c.xs.some(x => this.holds(p, x))
    const have = new Set(p.pc.flatMap(x => (x.op === 'and' ? x.xs : [x])).map(I.keyOf))
    const parts = (x: B): B[] => (x.op === 'and' ? x.xs.flatMap(parts) : x.op === 'not' && x.x.op === 'or' ? x.x.xs.map(I.not).flatMap(parts) : [x])
    return parts(c).every(x => (x.op === 'const' && x.v) || have.has(I.keyOf(x)))
  }
  orderedObj(m: V, p: Path): [string, Extract<Obj, {k: 'map'}>] | undefined {
    const o = m.t === 'ref' ? p.heap.get(m.id) : undefined
    return o?.k === 'map' && o.decl.ordered && o.origin === 'state' ? [(m as {id: string}).id, o] : undefined
  }
  // A list of the state's item at its first or last place (xs[0], xs[-1], xs.pop(0), max(xs) and the like): the cell,
  // and whether there is one.
  item(id: string, o: Extract<Obj, {k: 'map'}>, at: SX, last: boolean, by: (k: K) => {e: N, desc?: boolean}[] = () => []): {key: K, some: B, held: B, v: V} {
    const l = this.least(o, at, k => this.baseCell(o.decl, k).has, k => [...by(k), ...(last ? [{e: (k as {e: N}).e, desc: true}] : [])])
    const key: K = {op: 'num', e: l.key}
    return {key, some: l.some, held: l.held, v: o.decl.scalar ? this.cellOf(o, key, undefined as never, at).vals.get('value')! : {t: 'cell', map: id, key}}
  }
  // A list of the state's methods: append (at a place past every item), remove (the first item equal to the value),
  // pop (the last, or the first), each a write of one place.
  listCall(id: string, o0: Extract<Obj, {k: 'map'}>, name: string, x: SX, p: Path): [V, Path] {
    let o = o0
    return this.evArgs(x, p, (args, kw, q) => {
      const m: V = {t: 'ref', id}
      // (the list as evaluating the arguments left it: a write there is one the least keys see, and refuse)
      o = q.heap.get(id) as Extract<Obj, {k: 'map'}>
      if (kw.length) return refuse(x, `${x.text}: a list's method given keywords`)
      if (this.drain && o.decl.ordered) {
        // (in a while loop's pass: the collection it takes items of only gives its item up)
        if (name === 'append') return refuse(x, `${x.text}: an item put in ${o.decl.name} in a pass of a loop`)
        const rr = o.decl.scalar ? undefined : this.recOf(o.decl, x)
        if (name === 'remove' && rr && (!rr.kinds.includes('dataclass') || rr.kinds.includes('eq-identity') || rr.methods.__eq__)) return refuse(x, `${x.text}: a list's remove of ${rr.short}, whose equality isn't its fields' (a dataclass's)`)
        const rd = this.drain.rank?.get(o.decl.name)
        if (name === 'remove' && rd && args.length === 1 && args[0]!.t === 'cell' && args[0]!.map === id && I.same(args[0]!.key, rd.K)) return [{t: 'none'}, this.listDel(id, o, rd.K, x, this.assume(q, rd.exists))]
        if (name === 'remove' && this.drain.map?.name === o.decl.name && args.length === 1 && args[0]!.t === 'cell' && args[0]!.map === id && I.same(args[0]!.key, {op: 'num', e: this.drain.i})) return [{t: 'none'}, this.listDel(id, o, args[0]!.key, x, q)]
        if (name === 'remove') return refuse(x, `${x.text}: an item of ${o.decl.name} other than the one a pass of a loop takes, taken out`)
      }
      if (name === 'append' && args.length === 1) {
        const last = this.least(o, x, k => this.baseCell(o.decl, k).has, k => [{e: (k as {e: N}).e, desc: true}])
        return [{t: 'none'}, this.mapSet(m, {op: 'num', e: I.nite(last.some, I.add(last.key, I.num(1)), I.num(0))}, args[0]!, x, q)]
      }
      if (name === 'remove' && args.length === 1) {
        const r = o.decl.scalar ? undefined : this.recOf(o.decl, x)
        if (r && (!r.kinds.includes('dataclass') || r.kinds.includes('eq-identity') || r.methods.__eq__)) return refuse(x, `${x.text}: a list's remove of ${r.short}, whose equality isn't its fields' (a dataclass's)`)
        const v = args[0]!, field = (f: string): V => (o.decl.scalar ? v : this.fieldOf(v, f, x, q))
        const hit = this.least(o, x, k => { const c = this.cellOf(o, k, q, x); return I.and(c.has, ...o.decl.fields.map(f => this.equal(c.vals.get(f.name)!, field(f.name), x, q))) }, () => [])
        // (an item of this list itself: none equal to it only where it isn't held either)
        // (an item of this list itself, at a least key the path took: equal to itself, so never missing)
        const own = v.t === 'cell' && v.map === id ? this.leasts.find(l => l.map === o.decl.name && v.key.op === 'num' && v.key.e.op === 'var' && v.key.e.name === l.name) : undefined
        const none = I.and(I.not(hit.some), ...(v.t === 'cell' && v.map === id ? [I.not(this.baseCell(o.decl, v.key).has)] : []))
        if (!this.holds(q, I.not(none)) && !(own && this.holds(q, I.bvar(own.some)))) this.fail(q, none, x, `${x.text}: no item equal to it (a ValueError)`)
        return [{t: 'none'}, this.listDel(id, o, {op: 'num', e: hit.key}, x, this.assume(q, hit.held))]
      }
      if (name === 'pop' && args.length <= 1) {
        const i = args[0] ? constOf(args[0]) : -1
        if (i !== 0 && i !== -1) return refuse(x, `${x.text}: a list's pop at a place other than the first or the last`)
        const it = this.item(id, o, x, i === -1)
        if (!this.holds(q, it.some)) this.fail(q, I.not(it.some), x, `${x.text}: pop from an empty list (an IndexError)`)
        return [it.v, this.listDel(id, o, it.key, x, this.assume(q, it.held))]
      }
      return refuse(x, `${x.text}: list.${name} (the subset reads append, remove, pop() and pop(0), xs[0] and xs[-1], min and max with a key, and whether it is empty)`)
    })
  }
  // An item taken out of a list: its place no longer held, its fields kept (a value read from it before is still the
  // object the code holds; a place past every item is where the next one goes).
  listDel(id: string, o: Extract<Obj, {k: 'map'}>, key: K, at: SX, p: Path): Path {
    const c = this.cellOf(o, key, p, at)
    return this.writeCell(id, o, key, I.F, c.vals, at, p)
  }
  recOf(d: MapDecl, at: SX): SRec {
    const id = [...this.initHeap].find(([, x]) => x.k === 'map' && x.decl === d)?.[1] as Extract<Obj, {k: 'map'}> | undefined
    const t = id?.val
    return t?.k === 'rec' ? this.rec(t.name, at) : refuse(at, `${at.text}: a list of other than records`)
  }
  // A field of a record value: a cell's, a fresh record's.
  fieldOf(v: V, f: string, at: SX, p: Path): V {
    if (v.t === 'cell') { const o = p.heap.get(v.map); if (o?.k === 'map') return this.cellOf(o, v.key, p, at).vals.get(f) ?? refuse(at, `${at.text}: no field ${f}`) }
    if (v.t === 'ref') { const o = p.heap.get(v.id); if (o?.k === 'rec') return o.f.get(f) ?? refuse(at, `${at.text}: no field ${f}`) }
    return refuse(at, `${at.text}: a ${v.t === 'opaque' ? v.why : v.t} compared with a list's items`)
  }
  // min or max of a list of the state (by a key function over its items, of one argument), or of a dict's keys.
  minMax(n: 'min' | 'max', x: SX, p: Path): [V, Path] | undefined {
    const args = x.args as SX[], kw = x.kw as [string, SX][]
    if (args.length !== 1 || kw.some(([k]) => k !== 'key' && k !== 'default')) return undefined
    const [m, q] = this.ev(args[0]!, p), ord = this.orderedObj(m, q)
    const dict = !ord && m.t === 'ref' ? q.heap.get(m.id) : undefined
    if (!ord && !(dict?.k === 'map' && dict.origin === 'state' && dict.decl.key === 'num')) return undefined
    const keyFn = kw.find(([k]) => k === 'key')?.[1], dflt = kw.find(([k]) => k === 'default')?.[1]
    let q2 = q, d: V | undefined
    if (dflt) { [d, q2] = this.ev(dflt, q2) }
    // (the collection as evaluating the default left it: a write there refuses the least key)
    const now = m.t === 'ref' ? q2.heap.get(m.id) : undefined
    const desc = n === 'max'
    const partsOf = (v: V, at: SX): N[] => (v.t === 'tuple' ? v.xs.flatMap(y => partsOf(y, at)) : v.t === 'num' ? [v.e] : refuse(at, `${at.text}: a key of ${v.t === 'opaque' ? v.why : `a ${v.t}`} (the subset orders by numbers and tuples of them)`))
    // (a part negated: the part itself, ordered the other way)
    const signed = (e: N, d: boolean): {e: N, desc?: boolean} => (e.op === 'neg' ? signed(e.a, !d) : e.op === 'mulk' && e.k === -1 ? signed(e.a, !d) : {e, ...(d ? {desc: true} : {})})
    if (dict) {
      // (min(d), max(d): the least or greatest key the dict holds)
      if (keyFn) return refuse(x, `${x.text}: ${n} of a dict's keys by a key function`)
      const o = now as Extract<Obj, {k: 'map'}>, l = this.least(o, x, k => this.baseCell(o.decl, k).has, k => [{e: (k as {e: N}).e, desc}])
      return this.emptyOr(n, {t: 'num', e: l.key}, l, d, x, q2)
    }
    const [id] = ord!, o = now as Extract<Obj, {k: 'map'}>
    let by: (k: K) => {e: N, desc?: boolean}[]
    if (keyFn) {
      if (keyFn.e !== 'lambda') return refuse(x, `${x.text}: ${n}'s key other than a lambda of one argument`)
      const param = (keyFn.params as string[])[0]!
      by = k => { const [v] = this.ev(keyFn.x as SX, {...q2, locals: new Map(q2.locals).set(param, o.decl.scalar ? this.cellOf(o, k, q2, x).vals.get('value')! : {t: 'cell', map: id, key: k})}); return partsOf(v, keyFn.x as SX).map(e => signed(e, desc)) }
    } else if (o.decl.scalar) by = k => [{e: (this.cellOf(o, k, q2, x).vals.get('value') as {e: N}).e, desc}]
    else return refuse(x, `${x.text}: ${n} of records with no key (a TypeError: records aren't ordered)`)
    const l = this.least(o, x, k => this.baseCell(o.decl, k).has, by), key: K = {op: 'num', e: l.key}
    return this.emptyOr(n, o.decl.scalar ? this.cellOf(o, key, q2, x).vals.get('value')! : {t: 'cell', map: id, key}, l, d, x, q2)
  }
  emptyOr(n: string, v: V, l: {some: B, held: B}, d: V | undefined, x: SX, p: Path): [V, Path] {
    if (d) return [d.t === 'none' ? {t: 'opt', has: l.held, v} : this.ite(l.held, v, d, x), p]
    if (!this.holds(p, l.some)) this.fail(p, I.not(l.some), x, `${x.text}: ${n}() of an empty collection (a ValueError)`)
    return [v, this.assume(p, l.held)]
  }

  timeField(v: V, t: SType | undefined, read: boolean, at: {p: string, text?: string}): V {
    const inner = t?.k === 'opt' ? t.of : t
    if (inner?.k !== 'int' || !inner.unit?.startsWith('datetime-')) return v
    if (inner.unit === 'datetime-naive') { this.naiveUtc = true; this.notes.add('naive datetime values require a UTC process timezone') }
    if (v.t === 'opt') return {...v, v: this.timeField(v.v, inner, read, at)}
    if (v.t === 'none') return v
    const utc = inner.unit === 'datetime-utc' ? I.T : I.F
    if (read && v.t === 'num') return {t: 'val', ty: '$dt', f: new Map<string, V>([['ms', v], ['utc', {t: 'bool', e: utc}]])}
    if (v.t === 'val' && v.ty === '$dt' && I.same((v.f.get('utc') as {e?: B} | undefined)?.e ?? I.F, utc)) return read ? v : v.f.get('ms')!
    return refuse(at, `${at.text}: expected ${inner.unit} value`)
  }

  // ORM rows are detached copies. Only save/create/delete writes the table; mutating a fetched
  // object does not. Tables start empty and have the same map semantics used by system.ts.
  naiveUtc = false
  readonly ormTables = new Map<string, {id: string, decl: MapDecl}>()
  ormTable(rec: string, at: SX, p: Path): {id: string, decl: MapDecl} {
    let table = this.ormTables.get(rec)
    if (!table) {
      const r = this.rec(rec, at), meta = r.orm
      if (!meta || meta.why) return refuse(at, meta?.why || `${rec}: no ORM schema`)
      if (r.fields.some(f => ['__proto__', 'prototype', 'constructor'].includes(f.name))) return refuse(at, `${rec}: reserved ORM column name`)
      if (r.methods.save || r.methods.delete || r.methods.__init__) return refuse(at, `${rec}: custom ORM constructor/save/delete is outside the table boundary`)
      const kt = r.fields.find(f => f.name === meta.key)?.t
      if (kt?.k !== 'int' && kt?.k !== 'str') return refuse(at, `${rec}: primary key must be a non-null integer or string`)
      const fields: Var[] = []
      for (const f of r.fields) {
        if (f.name === meta.key) continue
        const t = f.t.k === 'opt' ? f.t.of : f.t, sort = this.scalar(t)
        if (!sort) return refuse(at, `${rec}.${f.name}: ${this.why(t)}`)
        if (r.fields.some(g => g.name === `${f.name}_has`)) return refuse(at, `${rec}: reserved ORM presence column`)
        fields.push({name: f.name, sort, role: 'state'})
        if (f.t.k === 'opt') fields.push({name: `${f.name}_has`, sort: {k: 'bool'}, role: 'state'})
      }
      const v = this.newVar(r.short, {k: 'num'}, 'state'), decl: MapDecl = {name: v.name, key: kt.k === 'int' ? 'num' : 'str', fields, scalar: false, js: 'Map'}
      table = {id: `orm:${rec}`, decl}
      this.maps.push(decl); this.ormTables.set(rec, table)
      this.initHeap.set(table.id, {k: 'map', decl, val: {k: 'rec', name: rec}, origin: 'state'})
      this.notes.add(`${rec}: ${meta.framework} table keyed by ${meta.key}; explicit keys, detached rows, no database touched by the check. Database constraints, triggers and signals are outside this stated table boundary; use gdp: env for isolation and store failures.`)
    }
    if (!p.heap.has(table.id)) p.heap.set(table.id, this.initHeap.get(table.id)!)
    return table
  }
  ormRow(rec: string, key: K, vals: Map<string, V>, at: SX, p: Path): [V, Path] {
    const r = this.rec(rec, at), table = this.ormTable(rec, at, p), f = new Map<string, V>()
    for (const fd of r.fields) {
      if (fd.name === r.orm!.key) { f.set(fd.name, key.op === 'num' ? {t: 'num', e: key.e} : {t: 'str', e: key}); continue }
      const v = vals.get(fd.name)!
      f.set(fd.name, fd.t.k === 'opt' ? {t: 'opt', has: this.boolv(vals.get(`${fd.name}_has`)!, at), v} : v)
    }
    const id = `fresh:${this.fresh++}`
    return [{t: 'ref', id}, {...p, heap: new Map(p.heap).set(id, {k: 'rec', ty: rec, f, origin: 'fresh', orm: {table: table.id, key, loaded: true}})}]
  }
  ormCall(rec: string, op: string, args: V[], kw: [string, V][], at: SX, p: Path): [V, Path] {
    const r = this.rec(rec, at), table = this.ormTable(rec, at, p), meta = r.orm!, o = p.heap.get(table.id) as Extract<Obj, {k: 'map'}>
    if (this.tries.length) return refuse(at, 'ORM operations inside try require modeled database exception classes')
    if (args.length) return refuse(at, `${at.text}: ORM arguments must be named`)
    if (op === 'new' || op === 'create') {
      const f = new Map(kw)
      for (const fd of r.fields) { const v = f.get(fd.name); if (v) f.set(fd.name, this.timeField(v, fd.t, false, at)) }
      if (f.size !== kw.length || kw.some(([n]) => !r.fields.some(fd => fd.name === n)) || r.fields.some(fd => !f.has(fd.name))) return refuse(at, `${at.text}: give every ORM column explicitly, including the primary key`)
      const key = this.keyOf(f.get(meta.key)!, at), id = `fresh:${this.fresh++}`
      keyKind(table.decl, key, at)
      let q: Path = {...p, heap: new Map(p.heap).set(id, {k: 'rec', ty: rec, f, origin: 'fresh', orm: {table: table.id, key}})}
      const row: V = {t: 'ref', id}
      if (op === 'create') {
        const has = this.cellOf(o, key, q, at).has
        this.fail(q, has, at, `${at.text}: duplicate primary key (an IntegrityError)`); q = this.assume(q, I.not(has))
        q = this.ormPersist(row, 'save', [], [], at, q)[1]
      }
      return [row, q]
    }
    if (kw.length !== 1 || ![meta.key, 'pk'].includes(kw[0]![0])) return refuse(at, `${at.text}: ORM queries require exactly the primary key ${JSON.stringify(meta.key)} (or "pk"); received filters: ${kw.map(([n]) => JSON.stringify(n)).join(', ') || '(none)'}; non-key filters need a scan`)
    const key = this.keyOf(kw[0]![1], at), c = this.cellOf(o, key, p, at)
    if (op === 'filter') return [{t: 'val', ty: `$orm-query:${rec}`, f: new Map([['key', kw[0]![1]]])}, p]
    if (op !== 'get') return refuse(at, `${at.text}: unsupported ORM operation ${op}`)
    this.fail(p, I.not(c.has), at, `${at.text}: row not found (DoesNotExist)`)
    return this.ormRow(rec, key, c.vals, at, this.assume(p, c.has))
  }
  ormSession(name: string, op: string, args: V[], kw: [string, V][], at: SX, p: Path): [V, Path] {
    if (kw.length || this.tries.length || p.called.includes(`session-committed:${name}`)) return refuse(at, `${at.text}: session options, exception handling or operations after commit are outside the subset`)
    if (op === 'get' && args.length === 2 && args[0]?.t === 'cls') {
      const rec = args[0].rec, r = this.rec(rec, at)
      if (r.orm?.framework !== 'sqlalchemy') return refuse(at, `${at.text}: Session.get requires a mapped class`)
      if (p.called.includes(`session-read:${rec}`)) return refuse(at, `${at.text}: repeated session reads require an identity map`)
      const table = this.ormTable(rec, at, p), key = this.keyOf(args[1]!, at), c = this.cellOf(p.heap.get(table.id) as Extract<Obj, {k: 'map'}>, key, p, at)
      const [v, q] = this.ormRow(rec, key, c.vals, at, p), row = q.heap.get((v as {id: string}).id) as Extract<Obj, {k: 'rec'}>
      row.orm!.session = name
      return [{t: 'opt', has: c.has, v}, {...q, called: [...q.called, `session-read:${rec}`]}]
    }
    if ((op === 'add' || op === 'delete') && args.length === 1 && args[0]?.t === 'ref') {
      const v = args[0], row = p.heap.get(v.id)
      if (row?.k !== 'rec' || !row.orm || this.rec(row.ty, at).orm?.framework !== 'sqlalchemy') return refuse(at, `${at.text}: session requires a mapped row`)
      if (row.orm.session && row.orm.session !== name) return refuse(at, `${at.text}: transferring a row between sessions is outside the subset`)
      if (op === 'delete' && !row.orm.loaded) return refuse(at, `${at.text}: deleting a transient session row is outside the subset`)
      return [{t: 'none'}, {...p, heap: new Map(p.heap).set(v.id, {...row, orm: {...row.orm, session: name, deleted: op === 'delete'}})}]
    }
    if (op === 'commit' && !args.length) {
      let q = p
      const pending: {table: string, key: K}[] = []
      for (const row of p.heap.values()) if (row.k === 'rec' && row.orm?.session === name) {
        const table = q.heap.get(row.orm.table) as Extract<Obj, {k: 'map'}>, exists = this.cellOf(table, row.orm.key, q, at).has
        // A missing get returned None, not an object added to the session. Only paths that
        // established its presence may flush it; otherwise the extraction is refused.
        if (row.orm.loaded && !this.holds(q, exists)) return refuse(at, `${at.text}: committing a session read without establishing row presence`)
        if (!row.orm.loaded && !row.orm.deleted) {
          const duplicate = I.or(exists, ...pending.filter(v => v.table === row.orm!.table).map(v => I.keq(v.key, row.orm!.key)))
          this.fail(q, duplicate, at, `${at.text}: duplicate primary key (IntegrityError)`); q = this.assume(q, I.not(duplicate))
          pending.push(row.orm)
        }
      }
      for (const [id, row] of p.heap) if (row.k === 'rec' && row.orm?.session === name) q = this.ormPersist({t: 'ref', id}, row.orm.deleted ? 'delete' : 'save', [], [], at, q)[1]
      return [{t: 'none'}, {...q, called: [...q.called, `session-committed:${name}`]}]
    }
    return refuse(at, `${at.text}: unsupported session operation ${op}`)
  }
  ormPersist(v: V, op: string, args: V[], kw: [string, V][], at: SX, p: Path): [V, Path] {
    if (args.length || kw.length || this.tries.length) return refuse(at, `${at.text}: ORM save/delete options or exception handler outside the subset`)
    const row = v.t === 'ref' ? p.heap.get(v.id) : undefined
    if (row?.k !== 'rec' || !row.orm) return refuse(at, `${at.text}: save/delete requires a row fetched or created in this request`)
    const r = this.rec(row.ty, at), key = this.keyOf(row.f.get(r.orm!.key)!, at)
    if (!I.same(key, row.orm.key)) return refuse(at, `${at.text}: changing an ORM primary key is outside the subset`)
    const o = p.heap.get(row.orm.table) as Extract<Obj, {k: 'map'}>
    if (op === 'delete') {
      const q = this.mapDel({t: 'ref', id: row.orm.table}, key, at, p, false)
      if (r.orm!.framework === 'django' && v.t === 'ref') q.heap.set(v.id, {...row, f: new Map(row.f).set(r.orm!.key, {t: 'none'})})
      return [{t: 'none'}, q]
    }
    const vals = new Map<string, V>()
    for (const fd of r.fields) {
      if (fd.name === r.orm!.key) continue
      const value = row.f.get(fd.name) ?? refuse(at, `${at.text}: missing column ${fd.name}`), f = o.decl.fields.find(f => f.name === fd.name)!
      if (fd.t.k === 'opt') {
        const has = value.t === 'none' ? I.F : value.t === 'opt' ? value.has : I.T
        const inner = value.t === 'none' ? zeroOf(f.sort) : value.t === 'opt' ? value.v : value
        vals.set(fd.name, this.ite(has, this.fit(inner, f, at), zeroOf(f.sort), at)); vals.set(`${fd.name}_has`, {t: 'bool', e: has})
      } else vals.set(fd.name, this.fit(value, f, at))
    }
    return [{t: 'none'}, this.writeCell(row.orm.table, o, key, I.T, vals, at, p)]
  }

  // --- stores ---------------------------------------------------------------------------------------------------------
  storeMap(store: string, tpl: string, kn: boolean, at: SX, p: Path): [string, Extract<Obj, {k: 'map'}>] {
    const key = `${store}\u0000${tpl}`
    let sm = this.storeMaps.get(key)
    if (!sm) {
      const decl = this.storeDecl(store)
      if (decl.apart) this.notes.add(`${store}: its key templates name distinct keys (stated: apart)`)
      else for (const other of [...this.storeMaps.values()].filter(x => x.store === store)) if (!disjoint(other.tpl, tpl)) refuse(at, `${store}: the key templates ${JSON.stringify(other.tpl)} and ${JSON.stringify(tpl)} may name one key`)
      const sv = decl.values?.[tpl]
      const val: SType = Array.isArray(sv) ? {k: 'choice', values: sv} : sv === 'int' || (!sv && decl.value === 'int') ? {k: 'int'} : sv === 'str' || (!sv && decl.value === 'str') ? {k: 'str'} : {k: 'float'}
      const name = `${store}_${tpl.replace(/\{\}/g, '').replace(/[^A-Za-z0-9]+/g, '_').replace(/^_|_$/g, '')}`
      let d: MapDecl, json: JField[] | undefined
      if (sv && typeof sv === 'object' && !Array.isArray(sv)) {
        // (a JSON record: a cell of its fields, an optional one beside whether the key holds a value, a str one left out)
        json = []
        const fields: Var[] = []
        for (const [f, t] of Object.entries(sv.json)) {
          if (t === 'str' || t === 'str | None') { json.push({name: f, out: true}); continue }
          const st = Array.isArray(t) ? {t: {k: 'choice', values: t} as SType} : sortOfText(t, at.p, this.mod.lang), opt = st.t.k === 'opt', inner = st.t.k === 'opt' ? st.t.of : st.t
          fields.push({name: f, sort: this.scalar(inner)!, role: 'state'})
          if (opt) fields.push({name: `${f}_has`, sort: {k: 'bool'}, role: 'state'})
          json.push({name: f, ...(opt ? {opt} : {}), ...(inner.k === 'choice' ? {choice: true, vals: inner.values} : {})})
        }
        const v = this.newVar(name, {k: 'num'}, 'state')
        d = {name: v.name, key: kn ? 'num' : 'str', fields, scalar: false, js: 'Map'}
        this.maps.push(d)
        this.notes.add(`${store}: ${JSON.stringify(tpl)} keys hold JSON records (stated): ${json.map(f => `${f.name}${f.out ? ' (a string, left out)' : f.opt ? ' (maybe absent)' : ''}`).join(', ')}`)
      } else d = this.mapDeclOf(name, {k: 'map', key: {k: kn ? 'int' : 'str'}, val, ...(val.k === 'str' ? {sv: true} : {})} as SType, at)
      const id = `store:${key}`
      sm = {store, tpl, id, decl: d, ...(json ? {json} : {}), ...(Array.isArray(sv) ? {choice: true} : {})}
      this.storeMaps.set(key, sm)
      this.initHeap.set(id, {k: 'map', decl: d, val, origin: 'state'})
      this.notes.add(`${store}: a store (${this.opts.stores?.[store] ? 'stated' : 'inferred: an injected dependency, read and written by a key'}): ${JSON.stringify(tpl)} keys held as ${d.name}, its expiry and eviction left out`)
    }
    if (!p.heap.has(sm.id)) p.heap.set(sm.id, this.initHeap.get(sm.id)!)
    return [sm.id, p.heap.get(sm.id) as Extract<Obj, {k: 'map'}>]
  }
  storeKey(v: V, at: SX): {tpl: string, k: K, kn: boolean} {
    if (v.t === 'fmt') return {tpl: v.tpl, k: v.k, kn: v.k.op === 'num'}
    if (v.t === 'str') return {tpl: '{}', k: v.e, kn: false}
    return refuse(at, `${at.text}: a store's key of ${v.t === 'opaque' ? v.why : `a ${v.t}`} (a string, or a format with one hole)`)
  }
  readonly storeAsync: Record<string, Record<string, boolean>> = {}
  // A store's declaration: the caller's, with the methods inference reads as its get, set and delete added.
  readonly storeDecls = new Map<string, StoreDecl>()
  // (an injected dependency's type: its methods' declared results)
  readonly storeTypes = new Map<string, string>()
  // (the stores whose keys the rule holds: stated, or an injected dependency the class calls a key's method on)
  readonly storeKeyed = new Set<string>()
  readonly injectedFields: string[] = []
  readonly globalStores: {name: string, mod: string}[] = []
  readonly inertAttrs: {store: string, path: string}[] = []
  // (the injected dependencies and stores: their type, whether the rule holds keys of theirs, whether the caller stated them)
  readonly deps: {name: string, ty?: string, keyed: boolean, stated: boolean}[] = []
  // A constructor argument held as an injected dependency (a store): one its reader marks so, or one of no scalar type
  // (another module's class, a protocol, none stated) the class keeps in a field and calls methods on; one defaulting
  // to None too (the check gives one: the claim is for objects given one, the code's fallback for None not read).
  injected(pa: SParam, init: SFunc, r: SRec): {keyed: boolean, ty?: string} | undefined {
    if (!this.inf) return undefined
    const t = pa.t.k === 'opt' ? pa.t.of : pa.t
    if (!pa.inject && (this.scalar(t) || ['lock', 'none', 'map', 'list'].includes(t.k) || (t.k === 'rec' && this.mod.recs[t.name]?.own && !this.mod.recs[t.name]!.kinds.includes('protocol')) || (pa.dflt && !(pa.t.k === 'opt' && pa.dflt.e === 'none')))) return undefined
    const fields: string[] = []
    // (self.f = arg, or one place of a tuple's, self.a, self.f = a, arg)
    const pairs = (to?: SX, v?: SX): [SX | undefined, SX | undefined][] => (to?.e === 'tuple' && v?.e === 'tuple' && (to.xs as SX[]).length === (v.xs as SX[]).length ? (to.xs as SX[]).flatMap((t, i) => pairs(t, (v.xs as SX[])[i])) : [[to, v]])
    deep(init.body, st => { if (st.s === 'set') for (const [to, v] of pairs(st.to as SX | undefined, st.x as SX | undefined)) if (to?.e === 'get' && (to.x as SX).e === 'var' && (to.x as SX).n === 'self' && v?.e === 'var' && v.n === pa.name) fields.push(String(to.f)) })
    const ms = this.callsOn(r, fields)
    if (!pa.inject && !ms.length) return undefined
    return {keyed: ms.some(m => !!keyShape(m)), ...(t.k === 'rec' ? {ty: t.name} : {})}
  }
  // The methods the class's code calls on its fields named (self.f.m(...), or through a reader of one: self.f().m()).
  callsOn(r: SRec, fields: string[]): string[] {
    const ms: string[] = [], self = (x?: SX) => x?.e === 'var' && x.n === 'self'
    const field = (x?: SX): string | undefined => {
      if (x?.e === 'get' && self(x.x as SX)) return String(x.f)
      const g = x?.e === 'call' && !(x.args as SX[]).length ? x.f as SX : undefined, body = g?.e === 'get' && self(g.x as SX) ? this.mod.funcs[r.methods[String(g.f)] ?? '']?.body : undefined
      return body?.length === 1 && body[0]!.s === 'ret' ? field(body[0]!.x as SX) : undefined
    }
    for (const id of Object.values(r.methods)) if (id && this.mod.funcs[id]) deep(this.mod.funcs[id]!.body, o => { const f = o.f as SX | undefined; if (o.e === 'call' && f?.e === 'get' && fields.includes(field(f.x as SX) ?? '')) ms.push(String(f.f)) })
    return ms
  }
  storeDecl(store: string): StoreDecl {
    let d = this.storeDecls.get(store)
    if (!d) { d = {...this.opts.stores?.[store]}; this.storeDecls.set(store, d) }
    return d
  }
  storeCall(store: string, m: string, args: V[], kw: [string, V][], at: SX, p: Path, awaited: boolean): [V, Path] {
    if (dead(p)) return [{t: 'opaque', why: 'unreachable'}, p]
    const d = this.storeDecl(store), all = [...args, ...kw.map(([, v]) => v)]
    // (other code given the rule's state may change it: refused unless the caller states it, the tag on its line)
    const given = (vs: V[]) => { if (!this.tagAt(at.p) && vs.some(v => this.stateRef(v, p))) refuse(at, `${at.text}: ${store}.${m} is given the rule's state, which other code may change (if it doesn't, a \`gdp: skip\` comment on its line says so)`) }
    const arg = (n: string, i: number) => kw.find(([k]) => k === n || (n === 'key' && k === 'name'))?.[1] ?? args[i] ?? refuse(at, `${at.text}: the store's ${n} not given`)
    const has = (n: string, i: number) => kw.some(([k]) => k === n) || args.length > i
    let kind: StoreOp | undefined = (d.get ?? ['get', 'async_get_cache', 'get_cache']).includes(m) ? 'get' : (d.set ?? ['set', 'async_set_cache', 'set_cache']).includes(m) ? 'set' : (d.delete ?? ['delete', 'delete_cache', 'async_delete_cache']).includes(m) ? 'delete' : d.add?.includes(m) ? 'add' : d.incr?.includes(m) ? 'incr' : undefined
    if (!kind && this.inf) {
      // (inferred: a method named as a key's get, set or delete, given a key that is a string or a format)
      const k = keyShape(m), key = kw.find(([n]) => n === 'key' || n === 'name')?.[1] ?? args[0]
      if (k && key && (key.t === 'str' || key.t === 'fmt') && ((k !== 'set' && k !== 'add') || has('value', 1))) { kind = k; (d[k] ??= []).push(m); this.notes.add(`${store}.${m}: read as the store's ${k} by a key (inferred from its name)`) }
      else {
        // (another method: an answer, or left out; of a store, one that may change what it holds, unless stated)
        if (this.storeKeyed.has(store) && !this.tagAt(at.p)) return refuse(at, `${at.text}: ${m}, a method of the store not stated as its get, set or delete (one that may change what it holds: state it, stores: {${store}: {get, set, delete}}, or skip it)`)
        given(all)
        const ty = this.storeTypes.get(store), ret = ty ? this.mod.recs[ty]?.rets?.[m] : undefined
        const out = this.boundary({...at, args: [], kw: []}, {key: `${store}.${m}`, name: `${store}.${m}`, patch: {store, path: [m]}, ...(ret ? {ret} : {}), args: false, refusal: `${at.text}: ${m}, a method of the store not stated as its get, set or delete`}, p, awaited)
        // (left out: the check's store does nothing for it; the claim assumes it returns and changes nothing the rule keeps)
        if (out[0].t === 'opaque' && out[0].ask) { if (!(d.skip ??= []).includes(m)) { d.skip.push(m); this.notes.add(`${store}.${m}: assumes it returns and changes nothing the rule keeps (left out: the check's ${store} does nothing for it)`) } (this.storeAsync[store] ??= {})[m] = awaited }
        return out
      }
    }
    if (!kind) return refuse(at, `${at.text}: ${m}, a method of the store not stated as its get, set or delete`)
    const was = (this.storeAsync[store] ??= {})[m]
    if (was !== undefined && was !== awaited) return refuse(at, `${at.text}: the store's ${m} awaited at one call and not at another`)
    this.storeAsync[store]![m] = awaited
    // (a key's operation takes its key, and a set its value: any other argument given the rule's state is refused)
    const sets = kind === 'set' || kind === 'add', keyV = arg('key', 0), valV = sets ? arg('value', 1) : kind === 'incr' && has('amount', 1) ? arg('amount', 1) : undefined
    // (a set's options: nx and xx make it conditional, its result whether it set (True, else None, as redis-py's); its
    // expiry is left out, as every store's is; any other option is refused)
    const TTL = ['ex', 'px', 'exat', 'pxat', 'ttl', 'timeout', 'expire', 'expiry']
    let only: 'nx' | 'xx' | undefined
    for (const [n, v] of kw) {
      if (n === 'key' || n === 'name' || n === 'value' || (kind === 'incr' && n === 'amount')) continue
      if (sets && TTL.includes(n)) { this.notes.add(`${store}.${m}: its ${n} (the key's expiry) left out, as the store's expiry is`); continue }
      if (kind === 'set' && (n === 'nx' || n === 'xx')) {
        if (v.t !== 'bool' || v.e.op !== 'const') return refuse(at, `${at.text}: ${n} given a value not known here`)
        if (v.e.v) { if (only) return refuse(at, `${at.text}: nx and xx both`); only = n }
        continue
      }
      // (another option given a constant, None or a flag, as a tracing span or which tier to use: the store is read as
      // one map whatever it says, the check's too, and the note says so; one given a value of the request is refused)
      if (v.t === 'none' || (v.t === 'bool' && v.e.op === 'const') || (v.t === 'num' && v.e.op === 'const') || (v.t === 'str' && v.e.op === 'slit')) {
        this.notes.add(`${store}.${m}: its ${n} (${v.t === 'none' ? 'None' : v.t === 'str' ? JSON.stringify((v.e as {value: string}).value) : String((v.e as {v: unknown}).v)}) left out: the store read as one map whatever it says`)
        continue
      }
      return refuse(at, `${at.text}: the store's ${m} given ${n}, a value the request decides (the subset reads a key, a value, nx, xx, the expiry and options given a constant)`)
    }
    // (a set's third argument, set(key, value, ttl) as most caches take it: the key's expiry, left out)
    const ttl = sets && args.length === 3 ? args[2] : undefined
    if (ttl) this.notes.add(`${store}.${m}: its third argument (the key's expiry) left out, as the store's expiry is`)
    given(all.filter(v => v !== keyV && v !== valV && v !== ttl))
    if (args.length > (sets ? 3 : kind === 'incr' ? 2 : 1)) return refuse(at, `${at.text}: the store's ${m} given more than its key${sets ? ', value and expiry' : kind === 'incr' ? ' and amount' : ''}`)
    const {tpl, k, kn} = this.storeKey(keyV, at)
    // (what a template's keys hold, where nothing states it: strings where the first write sets one)
    if (sets && valV?.t === 'str' && !d.value && !d.values?.[tpl] && !this.storeMaps.has(`${store}\u0000${tpl}`)) { (d.values ??= {})[tpl] = 'str'; this.notes.add(`${store}: ${JSON.stringify(tpl)} keys hold strings (inferred: a string set)`) }
    const [id, o] = this.storeMap(store, tpl, kn, at, p), sm = [...this.storeMaps.values()].find(x => x.id === id)!
    // (inside a try that may catch it: the store's operation may raise, as other code's may, before it acts)
    if (this.tries.length && !d.nothrow) p = this.passing(`${store}.${m}`, `${store}.${m}`, {store, path: [m]}, at, p, awaited)
    if (kind === 'get') {
      if (!sm.json) return this.mapGet({t: 'ref', id}, k, at, p, 'none')
      const c = this.cellOf(o, k, p, at), f = new Map<string, V>()
      for (const jf of sm.json) {
        if (jf.out) { f.set(jf.name, {t: 'opaque', why: `${at.text}: ${jf.name}, a string of a stored record (left out)`}); continue }
        const x = c.vals.get(jf.name)!
        f.set(jf.name, jf.opt ? {t: 'opt', has: (c.vals.get(`${jf.name}_has`) as {e: B}).e, v: x} : x)
      }
      return [{t: 'opt', has: c.has, v: {t: 'val', ty: '$json', f}}, p]
    }
    if (kind === 'delete') return [{t: 'none'}, this.mapDel({t: 'ref', id}, k, at, p, false)]
    if (kind === 'incr') {
      if (sm.json || sm.choice || o.val!.k === 'str') return refuse(at, `${at.text}: ${m} on a store that holds no numbers`)
      const by = valV ? this.numOf(valV, at, p) : I.num(1), c = this.cellOf(o, k, p, at)
      const now: V = {t: 'num', e: I.add(this.numOf(this.ite(c.has, c.vals.get('value')!, {t: 'num', e: I.num(0)}, at), at, p), by)}
      return [now, this.writeCell(id, o, k, I.T, new Map([['value', now]]), at, p)]
    }
    if (kind === 'add') only = 'nx'
    const v = arg('value', 1)
    let vals: Map<string, V>
    if (sm.json) {
      if (v.t !== 'val' || v.ty !== '$json') return refuse(at, `${at.text}: a ${v.t === 'opaque' ? v.why : v.t === 'val' ? v.ty.slice(1) : v.t} set where JSON records are held (stated)`)
      for (const n of v.f.keys()) if (!sm.json.some(jf => jf.name === n)) return refuse(at, `${at.text}: ${n}, a field the stated record doesn't have`)
      vals = new Map()
      for (const jf of sm.json) {
        if (jf.out) continue
        const fv = o.decl.fields.find(x => x.name === jf.name)!, x = v.f.get(jf.name)
        if (!jf.opt && (!x || x.t === 'opt' || x.t === 'none')) return refuse(at, `${at.text}: ${jf.name}, a field the stated record always holds, ${x ? 'maybe None' : 'not set'}`)
        const has: B = !x || x.t === 'none' ? I.F : x.t === 'opt' ? x.has : I.T, inner = x?.t === 'opt' ? x.v : x
        const zero: V = fv.sort.k === 'choice' ? {t: 'choice', e: I.llit(fv.sort.values[0]!, fv.sort.values)} : fv.sort.k === 'bool' ? {t: 'bool', e: I.F} : {t: 'num', e: I.num(0)}
        // (absent, or None: the default, as the text holds nothing there)
        vals.set(jf.name, inner && inner.t !== 'none' ? this.ite(has, this.fit(inner, fv, at), zero, at) : zero)
        if (jf.opt) vals.set(`${jf.name}_has`, {t: 'bool', e: has})
      }
    } else {
      // (a bool set where numbers are held: 1 or 0, as Python's True is)
      const v2 = sm.choice ? this.fit(v, o.decl.fields[0]!, at) : v.t === 'bool' && o.val!.k !== 'str' ? {t: 'num', e: I.nite(v.e, I.num(1), I.num(0))} as V : v
      if (sm.choice ? v2.t !== 'choice' : o.val!.k === 'str' ? v.t !== 'str' : v2.t !== 'num') return refuse(at, `${at.text}: a ${v.t === 'opaque' ? v.why : v.t} set in a store of ${o.val!.k === 'float' ? 'numbers' : o.val!.k}`)
      vals = new Map([['value', v2]])
    }
    if (!only) return [{t: 'none'}, this.writeCell(id, o, k, I.T, vals, at, p)]
    // (nx: where the key holds nothing; xx: where it holds a value)
    const c = this.cellOf(o, k, p, at), when = only === 'nx' ? I.not(c.has) : c.has
    const merged = new Map([...vals].map(([n, x]) => [n, this.ite(when, x, c.vals.get(n)!, at)]))
    const w = this.writeCell(id, o, k, I.bite(when, I.T, c.has), merged, at, p), wo = w.heap.get(id) as typeof o
    w.heap.set(id, {...wo, w: {...wo.w!, on: when}})
    return [kind === 'add' ? {t: 'bool', e: when} : {t: 'opt', has: when, v: {t: 'bool', e: I.T}}, w]
  }

  // --- context managers of the module's, made by @contextmanager ---------------------------------------------------------
  // with self.cm(...): body, where cm is a generator the module reads, decorated @contextmanager: the generator run,
  // the with's body where it yields (in the with's frame), so a raise in the body goes through the generator's
  // handlers and finally first, as contextmanager throws it there. The body may not return, break or set a local (not
  // read here); the generator yields once (a path that ends without yielding fails, as contextmanager's RuntimeError).
  readonly withBodies: {body: SS[], locals: Map<string, V>}[] = []
  generatorCM(s: SS, p: Path): Flow | undefined {
    const items = s.items as {x: SX, as?: SX}[]
    if (items.length !== 1 || items[0]!.x.e !== 'call') return undefined
    const it = items[0]!, fx = it.x.f as SX
    let f: V, q = p
    try { [f, q] = fx.e === 'get' ? this.get(fx, p) : this.ev(fx, p) } catch { return undefined }
    if (f.t !== 'fn') return undefined
    const fn = this.mod.funcs[f.id]
    if (!fn?.decorators.some(d => /(?:^|\.)contextmanager$/.test(d.name))) return undefined
    if (it.as) return refuse(s, `with ${it.x.text} as ...: a generator context manager's value`)
    const yields: SS[] = []
    let bad = ''
    deep(fn.body, o => { if (o.s === 'yield') yields.push(o); if (o.s === 'ret' || o.s === 'for') bad ||= o.s === 'ret' ? 'returns' : 'loops'; return false })
    if (bad || yields.length !== 1) return refuse(s, `${fn.name}: a @contextmanager generator that ${bad || `yields ${yields.length} times`} (the subset reads one that yields once)`)
    if (deep(s.body, o => ['ret', 'break', 'continue'].includes(o.s) || (o.s === 'set' && (o.to as SX | undefined)?.e === 'var'))) return refuse(s, `with ${it.x.text}: a body that returns, breaks or sets a local, inside a generator context manager (not read)`)
    this.notes.add(`with ${it.x.text} (${it.x.p}): ${fn.name}, a @contextmanager generator, run around the with's body`)
    this.withBodies.push({body: s.body as SS[], locals: q.locals})
    const start = {...q, heap: new Map(q.heap).set('$yielded', {k: 'rec', ty: '$yielded', f: new Map([['n', {t: 'bool', e: I.F}]]), origin: 'fresh'} as Obj)}
    let out: Path
    try { out = this.evArgs(it.x, start, (args, kw, q2) => this.callFunc(fn, f.self, args, kw, it.x, q2, false))[1] } finally { this.withBodies.pop() }
    const y = (out.heap.get('$yielded') as Extract<Obj, {k: 'rec'}> | undefined)?.f.get('n')
    const did = y?.t === 'bool' ? y.e : I.T, heap = new Map(out.heap)
    heap.delete('$yielded')
    this.fail(out, I.not(did), s, `${fn.name}: the generator didn't yield (a RuntimeError)`)
    return {live: this.assume({...out, heap}, did), rets: []}
  }

  // --- values by their fields: dict literals, JSON, datetimes ----------------------------------------------------------
  // d[k]: a key the dict holds (one it may not hold is read with get); a timestamp has no items.
  valItem(m: Extract<V, {t: 'val'}>, k: V, x: SX, p: Path): [V, Path] {
    const ks = strLit(k)
    if (m.ty !== '$dict' || ks === undefined) return refuse(x, `${x.text}: an item of a ${m.ty.slice(1)}${m.ty === '$dict' ? ' by a key not known here' : ''}`)
    const v = m.f.get(ks)
    if (!v) { this.fail(p, I.T, x, `${x.text}: a key the dict doesn't hold (a KeyError)`); return [{t: 'opaque', why: 'unreachable'}, {...p, pc: [...p.pc, I.F]}] }
    // (a key on some paths only, or a stored record's optional field: absent and None are one there, read by get)
    if (v.t === 'opt' && !(v.has.op === 'const' && v.has.v)) return refuse(x, `${x.text}: a key the dict may not hold, read by [] (the subset reads it with get)`)
    return [v, p]
  }
  valCall(o: Extract<V, {t: 'val'}>, m: string, args: V[], kw: [string, V][], x: SX, p: Path): [V, Path] {
    if (o.ty.startsWith('$orm-query:')) {
      if (args.length || kw.length || this.tries.length) return refuse(x, `${x.text}: ORM query options or exception handlers outside the subset`)
      const rec = o.ty.slice(11), table = this.ormTable(rec, x, p), key = this.keyOf(o.f.get('key')!, x)
      const obj = p.heap.get(table.id) as Extract<Obj, {k: 'map'}>, c = this.cellOf(obj, key, p, x)
      if (m === 'exists') return [{t: 'bool', e: c.has}, p]
      if (m === 'first') { const [v, q] = this.ormRow(rec, key, c.vals, x, p); return [{t: 'opt', has: c.has, v}, q] }
      if (m === 'delete') return [{t: 'none'}, this.mapDel({t: 'ref', id: table.id}, key, x, p, false)]
      return refuse(x, `${x.text}: unsupported ORM query operation ${m}`)
    }
    if (o.ty === '$dt' && m === 'timestamp' && !args.length && !kw.length) return [{t: 'val', ty: '$ts', f: o.f}, p]
    if (o.ty === '$dict' && m === 'get' && !kw.length && args.length >= 1 && args.length <= 2) {
      const ks = strLit(args[0]!), d: V = args[1] ?? {t: 'none'}
      if (ks === undefined) return refuse(x, `${x.text}: a dict's get by a key not known here`)
      const v = o.f.get(ks)
      if (!v) return [d, p]
      return [v.t === 'opt' ? this.ite(v.has, v.v, d, x) : v, p]
    }
    if (o.ty === '$dict' && (m === 'values' || m === 'keys') && !args.length && !kw.length) {
      if ([...o.f.values()].some(v => v.t === 'opt')) return refuse(x, `${x.text}: the ${m} of a dict whose keys depend on the path`)
      return [{t: 'tuple', xs: m === 'values' ? [...o.f.values()] : [...o.f.keys()].map(k => ({t: 'str', e: {op: 'slit', value: k}}))}, p]
    }
    return refuse(x, `${x.text}: ${m} of a ${o.ty.slice(1)}`)
  }
  // json.dumps of a dict literal: its text, kept by its fields (json.loads gives the dict back); of anything else, a
  // text outside the subset. Only keyword options that change no key or value (sort_keys, separators, indent).
  json(q0: string, args: V[], kw: [string, V][], x: SX, p: Path): [V, Path] {
    const v = args[0]
    if (args.length !== 1 || kw.some(([n]) => !['sort_keys', 'separators', 'indent', 'cls', 'ensure_ascii'].includes(n))) return refuse(x, `${x.text}: ${q0} given more than its value`)
    if (q0 === 'json.dumps') {
      if (v?.t === 'val' && v.ty === '$dict' && !kw.some(([n]) => n === 'cls')) {
        for (const [k, y] of v.f) { const z = y.t === 'opt' ? y.v : y; if (!['num', 'bool', 'str', 'choice', 'none', 'opaque'].includes(z.t)) return refuse(x, `${x.text}: ${k}, a ${z.t === 'val' ? z.ty.slice(1) : z.t} put in a JSON text (the subset reads one of scalars)`) }
        this.notes.add(`${x.text} (${x.p}): JSON of a dict of scalars, read back by json.loads as the same dict`)
        return [{t: 'val', ty: '$json', f: v.f}, p]
      }
      return [{t: 'opaque', why: `${x.text}: a JSON text of a value outside the subset`}, p]
    }
    if (v?.t === 'val' && v.ty === '$json') return [{t: 'val', ty: '$dict', f: v.f}, p]
    if (v?.t === 'opaque') return [v, p]
    return refuse(x, `${x.text}: json.loads of a ${v?.t === 'val' ? v.ty.slice(1) : v?.t ?? 'nothing'} (the subset reads back a text json.dumps made)`)
  }
  // A datetime plus or minus a timedelta, two datetimes apart, a timestamp in milliseconds (ts * 1000).
  valBin(op: string, a: V, b: V, x: SX, p: Path): V {
    const ms = (v: V): N => this.numOf((v as Extract<V, {t: 'val'}>).f.get('ms')!, x, p), ty = (v: V) => (v.t === 'val' ? v.ty : v.t)
    // (a datetime past year 9999 or before year 1: Python's OverflowError, the step's failure there)
    const mk = (t: string, e: N): V => {
      if (t === '$dt') this.fail(p, I.or(I.cmp('<', e, I.num(-62_135_596_800_000)), I.cmp('<', I.num(253_402_300_799_999), e)), x, `${x.text}: a datetime out of its range (an OverflowError)`)
      const source = a.t === 'val' && a.ty === '$dt' ? a : b.t === 'val' && b.ty === '$dt' ? b : undefined
      return {t: 'val', ty: t, f: new Map<string, V>([['ms', {t: 'num', e}], ...(t === '$dt' ? [['utc', source?.f.get('utc') ?? {t: 'bool', e: I.F}] as [string, V]] : [])])}
    }
    if (op === '+' && ty(a) === '$dt' && ty(b) === '$td') return mk('$dt', I.add(ms(a), ms(b)))
    if (op === '+' && ty(a) === '$td' && ty(b) === '$dt') return mk('$dt', I.add(ms(a), ms(b)))
    if (op === '-' && ty(a) === '$dt' && ty(b) === '$td') return mk('$dt', I.sub(ms(a), ms(b)))
    if (op === '-' && a.t === 'val' && a.ty === '$dt' && b.t === 'val' && b.ty === '$dt') {
      if (!I.same(a.f.get('utc') ?? {t: 'bool', e: I.F}, b.f.get('utc') ?? {t: 'bool', e: I.F})) return refuse(x, 'mixed aware and naive datetimes')
      return mk('$td', I.sub(ms(a), ms(b)))
    }
    if ((op === '+' || op === '-') && ty(a) === '$td' && ty(b) === '$td') return mk('$td', op === '+' ? I.add(ms(a), ms(b)) : I.sub(ms(a), ms(b)))
    if (op === '*' && ty(a) === '$ts' && constOf(b) === 1000) return {t: 'num', e: ms(a)}
    return refuse(x, `${x.text}: ${ty(a).replace('$', '')} ${op} ${ty(b).replace('$', '')}`)
  }

  // --- the boundary the caller states ---------------------------------------------------------------------------------
  calleeNames(x: SX): string[] {
    const f = x.f as SX
    const out: string[] = []
    if (typeof f.text === 'string') out.push(f.text)
    if (typeof f.q === 'string') out.push(f.q)
    if (f.e === 'get') out.push(String(f.f))
    if (f.e === 'fn') out.push(String(f.id))
    if (f.e === 'var') out.push(String(f.n))
    return out
  }
  match(list: string[] | undefined, names: string[]): string | undefined {
    return list?.find(e => names.some(n => n === e || n.startsWith(`${e}.`) || n.endsWith(`.${e}`) || n.endsWith(`.${e.replace(/^self\./, '')}`)))
  }
  skipped(names: string[]): boolean { return !!this.match(this.opts.skip, names) }
  // A call answered by the request: its result an input (one a step), the check stubbing the callee with it. Its type
  // is the caller's (a type string), a tag's, or the callee's declared one (inferred: `how` says which).
  answer(key: string, names: string[], patch: Patch | undefined, at: SX, p: Path, awaited: boolean, type: string | SType = this.opts.answers![key]!, how = 'stated'): [V, Path] {
    if (this.inFold) return refuse(at, `${at.text ?? names[0]}: other code's value read in a loop's pass (it may differ each pass)`)
    if (!patch && !at.end) return refuse(at, `${at.text}: an answered call the check can't stub`)
    if (this.mod.stubs === false) return refuse(at, `${at.text}: answered (${how}), but the ${LANG[this.mod.lang] ?? this.mod.lang} check can't stub a call yet`)
    if (p.called.includes(key)) return refuse(at, `${at.text}: ${key} called twice in one step (an answer is one a step)`)
    const q: Path = {...p, called: [...p.called, key]}
    // (where it is called: a compiled language's check stubs it there, its source rewritten)
    const site = {p: at.p, ...(at.end ? {end: at.end as string} : {}), ...(at.span ? {span: at.span as [number, number]} : {})}
    let a = this.answers.get(key)
    const short = key.split(/\.|::/).pop()!
    if (!a) {
      const t = typeof type === 'string' ? sortOfText(type, at.p, this.mod.lang).t : type, text = typeof type === 'string' ? type : typeText(type)
      const inner = t.k === 'opt' ? t.of : t, s = this.scalar(inner)!
      const v = this.newVar(short, s, 'input', how === 'stated' ? `what ${names[0]} returns (stated: answers)` : `what ${names[0]} returns (${how}: any ${text})`)
      const none = t.k === 'opt' ? this.newVar(`${short}_none`, {k: 'bool'}, 'input', `whether ${names[0]} returns None`).name : undefined
      // (a result of a fixed width: within it, the claim is for the values its type holds)
      const fit = !!this.intTy(inner)
      this.typed(v, inner, 'input', inner.k === 'int' && inner.unit?.startsWith('datetime-') && none ? I.and(this.sel, I.not(I.bvar(none))) : this.sel)
      a = {key, patch: patch ?? {}, async: awaited, inputs: {name: v.name, ...(none ? {none} : {}), ...(inner.k === 'float' ? {float: true} : {}), ...(inner.k === 'int' && inner.unit?.startsWith('datetime-') ? {time: inner.unit} : {})}, sort: text, ...(how === 'stated' ? {} : {how}), ...(fit ? {fit} : {}), at: [], ...(at.ty ? {ty: at.ty as string} : {})}
      this.answers.set(key, a)
      this.notes.add(how === 'stated' ? `${names[0]} (${at.p}): answered by the request (stated), its arguments not read` : `${names[0]} (${at.p}): answered by the request (${how}: its value is read; assumes ${names[0]} may return any ${text}), its arguments not read`)
    } else if (a.async !== awaited) return refuse(at, `${at.text}: ${key} awaited at one call and not at another`)
    // (a callee whose declared result is a fixed-width integer, the reader's `ity`: an answer is within it where it is read)
    if (at.ity && this.vars.get(a.inputs.name)!.sort.k === 'num') this.typed(this.vars.get(a.inputs.name)!, at.ity as IntTy, 'input', I.and(this.sel, this.cond(p)))
    if (!a.at!.some(x => x.p === site.p)) a.at!.push(site)
    const vv = this.timeField(this.valueOf(this.vars.get(a.inputs.name)!), a.inputs.time ? {k: 'int', unit: a.inputs.time} : undefined, true, at)
    return [a.inputs.none ? {t: 'opt', has: I.not(I.bvar(a.inputs.none)), v: vv} : vv, this.mayRaise(a, names[0]!, at, q)]
  }
  // A call left out inside a try (its value unread): stubbed only to raise where the request says, else run as it is.
  passing(key: string, name: string, patch: Patch | undefined, at: SX, p: Path, awaited: boolean): Path {
    if (!this.tries.length) return p
    // (a logger's call: it never raises, logging handles its own errors)
    const fx = at.f as SX | undefined
    if (fx?.e === 'get' && (fx.x as SX | undefined)?.nothrow) { this.notes.add(`${at.text ?? name} (${at.p}): a logger's call, which never raises (logging handles its handlers' errors)`); return p }
    if (this.hidden) return refuse(at, `${at.text ?? name}: other code called in a loop inside a try (whether it raises would be one input a pass)`)
    if (!patch && !at.end) return refuse(at, `${at.text ?? name}: other code left out inside a try that may catch what it raises, and the check can't stub it`)
    let a = this.answers.get(key)
    if (!a) this.answers.set(key, a = {key, patch: patch ?? {}, async: awaited, inputs: {name: ''}, sort: '', pass: true, at: []})
    if (!a.pass) return refuse(at, `${at.text ?? name}: ${key} answered at one call and left out at another`)
    // (the sites where it may raise, which the check's stub raises at: those inside a try with a handler for it)
    const q = this.mayRaise(a, name, at, p)
    if (q !== p && !a.at!.some(x => x.p === at.p)) a.at!.push({p: at.p, ...(at.end ? {end: at.end as string} : {}), ...(at.span ? {span: at.span as [number, number]} : {})})
    return q
  }

  // --- the boundary inferred ---------------------------------------------------------------------------------------
  // A call of code the subset doesn't read (another module's, an injected dependency's, or the module's own function
  // cut): tagged, else inferred. Its arguments are evaluated (the code does). Given a reference to the rule's state,
  // other code may change it: refused unless the caller states it. Its value read (a run refused where it is): the next
  // run answers it by the request, over its declared type; else it is left out, kept only where nothing reads it.
  readonly pend = new Map<string, Pend>()
  // (the calls of other code left out, by the callee's names: a check that can't run them, C's, makes them no-ops)
  readonly leftOut = new Set<string>()
  readonly returnedBy = new Map<string, {id: string, roots: string[]}>()
  readonly entryIds = new Set<string>()
  boundary(x: SX, b: Bound, p: Path, awaited: boolean): [V, Path] {
    const tag = this.tagAt(x.p) ?? b.tag
    if (tag?.k === 'strict') return refuse(x, b.refusal)
    const [vals, q] = b.args === false ? [[], p] as [V[], Path] : this.argVals(x, p)
    // (a call a reader doesn't lower: the names its arguments mention, where the reader says; else taken as given it)
    const given = b.args === false && x.e === 'no' && !b.recv ? (x.names as string[] | undefined)?.some(n => { const v = q.locals.get(n); return !v || this.stateRef(v, q) }) ?? true : [b.recv, ...vals].some(v => v && this.stateRef(v, q))
    if (given && !tag && (!b.own || this.writesState(b.own, this.rootsOf(this.func(b.own, x), b.recv, vals, q))))
      return refuse(x, `${b.refusal}; it is given the rule's state, which ${b.own ? 'its code' : 'other code'} may change (if it doesn't, state it: skip: [${JSON.stringify(b.key.split('.').pop())}], or a \`gdp: skip\` comment on its line)`)
    const t = tag?.k === 'answer' ? (tag.arg ? tag.arg : b.ret && answerable(b.ret) ? b.ret : refuse(x, `${x.text}: tagged gdp: answer, and ${b.name} declares no type an answer takes: give it (gdp: answer float)`)) : this.inf!.answers.get(b.key)
    if (t) return this.answer(b.key, [b.name], b.patch, x, q, awaited, t, tag ? 'tagged' : 'inferred')
    const why = `${x.text ?? b.name}: the value of ${b.name}, other code left out`
    // (a call on an attribute of a store the rule doesn't state, a registry its constructor adds to: inert in the check)
    const ra = b.recv?.t === 'opaque' ? b.recv.sattr : b.recv?.t === 'sattr' ? {store: b.recv.store, path: b.recv.path} : undefined
    if (ra && !this.inertAttrs.some(i => i.store === ra.store && i.path === ra.path)) this.inertAttrs.push(ra)
    this.pend.set(why, {...b, why, at: x.p, ...(x.end ? {end: x.end as string} : {})})
    this.leftOut.add(b.name).add(b.key)
    this.notes.add(`${b.name} (${x.p}): left out (${tag ? 'tagged: gdp: skip' : 'inferred: nothing the rule keeps reads its value'}), run as it is by the check`)
    return [{t: 'opaque', why, ask: b.key}, this.passing(b.key, b.name, b.patch, x, q, awaited)]
  }
  argVals(x: SX, p: Path): [V[], Path] {
    let q = p
    const out: V[] = []
    for (const a of [...((x.args as SX[] | undefined) ?? []), ...((x.kw as [string, SX][] | undefined) ?? []).map(([, v]) => v)]) {
      try { const [v, q2] = this.ev(a, q); out.push(v); q = q2 } catch (e) { if (!(e instanceof Refusal) || !foreign(a)) throw e; out.push({t: 'opaque', why: e.what}) }
    }
    return [out, q]
  }
  // A value that is (or holds) a reference to the rule's state: the object, its nested objects, maps, lists, stores.
  stateRef(v: V, p: Path): boolean {
    const st = (id: string) => { const o = p.heap.get(id); return id === 'this' || (o?.k === 'store' ? this.storeKeyed.has(o.name) : !!o && 'origin' in o && o.origin === 'state') }
    if (v.t === 'ref' || v.t === 'map' || v.t === 'list') return st(v.id)
    if (v.t === 'cell') return st(v.map)
    if (v.t === 'ptr') return this.cases(v.to).objs.some(c => st(c.id))
    if (v.t === 'opt') return this.stateRef(v.v, p)
    if (v.t === 'tuple' || v.t === 'struct') return [...(v.t === 'tuple' ? v.xs : v.f.values())].some(y => this.stateRef(y, p))
    const by = v.t === 'fn' ? v.self : v.t === 'ext' ? v.recv : undefined
    return !!by && this.stateRef(by, p)
  }
  // The parameters of a function a call gives the rule's state (its receiver, its arguments).
  rootsOf(fn: SFunc, recv: V | undefined, args: V[], p: Path): Set<string> {
    const out = new Set<string>(), ps = fn.params.filter(x => !x.star)
    let i = 0
    for (const pa of ps) {
      const v = pa.self && !fn.static ? recv : args[i++]
      if (v && this.stateRef(v, p)) out.add(pa.name)
    }
    return out
  }
  // Whether a function may write the state its `roots` (parameters, then locals aliasing them) reach, read from the IR
  // alone: a write through one, a call of other code given one, a method called on one, or a statement or expression
  // the subset doesn't read. The module's own functions it calls are read the same way.
  writesState(id: string, roots: Set<string>, seen = new Set<string>()): boolean {
    if (!roots.size) return false
    const key = `${id}(${[...roots].sort().join()})`
    if (seen.has(key)) return false
    seen.add(key)
    const fn = this.mod.funcs[id]
    if (!fn) return true
    const rs = new Set(roots)
    const mentions = (x: unknown) => deep(x, o => o.e === 'var' && rs.has(String(o.n)))
    const isVar = (x: unknown) => !!x && typeof x === 'object' && (x as SX).e === 'var'
    const targets = (s: SS): unknown[] => [s.to, ...((s.l as unknown[] | undefined) ?? []), s.pl, (s.at as SX | undefined)?.m, s.s === 'del' ? s.x : undefined].filter(Boolean)
    // (aliases first: a local set from a root's parts is one)
    for (let grew = true; grew;) {
      grew = false
      deep(fn.body, st => { if ((st.s === 'set' || st.s === 'assign') && mentions(st.x ?? st.r)) for (const t of targets(st)) for (const y of (t as SX).e === 'tuple' ? (t as SX).xs as SX[] : [t as SX]) if (isVar(y) && !rs.has(String(y.n))) { rs.add(String(y.n)); grew = true } })
    }
    const own = (f: SX): SFunc | undefined => {
      if (f.e === 'fn') return this.mod.funcs[String(f.id)]
      if (f.e === 'get' && isVar(f.x) && rs.has(String((f.x as SX).n))) {
        const r = Object.values(this.mod.recs).find(r => r.own && Object.values(r.methods).includes(fn.id))
        const mid = r?.methods[String(f.f)]
        return mid ? this.mod.funcs[mid] : undefined
      }
      return undefined
    }
    const calls = (c: SX): boolean => {
      const f = c.f as SX, args = [...((c.args as SX[] | undefined) ?? [])], kw = (c.kw as [string, SX][] | undefined) ?? []
      const target = f && own(f)
      if (!target) return (f?.e === 'get' && mentions(f.x)) || args.some(mentions) || kw.some(([, a]) => mentions(a))
      const sub = new Set<string>(), ps = target.params.filter(x => !x.star)
      let i = 0
      for (const pa of ps) {
        if (pa.self && !target.static) { if (f.e === 'get') sub.add(pa.name); continue }
        const a = args[i++] ?? kw.find(([n]) => n === pa.name)?.[1]
        if (a && mentions(a)) sub.add(pa.name)
      }
      return this.writesState(target.id, sub, seen)
    }
    // (a statement or expression the subset doesn't read: where its reader names what it mentions, by those)
    return deep(fn.body, o => ((o.s === 'no' || o.e === 'no') && (!o.names || (o.names as string[]).some(n => rs.has(n)))) || (o.e === 'rmw' && mentions(o)) ||
      (!!o.s && ['set', 'assign', 'del', 'incdec', 'opset', 'mopset'].includes(o.s) && targets(o).some(t => !isVar(t) && mentions(t))) || (o.e === 'call' && calls(o)))
  }
  // The `gdp:` comments of the file read (skip, answer [type], strict), by line: on a call's line, they state its
  // boundary; on a function's line (or the line above it), every call of it. A decorator or annotation named
  // gdp.skip, gdp_skip or GdpSkip (answer, strict) states it for the function too.
  private tagLines = new Map<string, Map<number, Tag>>()
  tagAt(at: string): Tag | undefined {
    const m = this.inf && /^(.*):(\d+):\d+$/.exec(at)
    if (!m) return undefined
    let lines = this.tagLines.get(m[1]!)
    if (!lines) {
      lines = new Map()
      const src = sourceOf(this.mod, m[1]!) ?? ''
      src.split('\n').forEach((l, i) => { const t = /(?:#|\/\/|--|%)\s*gdp:\s*(skip|answer|strict|effect)\b[ \t]*([^#\n]*)$/.exec(l); if (t) lines!.set(i + 1, {k: t[1] as Tag['k'], arg: t[2]!.trim()}) })
      this.tagLines.set(m[1]!, lines)
    }
    return lines.get(Number(m[2]))
  }
  fnTag(fn: SFunc): Tag | undefined {
    for (const d of fn.decorators) { const m = TAG_DECO.exec(d.name); if (m) return {k: m[1]!.toLowerCase() as Tag['k'], arg: /\(\s*['"](.*)['"]\s*\)/.exec(d.text)?.[1] ?? ''} }
    const [file, line] = fn.span
    return this.tagAt(`${file}:${line}:1`) ?? this.tagAt(`${file}:${line - 1}:1`)
  }
  // The module's own function called where the boundary is: its patch for the check (a method of the object: on it).
  ownPatch(fn: SFunc, self: V | undefined): Patch | undefined {
    if (!fn.cls) return {mod: this.mod.module, path: [fn.id]}
    if (self?.t === 'ref' && self.id === 'this') return {self: fn.name}
    const r = Object.values(this.mod.recs).find(r => r.methods[fn.name] === fn.id)
    return r ? {mod: r.module, path: [r.short, fn.name]} : undefined
  }
  ownCut(fn: SFunc, self: V | undefined, x: SX): Bound | undefined {
    const tag = this.fnTag(fn), lineTag = this.tagAt(x.p)
    if (!this.inf || tag?.k === 'strict' || lineTag?.k === 'strict' || !(this.inf.cut.has(fn.id) || tag || lineTag)) return undefined
    const why = this.inf.cut.get(fn.id)
    if (why) this.notes.add(`${fn.name}: the module's own code, outside the subset (${why}), and writing none of the rule's state: taken as other code where it is called (inferred)`)
    return {key: fn.id, name: fn.name, patch: this.ownPatch(fn, self), ret: fn.ret, own: fn.id, recv: self, tag, refusal: `${x.text}: ${fn.name}`}
  }
  // The module's own function that returned other code's value (the innermost), where it may be cut: not cut yet, not
  // an entry, not strict, writing none of the state its call gave it.
  cuttable(why: string): SFunc | undefined {
    const own = this.returnedBy.get(why), fn = own ? this.mod.funcs[own.id] : undefined
    return fn && !this.inf!.cut.has(fn.id) && !this.entryIds.has(fn.id) && this.fnTag(fn)?.k !== 'strict' && !this.writesState(fn.id, new Set(own!.roots)) ? fn : undefined
  }
  // A refused run: what the next one infers, or the refusal (with the statement that would accept it). A value of
  // other code read is answered by its declared type (where the check can stub it); else the module's own function the
  // refusal is in (the innermost but the entries) is cut where it writes none of the rule's state.
  promote(e: Refusal): Refusal | undefined {
    let best: Pend | undefined
    for (const [why, pd] of this.pend) if (e.what.includes(why) && (!best || why.length > best.why.length)) best = pd
    let hint = ''
    if (best) {
      const t = best.ret && answerable(best.ret) ? best.ret : undefined
      if (t && (best.patch || best.end) && this.mod.stubs !== false) { this.inf!.answers.set(best.key, t); return undefined }
      const short = JSON.stringify(best.key.split('.').pop()), cant = this.mod.stubs === false ? `the ${LANG[this.mod.lang] ?? this.mod.lang} check can't stub a call yet` : !best.patch && !best.end ? 'the check can\'t stub it' : ''
      hint = `${best.refusal.replace(/ \(answer it, skip it, or read that module\)$/, '')} (${best.at}), whose value is read, and ${cant || (!best.ret || best.ret.k === 'any' ? 'it declares no type' : `it returns ${best.ret.k === 'rec' ? `an object (${this.mod.recs[best.ret.name]?.short ?? best.ret.name})` : this.why(best.ret)}`)}: ${cant ? 'read its code, or keep its value unread' : `state what it returns (answers: {${short}: 'int'}, or a \`gdp: answer int\` comment on its line)`}`
    }
    for (const id of (e as Framed).frames ?? []) {
      const fn = this.mod.funcs[id.id]
      if (!fn || this.inf!.cut.has(id.id) || this.entryIds.has(id.id) || this.fnTag(fn)?.k === 'strict' || this.writesState(id.id, new Set(id.roots))) continue
      this.inf!.cut.set(id.id, `${e.where}: ${e.what}`)
      return undefined
    }
    // (last: a value returned by the module's own function, writing none of the state: that function cut, answered by
    // its declared type)
    const fn = best && this.cuttable(best.why)
    if (fn) { this.inf!.cut.set(fn.id, `${e.where}: ${e.what}`); return undefined }
    return hint ? new Refusal(e.where, `${e.what}; ${hint}`) : e
  }

  // --- expressions ----------------------------------------------------------------------------------------------------
  ev(x: SX, p: Path, awaited = false): [V, Path] {
    switch (x.e) {
      case 'int': { const ty = (x.ity as IntTy | undefined) ?? (x.ty ? this.intTy(x.ty as SType) : undefined); return [{t: 'num', e: I.num(Number(x.v)), ...(ty ? {ty} : {})}, p] }
      case 'unit': return [{t: 'none'}, p]
      case 'opaque': return [{t: 'opaque', why: String(x.why), ...(x.firm ? {firm: true} : {}), ...(x.sink ? {sink: true} : {})}, p]
      case 'ref': case 'lock': return this.ev(x.x as SX, p)
      case 'copy': { const [v, q] = this.ev(x.x as SX, p); return this.copy(v, q, x) }
      case 'cast': return this.cast(x, p)
      case 'clock': return this.clock(x, p)
      case 'some': { const [v, q] = this.ev(x.x as SX, p); return [{t: 'opt', has: I.T, v}, q] }
      case 'ok': case 'err': { const [v, q] = this.ev(x.x as SX, p); return [{t: 'res', ok: x.e === 'ok' ? I.T : I.F, v: x.e === 'ok' ? v : {t: 'none'}, e: x.e === 'err' ? v : {t: 'none'}}, q] }
      case 'is': { const [v, q] = this.ev(x.x as SX, p); return [{t: 'bool', e: this.isOf(v, String(x.k), x)}, q] }
      case 'unwrap': { const [v, q] = this.ev(x.x as SX, p); return [this.inner(v, String(x.k), x), q] }
      case 'expect': {
        const [v, q] = this.ev(x.x as SX, p)
        const good = this.isOf(v, 'good', x)
        this.fail(q, I.not(good), x, x.npe ? `${x.text}: null unboxed (a NullPointerException)` : `${x.text}: unwrap of ${v.t === 'res' ? 'an Err' : 'None'} (a panic)`)
        return [this.inner(v, 'good', x), this.assume(q, good)]
      }
      case 'opt_or': {
        const [v, q] = this.ev(x.x as SX, p)
        const good = this.isOf(v, 'good', x), val = this.inner(v, 'good', x)
        const [d, q2] = (x.d as SX).e === 'zero' ? [zeroLike(val), q] as [V, Path] : this.ev(x.d as SX, q)
        return [this.ite(good, val, d, x), q2]
      }
      // The bad case of a value `?` returns: an Err with its error, or None.
      case 'bad': { const [v, q] = this.ev(x.x as SX, p); return [v.t === 'res' ? {t: 'res', ok: I.F, v: {t: 'none'}, e: v.e} : {t: 'none'}, q] }
      case 'res_ok': { const [v, q] = this.ev(x.x as SX, p); return [v.t === 'res' ? {t: 'opt', has: v.ok, v: v.v} : v, q] }
      case 'variant': return [{t: 'choice', e: I.llit(String(x.v), x.values as string[])}, p]
      case 'closure': {
        const caps = new Map<string, V>()
        for (const n of x.caps as string[]) { const v = p.locals.get(n); if (v) caps.set(n, v) }
        return [{t: 'fn', id: String(x.id), caps}, p]
      }
      case 'new': {
        let q = p
        const f = new Map<string, V>()
        for (const [n, y] of x.fields as [string, SX][]) { const [v, q2] = this.ev(y, q); f.set(n, v); q = q2 }
        const r = this.rec(String(x.rec), x)
        for (const fd of r.fields) if (!f.has(fd.name)) return refuse(x, `${x.text}: ${fd.name} not given`)
        for (const fd of r.fields) { const v = f.get(fd.name)!; if (fd.t.k === 'choice' && v.t === 'str' && v.e.op === 'slit') f.set(fd.name, {t: 'choice', e: I.llit(v.e.value, fd.t.values)}); const ty = this.intTy(fd.t); if (ty && v.t === 'num' && !v.ty) f.set(fd.name, {...v, ty}) }
        const id = `fresh:${this.fresh++}`
        return [{t: 'ref', id}, {...q, heap: new Map(q.heap).set(id, {k: 'rec', ty: String(x.rec), f, origin: 'fresh'})}]
      }
      // An immutable update (Elixir's %{s | f: v}): a fresh copy of the record, the fields given set in it.
      case 'upd': {
        const [o, q] = this.ev(x.x as SX, p)
        let [c, q2] = this.copy(o, q, x)
        // (Elixir's %{m | k: v}, strict: a key the map doesn't hold is a KeyError)
        const r = c.t === 'ref' && x.strict ? this.mod.recs[(q2.heap.get(c.id) as {ty?: string} | undefined)?.ty ?? ''] : undefined, gone = (x.fields as [string, SX][]).find(([f]) => r && !r.fields.some(y => y.name === f))
        if (gone) { this.fail(q2, I.T, x, `${x.text}: ${gone[0]}, a key the map doesn't hold (a KeyError)`); return [{t: 'opaque', why: 'unreachable'}, {...q2, pc: [...q2.pc, I.F]}] }
        for (const [f, y] of x.fields as [string, SX][]) { const [v, q3] = this.ev(y, q2); q2 = this.setField(c, f, v, x, q3) }
        return [c, q2]
      }
      case 'rmw': return this.rmw(x, p)
      case 'bool': return [{t: 'bool', e: x.v ? I.T : I.F}, p]
      case 'str': return [{t: 'str', e: {op: 'slit', value: String(x.v)}}, p]
      case 'none': return [{t: 'none'}, p]
      case 'var': {
        const v = p.locals.get(String(x.n))
        // (Python's local read on a path that never set it, past a raise caught before its assignment: an
        // UnboundLocalError on that path)
        // (Ruby's local read before it is set: nil)
        if (!v && !x.why && this.mod.lang === 'ruby') return [{t: 'none'}, p]
        if (!v && !x.why && this.mod.lang === 'python') { this.fail(p, I.T, x, `${String(x.n)}: a local read before it is set (an UnboundLocalError)`); return [{t: 'opaque', why: 'unreachable'}, {...p, pc: [...p.pc, I.F]}] }
        if (!v) return refuse(x, (x.why as string | undefined) ?? `${String(x.n)}: a variable read before it is set`)
        return [this.narrow(v, p), p]
      }
      case 'fn': return [{t: 'fn', id: String(x.id)}, p]
      case 'cls': return [{t: 'cls', rec: String(x.rec), ...(x.patch ? {patch: x.patch as Patch} : {})}, p]
      case 'builtin': return [{t: 'builtin', n: String(x.n)}, p]
      case 'lib': return [{t: 'lib', q: String(x.q)}, p]
      case 'ext': {
        // (a module's object a stated store names, Django's `cache`, a client made at import: the store, the check
        // giving one in its place)
        const pt = x.patch as Patch | undefined
        if (this.opts.stores?.[String(x.text)] && pt?.mod && pt.path?.length === 1) {
          const name = String(x.text), id = `store:${name}`
          if (!this.initHeap.has(id)) { this.initHeap.set(id, {k: 'store', name}); this.storeKeyed.add(name); this.globalStores.push({name, mod: pt.mod}); this.notes.add(`${name}: a store (stated), the module's object, the check giving one in its place`) }
          if (!p.heap.has(id)) p.heap.set(id, this.initHeap.get(id)!)
          return [{t: 'ref', id}, p]
        }
        return [{t: 'ext', q: String(x.q), text: String(x.text), ...(x.patch ? {patch: x.patch as Patch} : {}), ...(x.ret ? {ret: x.ret as SType} : {}), ...(x.nothrow ? {nothrow: true} : {})}, p]
      }
      case 'no': {
        // (a call of other code a reader doesn't lower, `ext` its name: at the boundary, where it is inferred)
        if (x.ext && !x.pre && !x.prepl) {
          const names = [x.ext as string], ans = this.match(Object.keys(this.opts.answers ?? {}), names), patch = x.patch as Patch | undefined
          // (a stub stated: nothing run, None returned, its arguments not read)
          const st = this.match(this.opts.stubs, names)
          if (st && patch) { const key = st.split('.').pop()!; if (!this.answers.has(key)) { this.answers.set(key, {key, patch, async: false, inputs: {name: ''}, sort: '', pass: true, effect: true, quiet: true, at: []}); this.notes.add(`${key} (${x.p}): stubbed (stated): it does nothing and returns None in the check`) } return [{t: 'none'}, p] }
          if (ans) return this.answer(ans, names, patch, x, x.args ? this.argsRead(x, p) : p, false)
          if (this.skipped(names)) { for (const n of names) this.leftOut.add(n); this.notes.add(`${names[0]} (${x.p}): left out (stated: skip), run as it is by the check`); return [{t: 'opaque', why: `${names[0]}: the value of a call left out (skip)`}, this.passing(names[0]!, names[0]!, patch, x, x.args ? this.argsRead(x, p) : p, false)] }
          let q = p, recv: V | undefined
          if (x.recv && this.inf) [recv, q] = this.ev(x.recv as SX, q)
          if (this.inf) return this.boundary(x, {key: names[0]!, name: names[0]!, refusal: String(x.why), ...(x.args ? {} : {args: false}), ...(recv ? {recv} : {}), ...(x.ret ? {ret: x.ret as SType} : {}), ...(patch ? {patch} : {})}, q, false)
        }
        let q = p; for (const y of (x.pre as SX[] | undefined) ?? []) q = this.ev(y, q)[1]; if (x.prepl) this.place(x.prepl as SX, q); return refuse(x, String(x.why)) }
      case 'nil': return [{t: 'nil'}, p]
      case 'ptr0': return [{t: 'ptr', to: {k: 'nil'}}, p]
      case 'errv': { let q = p; for (const y of (x.pre as SX[] | undefined) ?? []) q = this.ev(y, q)[1]; if (x.note) this.notes.add(x.note as string); return [{t: 'err', is: x.is ? I.T : I.F}, q] }
      case 'struct': { let q = p; const f = new Map<string, V>(); for (const [n, y] of x.fields as [string, SX][]) { const [v, q2] = this.ev(y, q); f.set(n, v); q = q2 } return [{t: 'struct', ty: String(x.ty), f}, q] }
      case 'at': { const [pl, q] = this.place(x.pl as SX, p); if (pl.k === 'blank') return refuse(x, '_'); const [v, q2] = this.read(pl, x, q); if (v.t === 'opaque' && !x.raw) return refuse(x, v.why); return [v, q2] }
      case 'deref': { const [v, q] = this.ev(x.x as SX, p); return this.deref(v, [], x, q) }
      case 'as': { const [v, q] = this.ev(x.x as SX, p); if (v.t === 'num' && x.ity) return [{...v, ty: x.ity as IntTy}, q]; if (v.t === 'nil' && x.nil) return [x.nil === 'ptr' ? {t: 'ptr', to: {k: 'nil'}} : {t: 'err', is: I.F}, q]; return [v, q] }
      case 'conv': {
        const [v, q] = this.ev(x.x as SX, p), ty = x.ity as IntTy | undefined
        // (a bit form to an unsigned type: its bits below the type's width, the same form)
        if (ty && v.t === 'num' && v.bits && !ty.mod && ty.signed === false && ty.bits > 0 && ty.bits < 53) { const m = 2 ** ty.bits, f = {...v.bits, A: v.bits.A % m, B: v.bits.B % m}; return [{t: 'num', e: f.A === v.bits.A && f.B === v.bits.B ? v.e : this.ofBits(f, x), ty, bits: f}, q] }
        if (ty && v.t === 'num') return [{t: 'num', e: this.wrap(v.e, ty.ub ? {bits: ty.bits, signed: ty.signed, name: ty.name, t: ty.t} : ty, x, q), ty}, q]; return refuse(x, v.t === 'opaque' && v.ask ? `${String(x.why)}: of ${v.why}` : String(x.why)) }
      case 'binop': { const [a, q] = this.ev(x.x as SX, p), [b, q2] = this.ev(x.y as SX, q); return [this.binop(String(x.op), a, b, x, q2), q2] }
      case 'andalso': {
        // The right side runs only where the left doesn't decide: its failures and effects only there.
        const and = x.op === '&&', [a, q] = this.ev(x.x as SX, p), ab = this.boolv(a, x.x as SX), c = and ? ab : I.not(ab)
        const [b, q2] = this.ev(x.y as SX, this.assume(q, c)), bb = this.boolv(b, x.y as SX)
        return [{t: 'bool', e: and ? I.and(ab, bb) : I.or(ab, bb)}, q2.heap === q.heap ? q : this.merge({...q2, pc: [...q.pc, c]}, q, x)]
      }
      case 'unop': {
        const [a, q] = this.ev(x.x as SX, p), op = String(x.op)
        if (op === '!') return [{t: 'bool', e: I.not(this.boolv(a, x))}, q]
        if (op === '-') { if (a.t !== 'num') return refuse(x, `- of a ${a.t}`); return [{t: 'num', e: this.wrap(I.neg(a.e), a.ty!, x, q), ty: a.ty}, q] }
        if (op === '+') return [a, q]
        // (~x: −x − 1 in two's complement, at x's width)
        if (op === '^' && a.t === 'num') return [{t: 'num', e: this.wrap(I.sub(I.neg(a.e), I.num(1)), a.ty!, x, q), ty: a.ty}, q]
        return refuse(x, String(x.why))
      }
      case 'addr': {
        const [pl, q] = this.place(x.pl as SX, p)
        if (pl.k === 'heap' && pl.ptr.t === 'ptr') return [{t: 'ptr', to: this.shift(pl.ptr.to, pl.path)}, this.nonNil(pl.ptr.to, x, q, 'a nil dereference')[1]]
        return refuse(x, String(x.why))
      }
      case 'alloc': {
        const [v, q] = this.ev(x.x as SX, p), id = `new:${++this.fresh}`
        if (v.t !== 'struct') return refuse({p: ''}, 'new of other than a struct')
        return [{t: 'ptr', to: {k: 'obj', id, path: []}}, {...q, heap: new Map(q.heap).set(id, {k: 'rec', ty: v.ty, f: new Map(v.f), origin: 'fresh'})}]
      }
      case 'bignew': { if (!x.x) return this.newBig(I.num(0), p); const [v, q] = this.ev(x.x as SX, p); return this.newBig(this.numv(v, x), q) }
      case 'big': return this.bigCall(x, p)
      case 'mutex': return this.lockCall(x, p)
      case 'gcall': {
        const fn = this.func(String(x.fn), x), r = x.recv as SX | undefined
        let q = p, recv: V | undefined
        if (r?.e === 'addr') [recv, q] = this.ev(r, q)
        else if (r?.k === 'rd') { const [pl, q2] = this.place(r.pl as SX, q); [recv, q] = this.read(pl, x, q2) }
        else if (r) { const [v, q2] = this.ev(r.x as SX, q); q = q2; if (r.k === 'val' && v.t === 'ptr') [recv, q] = this.deref(v, [], x, q); else recv = v }
        const args: V[] = []
        for (const a of x.args as SX[]) { const [v, q2] = this.ev(a, q); args.push(v); q = q2 }
        return this.inline(fn, recv, args, x, q)
      }
      case 'len': {
        const [s, q] = this.ev(x.x as SX, p)
        if (x.k === 'str') { if (s.t !== 'str') refuse(x, 'len of a non-string'); return [{t: 'num', e: I.num(0), ty: x.ity as IntTy, slen: (s as {e: K}).e}, q] }
        return [{t: 'num', e: this.listLen(s, x, q), ty: x.ity as IntTy}, q]
      }
      case 'append': {
        const [s, q] = this.ev(x.s as SX, p), [v, q2] = this.ev(x.x as SX, q)
        if (s.t !== 'list') return refuse(x, 'append to other than a slice of the state')
        if (v.t === 'num' && v.slen) return refuse(x.at1 as SX, 'len of a string read other than against 0')
        return [{t: 'push', id: s.id, x: v}, q2]
      }
      case 'delete': { const [m, q] = this.ev(x.m as SX, p), [k, q2] = this.ev(x.k as SX, q); return [{t: 'tuple', xs: []}, this.mapDelete(m, k, x, q2)] }
      case 'newmap': return [{t: 'map', id: 'new-map'}, p]
      case 'newlist': return [{t: 'list', id: 'new-list'}, p]
      case 'minmax': {
        let q = p
        const vs: V[] = []
        for (const y of x.xs as SX[]) { const [v, q2] = this.ev(y, q); vs.push(v); q = q2 }
        let e = this.numv(vs[0]!, x)
        for (const v of vs.slice(1)) e = x.op === 'min' ? I.nmin(e, this.numv(v, x)) : I.nmax(e, this.numv(v, x))
        return [{t: 'num', e, ty: (x.ity as IntTy | undefined) ?? refuse(x, String(x.why))}, q]
      }
      case 'panic': { let q = p; for (const a of x.args as SX[]) q = this.ev(a, q)[1]; this.refuseWhere(q, I.T, x, (x.what as string | undefined) ?? 'a panic'); return [{t: 'tuple', xs: []}, {...q, pc: [...q.pc, I.F]}] }
      case 'midx': { const [b, q] = this.ev(x.m as SX, p), [i, q2] = this.ev(x.k as SX, q); return [this.mapRead(b, i, x, q2).v, q2] }
      case 'lidx': { const [b, q] = this.ev(x.s as SX, p), [i, q2] = this.ev(x.i as SX, q); return this.listGet(b, i, x, q2) }
      case 'pop': {
        const [s, q] = this.ev(x.s as SX, p)
        if (s.t === 'list' && x.ok) {
          const len = this.listLen(s, x, q)
          this.refuseWhere(q, I.cmp('<', len, I.num(1)), x, 'a slice out of range (a panic: s[:len(s)-1] of an empty s)')
          return [{t: 'pop', id: s.id}, this.assume(q, I.cmp('<=', I.num(1), len))]
        }
        return refuse(x, String(x.why))
      }
      case 'await': {
        const inner = x.x as SX
        if (inner.e !== 'call') return refuse(x, `await ${inner.text ?? ''}: an await of other than a call`)
        return this.ev(inner, p, true)
      }
      case 'get': return this.get(x, p)
      case 'idx': {
        const [m, q] = this.ev(x.x as SX, p), [k, q2] = this.ev(x.i as SX, q)
        // (an item of a value outside the subset: whether it holds one, and what, is that value's)
        if (m.t === 'opaque' && m.why === 'unreachable') return [m, q2]
        if (m.t === 'opaque') return refuse(x, `${x.text}: an item of ${m.why} (whether it holds one is that value's)`)
        if (m.t === 'val') return this.valItem(m, k, x, q2)
        const ord = this.orderedObj(m, q2)
        if (ord) {
          const i = constOf(k)
          if (i !== 0 && i !== -1) return refuse(x, `${x.text}: a list's item at a place other than the first or the last (xs[0], xs[-1])`)
          const it = this.item(ord[0], ord[1], x, i === -1)
          if (!this.holds(q2, it.some)) this.fail(q2, I.not(it.some), x, `${x.text}: an item of an empty list (an IndexError)`)
          return [it.v, this.assume(q2, it.held)]
        }
        return this.mapGet(m, this.keyOf(k, x.i as SX), x, q2, 'fail')
      }
      case 'neg': { const [v, q] = this.ev(x.x as SX, p); if (v.t === 'opaque' && v.ask) return refuse(x, `${x.text ?? '-'}: arithmetic on ${v.why} (what it does depends on that value)`); if (v.t === 'opaque') return [v, q]; return [{t: 'num', e: I.neg(this.numOf(v, x, q))}, q] }
      case 'not': { const [v, q] = this.ev(x.x as SX, p); if (v.t === 'opaque') return [v, q]; if (x.strict && v.t !== 'bool') return refuse(x, `${x.text ?? '!'}: a bitwise not`); return [{t: 'bool', e: I.not(this.truthy(v, x, q))}, q] }
      case 'bin': return this.bin(x, p)
      case 'cmp': return this.compare(x, p)
      case 'and': case 'or': return this.boolOp(x, p)
      case 'ite': {
        const [cv, q] = this.ev(x.c as SX, p)
        if (cv.t === 'opaque') return [cv, q]
        const c = this.truthy(cv, x.c as SX, q)
        if (c.op === 'const') return this.ev((c.v ? x.a : x.b) as SX, q)
        const [a, qa] = this.ev(x.a as SX, this.assume(q, c)), [b, qb] = this.ev(x.b as SX, this.assume(q, I.not(c)))
        return [this.ite(c, a, b, x), this.merge(qa, qb, x)]
      }
      case 'tuple': {
        let q = p
        const xs: V[] = []
        for (const y of x.xs as SX[]) { const [v, q2] = this.ev(y, q); xs.push(v); q = q2 }
        return [{t: 'tuple', xs}, q]
      }
      case 'fstr': return this.fstr(x, p)
      case 'dict': {
        if (!(x.keys as SX[]).length) return [{t: 'opaque', why: '{} (an empty dict, a map only where a field declares its type)'}, p]
        // (string keys known here, a record by value: its keys its fields)
        let q = p
        const f = new Map<string, V>()
        for (const [i, kx] of (x.keys as SX[]).entries()) {
          const [k, q1] = this.ev(kx, q), ks = strLit(k)
          if (ks === undefined) return refuse(x, `${x.text ?? 'a dict literal'}: a dict literal whose keys aren't strings known where it is made (a record is made by its class)`)
          const [v, q2] = this.ev((x.vals as SX[])[i]!, q1)
          f.set(ks, v); q = q2
        }
        return [{t: 'val', ty: '$dict', f}, q]
      }
      // (an empty list: an ordered collection where a field of the state declares a list of records or numbers)
      case 'list': return (x.xs as SX[]).length ? refuse(x, 'a list literal with items (the subset keeps a list of the state, made empty)') : [{t: 'opaque', why: '[] (an empty list, a collection only where a field declares its type)'}, p]
      case 'lambda': return refuse(x, `${x.text}: a lambda (a closure; read only as min's or max's key over a collection of the state)`)
      case 'call': return this.call(x, p, awaited)
      case 'fold': return this.foldExpr(x, p)
      // (a / k rounded to a whole number, by a reader's own rounding: Math.round, math.Round, f64::round, floorDiv ...)
      // (an integer converted to a float of `bits` bits (Java's (float) p): itself below 2^bits, an edge past it)
      case 'fbits': {
        const [v, q] = this.ev(x.x as SX, p)
        if (v.t !== 'num') return [v, q]
        this.refuseWhere(q, I.or(I.cmp('<=', I.num(2 ** (x.bits as number)), v.e), I.cmp('<=', v.e, I.num(-(2 ** (x.bits as number))))), x, `${x.text}: converted to a float at |x| of 2^${x.bits as number} or more (past its precision)`, false)
        return [v, q]
      }
      // (of a whole number, itself; of another float, a value outside the subset where it is read)
      case 'rnd': {
        const d = x.x as SX
        if (d.e === 'bin' && d.op === '/' && !d.ovf) return this.quotient(d, p, x.mode as 'floor')
        const [v, q] = this.ev(d, p)
        return v.t === 'num' || v.t === 'opaque' ? [v, q] : refuse(x, `${x.text}: a rounding of a ${v.t}`)
      }
    }
    return refuse(x, `${x.text ?? x.e}: an expression the subset doesn't read`)
  }
  // A value read by value (Rust's copies and moves): an object copied whole into a fresh one, a map's record too.
  copy(v: V, p: Path, at: SX): [V, Path] {
    if (v.t === 'cell') { const m = p.heap.get(v.map) as Extract<Obj, {k: 'map'}>, c = this.cellOf(m, v.key, p, at); const id = `fresh:${this.fresh++}`; return [{t: 'ref', id}, {...p, heap: new Map(p.heap).set(id, {k: 'rec', ty: (m.val as {name: string}).name, f: new Map(c.vals), origin: 'fresh'})}] }
    if (v.t === 'opt') { const [w, q] = this.copy(v.v, p, at); return [{...v, v: w}, q] }
    if (v.t !== 'ref') return [v, p]
    const o = p.heap.get(v.id)
    if (o?.k !== 'rec') return o?.k === 'map' ? refuse(at, `${at.text ?? ''}: a map copied whole`) : [v, p]
    let q = p
    const f = new Map<string, V>()
    for (const [n, w] of o.f) { const [c, q2] = this.copy(w, q, at); f.set(n, c); q = q2 }
    const id = `fresh:${this.fresh++}`
    return [{t: 'ref', id}, {...q, heap: new Map(q.heap).set(id, {k: 'rec', ty: o.ty, f, origin: 'fresh', ...(o.lazy && o.origin === 'input' ? {} : {})})}]
  }
  // Which of its cases a value is: Some / None, Ok / Err, good (Some or Ok) / bad.
  isOf(v: V, k: string, at: SX): B {
    if (v.t === 'opt') return k === 'some' || k === 'good' ? v.has : k === 'none' || k === 'bad' ? I.not(v.has) : refuse(at, `${at.text ?? ''}: an Option tested as ${k}`)
    if (v.t === 'none') return k === 'none' || k === 'bad' ? I.T : k === 'some' || k === 'good' ? I.F : refuse(at, `${at.text ?? ''}: None tested as ${k}`)
    if (v.t === 'res') return k === 'ok' || k === 'good' ? v.ok : k === 'err' || k === 'bad' ? I.not(v.ok) : refuse(at, `${at.text ?? ''}: a Result tested as ${k}`)
    if (v.t === 'opaque') return refuse(at, `${at.text ?? ''}: ${v.why}`)
    return k === 'some' || k === 'good' ? I.T : k === 'none' || k === 'bad' ? I.F : refuse(at, `${at.text ?? ''}: a ${v.t} tested as ${k}`)
  }
  inner(v: V, k: string, at: SX): V {
    if (v.t === 'opt') return v.v
    if (v.t === 'res') return k === 'err' ? v.e : v.v
    if (v.t === 'none') return {t: 'none'}
    if (v.t === 'opaque') return v
    return k === 'err' ? refuse(at, `${at.text ?? ''}: the Err of a value that is no Result`) : v
  }
  // An atomic's operation on the field it is: read, written, or both (one step is one call).
  rmw(x: SX, p: Path): [V, Path] {
    const place = x.place as SX, op = String(x.op), args = x.args as SX[]
    const [cur, q] = this.ev(place, p)
    if (cur.t !== 'num' && cur.t !== 'bool') return refuse(x, `${x.text}: an atomic of ${cur.t === 'opaque' ? cur.why : `a ${cur.t}`}`)
    this.notes.add(`${x.text} (${x.p}): an atomic read and written as the field it is (each request one step: the claim is for calls that don't interleave)`)
    const argv: V[] = []
    let q2 = q
    for (const a of args) { const [v, q3] = this.ev(a, q2); argv.push(v); q2 = q3 }
    const wrap = (e: N): V => { const ty = cur.t === 'num' ? cur.ty : undefined; return ty ? {t: 'num', e: this.wrap(e, ty, x, q2), ty} : {t: 'num', e} }
    const set = (v: V) => this.assign(place, v, x, q2)
    switch (op) {
      case 'load': return [cur, q2]
      case 'store': return [{t: 'none'}, set(argv[0]!)]
      case 'swap': return [cur, set(argv[0]!)]
      case 'fetch_add': case 'fetch_sub': return [cur, set(wrap(op === 'fetch_add' ? I.add(this.numOf(cur, x, q2), this.numOf(argv[0]!, x, q2)) : I.sub(this.numOf(cur, x, q2), this.numOf(argv[0]!, x, q2))))]
      case 'fetch_max': case 'fetch_min': return [cur, set({...cur, e: op === 'fetch_max' ? I.nmax(this.numOf(cur, x, q2), this.numOf(argv[0]!, x, q2)) : I.nmin(this.numOf(cur, x, q2), this.numOf(argv[0]!, x, q2))} as V)]
      case 'compare_exchange': case 'compare_exchange_weak': {
        const c = this.equal(cur, argv[0]!, x, q2)
        if (op === 'compare_exchange_weak') this.notes.add(`${x.text}: compare_exchange_weak read as compare_exchange (it may fail spuriously: the claim is for calls where it doesn't)`)
        return [{t: 'res', ok: c, v: cur, e: cur}, set(this.ite(c, argv[1]!, cur, x))]
      }
    }
    return refuse(x, `${x.text}: an atomic's ${op}`)
  }
  classConstant(value: number | string | boolean | null, at: SX): V {
    if (value === null) return {t: 'none'}
    if (typeof value === 'boolean') return {t: 'bool', e: value ? I.T : I.F}
    if (typeof value === 'number') return Number.isInteger(value) ? {t: 'num', e: I.num(value)} : {t: 'opaque', why: `${at.text}: a float`}
    return {t: 'str', e: {op: 'slit', value}}
  }
  classCollection(owner: string, name: string): V {
    this.notes.add(`${owner}.${name}: a class collection, preserved by the original code; its contents and shared identity are outside the modeled state, never copied or frozen`)
    return {t: 'opaque', why: `${owner}.${name}: a shared class collection outside the modeled state`}
  }
  get(x: SX, p: Path): [V, Path] {
    const [o, q] = this.ev(x.x as SX, p), f = String(x.f)
    switch (o.t) {
      case 'opaque': if (o.sattr) return this.storeAttr(o.sattr.store, `${o.sattr.path}.${f}`, x, q); return [{t: 'opaque', why: o.why, ...(o.ask ? {ask: o.ask} : {})}, q]
      case 'ext': return [{t: 'ext', q: `${o.q}.${f}`, text: `${o.text}.${f}`, ...(o.patch?.path ? {patch: {...o.patch, path: [...o.patch.path, f]}} : {}), ...(o.nothrow ? {nothrow: true} : {})}, q]
      case 'none': this.fail(q, I.T, x, `${x.text}: a field of None (an AttributeError)`); return [{t: 'opaque', why: 'unreachable'}, {...q, pc: [...q.pc, I.F]}]
      case 'opt': { this.fail(q, I.not(o.has), x, `${x.text}: a field of None (an AttributeError)`); const [v2, q3] = this.get({...x, x: {e: 'var', n: '$v', p: x.p}}, {...this.assume(q, o.has), locals: new Map(q.locals).set('$v', o.v)}); return [v2, {...q3, locals: q.locals}] }
      case 'sattr': case 'ref': break
      case 'cell': {
        const m = q.heap.get(o.map) as Extract<Obj, {k: 'map'}>, c = this.cellOf(m, o.key, q, x)
        return [c.vals.get(f) ?? refuse(x, `${x.text}: no field ${f}`), q]
      }
      case 'cls': {
        const r = this.rec(o.rec, x), mid = r.methods[f]
        if (r.orm && f === 'objects' && r.orm.framework !== 'sqlalchemy') return [{t: 'ext', q: `orm:${r.name}`, text: x.text ?? f}, q]
        if (mid) return [{t: 'fn', id: mid}, q]
        const ca = r.cattrs?.[f]
        if (ca !== undefined) return [this.classConstant(ca, x), q]
        if (r.classCollections?.[f]) return [this.classCollection(r.classCollections[f]!, f), q]
        return [{t: 'ext', q: `${o.rec}.${f}`, text: x.text ?? f, ...(o.patch?.path ? {patch: {...o.patch, path: [...o.patch.path, f]}} : {}), ...(r.rets?.[f] ? {ret: r.rets[f]} : {})}, q]
      }
      case 'bool': case 'builtin': case 'choice': case 'fmt': case 'fn': case 'lib': case 'lock': case 'num': case 'str': case 'tuple': case 'res': case 'ptr': case 'struct': case 'err': case 'nil': case 'map': case 'list': case 'push': case 'pop': case 'val': return refuse(x, `${x.text}: a field of a ${o.t === 'val' ? o.ty.slice(1) : o.t}`)
    }
    if (o.t === 'sattr') return this.storeAttr(o.store, o.path ? `${o.path}.${f}` : f, x, q)
    const obj = q.heap.get(o.id)
    if (obj?.k === 'store') return this.storeAttr(obj.name, f, x, q)
    if (obj?.k !== 'rec') return refuse(x, `${x.text}: a field of other than an object`)
    const r = this.rec(obj.ty, x)
    // Python super starts after the defining owner in the actual receiver's
    // C3 order. Only an owner's own binding may win, not its flattened methods.
    if (typeof x.superFrom === 'string') {
      const index = r.mro?.indexOf(x.superFrom) ?? -1
      if (index < 0) return refuse(x, `${x.text}: the receiver's MRO cannot be bound`)
      const owner = r.mro!.slice(index + 1).find(name => this.rec(name, x).declared?.includes(f))
      if (!owner) {
        if (f === '__init__') return [{t: 'builtin', n: '$object_init'}, q]
        return refuse(x, `${x.text}: no inherited attribute ${f} after ${x.superFrom}`)
      }
      const base = this.rec(owner, x), id = base.methods[f]
      if (id) {
        const fn = this.func(id, x)
        if (fn.decorators.some(d => d.name === 'property')) return this.callFunc(fn, o, [], [], x, q, false)
        return [{t: 'fn', id, self: fn.static ? undefined : o}, q]
      }
      const ca = base.cattrs?.[f]
      if (ca !== undefined) return [this.classConstant(ca, x), q]
      if (base.classCollections?.[f]) return [this.classCollection(base.classCollections[f]!, f), q]
      return refuse(x, `${x.text}: inherited attribute ${owner}.${f} cannot be bound`)
    }
    // (a base method already resolved by a reader, on this object)
    if (typeof x.sup === 'string') return [{t: 'fn', id: x.sup, self: o}, q]
    const v = obj.f.get(f)
    if (v) return [this.timeField(v, r.fields.find(fd => fd.name === f)?.t, true, x), q]
    const mid = r.methods[f]
    if (mid !== undefined) {
      if (mid === null) return this.inf ? [{t: 'ext', q: `${r.name}.${f}`, text: x.text ?? f, patch: {mod: r.module, path: [r.short, f]}, recv: o, ...(r.rets?.[f] ? {ret: r.rets[f]} : {})}, q] : refuse(x, `${x.text}: a method of another module's class`)
      const fn = this.func(mid, x)
      if (fn.decorators.some(d => d.name === 'property')) return this.callFunc(fn, o, [], [], x, q, false)
      return [{t: 'fn', id: mid, self: fn.static ? undefined : o}, q]
    }
    if (obj.lazy) return this.lazyField(o.id, obj, f, x, q)
    // (a class attribute set to a constant, which no method sets on the object: that constant)
    const ca = r.cattrs?.[f]
    if (ca !== undefined) return [this.classConstant(ca, x), q]
    if (r.classCollections?.[f]) return [this.classCollection(r.classCollections[f]!, f), q]
    return refuse(x, `${x.text}: no field ${f} (the object's fields are those its constructor sets)`)
  }
  // A field of an object the caller gives, made an input where it is first read.
  lazyField(id: string, obj: Extract<Obj, {k: 'rec'}>, f: string, x: SX, p: Path): [V, Path] {
    const r = this.rec(obj.ty, x), fd = r.fields.find(g => g.name === f)
    if (!fd) return refuse(x, `${x.text}: ${f}, a field ${r.short} doesn't declare`)
    const li = this.lazy.get(id)!
    const had = li.vals.get(f)
    if (had) { p.heap.set(id, {...obj, f: new Map(obj.f).set(f, had)}); return [had, p] }
    const [v, a] = this.input(`${li.prefix}_${f}`, fd.t, x, p)
    li.args.push([f, a]); li.vals.set(f, v)
    p.heap.set(id, {...obj, f: new Map(obj.f).set(f, v)})
    return [v, p]
  }
  storeAttr(store: string, path: string, x: SX, p: Path): [V, Path] {
    const attrs = this.storeDecl(store).attrs ?? {}
    if (path in attrs) {
      const v = attrs[path]!
      this.notes.add(`${store}.${path} is ${JSON.stringify(v)} (stated)`)
      return [v === null ? {t: 'none'} : typeof v === 'boolean' ? {t: 'bool', e: v ? I.T : I.F} : typeof v === 'number' ? {t: 'num', e: I.num(v)} : {t: 'str', e: {op: 'slit', value: v}}, p]
    }
    if (Object.keys(attrs).some(k => k.startsWith(`${path}.`))) return [{t: 'sattr', store, path}, p]
    return [{t: 'opaque', why: `${x.text}: an attribute of the store not stated${this.inf ? ` (where the rule reads it, state its value: stores: {${store}: {attrs: {${JSON.stringify(path)}: null}}})` : ''}`, ...(this.inf ? {sattr: {store, path}} : {})}, p]
  }
  bin(x: SX, p: Path): [V, Path] {
    const op = String(x.op)
    if (x.ovf) return this.fixed(x, p)
    const [a, q] = this.ev(x.x as SX, p), [b, q2] = this.ev(x.y as SX, q)
    if (a.t === 'val' || b.t === 'val') return [this.valBin(op, a, b, x, q2), q2]
    // A true division: a float, kept only where nothing the rule keeps reads it (refused there); its divisor 0 fails.
    if (op === '/') {
      // (a float division of a reader's (Java's): no failure at 0, an infinity or NaN)
      if (x.fdiv) return [{t: 'opaque', why: `${x.text}: a float division (read where it is rounded to a whole number: Math.round, floor, ceil, rint or a cast)`}, q2]
      if (b.t === 'num' || b.t === 'bool') { const nb = this.numOf(b, x, q2); this.fail(q2, I.cmp('=', nb, I.num(0)), x, `${x.text}: a division by zero (a ZeroDivisionError)`); return [{t: 'opaque', why: `${x.text}: a true division (a float; the subset reads math.floor or math.ceil of x / k, int(x / k), or x // k)`}, this.assume(q2, I.not(I.cmp('=', nb, I.num(0))))] }
      return [{t: 'opaque', why: `${x.text}: a true division (a float; the subset reads math.floor or math.ceil of x / k, int(x / k), or x // k)`}, q2]
    }
    // (other code's value left out, computed with: whether that raises is that value's, so it is read)
    const asked = [a, b].find(v => v.t === 'opaque' && v.ask) as {why: string} | undefined
    if (asked) return refuse(x, `${x.text}: arithmetic on ${asked.why} (what it does depends on that value)`)
    if (a.t === 'opaque' || b.t === 'opaque') return [a.t === 'opaque' ? a : b, q2]
    if ((a.t === 'str' || a.t === 'fmt') && op === '+') return [{t: 'opaque', why: `${x.text}: strings joined`}, q2]
    if (a.t === 'str' && op === '%') {
      // ('...%s...' % x or % (x, y): %s and %d holes, %% a percent sign)
      const f = a.e.op === 'slit' ? a.e.value.split(/(%[sd%])/) : undefined, xs = b.t === 'tuple' ? b.xs : [b]
      if (!f || f.filter(t => t === '%s' || t === '%d').length !== xs.length) return [{t: 'opaque', why: `${x.text}: a string formatted`}, q2]
      let i = 0
      return this.fstr(x, q2, f.flatMap((t): (string | V)[] => (t === '%%' ? ['%'] : t === '%s' || t === '%d' ? [xs[i++]!] : t ? [t] : [])))
    }
    const na = this.numOf(a, x, q2), nb = this.numOf(b, x, q2)
    switch (op) {
      case '+': return [{t: 'num', e: I.add(na, nb)}, q2]
      case '-': return [{t: 'num', e: I.sub(na, nb)}, q2]
      case '*': return [{t: 'num', e: I.mul(na, nb)}, q2]
      case '//': case '%': {
        const k = constOf(b)
        if (k === undefined) return refuse(x, `${x.text}: a division by a value that isn't a constant`)
        if (k === 0) { this.fail(q2, I.T, x, `${x.text}: a division by zero (a ZeroDivisionError)`); return [{t: 'num', e: I.num(0)}, {...q2, pc: [...q2.pc, I.F]}] }
        const fl = this.floorDiv(na, k)
        return [{t: 'num', e: op === '//' ? fl : I.sub(na, I.mulk(k, fl))}, q2]
      }
    }
    return refuse(x, `${x.text}: ${op}`)
  }
  // Arithmetic with an overflow the reader states (Rust's, later C's): the result's type is its operands', and what
  // happens past its range is the operation's: a trap (a panic: the step's failure), a wrap (modulo 2^bits), a
  // saturation, or an Option (checked). Division and remainder truncate toward zero; by zero they trap.
  fixed(x: SX, p: Path): [V, Path] {
    const op = String(x.op), ovf = String(x.ovf)
    const [a, q] = this.ev(x.x as SX, p), [b, q2] = this.ev(x.y as SX, q)
    if (a.t === 'opaque' || b.t === 'opaque') return [a.t === 'opaque' ? a : b, q2]
    const na = this.numOf(a, x, q2), nb = this.numOf(b, x, q2)
    const ty = (x.ity as IntTy | undefined) ?? (a.t === 'num' ? a.ty : undefined) ?? (b.t === 'num' ? b.ty : undefined) ?? (ovf === 'sat0' || ovf === 'checked0' ? {bits: 0, signed: false} : undefined)
    let e: N
    if (op === '+') e = I.add(na, nb)
    else if (op === '-') e = I.sub(na, nb)
    else if (op === '*') e = I.mul(na, nb)
    else if (op === '/' || op === '%') {
      const k = constOf(b)
      if (k === undefined) return refuse(x, `${x.text}: a division by a value that isn't a constant`)
      if (k === 0) { this.fail(q2, I.T, x, `${x.text}: a division by zero (a panic)`); return [{t: 'num', e: I.num(0), ...(ty ? {ty} : {})}, {...q2, pc: [...q2.pc, I.F]}] }
      e = op === '/' ? (k < 0 ? I.neg(this.quot(na, -k)) : this.quot(na, k)) : this.rem(na, Math.abs(k))
    } else return refuse(x, `${x.text}: ${op}`)
    const out = (n: N): V => ({t: 'num', e: n, ...(ty ? {ty} : {})})
    const [lo, hi] = ty ? rangeOf(ty) : [-Infinity, Infinity], [below0, above0] = this.past(e, lo, hi, q2)
    // (a symbolic width: past it where the result may be at least its 2^bits; of two values below it, a difference is
    // never at or past it and a sum or a product never below 0)
    const above = ty?.mod ? (op === '-' ? I.F : this.pastMod(e, ty.mod)) : above0, below = ty?.mod && op !== '-' ? I.F : below0
    if (ty?.mod && ovf !== 'trap' && ovf !== 'checked' && ovf !== 'wrap') return refuse(x, `${x.text}: ${ovf} at ${tyName(ty)}`)
    switch (ovf) {
      case 'trap': this.fail(q2, I.or(below, above), x, `${x.text}: past ${tyName(ty)}'s range (${typeof x.trap === 'string' ? x.trap : `a panic: attempt to ${op === '+' ? 'add' : op === '-' ? 'subtract' : op === '*' ? 'multiply' : 'divide'} with overflow`})`); return [out(e), this.assume(q2, I.not(I.or(below, above)))]
      case 'sat': return [out(Number.isFinite(lo) || Number.isFinite(hi) ? I.nite(below, I.num(lo), I.nite(above, I.num(hi), e)) : e), q2]
      case 'sat0': return [out(I.nmax(e, I.num(0))), q2]
      case 'checked': return [{t: 'opt', has: I.not(I.or(below, above)), v: out(e)}, q2]
      case 'checked0': return [{t: 'opt', has: I.cmp('<=', I.num(0), e), v: out(e)}, q2]
      case 'wrap': return [out(ty ? this.wrap(e, ty, x, q2) : e), q2]
    }
    return refuse(x, `${x.text}: an overflow mode ${ovf}`)
  }
  // `x as T`: an integer into another width (wrapped where it may not fit), a C-like enum's discriminant, a bool's 0 or 1.
  cast(x: SX, p: Path): [V, Path] {
    const [v, q] = this.ev(x.x as SX, p), t = x.ty as SType, ty = this.intTy(t)
    if (v.t === 'opaque') return [v, q]
    let e: N
    if (v.t === 'num') e = v.e
    else if (v.t === 'bool') e = I.nite(v.e, I.num(1), I.num(0))
    else if (v.t === 'choice') {
      const vals = lvalues(v.e), discs = (x.x as SX).discs as number[] | undefined ?? this.discsOf(vals)
      e = vals.reduceRight((acc: N, val, i) => I.nite(I.is(v.e, val), I.num(discs[i] ?? i), acc), I.num(0))
    } else return refuse(x, `${x.text}: a ${v.t} cast`)
    if (!ty) return [{t: 'num', e}, q]
    const from = v.t === 'num' ? v.ty : {bits: 8, signed: false}
    const [lo, hi] = rangeOf(ty), [flo, fhi] = from ? rangeOf(from) : [-Infinity, Infinity]
    if (flo >= lo && fhi <= hi) return [{t: 'num', e, ty}, q]
    // (a narrowing cast of a value of a wider type: within the target's range by its bounds and the path's facts, or
    // refused where it isn't)
    const out = I.or(...this.past(e, lo, hi, q))
    if (!(out.op === 'const' && !out.v)) { this.refusals.push(I.and(this.cond(q), out)); this.notes.add(`${x.text} (${x.p}): a narrowing cast, refused where the value doesn't fit (it truncates)`) }
    return [{t: 'num', e, ty}, this.assume(q, I.not(out))]
  }
  discsOf(values: string[]): number[] { for (const e of Object.values(this.mod.enums ?? {})) if (e.values.join() === values.join()) return e.discs; return values.map((_, i) => i) }
  // ⌊a / k⌋ for a constant k (≠ 0): Python's // (and its float floor division at whole values).
  floorDiv(a: N, k: number): N { return k > 0 ? I.divk(k, a) : I.divk(-k, I.neg(a)) }
  compare(x: SX, p: Path): [V, Path] {
    const op = String(x.op)
    const [a, q] = this.ev(x.x as SX, p), [b, q2] = this.ev(x.y as SX, q)
    const out = (e: B): [V, Path] => [{t: 'bool', e}, q2]
    if (a.t === 'opaque' || b.t === 'opaque') return [a.t === 'opaque' ? a : b, q2]
    if (op === 'is' || op === 'is not') {
      const isNone = (v: V): B => (v.t === 'none' ? I.T : v.t === 'opt' ? I.not(v.has) : I.F)
      if (b.t !== 'none' && a.t !== 'none') return refuse(x, `${x.text}: an identity test of other than None`)
      const e = b.t === 'none' ? isNone(a) : isNone(b)
      return out(op === 'is' ? e : I.not(e))
    }
    if ((op === 'in' || op === 'not in') && this.listOf(b, q2, x)) {
      // (an item of a list, the request's or the state's: any(item == a for item in it), the fold)
      if (!callFree(x.y)) return refuse(x, `${x.text}: in a list made by a call`)
      const tmp = `__in${this.fresh++}`, it = `__item${this.fresh++}`, at = x.p, vr = (n: string): SX => ({e: 'var', n, p: at})
      const [v, q3] = this.foldExpr({e: 'fold', f: 'any', p: at, text: x.text, to: vr(it), over: x.y, x: {e: 'cmp', op: '==', x: vr(it), y: vr(tmp), p: at, text: x.text}, ifs: []}, {...q2, locals: new Map(q2.locals).set(tmp, a)})
      const locals = new Map(q3.locals)
      locals.delete(tmp)
      return [{t: 'bool', e: op === 'in' ? (v as {e: B}).e : I.not((v as {e: B}).e)}, {...q3, locals}]
    }
    if (op === 'in' || op === 'not in') {
      let e: B
      if (b.t === 'tuple') e = I.or(...b.xs.map(y => this.equal(a, y, x, q2)))
      else { const [, o] = this.mapObj(b, x, q2); e = this.cellOf(o, this.keyOf(a, x.x as SX), q2, x).has }
      return out(op === 'in' ? e : I.not(e))
    }
    const da = a.t === 'opt' ? a.v : a, db = b.t === 'opt' ? b.v : b
    if (da.t === 'val' && da.ty === '$dt' && db.t === 'val' && db.ty === '$dt') {
      const ah = a.t === 'opt' ? a.has : I.T, bh = b.t === 'opt' ? b.has : I.T
      const sameZone = I.same(da.f.get('utc') ?? {t: 'bool', e: I.F}, db.f.get('utc') ?? {t: 'bool', e: I.F})
      const na = this.numOf(da.f.get('ms')!, x, q2), nb = this.numOf(db.f.get('ms')!, x, q2)
      if (op === '==' || op === '!=') {
        const eq = this.equal(a, b, x, q2)
        return out(op === '==' ? eq : I.not(eq))
      }
      if (!sameZone) return refuse(x, 'mixed aware and naive datetimes')
      this.fail(q2, I.not(I.and(ah, bh)), x, `${x.text}: ordering None and a datetime (a TypeError)`)
      return out(op === '<' ? I.cmp('<', na, nb) : op === '<=' ? I.cmp('<=', na, nb) : op === '>' ? I.cmp('<', nb, na) : I.cmp('<=', nb, na))
    }
    if (op === '==' || op === '!=') { const e = this.equal(a, b, x, q2); return out(op === '==' ? e : I.not(e)) }
    if (a.t === 'str' || b.t === 'str' || a.t === 'choice' || b.t === 'choice') return refuse(x, `${x.text}: strings ordered (the subset compares them for equality)`)
    const na = this.numOf(a, x, q2), nb = this.numOf(b, x, q2)
    return out(op === '<' ? I.cmp('<', na, nb) : op === '<=' ? I.cmp('<=', na, nb) : op === '>' ? I.cmp('<', nb, na) : I.cmp('<=', nb, na))
  }
  equal(a: V, b: V, at: SX, p: Path): B {
    if (a.t === 'none' || b.t === 'none') { const o = a.t === 'none' ? b : a; return o.t === 'none' ? I.T : o.t === 'opt' ? I.not(o.has) : I.F }
    const da = a.t === 'opt' ? a.v : a, db = b.t === 'opt' ? b.v : b
    if (da.t === 'val' && da.ty === '$dt' && db.t === 'val' && db.ty === '$dt') {
      const ah = a.t === 'opt' ? a.has : I.T, bh = b.t === 'opt' ? b.has : I.T
      const same = I.same(da.f.get('utc') ?? {t: 'bool', e: I.F}, db.f.get('utc') ?? {t: 'bool', e: I.F})
      const values = same ? I.cmp('=', this.numOf(da.f.get('ms')!, at, p), this.numOf(db.f.get('ms')!, at, p)) : I.F
      return I.or(I.and(I.not(ah), I.not(bh)), I.and(ah, bh, values))
    }
    if (a.t === 'opt') return I.and(a.has, this.equal(a.v, b, at, p))
    if (b.t === 'opt') return I.and(b.has, this.equal(a, b.v, at, p))
    if (a.t === 'num' && b.t === 'num') return I.cmp('=', a.e, b.e)
    if (a.t === 'bool' && b.t === 'bool') return I.bite(a.e, b.e, I.not(b.e))
    if (a.t === 'str' && b.t === 'str') { const isB = (k: K) => (k.op === 'svar' ? this.bytesVars.has(k.name) : k.op === 'slit' ? false : undefined), x = isB(a.e), y = isB(b.e); return x !== undefined && y !== undefined && x !== y ? I.F : I.keq(a.e, b.e) }
    if (a.t === 'choice' && b.t === 'choice') return I.leq(a.e, b.e)
    if (a.t === 'choice' && b.t === 'str' && b.e.op === 'slit') return I.is(a.e, b.e.value)
    if (b.t === 'choice' && a.t === 'str' && a.e.op === 'slit') return I.is(b.e, a.e.value)
    if ((a.t === 'num' && b.t === 'str') || (a.t === 'str' && b.t === 'num')) return I.F
    return refuse(at, `${at.text}: ${a.t} == ${b.t}`)
  }
  // The truth of a condition: of and / or, its operands' truths (short-circuited), whatever kinds their values are
  // (bool(n and t > n), where `and`'s value would be a number on one path and a boolean on another).
  truth(x: SX, p: Path): [B, Path] {
    if (x.e === 'and' || x.e === 'or') {
      const xs = x.xs as SX[], isAnd = x.e === 'and'
      const go = (i: number, q: Path): [B, Path] => {
        const [c, q1] = this.truth(xs[i]!, q)
        if (i === xs.length - 1) return [c, q1]
        const stop = isAnd ? I.not(c) : c
        if (stop.op === 'const' && stop.v) return [isAnd ? I.F : I.T, q1]
        const [rest, q2] = go(i + 1, this.assume(q1, I.not(stop)))
        if (stop.op === 'const') return [rest, q2]
        return [isAnd ? I.and(c, rest) : I.or(c, rest), this.merge(this.assume(q1, stop), q2, x)]
      }
      return go(0, p)
    }
    if (x.e === 'not' && !x.strict) { const [c, q] = this.truth(x.x as SX, p); return [I.not(c), q] }
    const [v, q] = this.ev(x, p)
    if (v.t === 'opaque') return refuse(x, `${x.text ?? ''}: the truth of ${v.why}`)
    return [this.truthy(v, x, q), q]
  }
  // and / or: Python's give one of their operands (the first falsy, or the last; the first truthy, or the last).
  boolOp(x: SX, p: Path): [V, Path] {
    const xs = x.xs as SX[], isAnd = x.e === 'and'
    const go = (i: number, q: Path): [V, Path] => {
      const [v, q1] = this.ev(xs[i]!, q)
      if (i === xs.length - 1 || v.t === 'opaque') return [v, q1]
      const c = this.truthy(v, xs[i]!, q1)
      const stop = isAnd ? I.not(c) : c
      if (stop.op === 'const' && stop.v) return [v, q1]
      const [rest, q2] = go(i + 1, this.assume(q1, I.not(stop)))
      if (stop.op === 'const') return [rest, q2]
      // (the operand kept where it stops: an optional value is its value where it is truthy)
      const kept = !isAnd && v.t === 'opt' ? v.v : v
      return [this.ite(stop, kept, rest, x), this.merge(this.assume(q1, stop), q2, x)]
    }
    return go(0, p)
  }
  // An f-string: with one hole between literal text, a key a store reads by (its template); else a value kept only
  // where nothing reads it.
  // A constant string in a hole (a literal, a stated attribute: a store's name) is literal text of the template; a
  // % format ('%s.lock.%s' % (a, b)) is read as the f-string it spells.
  checkOrmDisplay(v: V, at: SX): void {
    // Formatting can call user code even when its result is discarded. Keep
    // non-scalar conversion outside the boundary if a modeled ORM class has
    // display hooks; this also covers containers/optionals holding such rows.
    if (this.mod.lang === 'python' && !['num', 'bool', 'str', 'choice', 'none'].includes(v.t) &&
        Object.values(this.mod.recs).some(r => r.orm && ('__str__' in r.methods || '__repr__' in r.methods)))
      refuse(at, `${at.text}: implicit ORM display conversion may execute custom methods`)
  }
  fstr(x: SX, p: Path, given?: (string | V)[]): [V, Path] {
    const parts = given ?? x.parts as (string | {x: SX, plain: boolean})[]
    let q = p, tpl = '', hole: K | undefined, n = 0, opaque = false, ask: V | undefined
    for (const part of parts) {
      if (typeof part === 'string') { tpl += part.replace(/\{\}/g, '{ }'); continue }
      let v: V
      const plain = 't' in part || part.plain
      if ('t' in part) v = part
      else { const [v1, q2] = this.ev(part.x, q); v = v1; q = q2 }
      this.checkOrmDisplay(v, x)
      if (v.t === 'str' && v.e.op === 'slit' && plain) { tpl += v.e.value.replace(/\{\}/g, '{ }'); continue }
      n++
      if (v.t === 'opaque' && v.ask) ask ??= v
      if (!plain || n > 1 || !(v.t === 'str' || v.t === 'num')) { opaque = true; continue }
      hole = v.t === 'str' ? v.e : {op: 'num', e: v.e}
      tpl += '{}'
    }
    if (ask?.t === 'opaque') return [{t: 'opaque', why: `${x.text}: a formatted string (${ask.why})`, ask: ask.ask}, q]
    if (opaque || !hole) return [{t: 'opaque', why: `${x.text}: a formatted string`}, q]
    return [{t: 'fmt', tpl, k: hole}, q]
  }
  call(x: SX, p: Path, awaited: boolean): [V, Path] {
    if (dead(p)) return [{t: 'opaque', why: 'unreachable'}, p]
    const fx = x.f as SX, names = this.calleeNames(x), args0 = x.args as SX[], kw0 = x.kw as [string, SX][]
    // The boundary first: an effect, an answered call, then a skipped one (none's arguments read but an effect's).
    const quiet = this.match(this.opts.stubs, names), eff = quiet ?? this.match(this.opts.effects, names) ?? (this.tagAt(x.p)?.k === 'effect' ? names[0] : undefined)
    const ans = !eff ? this.match(Object.keys(this.opts.answers ?? {}), names) : undefined, skip = !eff && !ans && this.skipped(names)
    if (ans || skip || eff) {
      let patch: Patch | undefined
      if (!ans && !eff && !this.tries.length) {} // (left out outside a try: run as it is, no stub)
      else if (fx.e === 'fn') patch = {mod: this.mod.module, path: [String(fx.id)]}
      else if (fx.e === 'get' && (fx.x as SX).e === 'var' && (fx.x as SX).n === 'self') patch = {self: String(fx.f)}
      else if (fx.e === 'get') {
        // A method of an object the caller gives, of another module's class: the class's method stubbed.
        const [o] = this.ev(fx.x as SX, p), obj = o.t === 'ref' ? p.heap.get(o.id) : undefined
        // (a class's method, Redis.from_url: stubbed on the class where the module reads it)
        if (o.t === 'cls' && o.patch?.path && (eff || ans)) patch = {...o.patch, path: [...o.patch.path, String(fx.f)]}
        else if (obj?.k === 'rec') { const r = this.rec(obj.ty, x); patch = {mod: r.module, path: [r.short, String(fx.f)]} }
        // (a method of a store or an injected dependency: stubbed on the one the check gives)
        else if (obj?.k === 'store') patch = {store: (obj as {name: string}).name, path: [String(fx.f)]}
        else { const [v] = this.ev(fx, p); if (v.t === 'ext' || v.t === 'cls') patch = v.patch }
      } else { const [o] = this.ev(fx, p); if (o.t === 'ext' || o.t === 'cls') patch = o.patch }
      if (ans) return this.answer(ans, names, patch, x, this.argsRead(x, p), awaited)
      if (eff) {
        if (!patch) return refuse(x, `${x.text}: an effect the check can't stub (a function of the module, a method of the object, a store or another module's)`)
        const key = eff.split('.').pop()!
        const a = this.answers.get(key)
        if (a && !a.effect) return refuse(x, `${x.text}: ${key} an effect at one call and not at another`)
        if (!a) { this.answers.set(key, {key, patch, async: awaited, inputs: {name: ''}, sort: '', pass: true, effect: true, ...(quiet ? {quiet: true} : {}), at: []}); this.notes.add(quiet ? `${key} (${x.p}): stubbed (stated): it does nothing and returns None in the check` : `${key}: an effect (${this.opts.effects?.length ? 'stated' : 'tagged'}): each step says whether it called it (${key}.called), the check stubbing it`) }
        if (quiet) return [{t: 'none'}, p]
        const q = this.argsRead(x, p)
        return [{t: 'none'}, {...q, eff: new Map(q.eff).set(key, I.T)}]
      }
      for (const n of names) this.leftOut.add(n)
      this.notes.add(`${names[0]} (${x.p}): left out (stated: skip), run as it is by the check`)
      return [{t: 'opaque', why: `${x.text}: the value of a call left out (skip)`}, this.passing(names[0]!, names[0]!, patch, x, this.argsRead(x, p), awaited)]
    }
    // The callee and its object.
    let f: V, q = p
    if (fx.e === 'get') {
      const [o, q1] = this.ev(fx.x as SX, q)
      q = q1
      if (o.t === 'ext' && o.q.startsWith('orm-session:')) return this.evArgs(x, q, (args, kw, q2) => this.ormSession(o.q.slice(12), String(fx.f), args, kw, x, q2))
      if (o.t === 'ext' && o.q.startsWith('orm:')) return this.evArgs(x, q, (args, kw, q2) => this.ormCall(o.q.slice(4), String(fx.f), args, kw, x, q2))
      if (o.t === 'ref') {
        const row = q.heap.get(o.id)
        if (row?.k === 'rec' && this.mod.recs[row.ty]?.orm && ['save', 'delete'].includes(String(fx.f))) return this.evArgs(x, q, (args, kw, q2) => this.ormPersist(o, String(fx.f), args, kw, x, q2))
      }
      if (o.t === 'val') return this.evArgs(x, q, (args, kw, q2) => this.valCall(o, String(fx.f), args, kw, x, q2))
      const ord = this.orderedObj(o, q)
      if (ord) return this.listCall(ord[0], ord[1], String(fx.f), x, q)
      if (o.t === 'ref' && q.heap.get(o.id)?.k === 'map') return this.dictCall(o, String(fx.f), x, q)
      if (o.t === 'ref' && q.heap.get(o.id)?.k === 'store') return this.evArgs(x, q, (args, kw, q2) => this.storeCall((q.heap.get(o.id) as {name: string}).name, String(fx.f), args, kw, x, q2, awaited))
      if (o.t === 'sattr') return refuse(x, `${x.text}: a method of the store's ${o.path} (not stated)`)
      ;[f, q] = this.get(fx, q)
      if (o.t === 'opaque' && f.t === 'opaque') return this.inf ? this.boundary(x, {key: names[0] ?? String(x.text), name: names[0] ?? String(x.text), refusal: `${x.text}: a call on ${o.why}`, ...(o.sattr ? {recv: o} : {})}, q, awaited) : refuse(x, `${x.text}: a call on ${o.why}`)
    } else [f, q] = this.ev(fx, q)
    switch (f.t) {
      case 'fn': {
        const fn = this.func(f.id, x)
        if ((fn as {generic?: boolean}).generic) return refuse(x, `${fn.name}: a generic function`)
        const cut = this.ownCut(fn, f.self, x)
        if (cut) return this.boundary(x, cut, q, !!fn.async)
        try { return this.evArgs(x, q, (args, kw, q2) => this.callFunc(fn, f.self, args, kw, x, q2, awaited || !fn.async, f.caps)) } catch (e) {
          // (refused before its body runs, an argument or the call itself: the function is where it may be cut)
          if (e instanceof Refusal && this.inf && !(e as Framed).frames?.length) (e as Framed).frames = [{id: fn.id, roots: f.self && this.stateRef(f.self, q) ? fn.params.filter(x => x.self).map(x => x.name) : []}]
          throw e
        }
      }
      case 'cls': {
        if (this.mod.recs[f.rec]?.orm) return this.evArgs(x, q, (args, kw, q2) => this.ormCall(f.rec, 'new', args, kw, x, q2))
        // (another module's class made: other code, at the boundary)
        const r = this.inf ? this.mod.recs[f.rec] : undefined
        if (r && !r.own && !madeByInit(r)) return this.boundary(x, {key: f.rec, name: names[0] ?? r.short, ...(f.patch ? {patch: f.patch} : {}), ret: {k: 'rec', name: f.rec}, refusal: `${x.text}: ${r.short} made (the subset makes the module's own dataclasses)`}, q, awaited)
        return this.evArgs(x, q, (args, kw, q2) => this.construct(f.rec, args, kw, x, q2))
      }
      case 'builtin': return this.builtin(f.n, x, q)
      case 'lib': return this.lib(f.q, x, q)
      case 'ext': {
        if (f.q === 'json.dumps' || f.q === 'json.loads') return this.evArgs(x, q, (args, kw, q2) => this.json(f.q, args, kw, x, q2))
        const refusal = `${x.text}: ${f.q}, other code (answer it, skip it, or read that module)`
        return this.inf ? this.boundary(x, {key: f.q, name: /\s/.test(names[0] ?? ' ') ? f.q : names[0]!, ...(f.patch ? {patch: f.patch} : {}), ...(f.ret ? {ret: f.ret} : {}), ...(f.recv ? {recv: f.recv} : {}), refusal}, q, awaited) : refuse(x, refusal)
      }
      case 'opaque': return this.inf ? this.boundary(x, {key: names[0] ?? String(x.text), name: names[0] ?? String(x.text), refusal: `${x.text}: a call of ${f.why}`}, q, awaited) : refuse(x, `${x.text}: a call of ${f.why}`)
      case 'bool': case 'cell': case 'choice': case 'fmt': case 'lock': case 'none': case 'num': case 'opt': case 'ref': case 'sattr': case 'str': case 'tuple': case 'res': case 'ptr': case 'struct': case 'err': case 'nil': case 'map': case 'list': case 'push': case 'pop': case 'val': break
    }
    void args0; void kw0
    return refuse(x, `${x.text}: a call of a ${f.t}`)
  }
  // The arguments of a call left to the boundary, read as far as the subset goes: the code evaluates them, so the fields
  // they read are inputs the check gives. An argument outside the subset that reaches none of the module's code and
  // not the object itself (other code's calls on other values) is taken as changing nothing of the state.
  argsRead(x: SX, p: Path): Path { return this.argVals(x, p)[1] }
  evArgs<T>(x: SX, p: Path, k: (args: V[], kw: [string, V][], p: Path) => T): T {
    let q = p
    const args: V[] = [], kw: [string, V][] = []
    for (const a of x.args as SX[]) { const [v, q2] = this.ev(a, q); args.push(v); q = q2 }
    for (const [n, a] of x.kw as [string, SX][]) { const [v, q2] = this.ev(a, q); kw.push([n, v]); q = q2 }
    return k(args, kw, q)
  }
  dictCall(m: V, name: string, x: SX, p: Path): [V, Path] {
    if (this.mapObj(m, x, p)[1].decl.js === 'Set') return this.setCall(m, name, x, p)
    return this.evArgs(x, p, (args, kw, q) => {
      if (kw.length) return refuse(x, `${x.text}: a dict's method given keywords`)
      const key = () => this.keyOf(args[0] ?? refuse(x, `${x.text}: no key`), (x.args as SX[])[0]!)
      if (name === 'contains_key') return [{t: 'bool', e: this.cellOf(this.mapObj(m, x, q)[1], key(), q, x).has}, q]
      if (name === 'insert') { const k = key(), [old, q2] = this.mapGet(m, k, x, q, 'none'); return [old, this.mapSet(m, k, args[1] ?? refuse(x, `${x.text}: no value`), x, q2)] }
      if (name === 'remove') { const k = key(), [old, q2] = this.mapGet(m, k, x, q, 'none'); return [old, this.mapDel(m, k, x, q2, false)] }
      if (name === 'get_mut') { const k = key(), [, o] = this.mapObj(m, x, q); if (o.decl.scalar) return refuse(x, `${x.text}: a reference to a map's number (the subset writes one through m.insert)`); return this.mapGet(m, k, x, q, 'none') }
      if (name === 'get') return args.length > 1 ? this.mapGet(m, key(), x, q, args[1]!) : this.mapGet(m, key(), x, q, 'none')
      if (name === 'pop') {
        const k = key()
        const [v, q2] = args.length > 1 ? this.mapGet(m, k, x, q, args[1]!) : this.mapGet(m, k, x, q, 'fail')
        return [v, this.mapDel(m, k, x, q2, false)]
      }
      return refuse(x, `${x.text}: dict.${name} (the subset reads get, pop, [k], in and del)`)
    })
  }
  // A set's methods: add, discard and remove (a KeyError where the key isn't held), each a write of one key.
  setCall(m: V, name: string, x: SX, p: Path): [V, Path] {
    return this.evArgs(x, p, (args, kw, q) => {
      if (kw.length || args.length !== 1) return refuse(x, `${x.text}: a set's method given other than one key`)
      const [id, o] = this.mapObj(m, x, q), k = this.keyOf(args[0]!, (x.args as SX[])[0]!)
      if (name === 'add') return [{t: 'none'}, this.writeCell(id, o, k, I.T, new Map(), x, q)]
      if (name === 'discard' || name === 'remove') return [{t: 'none'}, this.mapDel(m, k, x, q, name === 'remove')]
      return refuse(x, `${x.text}: set.${name} (the subset reads add, discard, remove and in)`)
    })
  }
  // This is a presence check, not a speculative getattr: descriptors and custom
  // lookup can execute code or raise AttributeError even when a name is declared.
  hasAttribute(v: V, name: string, at: SX, p: Path): boolean {
    if (v.t !== 'ref') return refuse(at, `${at.text}: hasattr requires a modeled instance`)
    const obj = p.heap.get(v.id)
    if (obj?.k !== 'rec') return refuse(at, `${at.text}: hasattr requires a modeled record`)
    const r = this.rec(obj.ty, at)
    if (!r.mro) return refuse(at, `${at.text}: hasattr needs a known static MRO`)
    for (const owner of r.mro) {
      const base = this.rec(owner, at)
      if (base.declared?.some(n => ['__getattribute__', '__getattr__'].includes(n)))
        return refuse(at, `${at.text}: hasattr with custom attribute lookup`)
    }
    const owner = r.mro.map(n => this.rec(n, at)).find(b => b.declared?.includes(name))
    if (owner) {
      const id = owner.methods[name]
      if (id) {
        const fn = this.func(id, at)
        if (fn.decorators.some(d => !['staticmethod', 'classmethod', 'override', 'typing.override', 'abstractmethod'].includes(d.name)))
          return refuse(at, `${at.text}: hasattr may invoke a descriptor`)
      } else if (!Object.hasOwn(owner.cattrs ?? {}, name) && !Object.hasOwn(owner.classCollections ?? {}, name)) {
        return refuse(at, `${at.text}: hasattr cannot resolve the final class binding`)
      }
      return true
    }
    if (obj.f.has(name)) return true
    // Implicit object/type attributes are outside the reader's explicit MRO.
    if (name.startsWith('__') && name.endsWith('__')) return refuse(at, `${at.text}: hasattr of an implicit object attribute`)
    return false
  }
  // Entry and nested construction must agree about the final __init__ binding.
  initMethod(r: SRec, at: {p: string}): string | null | undefined {
    const id = r.methods.__init__
    if (this.mod.lang !== 'python') return id
    const generated = r.kinds.includes('dataclass') || !!r.orm
    if (!r.mro && !generated) return refuse(at, `${r.short}: construction needs a known static MRO`)
    const order = (r.mro ?? [r.name]).map(n => this.rec(n, at))
    if (order.some(b => b.declared?.some(n => ['__new__', '__init_subclass__', '__getattribute__', '__getattr__', '__setattr__', '__delattr__'].includes(n))))
      return refuse(at, `${r.short}: custom allocation or attribute hooks are outside modeled construction`)
    const owner = order.find(b => b.declared?.includes('__init__'))
    if (owner && (!id || owner.methods.__init__ !== id)) return refuse(at, `${r.short}: final __init__ binding is not a known method`)
    if (id && this.func(id, at).decorators.some(d => !['override', 'typing.override', 'abstractmethod'].includes(d.name)))
      return refuse(at, `${r.short}: decorated __init__ is outside modeled construction`)
    return id
  }
  construct(rec: string, args: V[], kw: [string, V][], x: SX, p: Path): [V, Path] {
    const r = this.rec(rec, x)
    const initId = this.initMethod(r, x)
    // (a plain class of the repository whose __init__ the reader read: made by running it on a fresh object)
    if (madeByInit(r)) {
      const id = `fresh:${this.fresh++}`, q1: Path = {...p, heap: new Map(p.heap).set(id, {k: 'rec', ty: rec, f: new Map(), origin: 'fresh'})}
      this.notes.add(`${r.short}(...) (${x.p}): made by its __init__, read`)
      return [{t: 'ref', id}, this.callFunc(this.func(initId!, x), {t: 'ref', id}, args, kw, x, q1, false)[1]]
    }
    if (!r.kinds.includes('dataclass') || !r.own) return refuse(x, `${x.text}: ${r.short} made (the subset makes the module's own dataclasses)`)
    if (r.methods.__init__ || r.methods.__post_init__) return refuse(x, `${x.text}: ${r.short} has its own __init__ or __post_init__`)
    const f = new Map<string, V>()
    let i = 0, q = p
    for (const fd of r.fields) {
      let v = i < args.length ? args[i++] : kw.find(([n]) => n === fd.name)?.[1]
      if (!v && fd.dflt) { const [d, q2] = this.ev(fd.dflt, q); v = d; q = q2 }
      if (!v) return refuse(x, `${x.text}: ${fd.name} not given`)
      if (fd.t.k === 'choice' && v.t === 'str' && v.e.op === 'slit') v = {t: 'choice', e: I.llit(v.e.value, fd.t.values)}
      f.set(fd.name, v)
    }
    const id = `fresh:${this.fresh++}`
    return [{t: 'ref', id}, {...q, heap: new Map(q.heap).set(id, {k: 'rec', ty: rec, f, origin: 'fresh'})}]
  }
  builtin(n: string, x: SX, p: Path): [V, Path] {
    const a0 = (x.args as SX[])[0]
    // min or max of a collection of the state (a list's items by a key, a dict's keys): its least key.
    if ((n === 'min' || n === 'max') && (a0?.e === 'get' || a0?.e === 'var')) { const r = this.minMax(n, x, p); if (r) return r }
    // int(x / k): truncated toward zero; round(x / k): to the nearest, a half to the even one (Python's round).
    if (n === 'int' && a0?.e === 'bin' && a0.op === '/') return this.quotient(a0, p, 'trunc')
    if (n === 'round' && a0?.e === 'bin' && a0.op === '/' && (x.args as SX[]).length === 1 && !(x.kw as unknown[]).length) return this.quotient(a0, p, 'even')
    if (n === 'bool' && (a0?.e === 'and' || a0?.e === 'or') && (x.args as SX[]).length === 1) { const [c, q] = this.truth(a0, p); return [{t: 'bool', e: c}, q] }
    // (set(), dict(), list(): an empty collection, as {} and [] are, a collection only where a field declares its type)
    if ((n === 'set' || n === 'frozenset' || n === 'dict' || n === 'list') && !(x.args as SX[]).length && !(x.kw as unknown[]).length)
      return [{t: 'opaque', why: n === 'list' ? `${n}() [] (an empty list, a collection only where a field declares its type)` : `${n}() {} (an empty ${n === 'dict' ? 'dict' : 'set'}, a collection only where a field declares its type)`}, p]
    return this.evArgs(x, p, (args, kw, q) => {
      if (kw.length) return refuse(x, `${x.text}: ${n} given keywords`)
      if (n === 'str' || n === 'repr') for (const v of args) this.checkOrmDisplay(v, x)
      // (int of a timestamp: its whole seconds)
      if (n === 'int' && args[0]?.t === 'val') return args[0].ty === '$ts' ? [{t: 'num', e: I.divk(1000, this.numOf(args[0].f.get('ms')!, x, q))}, q] : refuse(x, `${x.text}: int of a ${args[0].ty.slice(1)}`)
      if (args.some(a => a.t === 'opaque') && ['str', 'repr', 'len', 'isinstance', 'round', 'int', 'float', 'bool'].includes(n)) { const ask = args.find(a => a.t === 'opaque' && a.ask) as {why: string, ask: string} | undefined; return [{t: 'opaque', why: `${x.text}: of a value outside the subset${ask ? ` (${ask.why})` : ''}`, ...(ask ? {ask: ask.ask} : {})}, q] }
      const v = args[0]
      // (a list the request carries: its length, an input)
      const cl = v && this.listOf(v, q, x, true)
      if (n === 'len' && cl) return [{t: 'num', e: cl.len}, q]
      switch (n) {
        case 'hasattr': {
          const name = args[1]
          if (args.length !== 2 || name?.t !== 'str' || name.e.op !== 'slit') return refuse(x, `${x.text}: hasattr requires an object and a literal attribute name`)
          return [{t: 'bool', e: this.hasAttribute(args[0]!, name.e.value, x, q) ? I.T : I.F}, q]
        }
        case '$object_init':
          if (!args.length) return [{t: 'none'}, q]
          return refuse(x, `${x.text}: object.__init__ takes no arguments`)
        case 'min': case 'max': {
          if (args.length < 2) return refuse(x, `${x.text}: ${n} of an iterable`)
          const ns = args.map(a => this.numOf(a, x, q))
          const ty = args.map(v => (v.t === 'num' ? v.ty : undefined)).find(Boolean)
          return [{t: 'num', e: ns.slice(1).reduce((acc, y) => (n === 'min' ? I.nmin(acc, y) : I.nmax(acc, y)), ns[0]!), ...(ty ? {ty} : {})}, q]
        }
        case 'abs': { const e = this.numOf(v!, x, q); return [{t: 'num', e: I.nite(I.cmp('<', e, I.num(0)), I.neg(e), e)}, q] }
        // (round of a whole number, an int or a float at a whole value: itself)
        case 'round': if (args.length === 1 && v?.t === 'num') return [v, q]; break
        case 'int': case 'float':
          if (v?.t === 'str') return refuse(x, `${x.text}: a string parsed`)
          if (v?.t === 'bool') return [{t: 'num', e: I.nite(v.e, I.num(1), I.num(0))}, q]
          return [{t: 'num', e: this.numOf(v ?? {t: 'num', e: I.num(0)}, x, q)}, q]
        case 'bool': return [{t: 'bool', e: v ? this.truthy(v, x, q) : I.F}, q]
        case 'str': if (v?.t === 'str') return [v, q]; return [{t: 'opaque', why: `${x.text}: a value made a string`}, q]
        case 'repr': return [{t: 'opaque', why: `${x.text}: a repr`}, q]
      }
      return refuse(x, `${x.text}: ${n}() (a builtin outside the subset)`)
    })
  }
  // a / k rounded to a whole number, for a constant k: floor, ceil and trunc (toward zero) exact for |a| below 2^53 (the
  // float a / k is within half its last place of a / k, less than 1/k from it, so it never reaches the next whole
  // number); to the nearest, a half to the even one (`even`: Python's round, Java's Math.rint), up (`up`: Java's and
  // JavaScript's Math.round) or away from zero (`away`: Go's math.Round, Rust's round, C's round) exact for |a| below
  // 2^52 only: a / k not a half is at least 1/(2k) from one, and the float is within |a / k|·2^-53 of it, less than
  // 1/(2k) only there (3·2^51 + 2 over 3 lands on a half). Past it, an edge: the claim is for |a| below 2^52.
  quotient(d: SX, p: Path, round: 'floor' | 'ceil' | 'trunc' | 'even' | 'up' | 'away'): [V, Path] {
    const [a, q] = this.ev(d.x as SX, p), [b, q2] = this.ev(d.y as SX, q), k = constOf(b)
    if (k === undefined) return refuse(d, `${d.text}: a division by a value that isn't a constant`)
    if (k === 0 && d.fdiv) return refuse(d, `${d.text}: a float division by 0 rounded (an infinity or NaN)`)
    if (k === 0) { this.fail(q2, I.T, d, `${d.text}: a division by zero (a ZeroDivisionError)`); return [{t: 'num', e: I.num(0)}, {...q2, pc: [...q2.pc, I.F]}] }
    if (!Number.isSafeInteger(k)) return refuse(d, `${d.text}: a division by a constant that isn't whole`)
    const n = this.numOf(a, d, q2), fl = this.floorDiv(n, k), ce = I.neg(this.floorDiv(I.neg(n), k))
    const lt = k > 0 ? I.cmp('<', n, I.num(0)) : I.cmp('<', I.num(0), n)
    // (a float's precision: a double's 53 bits (Python's and the rule's own bound), a float's 24: past 2^bits, a / k and
    // its operands aren't exact, an edge)
    const bits = (d.prec as number | undefined) ?? 53, edge = (e: number, why: string) => { if (Math.abs(k) > 1 || bits < 53) this.refuseWhere(q2, I.or(I.cmp('<=', I.num(2 ** e), n), I.cmp('<=', n, I.num(-(2 ** e)))), d, `${d.text}: ${why}`, false) }
    if (round === 'floor' || round === 'ceil' || round === 'trunc') { if (bits < 53) edge(bits, `rounded at |a| of 2^${bits} or more (past a float's precision)`); return [{t: 'num', e: round === 'floor' ? fl : round === 'ceil' ? ce : I.nite(lt, ce, fl)}, q2] }
    // (a / k as m / j with j = |k| > 0: q = ⌊m/j⌋, r = m − j·q in [0, j); below half of j q, past it q + 1, at it the mode's)
    const j = Math.abs(k), m = k > 0 ? n : I.neg(n), qq = I.divk(j, m), r2 = I.mulk(2, I.sub(m, I.mulk(j, qq))), half = I.num(j)
    const tie = round === 'even' ? I.add(qq, I.sub(qq, I.mulk(2, I.divk(2, qq)))) : round === 'up' ? I.add(qq, I.num(1)) : I.nite(I.cmp('<', m, I.num(0)), qq, I.add(qq, I.num(1)))
    edge(bits - 1, `rounded to the nearest at |a| of 2^${bits - 1} or more (the float a / k may land on a half there)`)
    return [{t: 'num', e: I.nite(I.cmp('<', r2, half), qq, I.nite(I.cmp('<', half, r2), I.add(qq, I.num(1)), tie))}, q2]
  }
  lib(q0: string, x: SX, p: Path): [V, Path] {
    const a0 = (x.args as SX[])[0]
    if ((q0 === 'math.floor' || q0 === 'math.ceil') && a0?.e === 'bin' && a0.op === '/') return this.quotient(a0, p, q0 === 'math.floor' ? 'floor' : 'ceil')
    if (q0 === 'time.time' || q0 === 'time.monotonic' || q0 === 'time.perf_counter') { this.notes.add(`${q0}() is the request's time (an input, read once a step, at whole seconds: the claim is for those)`); return this.clock(x, p) }
    if (q0 === 'threading.Lock' || q0 === 'threading.RLock' || q0 === 'asyncio.Lock') return [{t: 'lock'}, p]
    // A datetime: the request's time (in whole seconds, as time.time()), in milliseconds; a timedelta by its parts.
    if (q0 === 'datetime.datetime.now') {
      const args = x.args as SX[], kw = x.kw as [string, SX][]
      const zone = args[0] ?? kw.find(([k]) => k === 'tz')?.[1]
      const isUTC = (z: SX | undefined): boolean => !!z && ((z.e === 'ext' && z.q === 'datetime.timezone.utc') || (z.e === 'get' && z.f === 'utc' && (z.x as SX).e === 'ext' && (z.x as SX).q === 'datetime.timezone'))
      if (args.length + kw.length > 1 || (kw.length && kw[0]![0] !== 'tz') || (zone && !isUTC(zone))) return refuse(x, `${x.text}: only timezone.utc is supported`)
      this.notes.add(`${q0}() is the request's time (an input, at whole seconds: the claim is for those)`)
      if (!zone) { this.naiveUtc = true; this.notes.add('naive datetime clocks require a UTC process timezone') }
      const [t, q] = this.clock(x, p)
      return [{t: 'val', ty: '$dt', f: new Map<string, V>([['ms', {t: 'num', e: I.mulk(1000, (t as {e: N}).e)}], ['utc', {t: 'bool', e: zone ? I.T : I.F}]])}, q]
    }
    if (q0 === 'datetime.timedelta' || q0 === 'dateutil.relativedelta.relativedelta') return this.evArgs(x, p, (args, kw, q) => {
      const unit: Record<string, number> = {days: 86_400_000, seconds: 1000, milliseconds: 1, minutes: 60_000, hours: 3_600_000, weeks: 604_800_000}
      if (q0 === 'dateutil.relativedelta.relativedelta' && args.length) return refuse(x, `${x.text}: relativedelta requires named linear durations`)
      if (args.length > 1) return refuse(x, `${x.text}: a timedelta of positional parts past its days`)
      const parts: [string, V][] = [...(args.length ? [['days', args[0]!] as [string, V]] : []), ...kw]
      let ms: N = I.num(0)
      for (const [n, v] of parts) { if (!(n in unit)) return refuse(x, `${x.text}: a timedelta's ${n}`); ms = I.add(ms, I.mulk(unit[n]!, this.numOf(v, x, q))) }
      return [{t: 'val', ty: '$td', f: new Map([['ms', {t: 'num', e: ms}]])}, q]
    })
    return this.evArgs(x, p, (args, _kw, q) => {
      const v = args[0]
      if (v?.t === 'opaque') return [v, q]
      if (q0 === 'math.floor' || q0 === 'math.ceil') return [{t: 'num', e: this.numOf(v!, x, q)}, q]
      // Whole numbers are finite: isfinite holds, isnan and isinf don't (a float here is a whole value).
      if (q0 === 'math.isfinite') { this.numOf(v!, x, q); return [{t: 'bool', e: I.T}, q] }
      if (q0 === 'math.isnan' || q0 === 'math.isinf') { this.numOf(v!, x, q); return [{t: 'bool', e: I.F}, q] }
      return refuse(x, `${x.text}: ${q0}`)
    })
  }

  // --- pointers into the state, value records, lists, error values and locks (Go's lowering's; C's and Rust's next) --
  // A pointer is by cases on the objects it may be (an interior one, &x.f, a path into it), or nil; a record held by
  // value is copied where it is assigned; an error value is nil or not; a list of the state is pushed, popped or set
  // once a step; a lock held until the deferred unlock at the return. Each failure is where it is (refuseWhere: the
  // step's refusal, the state as it was there), and each refusal text is the reader's own.
  readonly edges: B[] = []
  readonly lists: MapDecl[] = []
  readonly spans = new Map<string, [string, number, number]>()
  readonly stateOrigin = new Map<string, string>()
  readonly lazyIn = new Map<string, {id: string, fields: [string, string][], sel: B, recipes: Record<string, Recipe>}>()
  // A failure where c holds on this path, refused (the step's refusal); `state` false: one the code goes on past and
  // the rule's numbers stop at (an edge, counted apart by the check).
  refuseWhere(p: Path, c: B, at: {p: string}, what: string, state = true) {
    const w = I.and(this.cond(p), c)
    if (w.op === 'const' && !w.v) return
    if (state) this.unwritten(p, at, what)
    this.refusals.push(w)
    if (!state) this.edges.push(w)
  }
  // The cases a pointer is: each object (with the condition it is that one), and the condition it is nil.
  cases(p: Ptr, c: B = I.T): {nil: B, objs: {c: B, id: string, path: string[]}[]} {
    if (p.k === 'nil') return {nil: c, objs: []}
    if (p.k === 'obj') return {nil: I.F, objs: [{c, id: p.id, path: p.path}]}
    const a = this.cases(p.a, I.and(c, p.c)), b = this.cases(p.b, I.and(c, I.not(p.c)))
    return {nil: I.or(a.nil, b.nil), objs: [...a.objs, ...b.objs]}
  }
  // A pointer's cases, a failure (what) where it may be nil, and the path where it isn't.
  nonNil(to: Ptr, at: {p: string}, p: Path, what: string): [ReturnType<Stepper['cases']>, Path] { const cs = this.cases(to); this.refuseWhere(p, cs.nil, at, what); return [cs, this.assume(p, I.not(cs.nil))] }
  shift(p: Ptr, path: string[]): Ptr { return p.k === 'nil' ? p : p.k === 'obj' ? {...p, path: [...p.path, ...path]} : {...p, a: this.shift(p.a, path), b: this.shift(p.b, path)} }
  readObj(o: Obj, path: string[], at: {p: string}, p: Path, id: string): V {
    if (o.k === 'big') { if (path.length) refuse(at, 'a field of a big.Int'); return refuse(at, 'a big.Int read as a value (it is used through its pointer)') }
    if (o.k !== 'rec') return refuse(at, 'a field of other than a struct')
    let v: V = {t: 'struct', ty: o.ty, f: o.f}
    for (const seg of path) {
      if (v.t !== 'struct') return refuse(at, `.${seg} of other than a struct`)
      v = v.f.get(seg) ?? this.lazyFieldIn(id, seg, p, at)
    }
    return v
  }
  writeObj(o: Obj, path: string[], x: V, at: {p: string}): Obj {
    if (o.k !== 'rec') return refuse(at, 'a write into other than a struct')
    if (!path.length) { if (x.t !== 'struct') return refuse(at, 'a struct set to other than a struct'); return {...o, f: new Map(x.f)} }
    const set = (fs: Map<string, V>, segs: string[]): Map<string, V> => {
      const seg = segs[0]!, rest = segs.slice(1), out = new Map(fs)
      if (!rest.length) { const old = fs.get(seg); if (old?.t === 'opaque' && old.sink) { out.set(seg, old); return out } if (old?.t === 'opaque') refuse(at, `writes ${old.why}`); out.set(seg, x); return out }
      const inner = fs.get(seg)
      if (inner?.t !== 'struct') return refuse(at, `.${seg} of other than a struct`)
      out.set(seg, {...inner, f: set(inner.f, rest)})
      return out
    }
    return {...o, f: set(o.f, path)}
  }
  // A field of a record the caller gives, made an input where it is first read (by the reader's recipe for it).
  lazyFieldIn(id: string, f: string, p: Path, at: {p: string}): V {
    const li = this.lazyIn.get(id), r = li?.recipes[f]
    if (!li || !r) return refuse(at, `no field ${f}`)
    if (r.k === 'no') return refuse(at, r.why)
    let g: V
    if (r.k === 'big') {
      const v = this.newVar(`${li.id}_${f}`, {k: 'num'}, 'input', 'a *big.Int argument (not nil: the claim is for calls that give one)')
      li.fields.push([f, v.name])
      p.heap.set(`in:${v.name}`, {k: 'big', v: I.nvar(v.name), origin: 'input'})
      g = {t: 'ptr', to: {k: 'obj', id: `in:${v.name}`, path: []}}
    } else {
      const v = this.newVar(`${li.id}_${f}`, {k: r.k}, 'input')
      li.fields.push([f, v.name])
      g = this.valueOfIn(v, r.ty, li.sel)
    }
    ;(p.heap.get(id) as {f: Map<string, V>}).f.set(f, g)
    return g
  }
  // An input's value, its type's range kept (a request outside it refused where sel holds: the claim is for its values).
  valueOfIn(v: Var, ty: IntTy | undefined, sel: B): V {
    if (ty) this.typed(v, ty, 'input', sel)
    return v.sort.k === 'num' ? {t: 'num', e: I.nvar(v.name), ty: ty ?? {bits: 64, signed: true}} : this.valueOf(v)
  }
  // *x read: by cases on the objects x may point to; nil fails.
  deref(v: V, path: string[], at: {p: string}, p: Path): [V, Path] {
    if (v.t === 'nil') { this.refuseWhere(p, I.T, at, 'a nil dereference'); return [{t: 'opaque', why: 'unreachable', firm: true}, {...p, pc: [...p.pc, I.F]}] }
    if (v.t !== 'ptr') return refuse(at, `a dereference of a ${v.t}`)
    const [cs, q] = this.nonNil(v.to, at, p, `a nil dereference (${at.p})`)
    if (!cs.objs.length) return [{t: 'opaque', why: 'unreachable', firm: true}, q]
    let out: V | undefined
    for (const o of [...cs.objs].reverse()) { const x = this.readObj(q.heap.get(o.id)!, [...o.path, ...path], at, q, o.id); out = out ? this.ite(o.c, x, out, at) : x }
    return [out!, q]
  }
  // A write through a pointer: to each object it may be, where it is that one.
  writeThrough(v: V, path: string[], x: V, at: {p: string}, p: Path): Path {
    if (v.t !== 'ptr') return refuse(at, `a write through a ${v.t}`)
    const [cs, q] = this.nonNil(v.to, at, p, 'a nil dereference'), heap = new Map(q.heap)
    for (const o of cs.objs) {
      const obj = heap.get(o.id)!, pa = [...o.path, ...path]
      heap.set(o.id, this.writeObj(obj, pa, this.ite(o.c, x, this.readObj(obj, pa, at, q, o.id), at), at))
    }
    return {...q, heap}
  }
  // A place: a local (and a path into its record), or a path inside the object a pointer is.
  place(x: SX, p: Path): [Place, Path] {
    switch (x.e) {
      case 'blank': return [{k: 'blank'}, p]
      case 'var': return [{k: 'local', id: String(x.n), path: []}, p]
      case 'deref': { const [v, q] = this.ev(x.x as SX, p); return [{k: 'heap', ptr: v, path: []}, q] }
      case 'fld': { const [b, q] = this.place(x.x as SX, p); if (b.k === 'blank') return refuse(x, 'a field of _'); return [{...b, path: [...b.path, String(x.f)]}, q] }
    }
    return refuse(x, (x.why as string | undefined) ?? `${x.text}: an assignment to other than a variable, a field or *p`)
  }
  read(pl: Place, at: SX | SS | {p: string}, p: Path): [V, Path] {
    if (pl.k === 'blank') return refuse(at, '_ read')
    if (pl.k === 'heap') return this.deref(pl.ptr, pl.path, at, p)
    let v = p.locals.get(pl.id) ?? refuse(at, `${(at as SX).text ?? ''}: a variable read before it is set`)
    for (const s of pl.path) { if (v.t !== 'struct') refuse(at, `.${s} of other than a struct`); v = (v as {f: Map<string, V>}).f.get(s) ?? refuse(at, `no field ${s}`) }
    return [v, p]
  }
  write(pl: Place, x: V, at: {p: string}, p: Path): Path {
    if (pl.k === 'blank') return p
    this.secondName(x, at)
    if (pl.k === 'heap') { this.keepsInState(pl, x, at, p); return this.writeThrough(pl.ptr, pl.path, x, at, p) }
    if (!pl.path.length) return {...p, locals: new Map(p.locals).set(pl.id, x)}
    const set = (v: V, segs: string[]): V => {
      const s = segs[0]!, rest = segs.slice(1)
      if (v.t !== 'struct') return refuse(at, `.${s} of other than a struct`)
      return {...v, f: new Map(v.f).set(s, rest.length ? set(v.f.get(s)!, rest) : x)}
    }
    return {...p, locals: new Map(p.locals).set(pl.id, set(p.locals.get(pl.id) ?? refuse(at, 'a field of a variable not set'), pl.path))}
  }
  // A list or a map under a second name: refused (two slices may share a backing array; a map is a reference).
  secondName(x: V, at: {p: string}) {
    if (x.t === 'list') refuse(at, 'a slice given a second name (two slices may share a backing array: append writes into it or not by its capacity)')
    if (x.t === 'map') refuse(at, 'a map given a second name (a map is a reference: a write through either is a write to both)')
  }
  // A pointer stored into the state: to a fresh object only (one the state holds would be in two places; one the
  // caller gave the caller's to change after the call).
  keepsInState(pl: Extract<Place, {k: 'heap'}>, x: V, at: {p: string}, p: Path) {
    if (x.t !== 'ptr') return
    const into = this.cases(pl.ptr.t === 'ptr' ? pl.ptr.to : {k: 'nil'})
    if (!into.objs.some(o => (p.heap.get(o.id) as {origin?: Origin})?.origin === 'state')) return
    for (const o of this.cases(x.to).objs) {
      const origin = (p.heap.get(o.id) as {origin?: Origin})?.origin
      if (origin === 'input') refuse(at, 'the state keeps a pointer the caller gave (the caller may change its object after the call)')
      if (origin === 'state') refuse(at, `the state's ${this.stateOrigin.get(o.id) ?? 'object'} put in a second place of the state (one object in two places)`)
    }
  }
  bindLocal(id: string, v: V, at: {p: string}, p: Path): Path {
    if (v.t === 'list' || v.t === 'map' || v.t === 'push' || v.t === 'pop') this.secondName(v.t === 'push' || v.t === 'pop' ? {t: 'list', id: v.id} : v, at)
    if (v.t === 'num' && v.slen) refuse(at, 'len of a string kept (it is read only against 0)')
    return {...p, locals: new Map(p.locals).set(id, v)}
  }
  numv(v: V, at: SX | {p: string}): N {
    if (v.t !== 'num') return refuse(at, `${(at as SX).text ?? ''}: ${v.t === 'opaque' ? v.why : `a ${v.t}`} where a number is read`)
    if (v.slen) return refuse(at, 'len of a string read other than against 0 (strings are set and compared in the subset)')
    return v.e
  }
  boolv(v: V, at: SX | {p: string}): B { if (v.t !== 'bool') return refuse(at, `${(at as SX).text ?? ''}: ${v.t === 'opaque' ? v.why : `a ${v.t}`} where a condition is read`); return v.e }
  // A binary operation of the reader's language with fixed-width integers (Go's): comparisons, arithmetic wrapped.
  binop(op: string, a: V, b: V, x: {p: string}, p: Path): V {
    if (op === '==' || op === '!=') { const e = this.eq(a, b, x, p); return {t: 'bool', e: op === '==' ? e : I.not(e)} }
    // len(s) of a string against 0: whether it is empty.
    const sl = (v: V, k: V) => (v.t === 'num' && v.slen && k.t === 'num' && !k.slen && k.e.op === 'const' && k.e.v === 0 ? v.slen : undefined)
    const flip: Record<string, string> = {'<': '>', '<=': '>=', '>': '<', '>=': '<='}
    if (['<', '<=', '>', '>='].includes(op) && (sl(a, b) || sl(b, a))) {
      const s = (sl(a, b) ?? sl(b, a))!, empty = I.keq(s, {op: 'slit', value: ''}), o = sl(a, b) ? op : flip[op]!
      return {t: 'bool', e: o === '<=' ? empty : o === '>' ? I.not(empty) : o === '>=' ? I.T : I.F}
    }
    if (['<', '<=', '>', '>='].includes(op)) {
      if (a.t === 'str' || b.t === 'str') return refuse(x, 'strings ordered (strings are set and compared in the subset)')
      // x.Cmp(y) against 0, read as the comparison of x and y.
      const cmpOf = (v: V, k: V): [N, N] | undefined => (v.t === 'num' && v.cmp && k.t === 'num' && k.e.op === 'const' && k.e.v === 0 ? v.cmp : undefined)
      const ca = cmpOf(a, b), cb = cmpOf(b, a)
      let l: N, r: N, o = op
      if (ca) [l, r] = ca
      else if (cb) { [l, r] = cb; o = flip[op]! } else { l = this.numv(a, x); r = this.numv(b, x) }
      return {t: 'bool', e: o === '<' ? I.cmp('<', l, r) : o === '<=' ? I.cmp('<=', l, r) : o === '>' ? I.cmp('<', r, l) : I.cmp('<=', r, l)}
    }
    if (['+', '-', '*', '/', '%', '<<', '>>'].includes(op)) {
      if (a.t === 'str') return refuse(x, 'strings joined (strings are set and compared in the subset)')
      return this.arith(op, a, b, x, p)
    }
    if (['&', '|', '^', '&^'].includes(op) && a.t === 'num' && b.t === 'num') return this.bitop(op, a, b, x)
    return refuse(x, `${op}: a bit operation (outside the subset)`)
  }
  // A bit operation with a constant (a flag set, cleared, tested, toggled; a mask), or with a value that is 0 or 1: exact
  // in linear terms, in two's complement of any width (floor division and remainder take a negative value's bits):
  // x & K, K ≥ 0, is the sum over K's runs of ones [lo, lo + n) of ((x div 2^lo) mod 2^n)·2^lo; x & K, K < 0, is
  // x − (x & ~K); x | K = x + K − (x & K); x ^ K = x + K − 2(x & K); x &^ K = x − (x & K). Of two values neither
  // constant nor 0 or 1, refused (bit-vectors).
  bitop(op: string, a: Extract<V, {t: 'num'}>, b: Extract<V, {t: 'num'}>, x: {p: string}): V {
    const ty = a.ty?.name !== undefined ? a.ty : b.ty!, at = (x as SX).text ? `${(x as SX).text}: ` : ''
    const isK = (v: N) => v.op === 'const', bit01 = (v: N) => { const [lo, hi] = this.bounds(v); return lo >= 0 && hi <= 1 }
    // (two values at least 0 of few bits, a byte's flags masked by another's: bit by bit, each bit a case)
    const width = (v: N) => { const [lo, hi] = this.bounds(v); if (lo < 0 || !Number.isFinite(hi)) return Infinity; let w = 0; while (2 ** w <= hi) w++; return w }
    if (!isK(a.e) && !isK(b.e) && !bit01(a.e) && !bit01(b.e) && Math.max(width(a.e), width(b.e)) <= 16) {
      const w = Math.max(width(a.e), width(b.e)), bit = (v: N, j: number) => I.cmp('=', I.modk(2, I.divk(2 ** j, v)), I.num(1))
      let e: N = I.num(0)
      for (let j = 0; j < w; j++) {
        const x1 = bit(a.e, j), y1 = bit(b.e, j), on = op === '&' ? I.and(x1, y1) : op === '|' ? I.or(x1, y1) : op === '^' ? I.or(I.and(x1, I.not(y1)), I.and(I.not(x1), y1)) : I.and(x1, I.not(y1))
        e = I.add(e, I.nite(on, I.num(2 ** j), I.num(0)))
      }
      return {t: 'num', e, ty}
    }
    const [vv, wv] = isK(b.e) ? [a, b] : isK(a.e) ? [b, a] : bit01(b.e) ? [a, b] : bit01(a.e) ? [b, a] : refuse(x, `${at}${op} of two values neither of them a constant nor of 16 bits or fewer (bit-vectors are outside the subset)`)
    const v = vv.e, w = wv.e, first = vv === a
    if (!isK(w)) {
      // (with a value that is 0 or 1: its low bit, where that value is 1)
      const k = I.nite(I.cmp('=', w, I.num(1)), I.modk(2, v), I.num(0))
      return {t: 'num', e: op === '&' ? k : op === '|' ? I.sub(I.add(v, w), k) : op === '^' ? I.sub(I.add(v, w), I.mulk(2, k)) : first ? I.sub(v, k) : I.sub(w, k), ty}
    }
    const K = (w as {v: number}).v
    // (x &^ K, Go's: x & ~K; K &^ x: K & ~x, read as K − (K & x))
    if (op === '&^' && !first) { const k = this.bitop('&', vv, wv, x) as {e: N}; return {t: 'num', e: I.sub(I.num(K), k.e), ty} }
    // A value at least 0 below 2^w: its form (x & A) ^ B composed with this one (K within its w bits).
    const form = vv.bits ?? this.bitsOf(v)
    if (form) {
      const m = 2 ** form.w, k = ((K % m) + m) % m, f = op === '&' ? {...form, A: and(form.A, k), B: and(form.B, k)} : op === '|' ? {...form, A: and(form.A, m - 1 - k), B: or(form.B, k)} : op === '^' ? {...form, B: xor(form.B, k)} : {...form, A: and(form.A, m - 1 - k), B: and(form.B, m - 1 - k)}
      // (K's bits past w: x | K and x ^ K keep them, past every bit x has)
      const past = op === '|' || op === '^' ? K - k : 0
      if (past && (K < 0 || ty.signed !== false)) return this.bitGeneric(op, v, w, first, ty, x)
      const e = this.ofBits(f, x)
      return {t: 'num', e: past ? I.add(e, I.num(past)) : e, ty, ...(past ? {} : {bits: f})}
    }
    return this.bitGeneric(op, v, w, first, ty, x)
  }
  // (x & A) ^ B as a term, a natural by its form: x's bits where A is set and B isn't, plus the complement of x's bits
  // where both are (AB − (x & AB)), plus B's bits where A isn't; each x & K the sum over K's runs of ones [lo, lo + n) of
  // ((x div 2^lo) mod 2^n)·2^lo.
  ofBits(f: Bits, at: {p: string}): N {
    const ab = and(f.A, f.B), kept = f.A - ab, set = f.B - ab
    let e: N = kept ? this.andRuns(f.x, kept, at) : I.num(0)
    if (ab) e = I.add(e, I.sub(I.num(ab), this.andRuns(f.x, ab, at)))
    return set ? I.add(e, I.num(set)) : e
  }
  andRuns(v: N, k: number, at: {p: string}): N {
    const runs: [number, number][] = []
    for (let i = 0, r = k; r > 0; i++, r = Math.floor(r / 2)) if (r % 2) { const last = runs.at(-1); if (last && last[0] + last[1] === i) last[1]++; else runs.push([i, 1]) }
    if (runs.length > 16) return refuse(at, `${(at as SX).text ? `${(at as SX).text}: ` : ''}a mask of more than 16 runs of ones`)
    return runs.reduce<N>((s, [lo, n]) => I.add(s, I.mulk(2 ** lo, I.modk(2 ** n, I.divk(2 ** lo, v)))), I.num(0))
  }
  // (a value at least 0 with a finite bound: x itself, every bit of its w kept)
  bitsOf(v: N): Bits | undefined {
    const [lo, hi] = this.bounds(v)
    if (!(lo >= 0 && Number.isFinite(hi) && hi < 2 ** 53)) return undefined
    let w = 0
    while (2 ** w <= hi) w++
    return {x: v, A: 2 ** w - 1, B: 0, w}
  }
  // In two's complement of any width (floor division and remainder take a negative value's bits): x & K, K < 0, is
  // x − (x & ~K); x | K = x + K − (x & K); x ^ K = x + K − 2(x & K); x &^ K = x − (x & K).
  bitGeneric(op: string, v: N, w: N, first: boolean, ty: IntTy, x: {p: string}): V {
    const K = (w as {v: number}).v, andK = (kk: number): N => (kk < 0 ? I.sub(v, andK(-kk - 1)) : this.andRuns(v, kk, x)), k = andK(K)
    return {t: 'num', e: op === '&' ? k : op === '|' ? I.sub(I.add(v, w), k) : op === '^' ? I.sub(I.add(v, w), I.mulk(2, k)) : first ? I.sub(v, k) : I.sub(w, k), ty}
  }
  eq(a: V, b: V, x: {p: string}, p?: Path): B {
    if (a.t === 'map' && b.t === 'nil' && p) return this.mapAt(a, x as SX, p).nil!
    if (a.t === 'nil' && b.t === 'map' && p) return this.mapAt(b, x as SX, p).nil!
    if (a.t === 'num' && b.t === 'num') return I.cmp('=', this.numv(a, x), this.numv(b, x))
    if (a.t === 'bool' && b.t === 'bool') return I.or(I.and(a.e, b.e), I.and(I.not(a.e), I.not(b.e)))
    if (a.t === 'str' && b.t === 'str') return I.keq(a.e, b.e)
    if (a.t === 'err' && b.t === 'nil') return I.not(a.is)
    if (a.t === 'nil' && b.t === 'err') return I.not(b.is)
    if (a.t === 'err' && b.t === 'err') return refuse(x, 'two errors compared (an error is nil or not in the subset)')
    if ((a.t === 'ptr' || a.t === 'nil') && (b.t === 'ptr' || b.t === 'nil')) {
      if (a.t === 'nil' && b.t === 'nil') return I.T
      if (b.t === 'nil') return this.cases((a as {to: Ptr}).to).nil
      if (a.t === 'nil') return this.cases((b as {to: Ptr}).to).nil
      // Two pointers: the same object (and place), or both nil.
      const ca = this.cases((a as {to: Ptr}).to), cb = this.cases((b as {to: Ptr}).to)
      return I.or(I.and(ca.nil, cb.nil), ...ca.objs.flatMap(o => cb.objs.filter(q => q.id === o.id && q.path.join() === o.path.join()).map(q => I.and(o.c, q.c))))
    }
    if ((a.t === 'list' || a.t === 'map') && b.t === 'nil') return refuse(x, `a ${a.t === 'list' ? 'slice' : 'map'} compared with nil (nil and empty are one ${a.t === 'list' ? 'list' : 'map'} in the subset)`)
    return refuse(x, `${a.t === 'opaque' && a.ask ? a.why : `a ${a.t}`} compared with ${b.t === 'opaque' && b.ask ? b.why : `a ${b.t}`}`)
  }
  // Integer arithmetic at the type's width: the exact result, wrapped as the type wraps it (or refused, at 64 bits).
  arith(op: string, a: V, b: V, x: {p: string}, p: Path): V {
    // (other code's value left out, computed with: named, so the next run answers it)
    if (a.t !== 'num' || b.t !== 'num') { const o = [a, b].find(v => v.t === 'opaque') as {why: string} | undefined; return refuse(x, o ? `${(x as SX).text ?? op}: arithmetic on ${o.why}` : `${op} of a ${a.t} and a ${b.t}`) }
    this.numv(a, x); this.numv(b, x)
    const ty = a.ty?.name !== undefined ? a.ty : b.ty!
    let e: N
    switch (op) {
      case '+': e = I.add(a.e, b.e); break
      case '-': e = I.sub(a.e, b.e); break
      case '*': e = I.mul(a.e, b.e); break
      case '/': case '%': {
        if (b.e.op !== 'const') return refuse(x, `${op} by other than a constant`)
        if (b.e.v === 0) { this.refuseWhere(p, I.T, x, 'a division by zero'); return {t: 'num', e: I.num(0), ty} }
        const k = Math.abs(b.e.v), q = this.quot(a.e, k)
        e = op === '/' ? (b.e.v < 0 ? I.neg(q) : q) : this.rem(a.e, k)
        break
      }
      case '>>': if (b.e.op !== 'const' || b.e.v < 0) return refuse(x, '>> by other than a constant'); if (b.e.v >= 53) return refuse(x, `>> ${b.e.v} (past the rule's 2^53)`); e = I.divk(2 ** b.e.v, a.e); break
      case '<<': if (b.e.op !== 'const' || b.e.v < 0) return refuse(x, '<< by other than a constant'); if (b.e.v >= 53) return refuse(x, `<< ${b.e.v} (past the rule's 2^53)`); if (ty.ub) this.refuseWhere(p, I.cmp('<', a.e, I.num(0)), x, `${(x as SX).text ? `${(x as SX).text}: ` : ''}a negative value shifted left (undefined behavior)`); e = I.mulk(2 ** b.e.v, a.e); break
      default: return refuse(x, `${op}: outside the subset`)
    }
    return {t: 'num', e: this.wrap(e, ty, x, p), ty}
  }
  // a / k and a % k truncated toward zero (the remainder takes the dividend's sign), for a constant k > 0: one case
  // where a's bounds say it is at least 0.
  quot(a: N, k: number): N { return this.bounds(a)[0] >= 0 ? I.divk(k, a) : I.nite(I.cmp('<=', I.num(0), a), I.divk(k, a), I.neg(I.divk(k, I.neg(a)))) }
  // (0 − r, not −r: the printer's remainder is a natural's, which Int subtracts from)
  rem(a: N, k: number): N { return this.bounds(a)[0] >= 0 ? I.modk(k, a) : I.nite(I.cmp('<=', I.num(0), a), I.modk(k, a), I.sub(I.num(0), I.modk(k, I.neg(a)))) }
  // The bounds a term's value is within, from its variables' types (a cell's too) and its constants.
  bounds(e: N): [number, number] {
    const r = (n: string): [number, number] => { const ty = this.ints.get(n); return ty ? rangeOf(ty) : [-Infinity, Infinity] }
    switch (e.op) {
      case 'const': return [e.v, e.v]
      case 'var': return r(e.name)
      case 'cell': return r(`${e.map}.${e.field}`)
      case 'add': { const a = this.bounds(e.a), b = this.bounds(e.b); return [a[0] + b[0], a[1] + b[1]] }
      // (x − k·(x div k): x's floor remainder by k, a conversion's wrap)
      case 'sub': { if (e.b.op === 'mulk' && e.b.a.op === 'divk' && e.b.a.k === e.b.k && I.same(e.b.a.a, e.a)) return [0, e.b.k - 1]; const a = this.bounds(e.a), b = this.bounds(e.b); return [a[0] - b[1], a[1] - b[0]] }
      case 'neg': { const a = this.bounds(e.a); return [-a[1], -a[0]] }
      case 'mulk': { const a = this.bounds(e.a); return e.k >= 0 ? [e.k * a[0], e.k * a[1]] : [e.k * a[1], e.k * a[0]] }
      case 'mul': { const a = this.bounds(e.a), b = this.bounds(e.b), xs = [a[0] * b[0], a[0] * b[1], a[1] * b[0], a[1] * b[1]].map(v => (Number.isNaN(v) ? 0 : v)); return [Math.min(...xs), Math.max(...xs)] }
      case 'min': { const a = this.bounds(e.a), b = this.bounds(e.b); return [Math.min(a[0], b[0]), Math.min(a[1], b[1])] }
      case 'max': { const a = this.bounds(e.a), b = this.bounds(e.b); return [Math.max(a[0], b[0]), Math.max(a[1], b[1])] }
      case 'divk': { const a = this.bounds(e.a); return [Math.floor(a[0] / e.k), Math.floor(a[1] / e.k)] }
      case 'modk': return [0, e.k - 1]
      case 'ite': { const a = this.bounds(e.a), b = this.bounds(e.b); return [Math.min(a[0], b[0]), Math.max(a[1], b[1])] }
    }
  }
  // A result past its type's range: at 8, 16 and 32 bits modulo 2^n by cases (none where the bounds of the term or the
  // path's facts keep it within); at 64 bits the rule's numbers stop at ±2^53, and an unsigned one below 0 is refused.
  wrap(e: N, ty: IntTy, x: {p: string}, p: Path): N {
    if (ty.bits === 0) return e
    if (ty.mod) {
      // Modulo a symbolic 2^bits: a sum or a difference of two values below it is at most once past it, by cases (a
      // product may be many times past: refused).
      if (hasProduct(e)) return refuse(x, `${(x as SX).text ? `${(x as SX).text}: ` : ''}a product wrapped modulo 2^${ty.bits} (the subset wraps sums and differences at that width)`)
      // (two values below 2^n: a sum is never below 0, a difference never at or past 2^n)
      const below = e.op === 'add' ? I.F : this.past(e, 0, Infinity, p)[0], above = e.op === 'sub' ? I.F : this.pastMod(e, ty.mod), m = I.nvar(ty.mod)
      this.notes.add(`${ty.name ?? tyName(ty)}: a result past its range wraps modulo 2^${ty.bits} (${ty.mod}, any width at least 2 in the rule: a law proven is proven at 2^${ty.bits})`)
      // (a − b below 0 is (2^n − b) + a: each part a natural, b being below 2^n)
      return I.nite(below, e.op === 'sub' ? I.add(I.sub(m, e.b), e.a) : I.add(e, m), I.nite(above, I.sub(e, m), e))
    }
    if (ty.ub) {
      const out = I.or(...this.past(e, ...rangeOf(ty), p))
      if (!(out.op === 'const' && !out.v)) { this.refuseWhere(p, out, x, `${(x as SX).text ? `${(x as SX).text}: ` : ''}past ${ty.name ?? tyName(ty)}'s range (signed overflow: undefined behavior)`); this.notes.add(`${ty.name ?? tyName(ty)}: a result past its range is refused (signed overflow is undefined behavior in ${LANG[this.mod.lang] ?? this.mod.lang})`) }
      return e
    }
    const [lo, hi] = rangeOf(ty), [blo0, bhi0] = this.bounds(e)
    if (blo0 >= lo && bhi0 <= hi) return e
    const blo = blo0 >= lo || this.within(e, lo, 'lo', p) ? Math.max(blo0, lo) : blo0, bhi = bhi0 <= hi || this.within(e, hi, 'hi', p) ? Math.min(bhi0, hi) : bhi0
    if (blo >= lo && bhi <= hi) return e
    const name = ty.name ?? tyName(ty), lang = LANG[this.mod.lang] ?? this.mod.lang
    if (ty.bits >= 64) {
      if (!ty.signed && blo < 0) { this.refuseWhere(p, I.cmp('<', e, I.num(0)), x, `a ${name} below 0 (${lang} wraps it to 2^64 − x, past the rule's numbers)`, false); this.notes.add(`${name}: a result below 0 is refused (${lang} would wrap it past 2^53)`) }
      return e
    }
    const m = 2 ** ty.bits, k0 = Math.floor((blo - lo) / m), k1 = Math.floor((bhi - lo) / m)
    this.notes.add(`${name}: a result past its range wraps modulo 2^${ty.bits}, as ${lang}'s does`)
    if (Number.isFinite(k0) && Number.isFinite(k1) && k1 - k0 <= 3) {
      // By cases from the bottom: e at least lo + k·2^n takes e − k·2^n.
      const less = (k: number): N => (k >= 0 ? I.sub(e, I.num(k * m)) : I.add(e, I.num(-k * m)))
      let acc: N = less(k0)
      for (let k = k0 + 1; k <= k1; k++) acc = I.nite(I.cmp('<=', I.num(lo + k * m), e), less(k), acc)
      return acc
    }
    // Many times over (a conversion from a wider type, a product): e − 2^n·⌊(e − lo)/2^n⌋.
    return I.sub(e, I.mulk(m, I.divk(m, I.add(e, I.num(-lo)))))
  }
  // Where e may be at or past a symbolic 2^bits (false where e is a constant below 2, the least width).
  pastMod(e: N, mod: string): B { return e.op === 'const' && e.v < 2 ? I.F : I.cmp('<=', I.nvar(mod), e) }
  // Where e may be past [lo, hi] on the path: below and above, each false where the term's bounds or the path's facts
  // keep it within.
  past(e: N, lo: number, hi: number, p: Path): [B, B] {
    const [blo, bhi] = this.bounds(e)
    return [!Number.isFinite(lo) || blo >= lo || this.within(e, lo, 'lo', p) ? I.F : I.cmp('<', e, I.num(lo)), !Number.isFinite(hi) || bhi <= hi || this.within(e, hi, 'hi', p) ? I.F : I.cmp('<', I.num(hi), e)]
  }
  // Whether e is at least lo (or at most hi) on the path: its conditions and its variables' ranges as facts.
  within(e: N, b: number, side: 'lo' | 'hi', p: Path): boolean {
    if (!Number.isFinite(b)) return false
    const facts: B[] = [...p.pc]
    for (const n of I.varsOf(e).vars) { const ty = this.ints.get(n); if (ty) { const r = rangeOf(ty); if (Number.isFinite(r[0])) facts.push(I.cmp('<=', I.num(r[0]), I.nvar(n))); if (Number.isFinite(r[1])) facts.push(I.cmp('<=', I.nvar(n), I.num(r[1]))) } }
    return nonneg(side === 'lo' ? I.sub(e, I.num(b)) : I.sub(I.num(b), e), {m: {refuse: I.F, pre: I.T} as Model, sorts: new Map(), atoms: facts})
  }
  // --- maps with a nil state, lists, big integers, locks --------------------------------------------------------------
  mapAt(m: V, at: SX, p: Path): Extract<Obj, {k: 'map'}> {
    if (m.t !== 'map' || !p.heap.has(m.id)) return refuse(at, `${at.text}: a map other than the state's`)
    return p.heap.get(m.id) as Extract<Obj, {k: 'map'}>
  }
  mkey(k: V, d: MapDecl, at: SX): K {
    if (d.key === 'num') { if (k.t !== 'num') refuse(at, 'a map key of the wrong kind'); return {op: 'num', e: (k as {e: N}).e} }
    if (k.t !== 'str') return refuse(at, 'a map key of the wrong kind')
    return k.e
  }
  // A map's value at a key: its type's zero where the map doesn't hold it.
  mapRead(m: V, k: V, at: SX, p: Path): {v: V, has: B} {
    const o = this.mapAt(m, at, p), cell = this.cellOf(o, this.mkey(k, o.decl, at), p, at), tys = at.tys as Record<string, IntTy | null>
    const vals = new Map([...cell.vals].map(([f, v]) => {
      const it = tys[f], typed: V = v.t === 'num' && it ? {...v, ty: it} : v
      return [f, this.ite(cell.has, typed, typed.t === 'num' ? {...typed, e: I.num(0)} : typed.t === 'bool' ? {t: 'bool', e: I.F} : typed, at)] as const
    }))
    return {v: o.decl.scalar ? vals.get('value')! : {t: 'struct', ty: String(at.sty), f: new Map(vals)}, has: cell.has}
  }
  mapWrite(m: V, k: V, v: V, at: SX, p: Path): Path {
    const o = this.mapAt(m, at, p), key = this.mkey(k, o.decl, at)
    if (o.origin !== 'state') return refuse(at, 'a write to a map other than the state\'s')
    this.refuseWhere(p, o.nil!, at, 'a write to a nil map (a panic)')
    const q = this.assume(p, I.not(o.nil!))
    if (o.w && !I.same(o.w.key, key)) return refuse(at, `writes ${o.decl.name} at a second key in one step`)
    const vals = new Map<string, V>(o.decl.scalar ? [['value', v]] : o.decl.fields.map(f => [f.name, (v as {f?: Map<string, V>}).f?.get(f.name) ?? refuse(at, 'a map value of the wrong kind')]))
    return {...q, heap: new Map(q.heap).set((m as {id: string}).id, {...o, w: {key, has: I.T, vals}})}
  }
  mapDelete(m: V, k: V, at: SX, p: Path): Path {
    const o = this.mapAt(m, at, p), key = this.mkey(k, o.decl, at)
    if (o.w && !I.same(o.w.key, key)) return refuse(at, `writes ${o.decl.name} at a second key in one step`)
    const vals = new Map<string, V>(o.decl.fields.map(f => [f.name, f.sort.k === 'num' ? {t: 'num', e: I.num(0), ty: {bits: 64, signed: true}} : {t: 'bool', e: I.F}]))
    return {...p, heap: new Map(p.heap).set((m as {id: string}).id, {...o, w: {key, has: I.F, vals}})}
  }
  // A map field set to a new empty map where it is nil (the lazy start Go code makes): its nil flag cleared.
  mapAssign(x: SX, v: V, p: Path): Path {
    if (v.t !== 'map' || v.id !== 'new-map') return refuse(x, 'a map given a second name (a map is a reference: a write through either is a write to both)')
    const [pl, q] = this.place(x, p)
    if (pl.k === 'blank') return q
    const [cur, q2] = this.read(pl, x, q)
    if (cur.t !== 'map') return refuse(x, 'a new map kept other than in a map field of the state')
    const o = this.mapAt(cur, x, q2), nil = o.nil!
    if (!(nil.op === 'const' && nil.v) && !q2.pc.some(c => I.same(c, nil))) return refuse(x, `${o.decl.name} replaced whole (the subset sets a map once, where it is nil)`)
    return {...q2, heap: new Map(q2.heap).set(cur.id, {...o, nil: I.F})}
  }
  listObj(s: V, at: SX, p: Path): Extract<Obj, {k: 'list'}> {
    if (s.t !== 'list' || !p.heap.has(s.id)) return refuse(at, `${at.text}: a slice other than the state's`)
    return p.heap.get(s.id) as Extract<Obj, {k: 'list'}>
  }
  listLen(s: V, at: SX, p: Path): N {
    const o = this.listObj(s, at, p)
    if (o.ops.length) return refuse(at, `${o.decl.name} read after it is written in one step`)
    return o.decl.len !== undefined ? I.num(o.decl.len) : I.nvar(`${o.decl.name}_len`)
  }
  inside(s: V, i: V, at: SX, p: Path): [Extract<Obj, {k: 'list'}>, N, B] {
    const o = this.listObj(s, at, p), idx = this.numv(i, at), len = this.listLen(s, at, p), inside = I.and(I.cmp('<=', I.num(0), idx), I.cmp('<', idx, len))
    this.refuseWhere(p, I.not(inside), at, o.decl.len !== undefined ? `an index outside [0, ${o.decl.len}) (undefined behavior)` : 'an index out of range (a panic)')
    return [o, idx, inside]
  }
  listGet(s: V, i: V, at: SX, p: Path): [V, Path] {
    const [o, idx, inside] = this.inside(s, i, at, p), e = {op: 'cell', map: o.decl.name, key: {op: 'num', e: idx}, field: '$item'} as const
    return [o.decl.fields[0]!.sort.k === 'num' ? {t: 'num', e: e as N, ty: at.ty as IntTy} : {t: 'bool', e: e as B}, this.assume(p, inside)]
  }
  listSet(s: V, i: V, v: V, at: SX, p: Path): Path {
    const [o, idx, inside] = this.inside(s, i, at, p), q = this.assume(p, inside)
    if (o.decl.len !== undefined && o.ops.length) return refuse(at, `a second write to ${o.decl.name} in one step`)
    return {...q, heap: new Map(q.heap).set((s as {id: string}).id, {...o, ops: [{op: 'set', i: idx, x: v, when: I.T}]})}
  }
  // s = append(s, x) and s = s[:len(s)-1] in s's own place; any other list put there is refused.
  listAssign(x: SX, v: V, p: Path): Path {
    const [pl, q] = this.place(x, p)
    if (pl.k === 'blank') return q
    const [cur, q2] = this.read(pl, x, q)
    if ((v.t !== 'push' && v.t !== 'pop') || cur.t !== 'list' || v.id !== cur.id) return refuse(x, 'a slice given a second name, or replaced whole (two slices may share a backing array: append writes into it or not by its capacity)')
    const o = this.listObj(cur, x, q2)
    if (o.ops.length) return refuse(x, `a second write to ${o.decl.name} in one step`)
    const it = o.decl.fields[0]!.sort.k
    if (v.t === 'push' && ((it === 'num' && v.x.t !== 'num') || (it === 'bool' && v.x.t !== 'bool'))) return refuse(x, 'an item of the wrong kind appended')
    return {...q2, heap: new Map(q2.heap).set(cur.id, {...o, ops: [v.t === 'push' ? {op: 'push', x: v.x, when: I.T} : {op: 'pop', when: I.T}]})}
  }
  newBig(v: N, p: Path): [V, Path] {
    const id = `new:${++this.fresh}`
    return [{t: 'ptr', to: {k: 'obj', id, path: []}}, {...p, heap: new Map(p.heap).set(id, {k: 'big', v, origin: 'fresh'})}]
  }
  // A big integer's value through a pointer (by cases; nil fails).
  bigVal(v: V, at: SX, p: Path): [N, Path] {
    if (v.t !== 'ptr') return refuse(at, `${at.text}: a big.Int read through a ${v.t}`)
    const [cs, q] = this.nonNil(v.to, at, p, `a nil *big.Int (${at.text})`)
    let out: N | undefined
    for (const o of [...cs.objs].reverse()) {
      const obj = q.heap.get(o.id)
      if (obj?.k !== 'big' || o.path.length) return refuse(at, 'a big.Int pointer to other than a big.Int')
      out = out === undefined ? obj.v : I.nite(o.c, obj.v, out)
    }
    return [out ?? I.num(0), q]
  }
  bigCall(x: SX, p: Path): [V, Path] {
    const n = String(x.op), zx = x.z as SX, ax = x.args as SX[], ty = x.ty as IntTy
    const [z, q0] = this.ev(zx, p)
    const as: V[] = []
    let q = q0
    for (const a of ax) { const [v, q2] = this.ev(a, q); as.push(v); q = q2 }
    const vals: N[] = []
    const ints = (k: number) => { for (let i = 0; i < k; i++) { const a = as[i]!; if (a.t === 'num') vals.push(a.e); else { const [v, q2] = this.bigVal(a, ax[i]!, q); vals.push(v); q = q2 } } }
    // z = e, z the receiver (its object written where z points), and z returned.
    const set = (e: N): [V, Path] => {
      const [, q2] = this.bigVal(z, zx, q)
      const heap = new Map(q2.heap)
      for (const o of this.cases((z as {to: Ptr}).to).objs) { const obj = heap.get(o.id) as Extract<Obj, {k: 'big'}>; heap.set(o.id, {...obj, v: I.nite(o.c, e, obj.v)}) }
      return [z, {...q2, heap}]
    }
    const sign = (l: N, r: N): N => I.nite(I.cmp('<', l, r), I.num(-1), I.nite(I.cmp('=', l, r), I.num(0), I.num(1)))
    switch (n) {
      case 'Add': ints(2); return set(I.add(vals[0]!, vals[1]!))
      case 'Sub': ints(2); return set(I.sub(vals[0]!, vals[1]!))
      case 'Mul': ints(2); return set(I.mul(vals[0]!, vals[1]!))
      case 'Neg': ints(1); return set(I.neg(vals[0]!))
      case 'Abs': ints(1); return set(I.nmax(vals[0]!, I.neg(vals[0]!)))
      case 'Set': ints(1); return set(vals[0]!)
      case 'SetInt64': case 'SetUint64': return set(this.numv(as[0]!, x))
      case 'Cmp': case 'CmpAbs': {
        const [a, q2] = this.bigVal(z, zx, q); q = q2; ints(1)
        const l = n === 'Cmp' ? a : I.nmax(a, I.neg(a)), r = n === 'Cmp' ? vals[0]! : I.nmax(vals[0]!, I.neg(vals[0]!))
        return [{t: 'num', e: sign(l, r), ty, cmp: [l, r]}, q]
      }
      case 'Sign': { const [a, q2] = this.bigVal(z, zx, q); return [{t: 'num', e: sign(a, I.num(0)), ty, cmp: [a, I.num(0)]}, q2] }
      case 'Int64': case 'Uint64': {
        const [a, q2] = this.bigVal(z, zx, q)
        if (n === 'Uint64') this.refuseWhere(q2, I.cmp('<', a, I.num(0)), x, 'Uint64 of a big.Int below 0 (undefined: Go returns its low bits)', false)
        return [{t: 'num', e: a, ty}, q2]
      }
      case 'IsInt64': { const [, q2] = this.bigVal(z, zx, q); return [{t: 'bool', e: I.T}, q2] }
      case 'String': return refuse(x, 'a big.Int as a string (outside an error\'s text)')
    }
    return refuse(x, `${x.text}: big.Int's ${n} (outside the subset)`)
  }
  // A lock's key: the place it is (of the object, or a local).
  lockKey(x: SX, p: Path): string {
    const [pl] = this.place(x, p)
    if (pl.k === 'local') return `local:${pl.id}.${pl.path.join('.')}`
    if (pl.k === 'heap' && pl.ptr.t === 'ptr' && pl.ptr.to.k === 'obj') return `${pl.ptr.to.id}.${[...pl.ptr.to.path, ...pl.path].join('.')}`
    return refuse(x, 'a mutex not of the object')
  }
  lockCall(x: SX, p: Path): [V, Path] {
    const n = String(x.op), key = this.lockKey(x.pl as SX, p)
    if (n === 'Lock' || n === 'RLock') {
      if (p.locks.includes(key)) refuse(x, `${x.text}: the mutex is locked again in the same step (a deadlock)`)
      return [{t: 'tuple', xs: []}, {...p, locks: [...p.locks, key]}]
    }
    if (n === 'Unlock' || n === 'RUnlock') {
      if (!p.locks.includes(key)) refuse(x, `${x.text}: an unlock of a mutex not locked (a panic)`)
      return [{t: 'tuple', xs: []}, {...p, locks: p.locks.filter(k => k !== key)}]
    }
    return refuse(x, `${x.text}: a mutex's ${n}`)
  }
  // A function of the module inlined, its receiver and arguments bound by id (Go's): its returns joined, each result
  // by the path that returned it, the locks it deferred released at each.
  inline(fn: SFunc, recv: V | undefined, args: V[], at: SX, p: Path): [V, Path] {
    if (fn.why) return refuse(at, fn.why)
    if (this.frames.includes(fn.id)) return refuse(at, `${fn.name}: a recursive call`)
    if (fn.late) return refuse(at, fn.late)
    this.spans.set(fn.id, fn.span)
    let q: Path = {...p, locals: new Map(p.locals), defers: []}
    if (fn.recv && recv) q = this.bindLocal(fn.recv, recv, at, q)
    fn.params.forEach((pa, i) => { if (pa.name) q = this.bindLocal(pa.name, args[i]!, at, q) })
    this.frames.push(fn.id)
    let flow: Flow
    try { flow = this.block(fn.body, q) } finally { this.frames.pop() }
    if (flow.brk?.length) refuse(at, `${fn.name}: a break outside a switch`)
    const rets: [Path, V][] = [...flow.rets, ...(flow.live ? [[flow.live, {t: 'tuple', xs: []}] as [Path, V]] : [])]
    if (flow.live && fn.results) refuse(at, `${fn.name}: a path with no return`)
    if (!rets.length) return [{t: 'opaque', why: 'no return', firm: true}, {...p, pc: [...p.pc, I.F]}]
    const joined = this.join(rets.map(([r, v]) => ({...r, locks: r.locks.filter(k => !r.defers.includes(k)), defers: p.defers, locals: new Map([...r.locals, ...(v as {xs: V[]}).xs.map((x, i) => [`$ret${i}`, x] as const)])})), at)!
    const vals = Array.from({length: fn.results ?? 0}, (_, i) => joined.locals.get(`$ret${i}`)!)
    return [vals.length === 1 ? vals[0]! : {t: 'tuple', xs: vals}, {...joined, locals: new Map(p.locals), defers: p.defers}]
  }
  // An assignment of Go's: each value evaluated (or one of several results, or a map's item and whether it is held),
  // then each target in order: a local bound, a map's item, a list's, a list or a map put back in its place, a place.
  assignGo(s: SS, p: Path): Path {
    const to = s.to as SX[]
    if (s.mapok) { const at = s.mapok as SX, [m, q] = this.ev(at.m as SX, p), [k, q2] = this.ev(at.k as SX, q), cell = this.mapRead(m, k, at, q2); return this.assignTo(to, [cell.v, {t: 'bool', e: cell.has}], q2) }
    if (s.one) {
      const [v, q] = this.ev(s.one as SX, p)
      // (the results of a call left out: each one its value, kept only where nothing reads it)
      if (v.t === 'opaque' && v.ask) return s.decl ? to.reduce((q2, x) => this.bindLocal(String(x.n), v, s, q2), q) : this.assignTo(to, to.map(() => v), q)
      if (v.t !== 'tuple' || (!s.decl && v.xs.length !== to.length)) return refuse(s, String(s.why))
      return s.decl ? to.reduce((q2, x, i) => this.bindLocal(String(x.n), v.xs[i]!, s, q2), q) : this.assignTo(to, v.xs, q)
    }
    let q = p
    const vals: V[] = []
    for (const e of s.xs as SX[]) { const [v, q2] = this.ev(e, q); vals.push(v); q = q2 }
    return this.assignTo(to, vals, q)
  }
  assignTo(l: SX[], vals: V[], p: Path): Path {
    let q = p
    l.forEach((x, i) => {
      const v = vals[i]!
      if (x.bind && !(x.bind === 'new' && q.locals.has(String(x.n)))) { q = this.bindLocal(String(x.n), v, x, q); return }
      if (x.e === 'midx') { const [m, q2] = this.ev(x.m as SX, q), [k, q3] = this.ev(x.k as SX, q2); q = this.mapWrite(m, k, v, x, q3); return }
      if (x.e === 'lidx') { const [sv, q2] = this.ev(x.s as SX, q), [k, q3] = this.ev(x.i as SX, q2); q = this.listSet(sv, k, v, x, q3); return }
      if (x.e === 'no') return refuse(x, String(x.why))
      if (v.t === 'list' || v.t === 'push' || v.t === 'pop') { q = this.listAssign(x, v, q); return }
      if (v.t === 'map') { q = this.mapAssign(x, v, q); return }
      const [pl, q2] = this.place(x, q)
      q = this.write(pl, v, x, q2)
    })
    return q
  }
  // A switch: each case's condition (none before it matched; the default's, none matched), evaluated in order; a case
  // carried into the next by fallthrough, a break out of it joined after.
  switchGo(s: SS, p: Path): Flow {
    let q = p, tag: V | undefined
    if (s.tag) { const [v, q2] = this.ev(s.tag as SX, q); tag = v; q = q2 }
    const cases = s.cases as {list?: SX[], default?: boolean, b: SS[], p: string}[], conds: B[] = []
    let none: B = I.T
    for (const c of cases) {
      if (c.default) { conds.push(I.F); continue }
      let any: B = I.F
      for (const e of c.list!) { const [v, q2] = this.ev(e, q); q = q2; any = I.or(any, tag ? this.eq(tag, v, e, q) : v.t === 'bool' ? v.e : refuse(e, 'a case that isn\'t a condition')) }
      conds.push(I.and(none, any)); none = I.and(none, I.not(any))
    }
    const di = cases.findIndex(c => c.default)
    if (di >= 0) conds[di] = none
    const lives: Path[] = [], rets: [Path, V][] = [], conts: Path[] = []
    let carried: Path | undefined
    cases.forEach((c, i) => {
      const entry = conds[i]!.op === 'const' && !(conds[i] as {v: boolean}).v ? undefined : this.assume(q, conds[i]!)
      let into = this.join([...(entry ? [entry] : []), ...(carried ? [carried] : [])], c)
      // (entered and carried into: the join keeps that one or the other got here, which a later join reads)
      if (entry && carried && into) { let k = 0; while (k < entry.pc.length && k < carried.pc.length && I.same(entry.pc[k]!, carried.pc[k]!)) k++; into = this.assume(into, I.or(I.and(...entry.pc.slice(k)), I.and(...carried.pc.slice(k)))) }
      carried = undefined
      if (!into) return
      const f = this.block(c.b, into)
      if (f.live) lives.push(f.live)
      rets.push(...f.rets)
      const bs = (f.brk ?? []).filter(x => !x.cont)
      if (bs.length) lives.push(this.join(bs, c)!)
      conts.push(...(f.brk ?? []).filter(x => x.cont))
      if (f.ft) { if (i === cases.length - 1) refuse(c, 'fallthrough out of the last case'); carried = f.ft }
    })
    if (di < 0) lives.push(this.assume(q, none))
    const live = this.join(lives, s)
    return {...(live ? {live} : {}), rets, ...(conts.length ? {brk: conts} : {})}
  }
}

// --- folds' helpers --------------------------------------------------------------------------------------------------
// A cell of a carried list at a pass; a fold's own values (whether a pass ended it, returned, failed, refused).
const PASS = I.PASS, FLAGS = ['__done', '__returned', '__ret', '__failed', '__refused']
const cellV = (map: string, i: N, f: string, s: Var['sort'], ty?: IntTy): V => {
  const c = {op: 'cell' as const, map, key: {op: 'num' as const, e: i}, field: f}
  return s.k === 'num' ? {t: 'num', e: c, ...(ty ? {ty} : {})} : s.k === 'bool' ? {t: 'bool', e: c} : s.k === 'str' ? {t: 'str', e: c} : {t: 'choice', e: {...c, values: s.k === 'choice' ? s.values : []}}
}
// The fields of a collection's items an order reads (its parts over an item at a key).
const orderFields = (by: (k: K) => {e: N, desc?: boolean}[], d: MapDecl): string[] => { const out = new Set<string>(); JSON.stringify(by({op: 'num', e: I.nvar('kl$')}), (k, v) => { if (k === 'field' && typeof v === 'string' && d.fields.some(f => f.name === v)) out.add(v); return v }); return [...out] }
// A value with a numeric bound name (k$) replaced by a term, in its terms.
const substV = (v: V, name: string, by: N): V => (v.t === 'num' || v.t === 'bool' || v.t === 'choice' || v.t === 'str' ? {...v, e: I.substN(v.e as N, name, by)} as V : v)
const sortOfV = (v: V): Var['sort'] | undefined => (v.t === 'num' ? {k: 'num'} : v.t === 'bool' ? {k: 'bool'} : v.t === 'choice' ? {k: 'choice', values: lvalues(v.e)} : v.t === 'str' ? {k: 'str'} : undefined)
const termOfV = (v: V, at: {p: string}): Term => (v.t === 'num' ? {s: 'num', e: v.e} : v.t === 'bool' ? {s: 'bool', e: v.e} : v.t === 'choice' ? {s: 'choice', e: v.e} : v.t === 'str' ? {s: 'str', e: v.e} : refuse(at, `a ${v.t} where a fold keeps a number, a boolean, a string or a choice`))
// The locals a body sets (each statement's targets), by name.
const assigned = (ss: SS[]): Set<string> => {
  const out = new Set<string>(), tv = (t?: SX): void => { if (t?.e === 'var') out.add(String(t.n)); else if (t?.e === 'tuple') (t.xs as SX[]).forEach(tv) }
  deep(ss, o => { if (o.s === 'set' || o.s === 'incdec' || o.s === 'opset' || o.s === 'for') tv(o.to as SX); if (o.s === 'assign') ((o.to as SX[] | undefined) ?? []).forEach(tv); return false })
  return out
}
// A pointer by a condition (one case where both are the same).
export const phiP = (c: B, a: Ptr, b: Ptr): Ptr => (c.op === 'const' ? (c.v ? a : b) : JSON.stringify(a) === JSON.stringify(b) ? a : {k: 'phi', c, a, b})
// The values a merge keeps exact (Go's): refused, not made opaque, where two paths make them different.
// A path a failure ended (its condition false): what follows on it is never run.
const dead = (p: Path): boolean => p.pc.some(c => c.op === 'const' && !c.v)
// A string known where it is read (a literal; a choice's one value).
const strLit = (v: V): string | undefined => (v.t === 'str' && v.e.op === 'slit' ? v.e.value : v.t === 'choice' && v.e.op === 'lit' ? v.e.value : undefined)
// A class made by running its __init__: one the reader read (a class of the file, or of the repository the code makes),
// not a dataclass, a model or a protocol, every base known.
const madeByInit = (r: SRec): boolean => typeof r.methods.__init__ === 'string' && !r.kinds.some(k => ['dataclass', 'pydantic', 'typeddict', 'protocol'].includes(k) || k.startsWith('outside-base'))
const firm = (v: V): boolean => ['ptr', 'struct', 'err', 'nil', 'map', 'list', 'push', 'pop'].includes(v.t) || (v.t === 'opaque' && !!v.firm)
// An expression that calls nothing (so evaluating it changes nothing).
// Whether some node of an IR tree (an object, depth first) is one f says yes to.
const deep = (x: unknown, f: (o: SX & SS) => unknown): boolean => !!x && typeof x === 'object' && (!!f(x as SX & SS) || Object.values(x).some(y => deep(y, f)))
const callFree = (x: unknown): boolean => !deep(x, o => o.e === 'call' || o.e === 'await' || o.e === 'no')
// A key of the other kind than its map's (a string into a map keyed by numbers): never held where keys are compared as
// they are (a Map, a dict, a hash), so refused; an object's keys (a record's, JavaScript's) are strings both.
const kindOf = (k: K): 'num' | 'str' | undefined => k.op === 'num' ? 'num' : k.op === 'svar' || k.op === 'slit' ? 'str' : k.op === 'kite' && kindOf(k.a) === kindOf(k.b) ? kindOf(k.a) : undefined
function keyKind(d: MapDecl, k: K, at: SX): void {
  const kk = kindOf(k)
  if (kk && kk !== d.key && d.js !== 'record' && !d.untyped) refuse(at, `${at.text ?? ''}: a ${kk === 'num' ? 'number' : 'string'} key of a map keyed by ${d.key === 'num' ? 'numbers' : 'strings'} (never one it holds)`)
}
// An expression that reaches none of the module's own code and not `self`, nor what raises wherever it runs (a reader's
// `raises`: a name nothing binds).
const foreign = (x: unknown): boolean => !deep(x, o => o.e === 'fn' || (o.e === 'var' && o.n === 'self') || !!o.raises)
// Two key templates name disjoint keys: they differ at some position of their fixed prefixes or of their fixed
// suffixes (a hole's value can be any string, so only those parts tell keys apart).
export function disjoint(a: string, b: string): boolean {
  if (a === b) return false
  const [pa, sa] = split(a), [pb, sb] = split(b)
  for (let i = 0; i < Math.min(pa.length, pb.length); i++) if (pa[i] !== pb[i]) return true
  for (let i = 1; i <= Math.min(sa.length, sb.length); i++) if (sa[sa.length - i] !== sb[sb.length - i]) return true
  return false
}
const split = (t: string): [string, string] => { const i = t.indexOf('{}'); return i < 0 ? [t, t] : [t.slice(0, i), t.slice(i + 2)] }

// --- a module's step: the class (or the functions) read into the Model -------------------------------------------------
// What a refutation (or any request of the rule) assumes of the boundary inferred: each answer inferred or tagged
// that it gives a value, as "assumes `callee` may return v". A refutation that assumes none is the code's own.
export function assumed(x: {read?: StepRead}, request: Record<string, unknown> | undefined): string[] {
  const out: string[] = []
  for (const a of x.read?.answers ?? []) {
    // (a call that raises inside a try: the request says it does, and which handler's class)
    for (const rs of a.raises ?? []) {
      const r = request?.[rs.name]
      if (r !== undefined && r !== false && r !== 0 && r !== 'none') out.push(`assumes \`${a.key.split('.').pop()}\` may raise${typeof r === 'string' ? ` ${r}` : ''} (inside a try that catches it)`)
    }
    if (!a.how || a.pass || !request || !(a.inputs.name in request)) continue
    // (an integer of the prover's is a pair: x − x$neg; a boolean 0 or 1)
    const none = a.inputs.none && (request[a.inputs.none] === true || request[a.inputs.none] === 1), v = request[a.inputs.name], neg = request[`${a.inputs.name}$neg`]
    const shown = none ? 'None' : /^bool\b/.test(a.sort) ? String(v === true || v === 1) : typeof v === 'number' ? String(v - (typeof neg === 'number' ? neg : 0)) : JSON.stringify(v)
    out.push(`assumes \`${a.key.split('.').pop()}\` may return ${shown} (${a.how}: any ${a.sort})`)
  }
  return out
}
// The text of a file a position names (its name as the reader wrote it: absolute, under the root, or beside the file).
export function sourceOf(mod: {path: string, root: string}, file: string): string | undefined {
  const fs = node<{readFileSync: (f: string, e: string) => string}>('node:fs'), dir = mod.path.replace(/\/[^/]*$/, '')
  for (const f of [file.startsWith('/') ? file : '', mod.path.endsWith(`/${file}`) ? mod.path : '', `${mod.root}/${file}`, `${dir}/${file}`]) if (f) try { return fs.readFileSync(f, 'utf8') } catch { /* the next */ }
  return undefined
}
// The stubbing of a compiled language's check: each answered call's text (from its position to its end) replaced in
// its file by the harness's stub for that answer (in the code's language). Every file a call is answered in,
// rewritten, by its name in the positions; a call with no end (a reader that doesn't say) is a refusal of the check.
export function stubbed(read: StepRead, text: (file: string) => string | undefined, stub: (a: Answer, i: number, call: string) => string): Map<string, string> {
  const edits = new Map<string, [number, number, string][]>(), starts = new Map<string, number[]>()
  for (const [i, a] of (read.answers ?? []).entries()) {
    for (const s of a.at ?? []) {
      // (its place: offsets where the reader gives them, a JVM reader's; else from its position to its end)
      const m = /^(.*):(\d+):(\d+)$/.exec(s.p), e = s.end && /^(\d+):(\d+)$/.exec(s.end)
      if (!m || (!e && !s.span)) throw new Refusal(s.p, `${a.key}: an answered call whose end the reader doesn't give (the check can't stub it)`)
      const [from, to] = s.span ?? [lineCol(m[1]!, Number(m[2]), Number(m[3])), lineCol(m[1]!, Number(e![1]), Number(e![2]))]
      ;(edits.get(m[1]!) ?? edits.set(m[1]!, []).get(m[1]!)!).push([from, to, stub(a, i, (text(m[1]!) ?? '').slice(from, to))])
    }
  }
  function lineCol(f: string, l: number, c: number): number {
    let ls = starts.get(f)
    if (!ls) { const t = text(f) ?? ''; ls = [0]; for (let k = 0; k < t.length; k++) if (t[k] === '\n') ls.push(k + 1); starts.set(f, ls) }
    return (ls[l - 1] ?? 0) + c - 1
  }
  const out = new Map<string, string>()
  for (const [f, es] of edits) {
    let t = text(f) ?? ''
    for (const [a, b, r] of es.sort((x, y) => y[0] - x[0])) t = t.slice(0, a) + r + t.slice(b)
    out.set(f, t)
  }
  return out
}
// The names a reader is asked for (none: the module's classes, for the entry inferred).
export const entryNames = (opts: {entry?: string | string[]}): string[] => (opts.entry === undefined ? [] : Array.isArray(opts.entry) ? opts.entry : [opts.entry])
// The module read into the rule. Unless strict, the boundary is inferred: each run that refuses where the subset's
// inference can go on (a value of other code read, the module's own code outside the subset) adds what the next run
// infers, until one reads (or refuses with what the caller would state to accept it).
export function readStep(mod: SModule, opts: StepOptions): StepRead {
  if (opts.strict) return readOnce(mod, opts, new Stepper(mod, opts))
  const inf: Inferred = {answers: new Map(), cut: new Map()}
  for (let n = 0; ; n++) {
    const g = new Stepper(mod, opts, inf)
    try { return readOnce(mod, opts, g) } catch (e) {
      if (!(e instanceof Refusal)) throw e
      const r = n < 256 ? g.promote(e) : e
      if (r) throw r
    }
  }
}
class InitializerChoice extends Refusal {
  readonly initializers: NonNullable<Extraction['initializers']>
  constructor(r: SRec) {
    super(r.p, `${r.short}: several constructors (select ctor, or check every initializer with the CLI)`)
    this.initializers = {entry: r.name, name: r.short, selectors: r.initializers!}
  }
}
function readOnce(mod: SModule, opts: StepOptions, g: Stepper): StepRead {
  if (mod.error) refuse(mod.file ?? mod.root ?? '?', mod.error)
  const kept = opts.failures === 'kept', carried = kept && opts.onError !== 'discard'
  let entries = mod.entries
  for (const e of entries) if (e.k === 'missing') refuse(mod.file, `no class or function ${e.name} in ${mod.file}`)
  // No entry: the module's one class whose public methods write its state, and those methods.
  let writing: string[] | undefined
  if (!entryNames(opts).length) {
    if (!g.inf) refuse(mod.file, 'no entry (strict: name the class or the functions)')
    const pub = (r: SRec) => Object.keys(r.methods).filter(m => !m.startsWith('_') && r.methods[m] && g.writesState(r.methods[m]!, new Set(g.mod.funcs[r.methods[m]!]?.params.filter(x => x.self).map(x => x.name) ?? [])))
    const cands = entries.filter((e): e is {k: 'class', rec: string} => e.k === 'class' && pub(g.rec(e.rec, {p: mod.file})).length > 0)
    if (cands.length !== 1) refuse(mod.file, cands.length ? `several classes write their state (${cands.map(e => g.rec(e.rec, {p: mod.file}).short).join(', ')}): name one (entry)` : 'no class whose public methods write its state: name the entry (a class, or functions)')
    entries = cands
    writing = pub(g.rec(cands[0]!.rec, {p: mod.file}))
    g.notes.add(`the entry inferred: ${g.rec(cands[0]!.rec, {p: mod.file}).short}, the class whose public methods write its state${opts.methods ? '' : ` (${writing.join(', ')}; the others read it)`}`)
  }
  const cls = entries.length === 1 && entries[0]!.k === 'class' ? (entries[0] as {rec: string}).rec : undefined
  if (!cls && entries.some(e => e.k === 'class')) refuse(mod.file, 'a class read with other entries (one class, or functions)')
  const leaves: Leaf[] = [], ctor: [string, PArg][] = []
  const at = {p: `${mod.file}:1:1`}
  // --- the state: the object as its constructor makes it -----------------------------------------------------------
  const stateOf = new Map<string, V>()  // each leaf's value at the start (terms over the params)
  let pre: B = I.T
  const tree: {path: string[], v: V, t?: SType}[] = []
  if (cls) {
    const r = g.rec(cls, at)
    if (!r.own) refuse(at, `${r.short}: a class of another module`)
    const fresh: Path = {pc: [], locals: new Map(), heap: new Map([['this', {k: 'rec', ty: cls, f: new Map(), origin: 'state'}]]), called: [], locks: [], defers: []}
    g.init = true
    g.method = '__init__'
    const r0 = g.refusals.length
    let made: Path
    const initId = g.initMethod(r, at)
    if (initId) g.entryIds.add(initId)
    if (r.kinds.some(k => k.startsWith('generic:'))) refuse(r, `${r.short}: a generic type (its methods read a type parameter)`)
    if (r.initializers && r.initializers.length > 1) throw new InitializerChoice(r)
    const rustNew = mod.lang === 'rust' ? r.methods.new : undefined
    if (rustNew) g.entryIds.add(rustNew)
    if (mod.lang === 'rust' && rustNew) {
      // Rust: the object is what `new` returns, its arguments the rule's params (named after the fields' names).
      for (const f of r.fields) g.fieldNames.add(f.name)
      const fn = g.func(rustNew, at)
      const args: V[] = []
      let p = fresh
      for (const pa of fn.params.filter(x => !x.self)) {
        const [v, a] = g.input(pa.name, pa.t, fn, p, 'param')
        if (a.k === 'inert') refuse(fn, `${r.short}::new(${pa.name}): an argument of ${g.why(pa.t)}`)
        args.push(v); ctor.push([pa.name, a])
      }
      const [out, p2] = g.callFunc(fn, undefined, args, [], {e: 'call', p: fn.p, text: `${r.short}::new()`}, p, true)
      const obj = out.t === 'ref' ? p2.heap.get(out.id) : undefined
      if (obj?.k !== 'rec' || obj.ty !== cls) refuse(fn, `${r.short}::new returns ${out.t === 'ref' ? 'another object' : `a ${out.t}`} (the subset reads a new() that returns Self)`)
      made = {...p2, heap: new Map(p2.heap).set('this', {...(obj as Extract<Obj, {k: 'rec'}>), origin: 'state'})}
      if (ctor.length) g.notes.add(`${r.short} made by ${r.short}::new: its arguments are the rule's params`)
    } else if (mod.lang === 'rust') {
      if (!r.kinds.includes('default')) refuse(r, `${r.short}: no new() and no derived Default (the subset makes the object by one of them)`)
      const f = new Map<string, V>()
      for (const fd of r.fields) f.set(fd.name, defaultOf(fd.t, at))
      made = {...fresh, heap: new Map(fresh.heap).set('this', {k: 'rec', ty: cls, f, origin: 'state'})}
      g.notes.add(`${r.short}: made by its derived Default`)
    } else if (initId) {
      const fn = g.func(initId, at)
      // The fields it sets (named first: the state's names are the fields').
      const scan = (ss: SS[]) => { for (const st of ss) { const to = st.to as SX | undefined; if (st.s === 'set' && to?.e === 'get' && (to.x as SX).e === 'var' && (to.x as SX).n === 'self') g.fieldNames.add(String(to.f)); if (st.s === 'if') { scan(st.then as SS[]); scan(st.else as SS[]) } if (st.s === 'with') scan(st.body as SS[]) } }
      scan(fn.body)
      const args: V[] = [], kw: [string, V][] = []
      let p = fresh
      // (a keyword argument given as one)
      const give = (pa: SParam, v: V) => { if (pa.kw) kw.push([pa.name, v]); else args.push(v) }
      for (const pa of fn.params.filter(x => !x.self && !x.star)) {
        const dep = opts.stores?.[pa.name] ? undefined : g.injected(pa, fn, r)
        if (opts.stores?.[pa.name] || dep) {
          const id = `store:${pa.name}`; p.heap.set(id, {k: 'store', name: pa.name}); g.initHeap.set(id, {k: 'store', name: pa.name}); give(pa, {t: 'ref', id}); ctor.push([pa.name, {k: 'store', name: pa.name}])
          if (!dep || dep.keyed) g.storeKeyed.add(pa.name)
          const pt = pa.t.k === 'opt' ? pa.t.of : pa.t
          g.deps.push({name: pa.name, ...(pt.k === 'rec' ? {ty: pt.name} : {}), keyed: !dep || dep.keyed, stated: !dep})
          if (dep?.ty) g.storeTypes.set(pa.name, dep.ty)
          if (dep) g.notes.add(`${r.short}(${pa.name}): an injected dependency (inferred: ${pa.inject ? 'marked so' : `of ${dep.ty ? g.mod.recs[dep.ty]?.short ?? dep.ty : 'no stated type'}, its methods called`}), the check giving one that ${dep.keyed ? 'keeps what is set' : 'answers its calls'}`)
          if (pa.dflt?.e === 'none') g.notes.add(`${r.short}(${pa.name}): given one, never its default None (the claim is for objects made with one)`)
          continue
        }
        if (pa.dflt && !g.scalar(pa.t.k === 'opt' ? pa.t.of : pa.t)) { ctor.push([pa.name, {k: 'dflt'}]); const [d, p2] = g.ev(pa.dflt, p); give(pa, d); p = p2; continue }
        if (pa.dflt && opts.defaults?.includes(pa.name)) { ctor.push([pa.name, {k: 'dflt'}]); const [d, p2] = g.ev(pa.dflt, p); give(pa, d); p = p2; g.atDefault.add(d); g.notes.add(`${r.short}(${pa.name}): at its default (stated: defaults), the fields set to it constants`); continue }
        const [v, a] = g.input(pa.name, pa.t, fn, p, 'param')
        // (an argument of no kind the rule holds, a dict of no stated types say: the constructor and the methods may
        // keep it, and are refused wherever the rule would read it, as a method's argument of that type is; the check
        // gives an inert one)
        if (a.k === 'inert') g.notes.add(`${r.short}(${pa.name}): ${g.why(pa.t)}, read nowhere the rule keeps (the check gives an inert one)`)
        // (where the rule would read it, refused there, saying how: a store, or a default)
        give(pa, a.k === 'inert' && v.t === 'opaque' ? {...v, why: `${v.why} (a constructor argument: state it as a store, or give it a default)`} : v); ctor.push([pa.name, a])
      }
      const [, p2] = g.callFunc(fn, {t: 'ref', id: 'this'}, args, kw, {e: 'call', p: fn.p, text: `${r.short}()`}, p, false)
      made = p2
      if (ctor.length) g.notes.add(`${r.short} made by its constructor: its arguments are the rule's params`)
    } else if (r.kinds.includes('dataclass') || r.orm) {
      if (r.orm?.why) refuse(r, r.orm.why)
      const f = new Map<string, V>()
      let p = fresh
      for (const fd of r.fields) {
        if (fd.dflt) { const [d, p2] = g.ev(fd.dflt, p); f.set(fd.name, g.timeField(d, fd.t, false, {p: r.p})); p = p2; g.declared.set(`this.${fd.name}`, fd.t); continue }
        const [v, a] = g.input(fd.name, fd.t, {p: r.p}, p, 'param')
        if (a.k === 'inert') refuse(r, `${r.short}.${fd.name}: a field of ${g.why(fd.t)}`)
        f.set(fd.name, g.timeField(v, fd.t, false, {p: r.p})); ctor.push([fd.name, a]); g.declared.set(`this.${fd.name}`, fd.t)
      }
      if (r.methods.__post_init__) refuse(r, `${r.short}: __post_init__`)
      made = {...p, heap: new Map(p.heap).set('this', {k: 'rec', ty: cls, f, origin: 'state'})}
      g.notes.add(r.orm ? `${r.short}: a ${r.orm.framework} row; every declared column supplied as a parameter, no database read by its constructor` : `${r.short}: a dataclass, made with its fields' defaults (the claim is for objects made so) and the others as params`)
    } else made = fresh
    // (what the constructor refuses, a narrowing cast's value that doesn't fit, is the precondition's)
    pre = I.and(I.not(I.or(...g.fails)), I.not(I.or(...g.paramsOut)), I.not(I.or(...g.refusals.splice(r0))))
    g.fails = []
    g.init = false
    // (a field a framework injects, @Autowired or @Inject on it, or one a stated store names whatever the constructor
    // made it (a client made from a URL): the store the check gives, named by the field)
    const madeAs = (f: string) => (made.heap.get('this') as Extract<Obj, {k: 'rec'}>).f.get(f), isStore = (v?: V) => v?.t === 'ref' && made.heap.get(v.id)?.k === 'store'
    const stated = Object.keys(opts.stores ?? {}).filter(f => madeAs(f) && !isStore(madeAs(f)) && !r.fields.some(x => x.name === f)).map(f => ({name: f, t: {k: 'any'} as SType}))
    for (const fd of [...r.fields.filter(f => (g.inf && f.inject && !madeAs(f.name)) || (opts.stores?.[f.name] && madeAs(f.name) && !isStore(madeAs(f.name)))), ...stated]) {
      const id = `store:${fd.name}`, o: Obj = {k: 'store', name: fd.name}
      made.heap.set(id, o); g.initHeap.set(id, o); g.injectedFields.push(fd.name)
      ;(made.heap.get('this') as Extract<Obj, {k: 'rec'}>).f.set(fd.name, {t: 'ref', id})
      if (fd.t.k === 'rec') g.storeTypes.set(fd.name, fd.t.name)
      const keyed = g.callsOn(r, [fd.name]).some(m => !!keyShape(m))
      if (keyed) g.storeKeyed.add(fd.name)
      g.deps.push({name: fd.name, ...(fd.t.k === 'rec' ? {ty: fd.t.name} : {}), keyed, stated: false})
      g.notes.add(`${r.short}.${fd.name}: ${stated.includes(fd as never) ? 'a store (stated), the check giving one in its place after the constructor' : 'an injected dependency (marked so), the check giving one'}`)
    }
    // (two injected dependencies are taken as two objects: where they are of one type and the rule holds keys of one,
    // the code may be given one object for both, which the rule would take as two; refused unless both are stated)
    for (const [i, a] of g.deps.entries()) for (const b of g.deps.slice(i + 1)) {
      if (a.ty === b.ty && (a.keyed || b.keyed) && !(a.stated && b.stated)) refuse(r, `${r.short}(${a.name}, ${b.name}): two injected dependencies of one type (${a.ty ? g.mod.recs[a.ty]?.short ?? a.ty : 'none stated'}), the rule holding keys of ${a.keyed ? a.name : b.name}: the code may be given one object for both, which the rule would take as two (state both stores, stores: {${a.name}: {}, ${b.name}: {}}, to take them as distinct)`)
    }
    if (g.deps.length > 1) g.notes.add(`${r.short}: assumes its injected dependencies ${g.deps.map(d => d.name).join(', ')} are distinct objects (each with what it holds)`)
    const self = made.heap.get('this') as Extract<Obj, {k: 'rec'}>
    for (const [f, c] of Object.entries(opts.fields ?? {})) {
      if (!self.f.has(f)) refuse(r, `${r.short}.${f}: a field stated (fields) that the constructor doesn't set`)
      const v: V = c === null ? {t: 'none'} : typeof c === 'boolean' ? {t: 'bool', e: c ? I.T : I.F} : typeof c === 'number' ? {t: 'num', e: I.num(c)} : {t: 'str', e: {op: 'slit', value: c}}
      self.f.set(f, v); g.atDefault.add(v)
      g.notes.add(`${r.short}.${f}: held at ${JSON.stringify(c)} (stated: fields; the claim is for objects so configured)`)
    }
    for (const [f, v] of self.f) { const t = g.declared.get(`this.${f}`) ?? r.fields.find(x => x.name === f)?.t; tree.push({path: [f], v, ...(t && t.k !== 'any' ? {t} : {})}) }
    for (const fd of r.fields) if (!self.f.has(fd.name) && !r.kinds.includes('dataclass')) g.notes.add(`${r.short}.${fd.name}: declared on the class but not set by its constructor (left out)`)
    // Each field a leaf: a variable (two for an optional one), a nested object's own, a map, a store, or left out.
    const heap = new Map<string, Obj>()
    const fields = new Map<string, V>(), holding = new Set<string>()
    const build = (path: string[], v: V, t: SType | undefined, into: Map<string, V>, initPath: Path) => {
      const name = path.join('_'), f = path.at(-1)!, decl = t ?? undefined
      const scalarT = decl && decl.k !== 'opt' ? decl : undefined
      const leaf = (kind: Leaf['kind'], vr: Var, float?: boolean) => { leaves.push({name: vr.name, path, kind, ...(float ? {float: true} : {})}); return vr }
      const isFloat = (decl?.k === 'float') || (decl?.k === 'opt' && decl.of.k === 'float')
      if (g.atDefault.has(v)) { into.set(f, v); g.frozen.add(path.join('.')); leaves.push({name: '', path, kind: 'frame'}); return }
      const inner: SType | undefined = decl?.k === 'opt' ? decl.of : scalarT
      // (None, of an optional type of no scalar inside, a dict's or another class's: as a field set to None, below)
      const sort0: Var['sort'] | undefined = inner && g.scalar(inner) ? g.scalar(inner)! : v.t === 'num' ? {k: 'num'} : v.t === 'bool' ? {k: 'bool'} : v.t === 'str' ? {k: 'str'} : v.t === 'choice' ? {k: 'choice', values: lvalues(v.e)} : v.t === 'opt' && g.scalar({k: v.v.t === 'num' ? 'int' : v.v.t === 'bool' ? 'bool' : 'str'} as SType) ? (v.v.t === 'num' ? {k: 'num'} : v.v.t === 'bool' ? {k: 'bool'} : {k: 'str'}) : undefined
      if (v.t === 'num' || v.t === 'bool' || v.t === 'str' || v.t === 'choice' || (v.t === 'none' && decl?.k === 'opt' && sort0) || v.t === 'opt') {
        const sort: Var['sort'] = sort0 ?? refuse(at, `${path.join('.')}: a field of no scalar type`)
        if (v.t === 'str' && sort.k === 'choice' && v.e.op === 'slit') v = {t: 'choice', e: I.llit(v.e.value, sort.values)}
        const optional = v.t === 'none' || v.t === 'opt' || decl?.k === 'opt'
        const vr = leaf(sort.k === 'num' ? 'num' : sort.k, g.newVar(name, sort, 'state'), isFloat)
        if (inner) g.typed(vr, inner, 'state')
        const lf = leaves[leaves.length - 1]!; if (decl) lf.t = decl
        let cur: V = g.valueOf(vr)
        if (optional) {
          const nv = leaf('none', g.newVar(`${name}_none`, {k: 'bool'}, 'state', `whether ${path.join('.')} is None`))
          const has = I.not(I.bvar(nv.name))
          stateOf.set(nv.name, {t: 'bool', e: v.t === 'none' ? I.T : v.t === 'opt' ? I.not(v.has) : I.F})
          stateOf.set(vr.name, v.t === 'none' ? zeroOf(sort) : v.t === 'opt' ? v.v : v)
          cur = {t: 'opt', has, v: cur}
        } else stateOf.set(vr.name, v)
        into.set(f, cur)
        return
      }
      if (v.t === 'ref') {
        const o = initPath.heap.get(v.id)
        if (o?.k === 'store') { into.set(f, v); heap.set(v.id, o); return }
        if (o?.k === 'rec') {
          // (an object that holds itself, by a field of its own or of one it holds: its leaves would never end)
          if (holding.has(v.id)) refuse(at, `${path.join('.')}: an object that holds itself`)
          holding.add(v.id)
          const sub = new Map<string, V>(), id = `state:${path.join('.')}`
          for (const [ff, vv] of o.f) build([...path, ff], vv, g.mod.recs[o.ty]?.fields.find(x => x.name === ff)?.t, sub, initPath)
          holding.delete(v.id)
          heap.set(id, {k: 'rec', ty: o.ty, f: sub, origin: 'state'})
          leaves.push({name: '', path, kind: 'frame', cls: o.ty})
          into.set(f, {t: 'ref', id})
          return
        }
      }
      // A list of records or numbers the constructor makes empty: an ordered collection, a map keyed by each item's place
      // in the list's order (MapDecl.ordered).
      if (v.t === 'opaque' && decl?.k === 'list' && /\[\]/.test(v.why) && (decl.of.k === 'rec' || g.scalar(decl.of)?.k === 'num')) {
        const vt = decl.of, d = g.mapDeclOf(name, {k: 'map', key: {k: 'int'}, val: vt}, at), id = `state:${path.join('.')}`
        d.ordered = true
        heap.set(id, {k: 'map', decl: d, val: vt, origin: 'state'})
        leaves.push({name: d.name, path, kind: 'map', key: 'num', ordered: true, ...(vt.k === 'rec' ? {cls: vt.name, fields: d.fields.map(x => ({name: x.name, ...(g.mod.recs[vt.name]!.fields.find(y => y.name === x.name)?.t.k === 'float' ? {float: true} : {}), ...(x.sort.k === 'choice' ? {choice: true} : {})}))} : vt.k === 'float' ? {float: true} : {})})
        into.set(f, {t: 'ref', id})
        g.notes.add(`${path.join('.')}: a list, read as its items in order (each item's place a key that only grows as items are added)`)
        return
      }
      // (a dict whose cells the rule can hold: keyed by integers or strings, of sets' keys, records, or numbers, booleans
      // and literals; another, of threading.Event say, is a field outside the subset, left out like any other)
      const cellable = (t: SType & {k: 'map'}): boolean => (t.key.k === 'int' || t.key.k === 'str') && (!!t.set || t.val.k === 'rec' || (!!g.scalar(t.val) && g.scalar(t.val)!.k !== 'str'))
      if (v.t === 'opaque' && decl?.k === 'map' && /\{\}/.test(v.why) && !!decl.set === /^(set|frozenset)\(\)/.test(v.why) && cellable(decl)) {
        const d = g.mapDeclOf(name, decl, at), id = `state:${path.join('.')}`
        const vt = decl.val
        heap.set(id, {k: 'map', decl: d, val: vt, origin: 'state'})
        leaves.push({name: d.name, path, kind: 'map', key: d.key, ...(decl.set ? {set: true} : {}), ...(vt.k === 'rec' ? {cls: vt.name, fields: d.fields.map(x => ({name: x.name, ...(g.mod.recs[vt.name]!.fields.find(y => y.name === x.name)?.t.k === 'float' ? {float: true} : {}), ...(x.sort.k === 'choice' ? {choice: true} : {})}))} : vt.k === 'float' ? {float: true} : {})})
        into.set(f, {t: 'ref', id})
        return
      }
      if (v.t === 'lock') { into.set(f, v); return }
      // (a function of other code, json.dumps: a constant of the object, its calls other code's; a method rebinding it refused)
      if (v.t === 'ext' && !v.recv) { into.set(f, v); g.frozen.add(path.join('.')); leaves.push({name: '', path, kind: 'frame'}); return }
      // A field the constructor sets to None, of no declared type, or to a key's template (a lock's key made of its name):
      // a constant (a method setting it is refused).
      if (v.t === 'none' || v.t === 'fmt') { into.set(f, v); g.frozen.add(path.join('.')); leaves.push({name: '', path, kind: 'frame'}); return }
      into.set(f, {t: 'opaque', why: `${path.join('.')}: ${v.t === 'opaque' ? v.why : `a ${v.t}`}, a field outside the subset (left out of the rule)`})
      leaves.push({name: '', path, kind: 'frame'})
    }
    for (const {path, v, t} of tree) build(path, v, t, fields, made)
    heap.set('this', {k: 'rec', ty: cls, f: fields, origin: 'state'})
    for (const [id, o] of heap) g.initHeap.set(id, o)
  }
  // --- the requests: each method (or function) one -------------------------------------------------------------------
  const r = cls ? g.rec(cls, at) : undefined
  const chosen: SFunc[] = cls
    // (by default its public methods but the one it is made by, Rust's new, which takes no object)
    ? (opts.methods ?? writing ?? Object.keys(r!.methods).filter(m => !m.startsWith('_') && r!.methods[m] && !(mod.lang === 'rust' && m === 'new'))).map(m => (r!.methods[m] ? g.func(r!.methods[m]!, at) : refuse(at, `no method ${r!.short}.${m} in ${mod.file}`)))
    : entries.map(e => g.func((e as {id: string}).id, at))
  if (!chosen.length) refuse(at, `${cls ? r!.short : 'the entry'} has no methods to read`)
  for (const f of chosen) g.entryIds.add(f.id)
  for (const f of chosen) if (f.decorators.some(d => d.name === 'property')) refuse(f, `${f.name}: a property (read, not called)`)
  const names = chosen.map(f => f.name)
  const ev = names.length > 1 ? g.newVar('method', {k: 'choice', values: names}, 'input') : undefined
  const evL: L | undefined = ev ? {op: 'var', name: ev.name, values: names} : undefined
  const events: Event[] = [], argsOf: Record<string, [string, PArg][]> = {}
  type Final = {sel: B, path: Path, out?: V, fails: B[]}
  const finals: Final[] = []
  for (const fn of chosen) {
    g.method = fn.name
    const sel = evL ? I.is(evL, fn.name) : I.T
    g.sel = sel
    let p: Path = {pc: [sel], locals: new Map(), heap: new Map(g.initHeap), called: [], locks: [], defers: []}
    const args: V[] = [], pargs: [string, PArg][] = []
    if ((fn as {recv?: string}).recv === 'value') refuse(fn, `${fn.name}: a method that takes self by value (it consumes the object)`)
    if ((fn as {generic?: boolean}).generic) refuse(fn, `${fn.name}: a generic method`)
    const kth = new Map<string, number>()
    for (const pa of fn.params.filter(x => !x.self && !x.star)) {
      const s = opts.share && names.length > 1 ? g.scalar(pa.t) : undefined, ty = JSON.stringify(pa.t), k = kth.get(ty) ?? 0
      kth.set(ty, k + 1)
      // (shared: named by the argument where every method names its k-th of the type alike, else by the type and k)
      const at = s && chosen.map(f => f.params.filter(x => !x.self && !x.star && JSON.stringify(x.t) === ty)[k]?.name).filter(Boolean)
      const it = pa.t as {k: string, bits?: number, signed?: boolean}
      const nm = at ? (at.every(x => x === pa.name) ? pa.name : `${it.k === 'int' ? `${it.signed ? '' : 'u'}int${it.bits || ''}` : it.k}_${k}`) : `${names.length > 1 ? `${fn.name}_` : ''}${pa.name}`
      const had = at ? g.shared.get(`${ty} ${k}`) : undefined
      if (had && had[1].k === 'in') { g.typed(g.vars.get(had[1].name)!, pa.t, 'input'); args.push(had[0]); pargs.push([pa.name, had[1]]); continue }
      const [v, a] = g.input(nm, pa.t, fn, p)
      if (opts.keep?.includes(pa.name)) { const keepOf = (x: PArg): void => { if (x.k === 'in') g.kept.add(x.name); else if (x.k === 'opt') { g.kept.add(x.none); keepOf(x.v) } }; keepOf(a) }
      if (at) g.shared.set(`${ty} ${k}`, [v, a])
      args.push(v); pargs.push([pa.name, a])
    }
    g.fails = []; g.failPaths = []
    let [out, q] = g.callFunc(fn, cls ? {t: 'ref', id: 'this'} : undefined, args, [], {e: 'call', p: fn.p, text: fn.name}, p, fn.async ?? false)
    // A Result returned: its Err is the step's failure (Rust's error results, later Go's and Elixir's), its Ok the value.
    if (out.t === 'res') { g.fail(q, I.not(out.ok), fn, `${fn.name} returns an Err`); q = g.assume(q, out.ok); out = out.v }
    // (the failures first, the step's end the else: its conditions may be only what its returns share, which a merge
    // would read as holding on every path)
    p = g.failPaths.length ? g.join([...g.failPaths, q], fn)! : q
    finals.push({sel, path: p, out, fails: g.fails})
    argsOf[fn.name] = pargs
  }
  // --- the methods together: each leaf by the method called ---------------------------------------------------------
  const state: Var[] = [], init: Record<string, Term> = {}, writes: Record<string, Term> = {}, mapWrites: Model['mapWrites'] = {}, outputs: string[] = []
  const stateLeaves = leaves.filter(l => l.kind !== 'frame' && l.kind !== 'map')
  const failedOf = (f: Final) => I.or(...f.fails)
  const anyFail = (f: Final) => I.and(f.sel, failedOf(f))
  const termOf = (v: V, at2: {p: string}): Term => {
    if (v.t === 'num') return {s: 'num', e: v.e}
    if (v.t === 'bool') return {s: 'bool', e: v.e}
    if (v.t === 'str') return {s: 'str', e: v.e}
    if (v.t === 'choice') return {s: 'choice', e: v.e}
    return refuse(at2, `a ${v.t === 'opaque' ? v.why : v.t} where the state holds a scalar`)
  }
  // The value of each leaf at a path's end (the object's fields, nested ones through their objects).
  const leafAt = (path: Path, l: Leaf, at2: {p: string}): Term => {
    let o = path.heap.get('this') as Extract<Obj, {k: 'rec'}>
    for (const seg of l.path.slice(0, -1)) {
      const v = o.f.get(seg)
      if (v?.t !== 'ref') return refuse(at2, `${l.path.join('.')}: a nested object replaced by a ${v?.t}`)
      o = path.heap.get(v.id) as Extract<Obj, {k: 'rec'}>
    }
    const f = l.kind === 'none' ? l.path.at(-1)! : l.path.at(-1)!
    const v = o.f.get(f) ?? refuse(at2, `${l.path.join('.')} unset`)
    const s = g.vars.get(l.name)!.sort
    if (l.kind === 'none') return {s: 'bool', e: v.t === 'none' ? I.T : v.t === 'opt' ? I.not(v.has) : I.F}
    // (None holds its sort's zero: the value read where the field is Some, the zero elsewhere)
    const z = zeroOf(s), inOpt = (w: V): V => (v.t !== 'opt' ? w : w.t === 'num' && z.t === 'num' ? {t: 'num', e: I.nite(v.has, w.e, z.e)} : w.t === 'bool' && z.t === 'bool' ? {t: 'bool', e: I.bite(v.has, w.e, z.e)} : w.t === 'str' && z.t === 'str' ? {t: 'str', e: I.kite(v.has, w.e, z.e)} : w.t === 'choice' && z.t === 'choice' ? {t: 'choice', e: I.lite(v.has, w.e, z.e)} : w)
    const val = v.t === 'opt' ? inOpt(v.v) : v.t === 'none' ? z : v
    return termOf(val.t === 'str' && s.k === 'choice' && val.e.op === 'slit' ? {t: 'choice', e: I.llit(val.e.value, s.values)} : val, at2)
  }
  for (const l of stateLeaves) {
    const v = g.vars.get(l.name)!
    state.push(v)
    init[v.name] = termOf(stateOf.get(v.name)!, at)
    let acc: Term | undefined
    for (let i = finals.length - 1; i >= 0; i--) {
      const f = finals[i]!
      let t = leafAt(f.path, l, {p: chosen[i]!.p})
      if (kept && !carried) t = iteTerm(failedOf(f), varTerm(v), t)
      acc = acc === undefined ? t : iteTerm(f.sel, t, acc)
    }
    if (acc && !I.same(acc.e, varTerm(v).e)) writes[v.name] = acc
  }
  // A one-object check: no object in two places of the state.
  for (const f of finals) {
    const seen = new Set<string>()
    const visit = (o: Extract<Obj, {k: 'rec'}>, path: string) => { for (const [k, v] of o.f) if (v.t === 'ref') { if (seen.has(v.id)) refuse(chosen[0]!.p, `${path}.${k}: one object in two places of the state`); seen.add(v.id); const x = f.path.heap.get(v.id); if (x?.k === 'rec') visit(x, `${path}.${k}`) } }
    const self = f.path.heap.get('this')
    if (self?.k === 'rec') visit(self, 'self')
  }
  // The maps (and the stores' maps).
  for (const d of g.maps) {
    const id = [...g.initHeap].find(([, o]) => o.k === 'map' && o.decl === d)?.[0]
    if (!id) continue
    const cw = (w0: CellWrite, each?: boolean): CellW => ({key: w0.key, has: w0.has, vals: Object.fromEntries([...w0.vals].map(([f2, v]) => [f2, termOf(v, at)])), ...(each ? {each: true as const} : {})})
    const lists = finals.map(f => { const o = f.path.heap.get(id) as Extract<Obj, {k: 'map'}> | undefined; return [...(o?.ew ? [cw(o.ew, true)] : []), ...[...(o?.pre ?? []), ...(o?.w ? [o.w] : [])].map(w0 => cw(w0))] })
    // (a failure kept, the cell as it was there)
    const fix = (i: number, w2: CellW, base: (k: K) => CellW): CellW => { if (!kept || carried) return w2; const fl = failedOf(finals[i]!), b = base(w2.key); return {key: w2.key, has: I.bite(fl, b.has, w2.has), vals: Object.fromEntries(Object.entries(w2.vals).map(([f, t]) => [f, iteTerm(fl, b.vals[f]!, t)]))} }
    // (several keys written by some method: each method's writes under its own selector, so a key compared is the
    // request's, never one of two by the method)
    const base = (k: K): CellW => { const c = g.baseCell(d, k); return {key: k, has: c.has, vals: Object.fromEntries([...c.vals].map(([f2, v]) => [f2, termOf(v, at)]))} }
    const ws: (CellW & {when?: B})[] = lists.some(l => l.length > 1 || l.some(w0 => w0.each)) ? finals.flatMap((f, i) => lists[i]!.map(w2 => ({...fix(i, w2, base), when: f.sel}))) : []
    const w = ws.length ? ws.at(-1) : mapWritesOf(g, d, finals.map(f => f.sel), lists.map(l => l[0]), fix)
    if (w) mapWrites[d.name] = ws.length > 1 ? {...w, pre: ws.slice(0, -1)} : w.each ? {...w, pre: []} : w
  }
  // What each method returns, and whether it failed: the step's result.
  const results: Model['results'] = {}, resultKinds: StepRead['results'] = {}
  let failedVar: Var | undefined
  if (kept) { failedVar = g.newVar('failed', {k: 'bool'}, 'state', 'whether the step failed (an exception raised): the state is as it was'); }
  // (each effect: whether the step called it, on the method's path that did)
  const effectVars = [...g.answers.values()].filter(a => a.effect && !a.quiet).map(a => ({key: a.key, v: g.newVar(`${a.key.replace(/\W+/g, '_')}_called`, {k: 'bool'}, 'state', `whether the step called ${a.key}`)}))

  for (const [i, f] of finals.entries()) {
    const fn = chosen[i]!
    const out = f.out!
    let kind: 'none' | 'scalar' | 'maybe' = 'none', rv: Var | undefined, rn: Var | undefined
    // (a result of other code left out by inference: the step's result is kept, so its value is read)
    const asked = out.t === 'opaque' ? out : out.t === 'opt' && out.v.t === 'opaque' ? out.v : undefined
    // (other code's value returned: answered or cut by the next reading where it can be; an object of other code's
    // class, not kept, as any other value of no scalar kind)
    const pd = asked?.ask ? [...g.pend.values()].find(x => x.why === asked.why) : undefined
    if (asked?.ask && (pd?.ret?.k !== 'rec' || g.cuttable(asked.why))) refuse(fn, `${fn.name} returns ${asked.why} (a result the rule keeps)`)
    // (a string result that is one of the method's literals on every path, `return "adopt"` / `return "stop"`: a choice
    // of them, as a Literal result is; a string kept by cases is otherwise of two strings the rule holds)
    const strLits = (k: K): string[] | undefined => (k.op === 'slit' ? [k.value] : k.op === 'kite' ? ((a, b) => (a && b ? [...new Set([...a, ...b])] : undefined))(strLits(k.a), strLits(k.b)) : undefined)
    const lits = out.t === 'str' && out.e.op === 'kite' ? strLits(out.e) : undefined
    if (lits) { const l = asChoice((out as {e: K}).e, lits)!; f.out = {t: 'choice', e: l}; g.notes.add(`${fn.name} returns ${lits.map(x => JSON.stringify(x)).join(' or ')}: kept as a choice of them`) }
    const out1 = f.out!
    if (out1.t === 'num' || out1.t === 'bool' || out1.t === 'str' || out1.t === 'choice' || out1.t === 'opt') {
      const out = out1
      const inner = out.t === 'opt' ? out.v : out
      if (inner.t === 'num' || inner.t === 'bool' || inner.t === 'str' || inner.t === 'choice') {
        const sort: Var['sort'] = inner.t === 'num' ? {k: 'num'} : inner.t === 'bool' ? {k: 'bool'} : inner.t === 'str' ? {k: 'str'} : {k: 'choice', values: lvalues(inner.e)}
        rv = g.newVar(`${fn.name}_result`, sort, 'state', `what ${fn.name} returned, at the step that called it (its default at others)`)
        // (a kept result of a fixed-width type within its range: a law, as a field's is)
        const rt = g.intTy(fn.ret?.k === 'opt' || fn.ret?.k === 'res' ? fn.ret.of : fn.ret ?? {k: 'any'})
        if (rt) g.ints.set(rv.name, rt)
        if (out.t === 'opt') { rn = g.newVar(`${fn.name}_result_none`, {k: 'bool'}, 'state', `whether ${fn.name} returned None`); kind = 'maybe' } else kind = 'scalar'
      }
    } else if (out.t !== 'none') g.notes.add(`${fn.name} returns ${out.t === 'opaque' ? out.why : `a ${out.t}`}: not kept`)
    resultKinds[fn.name] = kind
    const fields: [string, string][] = []
    if (failedVar) fields.push(['failed', failedVar.name])
    if (rv) { fields.push(['value', rv.name]); outputs.push(rv.name); state.push(rv); init[rv.name] = termOf(zeroOf(rv.sort), at) }
    if (rn) { fields.push(['none', rn.name]); outputs.push(rn.name); state.push(rn); init[rn.name] = {s: 'bool', e: I.F} }
    for (const e of effectVars) fields.push([`effect:${e.key}`, e.v.name])
    if (fields.length === 1 && !failedVar && rv && !rn) results[fn.name] = {k: 'scalar', name: rv.name}
    else if (fields.length) results[fn.name] = {k: 'rec', fields}
    ;(f as Final & {rv?: Var, rn?: Var}).rv = rv; (f as Final & {rv?: Var, rn?: Var}).rn = rn
  }
  for (const o of outputs) {
    const v = g.vars.get(o)!
    let acc: Term = init[o]!
    for (let i = finals.length - 1; i >= 0; i--) {
      const f = finals[i]! as Final & {rv?: Var, rn?: Var}
      const out = f.out!
      let t: Term = init[o]!
      // (a result that is None holds its sort's zero, as the check reads the code's)
      if (f.rv?.name === o) t = termOf(out.t === 'opt' ? g.ite(out.has, out.v, zeroLike(out.v), chosen[i]!) : out, chosen[i]!)
      if (f.rn?.name === o) t = {s: 'bool', e: out.t === 'opt' ? I.not(out.has) : I.F}
      if (kept && (f.rv?.name === o || f.rn?.name === o)) t = iteTerm(failedOf(f), init[o]!, t)
      acc = iteTerm(f.sel, t, acc)
    }
    writes[o] = acc
    void v
  }
  for (const e of effectVars) { outputs.push(e.v.name); state.push(e.v); init[e.v.name] = {s: 'bool', e: I.F}; writes[e.v.name] = {s: 'bool', e: I.or(...finals.map(f => I.and(f.sel, f.path.eff?.get(e.key) ?? I.F)))} }
  if (failedVar) {
    outputs.push(failedVar.name); state.push(failedVar); init[failedVar.name] = {s: 'bool', e: I.F}
    writes[failedVar.name] = {s: 'bool', e: I.or(...finals.map(anyFail))}
  }
  const refuseB = I.or(...g.refusals, ...(kept ? [] : finals.map(anyFail)))
  // Inputs no term reads are still the request's (the check builds the arguments from them).
  const maps = g.maps.filter(d => [...g.initHeap.values()].some(o => o.k === 'map' && o.decl === d))
  const stores: StepRead['stores'] = Object.fromEntries([...new Set([...Object.keys(opts.stores ?? {}), ...g.storeDecls.keys()])].map(n => [n, {...g.storeDecl(n), async: g.storeAsync[n] ?? {}}]))
  for (const [rec, table] of g.ormTables) {
    const r = g.rec(rec, at)
    leaves.push({name: table.decl.name, path: [], kind: 'map', key: table.decl.key, orm: {rec, key: r.orm!.key, framework: r.orm!.framework, fields: r.fields}})
  }
  for (const sm of g.storeMaps.values()) {
    const str = sm.decl.fields[0]?.sort.k === 'str' && !sm.json
    leaves.push({name: sm.decl.name, path: [], kind: 'map', key: sm.decl.key, store: sm.store, tpl: sm.tpl, ...(stores[sm.store]?.value !== 'int' && stores[sm.store]?.values?.[sm.tpl] !== 'int' && !sm.json && !sm.choice && !str ? {float: true} : {}), ...(sm.json ? {json: sm.json} : {}), ...(sm.choice ? {choice: true} : {}), ...(str ? {str: true} : {})})
  }
  const layout: Layout = {k: 'rec', fields: state.filter(v => !outputs.includes(v.name)).map(v => [v.name, {k: 'scalar', name: v.name}] as [string, Layout])}
  for (const fn of chosen) {
    const used = new Set<string>()
    const walk = (a: PArg) => { if (a.k === 'in') used.add(a.name); else if (a.k === 'opt') { used.add(a.none); walk(a.v) } else if (a.k === 'rec') a.f.forEach(([, x]) => walk(x)) }
    argsOf[fn.name]!.forEach(([, a]) => walk(a))
    for (const a of g.answers.values()) { if (!a.pass) used.add(a.inputs.name); if (a.inputs.none) used.add(a.inputs.none); for (const r of a.raises ?? []) if (r.m === fn.name) used.add(r.name) }
    if (g.now) used.add(g.now.name)
    events.push({select: ev ? {[ev.name]: fn.name} : {}, call: fn.name, args: [{k: 'rec', fields: [...used].map(n => [n, {k: 'input', name: n} as Arg])}]})
  }
  const laws: string[] = []
  // A fixed-width field within its type's range (every state of the code is).
  laws.push(...rangeLaws(state, g.ints))
  for (const l of leaves) if (l.kind === 'none') { const base = l.name.replace(/_none$/, ''); if (g.vars.get(base)?.sort.k === 'num') laws.push(`r.law(${JSON.stringify(`${base}: a None one holds 0`)}, ({${base}, ${l.name}}) => any(${l.name}.not(), ${base}.eq(0)))`) }
  for (const [rec, table] of g.ormTables) {
    const nullable = g.rec(rec, at).fields.filter(f => f.t.k === 'opt'), n = table.decl.name
    if (nullable.length) {
      const zero = (f: typeof nullable[number]): string => {
        const t = f.t.k === 'opt' ? f.t.of : f.t, cell = `${n}.at(k).${f.name}`
        return t.k === 'bool' ? `${cell}.not()` : t.k === 'str' ? `${cell}.eq('')` : `${cell}.eq(0)`
      }
      laws.push(`r.law(${JSON.stringify(`${n}: absent nullable columns hold the default`)}, ({${n}}) => forall(k => all(${nullable.map(f => `any(${n}.at(k).${f.name}_has, ${zero(f)})`).join(', ')})))`)
    }
  }
  // (a stored JSON record's optional field: absent, its cell holds the default, as the text holds nothing there)
  for (const sm of g.storeMaps.values()) {
    const opts = (sm.json ?? []).filter(f => f.opt), n = sm.decl.name
    if (opts.length) laws.push(`r.law(${JSON.stringify(`${n}: a field a record lacks holds the default`)}, ({${n}}) => forall(k => all(${opts.map(f => `any(${n}.at(k).${f.name}_has, ${n}.at(k).${f.name}${f.choice ? `.is(${JSON.stringify(f.vals![0])})` : '.eq(0)'})`).join(', ')})))`)
  }
  if (g.now) {
    const n = g.vars.get(g.now.name)!
    n.note = 'Date.now() (here time.time()): the time of the request, an input'
  }
  const left = leaves.filter(l => l.kind === 'frame' && !l.cls).map(l => l.path.join('.'))
  if (left.length) g.notes.add(`left out (outside the subset; the methods read don't touch them): ${left.join(', ')}`)
  // Inputs no term reads are left out of the rule (the harness gives them their sort's zero, or None).
  const read = new Set<string>()
  const mention = (t: object) => { for (const n of I.varsOf(t as N).vars) read.add(n) }
  for (const t of [...Object.values(writes), ...Object.values(init)]) mention(t.e)
  for (const w of Object.values(mapWrites).flatMap(x => [x, ...(x.pre ?? [])])) { mention(w.has); mention(w.key); if (w.when) mention(w.when); for (const t of Object.values(w.vals)) mention(t.e) }
  mention(refuseB); mention(pre)
  for (const fd of g.folds) { for (const t of [...Object.values(fd.init), ...Object.values(fd.step)]) mention(t.e); mention(fd.len) }
  const unread = g.inputs.filter(v => !read.has(v.name) && v.name !== ev?.name && !g.kept.has(v.name))
  if (unread.length) g.notes.add(`read by the code but by no term of the rule (given their sort's zero, or None, by the check): ${unread.map(v => v.name).join(', ')}`)
  const inputs = g.inputs.filter(v => !unread.includes(v))
  for (const e of events) { const a = e.args[0] as {k: 'rec', fields: [string, Arg][]}; a.fields = a.fields.filter(([n]) => !unread.some(v => v.name === n)) }
  // A start that divides (a constructor's `limit / 2`): each quotient of the params a param of its own, which the
  // precondition fixes (k·q ≤ a < k·q + k) and the check computes from the others (a start reads the params alone,
  // and a quotient is no term over them).
  const pnames = new Set(g.params.map(v => v.name)), qs = new Map<string, Var>()
  const ok = (a: N) => { const r = I.varsOf(a); return !r.maps.size && [...r.vars].every(n => pnames.has(n)) }
  const qOf = (k: number, a: N): N => {
    const key = I.keyOf({k, a})
    let q = qs.get(key)
    if (!q) {
      q = g.newVar(`${[...I.varsOf(a).vars][0] ?? 'q'}_div${k}`, {k: 'num'}, 'param', `⌊${k === 1 ? '' : 'the start\'s dividend / '}${k}⌋ of the params (fixed by the precondition: a start divides)`)
      ;(q as Var & {derived?: N}).derived = {op: 'divk', k, a}
      qs.set(key, q)
      pre = I.and(pre, I.cmp('<=', I.mulk(k, I.nvar(q.name)), a), I.cmp('<', a, I.add(I.mulk(k, I.nvar(q.name)), I.num(k))))
    }
    return I.nvar(q.name)
  }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const lift = (t: any): any => {
    if (Array.isArray(t)) return t.map(lift)
    if (!t || typeof t !== 'object') return t
    if ((t.op === 'divk' || t.op === 'modk') && t.k > 1) { const a = lift(t.a) as N; if (ok(a)) return t.op === 'divk' ? qOf(t.k, a) : I.sub(a, I.mulk(t.k, qOf(t.k, a))) }
    return Object.fromEntries(Object.entries(t).map(([k, v]) => [k, lift(v)]))
  }
  for (const [n, t] of Object.entries(init)) init[n] = lift(t) as Term
  pre = lift(pre) as B
  const model: Model = {
    kind: cls ? 'a class and its methods' : names.length > 1 ? 'functions, each a request' : 'a function, each call a request',
    name: cls ? g.rec(cls, at).short : names.length === 1 ? names[0]! : mod.module.split('.').pop()!, shape: 'class', file: mod.file, entry: cls ? g.rec(cls, at).short : names.join(', '),
    params: g.params, inputs, state, maps, init, writes, mapWrites, outputs,
    refuse: refuseB, pre, layout, events, notes: [...g.notes], hints: g.hints, ...(ev ? {event: ev.name} : {}), results, laws,
    ...(g.leasts.length ? {leasts: g.leasts} : {}),
    ...(g.used.size || g.folds.length ? {seqs: g.seqs.filter(d => g.used.has(d.name)), folds: g.folds} : {}),
  }
  return {ints: Object.fromEntries(g.ints), ...(g.naiveUtc ? {naiveUtc: true} : {}), ...(g.madeAt ? {madeAt: g.madeAt.name} : {}), model, leaves, args: argsOf, answers: [...g.answers.values()], ctor, kept, arms: [...g.arms].map(a => { const i = a.lastIndexOf(':'); return [a.slice(0, i), Number(a.slice(i + 1))] }), ...(cls ? {cls} : {}), stores, results: resultKinds, ...(g.injectedFields.length ? {inject: g.injectedFields} : {}), ...(g.globalStores.length ? {globals: g.globalStores} : {}), ...(g.inertAttrs.length ? {inert: g.inertAttrs} : {}), ...(g.edges.length ? {edges: g.edges} : {}), ...(effectVars.length ? {effectsOf: Object.fromEntries(finals.map((f, i) => [chosen[i]!.name, effectVars.filter(e => f.path.eff?.has(e.key)).map(e => e.v.name)]))} : {})}
}
// A type's range (64 bits and wider: the rule's numbers stop at ±2^53 before the type's do, and are refused there).
export const rangeOf = (ty: IntTy): [number, number] => (ty.bits === 0 || ty.bits >= 64 ? (ty.signed ? [-Infinity, Infinity] : [0, Infinity]) : ty.signed ? [-(2 ** (ty.bits - 1)), 2 ** (ty.bits - 1) - 1] : [0, 2 ** ty.bits - 1])
// A value of the same kind as v, its zero (unwrap_or_default).
const zeroLike = (v: V): V => (v.t === 'num' ? {t: 'num', e: I.num(0), ...(v.ty ? {ty: v.ty} : {})} : v.t === 'bool' ? {t: 'bool', e: I.F} : v.t === 'str' ? {t: 'str', e: {op: 'slit', value: ''}} : v.t === 'choice' ? {t: 'choice', e: I.llit(lvalues(v.e)[0]!, lvalues(v.e))} : {t: 'opaque', why: 'a default of no scalar kind'})
// A derived Default's value of a type (a Rust field's): 0, false, "", None, the first variant.
const defaultOf = (t: SType, at: {p: string}): V => {
  if (t.k === 'int' || t.k === 'float') return {t: 'num', e: I.num(0)}
  if (t.k === 'bool') return {t: 'bool', e: I.F}
  if (t.k === 'str') return {t: 'str', e: {op: 'slit', value: ''}}
  if (t.k === 'opt') return {t: 'none'}
  return refuse(at, `a Default of ${t.k} (the subset makes numbers, booleans, strings and Options)`)
}
// A choice term's values (an ite's are its branches').
const lvalues = (e: L): string[] => (e.op === 'ite' ? lvalues(e.a) : e.values)
const zeroRaw = (s: Var['sort']): Raw => (s.k === 'num' ? 0 : s.k === 'bool' ? false : s.k === 'choice' ? s.values[0]! : '')
const zeroOf = (s: Var['sort']): V => (s.k === 'num' ? {t: 'num', e: I.num(0)} : s.k === 'bool' ? {t: 'bool', e: I.F} : s.k === 'choice' ? {t: 'choice', e: I.llit(s.values[0]!, s.values)} : {t: 'str', e: {op: 'slit', value: ''}})
// A map's writes, the methods' together: each by the method called (where one writes none, the cell as it was).
type CellW = {key: K, has: B, vals: Record<string, Term>, each?: true}
// Lists of writes of one map made one length: the shorter ones led by writes that change nothing (a cell as it is,
// at the key the longest list writes there), so place by place they merge as one write each.
export function padWrites<W extends {key: K}>(lists: W[][], base: (k: K) => Omit<W, 'key'>): W[][] {
  const n = Math.max(0, ...lists.map(l => l.length)), long = lists.find(l => l.length === n) ?? []
  return lists.map(l => [...long.slice(0, n - l.length).map(w => ({key: w.key, ...base(w.key)}) as W), ...l])
}
export function mapWritesOf(g: Stepper, d: MapDecl, sels: B[], ws: (CellW | undefined)[], fix: (i: number, w: CellW, base: (k: K) => CellW) => CellW = (_, w) => w): CellW | undefined {
  if (!ws.some(Boolean)) return undefined
  const key0 = ws.find(Boolean)!.key, base = (k: K): CellW => { const c = g.baseCell(d, k); return {key: k, has: c.has, vals: Object.fromEntries([...c.vals].map(([f, v]) => [f, {s: v.t === 'num' ? 'num' : v.t === 'choice' ? 'choice' : v.t === 'str' ? 'str' : 'bool', e: (v as {e: N}).e} as Term]))} }
  let acc: CellW | undefined
  for (let i = sels.length - 1; i >= 0; i--) {
    const w = ws[i] ? fix(i, ws[i]!, base) : base(acc?.key ?? key0), c = sels[i]!
    acc = acc === undefined ? w : {key: I.kite(c, w.key, acc.key), has: I.bite(c, w.has, acc.has), vals: Object.fromEntries(Object.entries(w.vals).map(([f, t]) => [f, iteTerm(c, t, acc!.vals[f]!)]))}
  }
  return acc
}
// Each fixed-width variable within its type's range: a law every state of the code keeps.
export const rangeLaws = (state: Var[], ints: Map<string, IntTy>): string[] => state.flatMap(v => {
  const ty = ints.get(v.name), law = (b: string) => [`r.law(${JSON.stringify(`${v.name} within its type's range`)}, ({${v.name}}) => ${v.name}.${b})`]
  if (!ty || v.sort.k !== 'num') return []
  if (ty.mod) return [`r.law(${JSON.stringify(`${v.name} within its type's range`)}, ({${v.name}, ${ty.mod}}) => ${v.name}.lt(${ty.mod}))`]
  const [lo, hi] = rangeOf(ty)
  return Number.isFinite(hi) ? law(`atMost(${hi}).and(${v.name}.atLeast(${lo}))`) : lo === 0 ? law('atLeast(0)') : []
})
// Whether a term multiplies (by a variable, or by a constant other than 0 and ±1): past a width more than once.
const hasProduct = (e: N): boolean => e.op === 'mul' || (e.op === 'mulk' && Math.abs(e.k) > 1) || ((e.op === 'add' || e.op === 'sub' || e.op === 'min' || e.op === 'max' || e.op === 'ite') && (hasProduct(e.a) || hasProduct(e.b))) || ((e.op === 'neg' || e.op === 'mulk') && hasProduct(e.a))
export const varTerm = (v: Var): Term => (v.sort.k === 'num' ? {s: 'num', e: I.nvar(v.name)} : v.sort.k === 'bool' ? {s: 'bool', e: I.bvar(v.name)} : v.sort.k === 'choice' ? {s: 'choice', e: {op: 'var', name: v.name, values: v.sort.values}} : {s: 'str', e: {op: 'svar', name: v.name}})
export function iteTerm(c: B, a: Term, b: Term): Term {
  if (a.s === 'num' && b.s === 'num') return {s: 'num', e: I.nite(c, a.e, b.e)}
  if (a.s === 'bool' && b.s === 'bool') return {s: 'bool', e: I.bite(c, a.e, b.e)}
  if (a.s === 'choice' && b.s === 'choice') return {s: 'choice', e: I.lite(c, a.e, b.e)}
  if (a.s === 'str' && b.s === 'str') return {s: 'str', e: I.kite(c, a.e, b.e)}
  throw new Refusal('?', 'a leaf of two sorts')
}

// --- the check: the code's side, a harness in its own language over JSON lines ----------------------------------------
type Raw = number | boolean | string
type FS = {mkdtempSync: (p: string) => string, rmSync: (p: string, o?: unknown) => void, openSync: (p: string, f: string) => number, closeSync: (fd: number) => void, readSync: (fd: number, b: Uint8Array, o: number, n: number, at: null) => number, writeSync: (fd: number, s: string) => number}
const proc = (globalThis as {process?: {getBuiltinModule?: (id: string) => unknown, env?: Record<string, string | undefined>}}).process
export const node = <T>(id: string): T => { const m = proc?.getBuiltinModule?.(id); if (!m) throw new Error(`the extractor runs the code's toolchain through ${id} (Node 20.16 or later, or Bun)`); return m as T }
// A file gdp-wired runs beside its modules (a front end's reader or harness, core/<lang>/...): its path, or a clear
// error when the install lacks it.
export function asset(rel: string): string {
  const p = node<{fileURLToPath: (u: URL) => string}>('node:url').fileURLToPath(new URL(`./${rel}`, import.meta.url))
  if (!node<{existsSync: (p: string) => boolean}>('node:fs').existsSync(p)) throw new Error(`gdp-wired's ${rel} is missing from its install (${p}): reinstall gdp-wired`)
  return p
}
// A harness started on the two named pipes in `work` and both opened. It runs under sh, which, if the harness exits
// before it answered (it couldn't start: a file missing, an interpreter absent, the code not loading), opens the
// pipes itself and answers the first request with the error, so nothing here waits on a harness that is gone. The
// reads here block, so the harness runs within GDP_CHECK_HARNESS_S seconds (120, all its requests): past them sh kills
// it and answers `stopped` (a step of the code that doesn't end: a loop a reader read as one that does).
export const harnessLimit = (): number => Number(proc?.env?.GDP_CHECK_HARNESS_S ?? 120)
// The check's build of the code (its compiler, the code with the harness): each within GDP_COMPILE_S seconds (900).
// The compiler's errors about the code's own files are the source's (a refusal, with its message), about the
// harness's the check's own; a compiler that fails saying nothing of the code (killed, crashed, past its time) runs
// once more (`first`: a failure already had), then fails the check's harness. Never "the rule and the code differ".
export const compileLimit = (): number => Number(proc?.env?.GDP_COMPILE_S ?? 900) * 1000
export type Built<T> = {ok: T} | {kind: 'source' | 'harness', why: string}
export function buildCheck<T>(tool: string, run: () => T, errorsOf: (e: unknown) => string[], ofSource: (line: string) => boolean, first?: unknown): Built<T> {
  let last = first
  for (let i = 0; i < 2; i++) {
    if (i > 0 || last === undefined) { try { return {ok: run()} } catch (e) { last = e } }
    const errs = (last as {signal?: string}).signal ? [] : errorsOf(last)
    if (errs.length) {
      const src = errs.filter(ofSource)
      return src.length ? {kind: 'source', why: `the source doesn't compile (${tool}): ${src.slice(0, 3).join(' | ').slice(0, 900)}`} : {kind: 'harness', why: `the check's harness for the code doesn't build (${tool}): ${errs.slice(0, 3).join(' | ').slice(0, 900)}`}
    }
  }
  const said = String((last as {stderr?: string}).stderr || (last as Error)?.message || last).split('\n').filter(l => l.trim()).slice(-2).join(' | ').slice(0, 300)
  return {kind: 'harness', why: `${tool} failed twice with nothing to say of the code (${(last as {signal?: string}).signal ? `killed: ${(last as {signal?: string}).signal}, ` : ''}${said})`}
}
// (a build's outcome as the check's evidence: the source refused, or the harness failed)
export const builtEvidence = (b: {kind: 'source' | 'harness', why: string}): {source: string} | {harness: string} => (b.kind === 'source' ? {source: b.why} : {harness: b.why})
// (the harness past its time, or its transport failing, `transport` set: the check's failure, not the code's)
export const stopped = (res: Record<string, unknown>): Record<string, unknown> => { if (res.stopped || res.transport) throw new HarnessFailure(String(res.error)); return res }
const GUARD = 'i=$1 o=$2 l=$3; shift 3; trap \'kill $p $w 2>/dev/null; exit 143\' TERM; "$@" "$i" "$o" & p=$!; (trap \'kill $s 2>/dev/null; exit 0\' TERM; sleep "$l" & s=$!; wait $s; kill -9 $p) 2>/dev/null & w=$!; wait $p; e=$?; kill $w 2>/dev/null; [ "$e" = 0 ] && exit 0; trap - TERM; if [ "$e" = 137 ]; then exec 4>"$o"; printf \'{"error": "the code did not answer within %s s (a request that does not end)", "stopped": true}\\n\' "$l" >&4; exit 1; fi; exec 3<"$i" 4>"$o"; read -r _ <&3; printf \'{"error": "the harness exited (status %s) before it answered"}\\n\' "$e" >&4'
export function openHarness(work: string, cmd: string, args: string[], o: Record<string, unknown>): {child: {kill: () => void}, wi: number, ro: number} {
  const fs = node<FS>('node:fs'), cp = node<{execFileSync: (f: string, a: string[], o: Record<string, unknown>) => string, spawn: (f: string, a: string[], o: Record<string, unknown>) => {kill: () => void}}>('node:child_process')
  cp.execFileSync('mkfifo', [`${work}/in`, `${work}/out`], {})
  const child = cp.spawn('sh', ['-c', GUARD, 'gdp-harness', `${work}/in`, `${work}/out`, String(harnessLimit()), cmd, ...args], o)
  const wi = fs.openSync(`${work}/in`, 'w'), ro = fs.openSync(`${work}/out`, 'r')
  return {child, wi, ro}
}
// A harness: the command that starts it (it opens the two named pipes it is given) and what it is told first.
// (error: why there is no harness, never a difference since no request ran; kind 'harness': the check's own tools
// failing (its outcome, after their retry), else ('source', the default) the code refused with why: its compiler
// rejects it, or the harness can't be made for it)
export type Harness = {cmd: string, args: string[], env?: Record<string, string>, hello: Record<string, unknown>, error?: string, kind?: 'source' | 'harness'}
export type StepEvidence = Evidence & {runMs: number}
export function checkStep(h: Harness, read: StepRead, r: Rule, sorts: Sorts, opts: StepOptions): StepEvidence {
  return retried(() => checkStepOnce(h, read, r, sorts, opts), () => ({...noEvidence(), runMs: 0}))
}
function checkStepOnce(h: Harness, read: StepRead, r: Rule, sorts: Sorts, opts: StepOptions): StepEvidence {
  const o = opts.check ?? {}, m = read.model, bound = o.bound ?? 12
  const fs = node<FS>('node:fs'), os = node<{tmpdir: () => string}>('node:os')
  const work = fs.mkdtempSync(`${os.tmpdir()}/gdp-stepcheck-`)
  let child: {kill: () => void} | undefined, wi = -1, ro = -1
  const empty = {runs: 0, requests: 0, fromStates: 0, probes: {conditions: 0, witnesses: 0, steps: 0}, refusedBoth: 0, outside: 0, edge: 0, compiledAgreed: 0, coverage: {arms: 0, hit: 0, missed: []}, ms: 0, runMs: 0}
  try {
    // (no harness: no request ran, so never a difference: the check's own failure, or the code refused with why)
    if (h.error) return h.kind === 'harness' ? {...empty, harness: h.error} : {...empty, source: h.error}
    ;({child, wi, ro} = openHarness(work, h.cmd, h.args, {stdio: ['ignore', 'ignore', 'inherit'], env: {...proc?.env, ...h.env}}))
    const buf = new Uint8Array(1 << 20), dec = new TextDecoder()
    let pend = ''
    const line = (): string | undefined => {
      for (;;) {
        const k = pend.indexOf('\n')
        if (k >= 0) { const l = pend.slice(0, k); pend = pend.slice(k + 1); return l }
        const n = fs.readSync(ro, buf, 0, buf.length, null)
        if (n === 0) return undefined
        pend += dec.decode(buf.subarray(0, n), {stream: true})
      }
    }
    const ask = (cmd: Record<string, unknown>): Record<string, unknown> => {
      fs.writeSync(wi, `${JSON.stringify(cmd)}\n`)
      const l = line()
      if (l === undefined) throw new HarnessFailure('the harness stopped before it answered')
      return stopped(JSON.parse(l) as Record<string, unknown>)
    }
    const hi = ask({op: 'hello', ...h.hello, naiveUtc: read.naiveUtc, leaves: read.leaves, ctor: read.ctor, answers: read.answers, kept: read.kept, cls: read.cls ?? null, stores: read.stores, arms: read.arms, discard: opts.onError === 'discard', ...(read.inject ? {inject: read.inject} : {}), ...(read.globals ? {globals: read.globals} : {}), ...(read.inert ? {inert: read.inert} : {}), ...(opts.fields ? {fields: opts.fields} : {})})
    if (hi.error) return {...empty, mismatch: `the code doesn't load with the check's harness: ${JSON.stringify(hi.error)}`}
    const num = (x: unknown, at: string): number => { const n = Number(x); if (typeof x === 'string' && Number.isSafeInteger(n) && String(n) === x) return n; throw new Outside(`${at} is ${String(x)}`) }
    const toSnap = (s: Record<string, unknown>): Snap => {
      const leaves: Record<string, Raw> = {}, maps: Snap['maps'] = {}
      for (const v of m.state) if (!m.outputs.includes(v.name)) leaves[v.name] = v.sort.k === 'num' ? num(s[v.name], v.name) : s[v.name] as Raw
      for (const d of m.maps) maps[d.name] = Object.fromEntries(Object.entries((s[d.name] ?? {}) as Record<string, Record<string, unknown>>).map(([k, c]) => [k, Object.fromEntries(d.fields.map(f => [f.name, f.sort.k === 'num' ? num(c[f.name], `${d.name}[${k}].${f.name}`) : c[f.name] as Raw]))]))
      return {leaves, maps}
    }
    const j = (x: Raw) => (typeof x === 'number' ? String(x) : x)
    const snapJson = (s: Snap): Record<string, unknown> => ({...Object.fromEntries(Object.entries(s.leaves).map(([k, v]) => [k, j(v)])), ...Object.fromEntries(Object.entries(s.maps).map(([k, cells]) => [k, Object.fromEntries(Object.entries(cells).map(([key, c]) => [key, Object.fromEntries(Object.entries(c).map(([f, x]) => [f, j(x)]))]))]))})
    const build = (a: PArg, inputs: Record<string, Raw>): unknown => (a.k === 'in' ? {in: inputs[a.name] ?? a.z ?? 0, ...(a.float ? {float: true} : {}), ...(a.sym ? {sym: true} : {}), ...(a.bytes ? {bytes: true} : {}), ...(a.time ? {time: a.time} : {})} : a.k === 'opt' ? (inputs[a.none] === true ? {none: true} : build(a.v, inputs)) : a.k === 'rec' ? (a.f.length ? {rec: a.cls, f: Object.fromEntries(a.f.map(([f, x]) => [f, build(x, inputs)]))} : {inert: true}) : a.k === 'inert' ? {inert: true, ...(a.dict ? {dict: true} : {})} : a.k === 'store' ? {store: a.name}
      : a.k === 'list' ? {list: ((inputs[a.name] ?? []) as unknown as Record<string, Raw>[]).map(it => build(a.item, it))} : {dflt: true})
    const ctorArgs = (params: Record<string, Raw>) => read.ctor.map(([n, a]) => [n, build(a, params)])
    let now = 0, inputsNow: Record<string, Raw> = {}
    // (an answer outside its type is no value the callee returns: the request is outside what the check compares)
    const answersOf = (call: string) => Object.fromEntries(read.answers.map(a => {
      const v = inputsNow[a.inputs.name] ?? 0, ty = read.ints[a.inputs.name], n = Number(v)
      if (a.fit && ty && !(a.inputs.none && inputsNow[a.inputs.none] === true)) { const [lo, hi] = rangeOf(ty); if (n < lo || n > hi) throw new Outside(`${a.key} answers ${String(v)}, outside its type`) }
      if (a.inputs.time && !(a.inputs.none && inputsNow[a.inputs.none] === true) && (n < -62_135_596_800_000 || n > 253_402_300_799_999)) throw new Outside(`${a.key} answers a datetime outside Python's range`)
      // (a call that may raise: the class of the handler the request says, by its index; a call left out runs as it is)
      const rs = a.raises?.find(x => x.m === call), r = rs && inputsNow[rs.name], raise = r === true ? 0 : typeof r === 'string' && r !== 'none' ? rs!.cls.findIndex((_, i) => (g0r(read.model, rs!.name, i + 1)) === r) : -1
      return [a.key, {...(a.pass ? {pass: true} : a.inputs.none && inputsNow[a.inputs.none] === true ? {none: true} : {in: v, ...(a.inputs.float ? {float: true} : {}), ...(a.inputs.time ? {time: a.inputs.time} : {})}), ...(raise >= 0 ? {raise: rs!.cls[raise]} : {})}]
    }))
    let coverage: Coverage | undefined
    const r0 = performance.now()
    const side: CodeSide = {
      make: params => { const res = ask({op: 'new', a: ctorArgs(params), now: read.madeAt ? params[read.madeAt] : 0}); return res.err !== undefined ? {ok: false, error: JSON.stringify(res.err)} : {ok: true, value: res.id} },
      at: (s, params) => { const res = ask({op: 'at', a: ctorArgs(params), now: read.madeAt ? params[read.madeAt] : 0, state: snapJson(s)}); return res.bad ? undefined : res.id },
      snapOf: self => { const res = ask({op: 'get', id: self}); if (res.error) throw new Error(JSON.stringify(res.error)); return toSnap(res.state as Record<string, unknown>) },
      call: (self, e, args) => {
        const res = ask({op: 'call', id: self, m: e.call, a: args, now, answers: answersOf(e.call)}) as {out?: unknown, err?: string, frame?: string, bad?: string, outside?: string}
        if (res.outside !== undefined) return {ok: false, outside: true, error: res.outside}
        if (res.frame) throw new Error(`the code changes ${res.frame}, a field the rule leaves out`)
        if (res.bad !== undefined) return {ok: false, error: `the code can't be given it (${res.bad})`}
        // (the harness failed making the call: no step of the code, neither a refusal nor one taken)
        if ((res as {error?: unknown}).error !== undefined) throw new HarnessFailure(`the harness failed on a call: ${String((res as {error?: unknown}).error)}`)
        const kind = read.results[e.call] ?? 'none', failed = res.err !== undefined
        if (failed && !read.kept) return {ok: false, error: `raised: ${res.err}`}
        const value = (x: unknown): unknown => { const t = x as {n?: string, s?: string, o?: string} | null; if (t && typeof t === 'object') { if (t.n !== undefined) return num(t.n, `${e.call}'s result`); if (t.s !== undefined) return t.s; return `<${t.o}>` } return x }
        const out = res.out
        const rk = m.results?.[e.call]
        if (!rk) return {ok: true, value: undefined}
        if (rk.k === 'scalar') return {ok: true, value: value(out)}
        const o: Record<string, unknown> = {}
        for (const [f] of (rk as {fields: [string, string][]}).fields) {
          if (f === 'failed') o.failed = failed
          if (f === 'value') { const rv = m.state.find(v => v.name === (rk as {fields: [string, string][]}).fields.find(x => x[0] === 'value')![1])!; o.value = failed || out === null || out === undefined ? (rv.sort.k === 'num' ? 0 : rv.sort.k === 'bool' ? false : rv.sort.k === 'choice' ? rv.sort.values[0] : '') : value(out) }
          if (f === 'none') o.none = !failed && (out === null || out === undefined) && kind === 'maybe'
          if (f.startsWith('effect:')) o[f] = !!(res as {effects?: Record<string, boolean>}).effects?.[f.slice(7)]
        }
        return {ok: true, value: o}
      },
      args: (inputs, e) => { inputsNow = inputs; return (read.args[e.call] ?? []).map(([n, a]) => [n, build(a, inputs)]) },
      setNow: n => { now = n },
      coverage: () => (coverage ??= closeAndCount()),
      drawSnap: rand => {
        const leaves: Record<string, Raw> = {}, maps: Snap['maps'] = {}
        const consts = constantsOf(m), strs = ['a', 'b', 'c', '']
        for (const v of m.state) {
          if (m.outputs.includes(v.name)) continue
          let x = draw(v.sort, sorts, v.name, rand, consts, bound, strs)
          if (typeof x === 'number' && sorts.get(v.name) === 'nat' && x < 0) x = -x
          if (typeof x === 'number' && Math.abs(x) > Number.MAX_SAFE_INTEGER / 4) x = rand(bound)
          leaves[v.name] = x
        }
        for (const l of read.leaves) if (l.kind === 'none' && leaves[l.name] === true) leaves[l.name.replace(/_none$/, '')] = g0(m, l.name.replace(/_none$/, ''))
        for (const d of m.maps) {
          const cells: Snap['maps'][string] = {}
          for (let i = rand(4); i > 0; i--) {
            const key = d.key === 'str' ? strs[rand(3)]! : String(rand(4))
            cells[key] = Object.fromEntries(d.fields.map(f => { let x = draw(f.sort, sorts, `${d.name}.${f.name}`, rand, consts, bound, strs); if (typeof x === 'number' && sorts.get(`${d.name}.${f.name}`) === 'nat') x = Math.abs(x); return [f.name, x] }))
            // (a stored JSON record's absent optional field: its default, as the text holds nothing there)
            const jl = read.leaves.find(l => l.name === d.name)?.json
            for (const f of jl ?? []) if (f.opt && cells[key]![`${f.name}_has`] === false) cells[key]![f.name] = f.choice ? f.vals![0]! : 0
            for (const f of read.leaves.find(l => l.name === d.name)?.orm?.fields ?? []) if (f.t.k === 'opt' && cells[key]![`${f.name}_has`] === false) cells[key]![f.name] = f.t.of.k === 'str' ? '' : f.t.of.k === 'bool' ? false : 0
          }
          maps[d.name] = cells
        }
        return {leaves, maps}
      },
      normalize: s => {
        for (const l of read.leaves) {
          if (l.kind === 'none' && s.leaves[l.name] === true) s.leaves[l.name.replace(/_none$/, '')] = g0(m, l.name.replace(/_none$/, ''))
          for (const f of l.orm?.fields ?? []) if (f.t.k === 'opt') for (const c of Object.values(s.maps[l.name] ?? {})) if (c[`${f.name}_has`] === false) c[f.name] = f.t.of.k === 'str' ? '' : f.t.of.k === 'bool' ? false : 0
        }
        return s
      },
      // (where the code goes on past what the rule's claim covers (a rounding past a float's exact range): an edge)
      // (and where two items of a list a loop takes by an order tie under it)
      ...(read.edges?.length || m.folds?.some(d => d.loop?.drains) ? {edge: (s: Snap, raw: Record<string, Raw>) => (read.edges ?? []).some(c => evalTerm(c, {...s.leaves, ...raw}, (map, key, field) => (field === 'has' ? !!s.maps[map]?.[String(key)] : s.maps[map]?.[String(key)]?.[field] ?? 0)) === true) || tiesIn(m, s, raw)} : {}),
    }
    function closeAndCount(): Coverage {
      const res = ask({op: 'coverage'}) as {hit?: [string, number][]}
      fs.closeSync(wi); wi = -1
      const hit = new Set((res.hit ?? []).map(([f, l]) => `${f}:${l}`))
      const arms = read.arms.map(([f, l]) => `${f}:${l}`)
      return {arms: arms.length, hit: arms.filter(a => hit.has(a)).length, missed: arms.filter(a => !hit.has(a)).map(a => `the arm at ${a}`)}
    }
    const ev = drive(m, r, sorts, side, o)
    return {...ev, runMs: Math.round(performance.now() - r0)}
  } catch (x) {
    if (x instanceof HarnessFailure) throw x
    return {...empty, mismatch: `the check's harness: ${(x as Error).message}`}
  } finally {
    if (wi >= 0) try { fs.closeSync(wi) } catch { /* closed */ }
    if (ro >= 0) try { fs.closeSync(ro) } catch { /* closed */ }
    try { child?.kill() } catch { /* gone */ }
    try { fs.rmSync(work, {recursive: true, force: true}) } catch { /* gone */ }
  }
}
// The i-th value of a choice input (a raise's handler by its index after 'none').
const g0r = (m: Model, name: string, i: number): string | undefined => { const v = m.inputs.find(x => x.name === name); return v?.sort.k === 'choice' ? v.sort.values[i] : undefined }
// The value a None leaf holds in the rule (its sort's zero).
const g0 = (m: Model, name: string): Raw => { const v = m.state.find(x => x.name === name); return v?.sort.k === 'num' ? 0 : v?.sort.k === 'bool' ? false : v?.sort.k === 'choice' ? v.sort.values[0]! : '' }

// A front end's whole run: the module read, the model printed and built, the code run beside it.
export function extractStep(mod: SModule, h: (read: StepRead) => Harness, opts: StepOptions): Extraction & {read?: StepRead} {
  const notes: string[] = []
  if (Object.values({...opts.types, ...opts.answers}).some(t => /datetime/.test(t))) notes.push('Stated datetime values are millisecond-aligned Python datetimes: datetime/datetime-naive is naive, datetime-utc is UTC-aware. None remains distinct; other precision and timezone semantics are outside this stated boundary.')
  // (a reader that said why it read nothing, the source not parsing say, or gave no module: refused with why)
  const said = (mod as {error?: unknown} | undefined)?.error
  if (said !== undefined || !mod || typeof mod.funcs !== 'object' || !mod.funcs || typeof mod.recs !== 'object' || !mod.recs)
    return {ok: false, refusals: [{where: (mod as {path?: string} | undefined)?.path ?? (mod as {file?: string} | undefined)?.file ?? 'the reader', what: said !== undefined ? `the reader read nothing: ${typeof said === 'string' ? said : JSON.stringify(said)}` : 'the reader gave no module of the source'}], notes}
  // (an argument the code declares no type of, given one: `types`, by its name)
  for (const f of Object.values(mod.funcs)) for (const pa of f.params) {
    const t = opts.types?.[pa.name]
    if (t && pa.t.k === 'any') { try { pa.t = sortOfText(t, f.p, mod.lang).t; notes.push(`${f.name}(${pa.name}): a ${t} (stated)`) } catch (e) { if (e instanceof Refusal) return {ok: false, refusals: [{where: e.where, what: e.what}], notes}; throw e } }
  }
  // (and a field the class declares no type of: its declared type, by name)
  for (const r of Object.values(mod.recs)) for (const [f, t] of Object.entries(opts.types ?? {})) {
    // (only a field its constructor sets: `self.<f> = ...`)
    const init = r.methods.__init__ ? mod.funcs[r.methods.__init__] : undefined
    let sets = false
    if (init) deep(init.body, st => { const to = st.to as SX | undefined; if (st.s === 'set' && to?.e === 'get' && (to.x as SX).e === 'var' && (to.x as SX).n === 'self' && to.f === f) sets = true })
    if (!r.own || r.fields.some(x => x.name === f) || !sets) continue
    try { r.fields.push({name: f, t: sortOfText(t, r.p, mod.lang).t}) } catch (e) { if (e instanceof Refusal) return {ok: false, refusals: [{where: e.where, what: e.what}], notes}; throw e }
  }
  let read: StepRead
  try { read = readStep(mod, opts) } catch (e) {
    if (e instanceof InitializerChoice) return {ok: false, refusals: [{where: e.where, what: e.what}], notes, initializers: e.initializers}
    if (e instanceof Refusal) return {ok: false, refusals: [{where: e.where, what: e.what}], notes}
    throw e
  }
  const unsigned = Object.fromEntries([...read.model.inputs, ...read.model.params].filter(v => read.ints[v.name] && !read.ints[v.name]!.signed).map(v => [v.name, 'nat' as const]))
  const x = fromModel(read.model, mod.file, {...unsigned, ...opts.domains}, notes, (rule, sorts) => checkStep(h(read), read, rule, sorts, opts))
  return {...x, read, names: stepNames(read), ...(mod.consts ? {consts: mod.consts} : {})}
}
// The names of a reading: each leaf of the state by its path, the constructor's and each method's arguments (an object
// the caller gives by its fields), each answer by its callee's qualified name, each method's result, the failure.
export function stepNames(read: StepRead): Name[] {
  const out: Name[] = [], m = read.model, at = (code: string) => out.find(n => n.code === code && n.role === 'state')
  for (const l of read.leaves) {
    const code = l.path.join('.')
    if (l.kind === 'map') out.push({code: l.orm ? l.name : l.store ?? code, rule: l.name, role: 'state', map: {fields: m.maps.find(d => d.name === l.name)?.fields.map(f => f.name) ?? [], ...(l.orm ? {store: l.orm.rec, tpl: '{}'} : l.store ? {store: l.store, tpl: l.tpl ?? '{}'} : {}), ...(l.ordered ? {ordered: true} : {})}})
    else if (l.kind === 'none') { const n = at(code); if (n) n.none = l.name; else out.push({code, rule: '', role: 'state', none: l.name}) }
    else if (l.kind !== 'frame') out.push({code, rule: l.name, role: 'state'})
  }
  const arg = (a: PArg, code: string, role: 'param' | 'input', method?: string) => {
    const k = method ? {method} : {}
    if (a.k === 'in') out.push({code, rule: a.name, role, ...k})
    else if (a.k === 'opt') { const n = out.length; arg(a.v, code, role, method); if (out[n]?.code === code) out[n]!.none = a.none; else out.push({code, rule: '', role, none: a.none, ...k}) }
    else if (a.k === 'rec') for (const [f, x] of a.f) arg(x, `${code}.${f}`, role, method)
  }
  for (const [code, a] of read.ctor) arg(a, code, 'param')
  for (const [method, as] of Object.entries(read.args)) for (const [code, a] of as) arg(a, code, 'input', method)
  for (const a of read.answers) {
    if (!a.pass) out.push({code: a.key, rule: a.inputs.name, role: 'answer', ...(a.inputs.none ? {none: a.inputs.none} : {})})
    for (const r of a.raises ?? []) out.push({code: `${a.key} raises`, rule: r.name, role: 'answer', method: r.m})
  }
  const vars = new Set([...m.state, ...m.inputs].map(v => v.name))
  for (const [method, k] of Object.entries(read.results)) if (k !== 'none') out.push({code: 'result', rule: `${method}_result`, role: 'result', method, ...(k === 'maybe' ? {none: `${method}_result_none`} : {})})
  if (vars.has('failed')) out.push({code: 'failed', rule: 'failed', role: 'failed'})
  for (const a of read.answers.filter(x => x.effect && !x.quiet)) out.push({code: `${a.key}.called`, rule: `${a.key.replace(/\W+/g, '_')}_called`, role: 'result'})
  if (vars.has('now')) out.push({code: 'now', rule: 'now', role: 'clock'})
  if (m.event) out.push({code: 'method', rule: m.event, role: 'method'})
  return out
}
