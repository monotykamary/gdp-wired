// The Rust front end (core/extract-rs.ts on core/extract-step.ts): rules read from Rust, each checked against the crate
// it was read from (built by cargo beside a generated harness, overflow checks on). The cases: a u8 that traps past
// its range, a wrapping and a checked one, an Option field, a Result's Err as the failure, a C-like enum and its
// discriminant, an atomic's fetch_add, and the refusals (a loop, a map in the state). Skipped where cargo isn't
// installed (research/langs/rust/rust-setup.sh installs it in a job).
import {expect, test} from 'bun:test'
import {createHash} from 'node:crypto'
import {execFileSync} from 'node:child_process'
import {mkdirSync, mkdtempSync, writeFileSync} from 'node:fs'
import {tmpdir} from 'node:os'
import {extractRust, readRust, rsReader} from './extract-rs.ts'
import {extractStep} from './extract-step.ts'
import {proveRule, proveSteps} from './dsl.ts'

const hasCargo = (() => { try { execFileSync('cargo', ['--version'], {stdio: 'ignore'}); return true } catch { return false } })()
const t = hasCargo ? test : test.skip
const DIR = new URL('./rs/examples/limits', import.meta.url).pathname
const budget = {runs: 40, depth: 8, states: 80}
const genericCrate = (code: string) => {
  const dir = mkdtempSync(`${tmpdir()}/gdp-rs-generics-`)
  mkdirSync(`${dir}/src`)
  writeFileSync(`${dir}/Cargo.toml`, '[package]\nname = "generic_meter"\nversion = "0.1.0"\nedition = "2021"\n')
  writeFileSync(`${dir}/src/lib.rs`, code)
  return dir
}

t('Rust atomic ordering: typed load and store retain invalid-order failures', () => {
  const dir = genericCrate(`use std::sync::atomic::{AtomicU32, Ordering};
    pub struct Meter { value: AtomicU32 }
    impl Meter {
      pub fn new() -> Self { Self { value: AtomicU32::new(7) } }
      pub fn load(&self, ordering: Ordering) -> u32 { self.value.load(ordering) }
      pub fn store(&self, value: u32, ordering: Ordering) { self.value.store(value, ordering); }
    }
  `)
  const x = ok(extractRust(dir, {entry: 'Meter', check: budget, failures: 'kept', strict: true, share: false}))
  expect(x.source).toContain("'Relaxed', 'Release', 'Acquire', 'AcqRel', 'SeqCst'")
  expect(x.notes.join('\n')).toContain("calls that don't interleave")
  const load = step(x, 'load never changes the atomic value', (b, a) => a.value.eq(b.value), b => b.method.is('load'))
  expect(load).toMatchObject({proven: true, checked: true})
  const store = step(x, 'failed store leaves the atomic value unchanged', (b, a) => a.failed.implies(a.value.eq(b.value)), b => b.method.is('store'))
  expect(store).toMatchObject({proven: true, checked: true})
  for (const method of ['load', 'store']) {
    const invalid = (b: A) => b[`${method}_ordering`].is(method === 'load' ? 'Release' : 'Acquire').or(b[`${method}_ordering`].is('AcqRel'))
    expect(step(x, `${method} fails exactly on invalid ordering`, (b, a) => invalid(b).implies(a.failed).and(a.failed.implies(invalid(b))), b => b.method.is(method))).toMatchObject({proven: true, checked: true})
  }
  expect(step(x, 'successful store keeps the supplied value', (b, a) => a.failed.not().implies(a.value.eq(b.store_value)), b => b.method.is('store'))).toMatchObject({proven: true, checked: true})
  const r = x.rule!, runtime = r.interpreter(), params = r.encodeParams({})
  for (const method of ['load', 'store']) for (const order of ['Relaxed', 'Release', 'Acquire', 'AcqRel', 'SeqCst']) {
    const invalid = order === 'AcqRel' || order === (method === 'load' ? 'Release' : 'Acquire')
    const next = runtime.step(params, runtime.init(params), r.encodeInput({method, load_ordering: order, store_ordering: order, store_value: 11}))
    expect(r.decode(next)).toMatchObject({value: method === 'store' && !invalid ? 11 : 7, failed: invalid})
  }
}, 300_000)

t('Rust atomic ordering: fully qualified standard types do not use a local Ordering enum', () => {
  const dir = genericCrate(`pub enum Ordering { Custom }
    pub struct Meter { value: core::sync::atomic::AtomicU16 }
    impl Meter {
      pub fn new() -> Self { Self { value: core::sync::atomic::AtomicU16::new(7) } }
      pub fn load(&self, order: core::sync::atomic::Ordering) -> u16 { self.value.load(order) }
      pub fn ordinal(&self, order: core::sync::atomic::Ordering) -> u8 { order as u8 }
    }
  `)
  ok(extractRust(dir, {entry: 'Meter', check: budget, failures: 'kept', strict: true}))
}, 300_000)

t('Rust atomic ordering: nonstandard enum values stay their own and dynamic RMW remains refused', () => {
  const own = genericCrate(`#[derive(Clone, Copy, Debug)] pub enum Ordering { First, Second }
    pub struct Meter { value: u8 }
    impl Meter {
      pub fn new() -> Self { Self { value: 0 } }
      pub fn choose(&mut self, order: Ordering) { self.value = match order { Ordering::First => 1, Ordering::Second => 2 }; }
    }
  `)
  const x = ok(extractRust(own, {entry: 'Meter', check: budget, strict: true}))
  expect(x.source).not.toContain('Relaxed')
  const dynamic = genericCrate(`use std::sync::atomic::{AtomicU32, Ordering};
    pub struct Meter { value: AtomicU32 }
    impl Meter {
      pub fn new() -> Self { Self { value: AtomicU32::new(0) } }
      pub fn add(&self, n: u32, order: Ordering) -> u32 { self.value.fetch_add(n, order) }
    }
  `)
  const refused = extractRust(dynamic, {entry: 'Meter', check: budget, strict: true})
  expect(refused.ok).toBe(false)
  expect(refused.refusals.length).toBeGreaterThan(0)
}, 300_000)

t('Rust atomic ordering: argument effects survive an invalid-order failure', () => {
  const dir = genericCrate(`use std::sync::atomic::{AtomicU32, Ordering};
    pub struct Meter { value: AtomicU32, seen: u8 }
    impl Meter {
      pub fn new() -> Self { Self { value: AtomicU32::new(7), seen: 0 } }
      pub fn store(&mut self, n: u32, order: Ordering) {
        self.value.store({ self.seen = self.seen.wrapping_add(1); n }, order);
      }
    }
  `)
  const x = ok(extractRust(dir, {entry: 'Meter', check: budget, failures: 'kept', strict: true}))
  const r = x.rule!, runtime = r.interpreter(), params = r.encodeParams({})
  for (const order of ['Acquire', 'Release']) {
    const next = runtime.step(params, runtime.init(params), r.encodeInput({n: 11, order}))
    expect(r.decode(next)).toMatchObject({seen: 1, value: order === 'Acquire' ? 7 : 11, failed: order === 'Acquire'})
  }
}, 300_000)

t('Rust atomic sequencing: capture an earlier read before the later argument mutates it', () => {
  const dir = genericCrate(`use std::sync::atomic::{AtomicU32, Ordering};
    pub struct Meter { value: AtomicU32, seen: u32 }
    impl Meter {
      pub fn new() -> Self { Self { value: AtomicU32::new(7), seen: 0 } }
      pub fn store(&mut self, order: Ordering) {
        self.value.store(self.seen, { self.seen = self.seen.wrapping_add(1); order });
      }
    }
  `)
  const x = ok(extractRust(dir, {entry: 'Meter', check: budget, failures: 'kept', strict: true}))
  const r = x.rule!, runtime = r.interpreter(), params = r.encodeParams({})
  for (const order of ['Relaxed', 'Release', 'Acquire', 'AcqRel', 'SeqCst']) {
    const failed = order === 'Acquire' || order === 'AcqRel'
    const state = runtime.step(params, runtime.init(params), r.encodeInput({order}))
    expect(r.decode(state)).toMatchObject({value: failed ? 7 : 0, seen: 1, failed})
  }
  const request = r.encodeInput({order: 'Release'})
  const first = runtime.step(params, runtime.init(params), request)
  expect(r.decode(runtime.step(params, first, request))).toMatchObject({value: 1, seen: 2, failed: false})
}, 300_000)

t('Rust atomic sequencing: an earlier argument failure prevents later argument effects', () => {
  const dir = genericCrate(`use std::sync::atomic::{AtomicU32, Ordering};
    pub struct Meter { value: AtomicU32, seen: u32, operand: u32 }
    impl Meter {
      pub fn new(start: u32) -> Self { Self { value: AtomicU32::new(7), seen: 0, operand: start } }
      pub fn store(&mut self, order: Ordering) {
        self.value.store(self.operand + 1u32, { self.seen = self.seen.wrapping_add(1); order });
      }
    }
  `)
  const x = ok(extractRust(dir, {entry: 'Meter', check: budget, failures: 'kept', strict: true}))
  const r = x.rule!, runtime = r.interpreter()
  for (const start of [0, 1, 4_294_967_295]) for (const order of ['Relaxed', 'Release', 'Acquire', 'AcqRel', 'SeqCst']) {
    const params = r.encodeParams({start}), overflow = start === 4_294_967_295
    const failed = overflow || order === 'Acquire' || order === 'AcqRel'
    const state = runtime.step(params, runtime.init(params), r.encodeInput({order}))
    expect(r.decode(state)).toMatchObject({value: failed ? 7 : start + 1, seen: overflow ? 0 : 1, failed})
  }
}, 300_000)

t('Rust atomic sequencing: variable division remains refused', () => {
  const dir = genericCrate(`use std::sync::atomic::{AtomicU32, Ordering};
    pub struct Meter { value: AtomicU32, seen: u32, divisor: u32 }
    impl Meter {
      pub fn new(divisor: u32) -> Self { Self { value: AtomicU32::new(7), seen: 0, divisor } }
      pub fn store(&mut self, order: Ordering) {
        self.value.store(10u32 / self.divisor, { self.seen = self.seen.wrapping_add(1); order });
      }
    }
  `)
  const x = extractRust(dir, {entry: 'Meter', check: budget, failures: 'kept', strict: true})
  expect(x.ok).toBe(false)
  expect(x.refusals.map(r => r.what).join('; ')).toContain("division by a value that isn't a constant")
}, 120_000)

t('Rust atomic ordering: unresolved aliases and wildcard imports remain refused', () => {
  for (const [imports, order] of [
    ['use std::sync::atomic::*;', 'Ordering'],
    ['use std::sync::atomic::{AtomicU32, Ordering as Order};', 'Order'],
  ]) {
    const dir = genericCrate(`${imports}
      pub struct Meter { value: AtomicU32 }
      impl Meter {
        pub fn new() -> Self { Self { value: AtomicU32::new(0) } }
        pub fn load(&self, ordering: ${order}) -> u32 { self.value.load(ordering) }
      }
    `)
    const x = extractRust(dir, {entry: 'Meter', check: budget, strict: true})
    expect(x.ok).toBe(false)
    expect(x.refusals.length).toBeGreaterThan(0)
  }
}, 120_000)

t('Rust atomic ordering: an explicit crate alias cannot masquerade as std or core', () => {
  for (const root of ['std', 'core']) {
    const dir = genericCrate(`extern crate other as ${root};
      pub struct Meter { value: u32 }
      impl Meter { pub fn load(&self, order: ::${root}::sync::atomic::Ordering) -> u32 { self.value } }
    `)
    const mod = readRust(dir, ['Meter'])
    const order = mod.funcs['Meter::load']!.params.find(p => p.name === 'order')!
    expect(order.t.k).toBe('opaque')
  }
}, 120_000)

t('Rust primitive extrema: every integer width replays its native associated min and max', () => {
  const types = ['u8', 'u16', 'u32', 'u64', 'u128', 'usize', 'i8', 'i16', 'i32', 'i64', 'i128', 'isize']
  const dir = genericCrate(`
    pub struct Meter { ${types.flatMap(t => [`lo_${t}: ${t}`, `hi_${t}: ${t}`]).join(',')} }
    impl Meter {
      pub fn new() -> Self { Self { ${types.flatMap(t => [`lo_${t}: 0`, `hi_${t}: 0`]).join(',')} } }
      ${types.map(t => `pub fn choose_${t}(&mut self, a: ${t}, b: ${t}) { self.lo_${t} = ${t}::min(a, b); self.hi_${t} = ${t}::max(a, b); }`).join('\n')}
    }
  `)
  const x = ok(extractRust(dir, {entry: 'Meter', check: budget, strict: true}))
  expect(x.notes.join('\n')).not.toMatch(/answered|left out/)
  expect(x.evidence!.requests).toBeGreaterThan(0)
}, 300_000)

t('Rust primitive extrema: a same-named user type keeps the declared call', () => {
  const dir = genericCrate(`
    #[allow(non_camel_case_types)] pub struct usize;
    impl usize { pub fn min(_a: u8, b: u8) -> u8 { b } }
    pub struct Meter { value: u8 }
    impl Meter {
      pub fn new() -> Self { Self { value: 0 } }
      pub fn choose(&mut self, a: u8, b: u8) { self.value = usize::min(a, b); }
    }
  `)
  const body = JSON.stringify(readRust(dir, ['Meter']).funcs['Meter::choose'])
  expect(body).not.toContain('"builtin"')
  expect(body).toContain('usize::min')
}, 300_000)

t('Rust primitive extrema: aliases, modules and glob imports do not authorize primitive lowering', () => {
  for (const declaration of [
    'type usize = u8;',
    'mod custom { pub struct Limit; } use custom::Limit as usize;',
    'mod usize { pub fn min(a: u8, _b: u8) -> u8 { a } }',
    'mod custom {} use custom::*;',
    'extern crate custom as usize;',
    '#![no_implicit_prelude]',
  ]) {
    const dir = genericCrate(`${declaration}
      pub struct Meter { value: u8 }
      impl Meter { pub fn choose(&mut self, a: u8, b: u8) { self.value = usize::min(a, b); } }
    `)
    expect(JSON.stringify(readRust(dir, ['Meter']).funcs['Meter::choose'])).not.toContain('"builtin"')
  }
}, 120_000)

t('Rust lifetime parameters do not masquerade as type or const parameters', () => {
  const dir = genericCrate(`
    pub struct Borrowed<'a> { value: &'a u8 }
    pub struct Typed<T> { value: T }
    pub struct Fixed<const N: usize> { value: [u8; N] }
    pub fn borrowed<'a>(value: &'a u8) -> u8 { *value }
    pub fn typed<T>(value: T) -> T { value }
    pub fn fixed<const N: usize>() -> usize { N }
  `)
  const mod = readRust(dir, ['Borrowed', 'Typed', 'Fixed', 'borrowed', 'typed', 'fixed'])
  expect(mod.recs.Borrowed!.kinds.some(k => k.startsWith('generic:'))).toBe(false)
  expect(mod.recs.Typed!.kinds.some(k => k.startsWith('generic:'))).toBe(true)
  expect(mod.recs.Fixed!.kinds.some(k => k.startsWith('generic:'))).toBe(true)
  expect(Object.values(mod.funcs).find(f => f.name === 'borrowed')).toHaveProperty('generic', false)
  expect(Object.values(mod.funcs).find(f => f.name === 'typed')).toHaveProperty('generic', true)
  expect(Object.values(mod.funcs).find(f => f.name === 'fixed')).toHaveProperty('generic', true)
}, 120_000)

t('Rust lifetime-bearing methods retain original-code replay', () => {
  const dir = genericCrate(`
    pub struct Meter { used: u8 }
    impl Meter {
      pub fn new() -> Self { Self { used: 0 } }
      pub fn add<'a>(&'a mut self, amount: u8) {
        self.used = self.used.wrapping_add(amount);
      }
      pub fn clear<'a: 'b, 'b>(&'a mut self) { self.used = 0; }
    }
  `)
  const x = extractRust(dir, {entry: 'Meter', methods: ['add', 'clear'], check: budget})
  expect(x.ok).toBe(true)
  expect(x.evidence?.requests).toBeGreaterThan(0)
}, 120_000)

t('Rust lifetime parameters do not authorize unsupported borrowed fields', () => {
  const dir = genericCrate(`
    pub struct Borrowed<'a> { bytes: &'a [u8], used: u8 }
    impl<'a> Borrowed<'a> {
      pub fn new(bytes: &'a [u8]) -> Self { Self { bytes, used: 0 } }
      pub fn advance(&mut self) { self.used = self.used.wrapping_add(1); }
    }
  `)
  const x = extractRust(dir, {entry: 'Borrowed', check: budget})
  expect(x.ok).toBe(false)
  expect(x.refusals.length).toBeGreaterThan(0)
  expect(x.refusals.every(r => !r.what.includes('a generic type'))).toBe(true)
}, 120_000)

t('Rust lifetime parameters do not erase mixed type or const method parameters', () => {
  for (const method of [
    "pub fn add<'a, T>(&'a mut self, amount: u8, value: T) { self.used = amount; }",
    "pub fn add<'a, const N: usize>(&'a mut self, amount: u8) { self.used = amount; }",
  ]) {
    const dir = genericCrate(`pub struct Meter { used: u8 } impl Meter {
      pub fn new() -> Self { Self { used: 0 } } ${method}
    }`)
    const x = extractRust(dir, {entry: 'Meter', methods: ['add'], check: budget})
    expect(x.ok).toBe(false)
    expect(x.refusals.some(r => r.what.includes('generic'))).toBe(true)
  }
}, 120_000)

t('Rust unresolved type and const parameters remain refused', () => {
  for (const declaration of [
    'pub struct Meter<T> { value: T }',
    'pub struct Meter<const N: usize> { value: [u8; N] }',
  ]) {
    const x = extractRust(genericCrate(declaration), {entry: 'Meter', check: budget})
    expect(x.ok).toBe(false)
    expect(x.refusals.some(r => r.what.includes('a generic type'))).toBe(true)
  }
}, 120_000)

for (const [name, initial, body, expected] of [
  ['plain arguments', 7, 'self.value = first(self.seen, 0);', {value: 0, seen: 0}],
  ['earlier read before later effects', 7, 'self.value = first(self.seen, { self.seen = self.seen.wrapping_add(1); 0 });', {value: 0, seen: 1}],
  ['each prelude before its own value', 7, 'self.value = first({ self.seen = self.seen.wrapping_add(1); self.seen }, { self.seen = self.seen.wrapping_add(1); 0 });', {value: 1, seen: 2}],
  ['earlier failure before later effects', 4_294_967_295, 'self.value = first(self.value + 1u32, { self.seen = self.seen.wrapping_add(1); 0 });', {value: 4_294_967_295, seen: 0, failed: true}],
  ['local callable shadows the free function', 7, 'let first = |a: u32, _b: u32| a.wrapping_add(10); self.value = first(self.seen, 0);', {value: 10, seen: 0}],
] as const) t(`Rust free calls: ${name}`, () => {
  const dir = genericCrate(`fn first(a: u32, _b: u32) -> u32 { a }
    pub struct Meter { value: u32, seen: u32 }
    impl Meter {
      pub fn new() -> Self { Self { value: ${initial}, seen: 0 } }
      pub fn take(&mut self) { ${body} }
    }
  `)
  const x = ok(extractRust(dir, {entry: 'Meter', check: budget, failures: 'kept', strict: true}))
  const r = x.rule!, runtime = r.interpreter(), params = r.encodeParams({})
  expect(r.decode(runtime.step(params, runtime.init(params), r.encodeInput({})))).toMatchObject(expected)
}, 300_000)

t('Rust method sequencing: direct primitive extrema capture the receiver first', () => {
  for (const [method, arg] of [['max', 0], ['min', 10]] as const) {
    const dir = genericCrate(`pub struct Meter { value:u32, seen:u32 }
      impl Meter {
        pub fn new()->Self { Self {value:7, seen:0} }
        pub fn take(&mut self) {
          self.value = self.seen.${method}({ self.seen = self.seen.wrapping_add(1); ${arg} });
        }
      }`)
    const x = ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
    const r = x.rule!, rt = r.interpreter(), p = r.encodeParams({})
    expect(r.decode(rt.step(p, rt.init(p), r.encodeInput({})))).toMatchObject({value:0, seen:1})
  }
}, 300_000)

t('Rust method sequencing: fixed borrowed helper preserves argument order and receiver identity', () => {
  for (const [initial, mutable, args, expected] of [
    [7, false, 'self.seen, 0', {value:0, seen:0, helper_bias:0}],
    [7, false, 'self.seen, { self.seen = self.seen.wrapping_add(1); 0 }', {value:0, seen:1, helper_bias:0}],
    [7, false, '{ self.seen = self.seen.wrapping_add(1); self.seen }, { self.seen = self.seen.wrapping_add(1); 0 }', {value:1, seen:2, helper_bias:0}],
    [4_294_967_295, false, 'self.value + 1u32, { self.seen = self.seen.wrapping_add(1); 0 }', {value:4_294_967_295, seen:0, helper_bias:0, failed:true}],
    [7, true, 'self.seen, { self.seen = self.seen.wrapping_add(1); 0 }', {value:1, seen:1, helper_bias:1}],
  ] as const) {
    const dir = genericCrate(`pub struct Helper {bias:u32}
      impl Helper { pub fn first(&${mutable ? 'mut ' : ''}self, a:u32, _b:u32)->u32 {
        ${mutable ? 'self.bias = self.bias.wrapping_add(1);' : ''} a.wrapping_add(self.bias)
      } }
      pub struct Meter {value:u32, seen:u32, helper:Helper}
      impl Meter {
        pub fn new()->Self { Self {value:${initial}, seen:0, helper:Helper {bias:0}} }
        pub fn take(&mut self) { self.value = self.helper.first(${args}); }
      }`)
    const x = ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
    const r = x.rule!, rt = r.interpreter(), p = r.encodeParams({}), input = r.encodeInput({})
    const first = rt.step(p, rt.init(p), input)
    expect(r.decode(first)).toMatchObject(expected)
    if (mutable) expect(r.decode(rt.step(p, first, input))).toMatchObject({value:3, seen:2, helper_bias:2})
  }
}, 300_000)

t('Rust D1: typed literal-sum receivers fail before argument effects', () => {
  for (const method of ['min', 'max']) for (const literal of ['1u32', '1']) {
    const dir = genericCrate(`pub struct Meter {value:u32, seen:u32}
      impl Meter {
        pub fn new(start:u32)->Self {Self {value:start, seen:0}}
        pub fn take(&mut self) {
          self.value = (self.value + ${literal}).${method}({self.seen = self.seen.wrapping_add(1); 0});
        }
      }`)
    const x = ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
    const r = x.rule!, rt = r.interpreter()
    for (const start of [0, 4_294_967_294, 4_294_967_295]) {
      const p = r.encodeParams({start}), failed = start === 4_294_967_295
      expect(r.decode(rt.step(p, rt.init(p), r.encodeInput({})))).toMatchObject({
        value:failed ? start : method === 'min' ? 0 : start + 1, seen:failed ? 0 : 1, failed,
      })
    }
  }
}, 300_000)

t('Rust D1: a successful computed receiver is captured before the argument changes its field', () => {
  const dir = genericCrate(`pub struct Meter {value:u32}
    impl Meter {
      pub fn new()->Self {Self {value:7}}
      pub fn take(&mut self) {
        self.value = (self.value + 1u32).max({self.value = self.value.wrapping_add(10); 0});
      }
    }`)
  const x = ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
  const r = x.rule!, rt = r.interpreter(), p = r.encodeParams({})
  expect(r.decode(rt.step(p, rt.init(p), r.encodeInput({})))).toMatchObject({value:8, failed:false})
}, 300_000)

t('Rust D2: scalar-field block receivers capture after their prelude and before arguments', () => {
  for (const [method, arg] of [['max', 0], ['min', 10]] as const) {
    const dir = genericCrate(`pub struct Meter {value:u32, seen:u32}
      impl Meter {
        pub fn new()->Self {Self {value:7, seen:0}}
        pub fn take(&mut self) {
          self.value = ({self.seen = self.seen.wrapping_add(1); self.seen}).${method}({self.seen = self.seen.wrapping_add(1); ${arg}});
        }
      }`)
    const x = ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
    const r = x.rule!, rt = r.interpreter(), p = r.encodeParams({}), input = r.encodeInput({})
    const first = rt.step(p, rt.init(p), input)
    expect(r.decode(first)).toMatchObject({value:1, seen:2})
    expect(r.decode(rt.step(p, first, input))).toMatchObject({value:3, seen:4})
  }
}, 300_000)

t('Rust D2: receiver-prelude return and panic prevent argument effects', () => {
  for (const kind of ['return', 'panic'] as const) {
    const dir = genericCrate(`pub struct Meter {value:u32, seen:u32}
      impl Meter {
        pub fn new()->Self {Self {value:7, seen:0}}
        pub fn take(&mut self, stop:bool) {
          self.value = ({
            self.seen = self.seen.wrapping_add(1);
            if stop { ${kind === 'return' ? 'return;' : 'panic!("receiver");'} }
            self.seen
          }).max({self.seen = self.seen.wrapping_add(1); 0});
        }
      }`)
    const x = ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
    const r = x.rule!, rt = r.interpreter(), p = r.encodeParams({})
    for (const stop of [false, true]) {
      expect(r.decode(rt.step(p, rt.init(p), r.encodeInput({stop})))).toMatchObject({
        value:stop ? 7 : 1, seen:stop ? 1 : 2, ...(kind === 'panic' ? {failed:stop} : {}),
      })
    }
  }
}, 300_000)

t('Rust D2: a scalar tail does not erase an unsupported receiver prelude', () => {
  const dir = genericCrate(`pub struct Meter {value:u32, seen:u32}
    impl Meter {
      pub fn new()->Self {Self {value:7, seen:0}}
      pub fn take(&mut self) {
        self.value = ({while self.seen < 1 {self.seen += 1;} self.seen}).max(0);
      }
    }`)
  const x = extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'})
  expect(x.ok).toBe(false)
  expect(x.refusals.map(r => r.what).join('; ')).toContain('a loop')
}, 300_000)

const d3First = 'fn first(a:u32, _b:u32)->u32 { a }'
const d3Prefix = 'self.seen = self.seen.wrapping_add(1);'
const d3Call = `self.value = ({ ${d3Prefix} first })({ self.seen = self.seen.wrapping_mul(2); self.seen }, 0);`
const d3Source = (body = d3Call, target = d3First, seen = 0) => `${target}
  pub struct Meter {value:u32, seen:u32}
  impl Meter {
    pub fn new()->Self {Self {value:7, seen:${seen}}}
    pub fn take(&mut self) {${body}}
  }`
const d3Refused = (name: string, source: string, reason: string) => {
  const dir = genericCrate(source)
  // Identity refusal is not established by compiler-invalid source.
  execFileSync('cargo', ['check', '--quiet', '--manifest-path', `${dir}/Cargo.toml`], {stdio:'pipe'})
  const x = extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'})
  expect({name, ok:x.ok}).toEqual({name, ok:false})
  const why = x.refusals.map(r => r.what).join('; ')
  expect(why).toContain(reason)
  console.log(JSON.stringify({d3Control:name, native:'cargo-check-pass', reader:'refused', mismatch:!!x.evidence?.mismatch, why}))
}

t('Rust D3: fixed item block preserves callee order and exact function identity', () => {
  const dir = genericCrate(d3Source())
  const x = ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
  expect(JSON.stringify(readRust(dir, ['Meter']).funcs['Meter::take'])).toContain('"f":{"e":"fn","id":"first"')
  const r = x.rule!, rt = r.interpreter(), p = r.encodeParams({}), input = r.encodeInput({})
  const first = rt.step(p, rt.init(p), input)
  expect(r.decode(first)).toMatchObject({value:2, seen:2})
  expect(r.decode(rt.step(p, first, input))).toMatchObject({value:6, seen:6})
}, 300_000)

t('Rust inline replay: matching module retains fixed identity and native sequencing', () => {
  const dir = genericCrate(`pub mod nested {${d3Source()}}`)
  const mod = readRust(dir, ['Meter'])
  expect((mod as {fmods?: Record<string, string>}).fmods?.first).toBe('crate::nested')
  expect(JSON.stringify(mod.funcs['Meter::take'])).toContain('"f":{"e":"fn","id":"first"')
  const x = ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
  const r = x.rule!, rt = r.interpreter(), p = r.encodeParams({}), input = r.encodeInput({})
  const first = rt.step(p, rt.init(p), input)
  expect(r.decode(first)).toMatchObject({value:2, seen:2})
  expect(r.decode(rt.step(p, first, input))).toMatchObject({value:6, seen:6})
}, 300_000)

t('Rust inline replay: argument capture and assignment failure remain native-aligned', () => {
  for (const [body, seen, expected] of [
    [`self.value = ({${d3Prefix} first})(self.seen, {self.seen = self.seen.wrapping_add(1); 0});`, 0, {value:1, seen:2}],
    ['self.value = ({self.seen = self.seen + 1; first})({self.value = 99; 0}, 0);', 4_294_967_295, {value:7, seen:4_294_967_295, failed:true}],
  ] as const) {
    const dir = genericCrate(`mod nested {${d3Source(body, d3First, seen)}}`)
    const x = ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
    const r = x.rule!, rt = r.interpreter(), p = r.encodeParams({})
    expect(r.decode(rt.step(p, rt.init(p), r.encodeInput({})))).toMatchObject(expected)
  }
}, 300_000)

const replaySite = (dir: string, file: string, module: string): {inline_end?: number | null, harness_name?: string, error?: string} => JSON.parse(execFileSync(rsReader(), [JSON.stringify({root:dir, harness_scope:{file, module}})], {encoding:'utf8'}))

t('Rust inline replay: parser byte positions handle Unicode, braces and following source', () => {
  const source = `// café 🦀\npub mod nested {const TEXT:&str = r#"} { 🦀"#; ${d3Source()}} // scope-end\nfn unrelated() {}`
  const dir = genericCrate(source)
  expect(replaySite(dir, 'src/lib.rs', 'crate::nested').inline_end).toBe(new TextEncoder().encode(source.slice(0, source.indexOf('} // scope-end'))).length)
  const x = ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
  const r = x.rule!, rt = r.interpreter(), p = r.encodeParams({})
  expect(r.decode(rt.step(p, rt.init(p), r.encodeInput({})))).toMatchObject({value:2, seen:2})
}, 300_000)

t('Rust inline replay: placement follows clock and answered-call rewrites', () => {
  const dir = genericCrate(`mod nested {
    use std::time::Instant;
    pub struct Clock {stamp:Instant, value:u32}
    impl Clock {
      pub fn new()->Self {Self {stamp:Instant::now(), value:0}}
      pub fn take(&mut self) {self.stamp = Instant::now(); self.value = std::process::id();}
    }
  }`)
  ok(extractRust(dir, {entry:'Clock', check:budget, strict:true, failures:'kept', answers:{'std::process::id':'u32'}}))
}, 300_000)

t('Rust inline replay: external file modules still append in their own scope', () => {
  const dir = genericCrate('mod nested;')
  writeFileSync(`${dir}/src/nested.rs`, d3Source())
  expect(replaySite(dir, 'src/nested.rs', 'crate::nested').inline_end).toBeNull()
  const x = ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
  const r = x.rule!, rt = r.interpreter(), p = r.encodeParams({})
  expect(r.decode(rt.step(p, rt.init(p), r.encodeInput({})))).toMatchObject({value:2, seen:2})
}, 300_000)

t('Rust inline replay: source errors before and after insertion remain source errors', () => {
  const bad = 'fn broken() {let _:u32 = "bad";}\n'
  for (const before of [true, false]) {
    const source = `pub mod nested {${d3Source()}}\n`
    const dir = genericCrate(before ? bad + source : source + bad)
    const x = extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'})
    expect(x.ok).toBe(false)
    expect(x.refusals[0]!.what).toMatch(/^the source doesn't compile \(cargo\): error\[E0308\]/)
  }
}, 300_000)

t('Rust helper module: original collision replays with a fresh fixed name', () => {
  const dir = genericCrate(`mod nested {
    mod __gdp_harness {}
    pub struct Meter {value:u32}
    impl Meter {pub fn new()->Self {Self {value:0}} pub fn take(&mut self) {self.value = 1;}}
  }`)
  expect(replaySite(dir, 'src/lib.rs', 'crate::nested').harness_name).toBe('__gdp_harness_1')
  const x = ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
  const r = x.rule!, rt = r.interpreter(), p = r.encodeParams({})
  expect(r.decode(rt.step(p, rt.init(p), r.encodeInput({})))).toMatchObject({value:1})
}, 300_000)

const helperMeter = 'pub struct Meter {value:u32} impl Meter {pub fn new()->Self {Self {value:0}} pub fn take(&mut self) {self.value = 1;}}'
const helperRefusal = (name: string, dir: string, why = 'namespace is not closed') => {
  execFileSync('cargo', ['check', '--quiet', '--manifest-path', `${dir}/Cargo.toml`], {stdio:'pipe'})
  const x = extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'})
  expect({name, ok:x.ok}).toEqual({name, ok:false})
  expect(x.refusals[0]!.what).toContain(why)
  console.log(JSON.stringify({helperControl:name, native:'cargo-check-pass', refusal:x.refusals[0]!.what}))
}

t('Rust helper module: occupied suffixes, module order and raw identifiers are respected', () => {
  const a = 'mod __gdp_harness {}', b = 'mod __gdp_harness_1 {}'
  for (const modules of [a + b, b + a]) {
    const dir = genericCrate(modules + helperMeter)
    expect(replaySite(dir, 'src/lib.rs', 'crate').harness_name).toBe('__gdp_harness_2')
    ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
  }
  const dir = genericCrate(`mod nested {mod r#__gdp_harness {} mod __gdp_harness_1 {} fn unused(__gdp_harness_2:u32) {} ${helperMeter}}`)
  expect(replaySite(dir, 'src/lib.rs', 'crate::nested').harness_name).toBe('__gdp_harness_3')
  ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
}, 300_000)

t('Rust helper module: noncolliding names in other namespaces or scopes keep the default', () => {
  for (const source of [
    `use std::mem; pub fn __gdp_harness()->u32 {0} mod other {pub mod __gdp_harness {}} ${helperMeter}`,
    `use std::mem; ${helperMeter.replaceAll('value', '__gdp_harness')}`,
  ]) {
    const dir = genericCrate(source)
    expect(replaySite(dir, 'src/lib.rs', 'crate').harness_name).toBe('__gdp_harness')
    ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
  }
}, 300_000)

t('Rust helper module: a declared type-name collision also receives a fresh module', () => {
  const dir = genericCrate('type __gdp_harness = u32;' + helperMeter)
  expect(replaySite(dir, 'src/lib.rs', 'crate').harness_name).toBe('__gdp_harness_1')
  ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
}, 300_000)

t('Rust helper module: clock and answer bridges target the renamed module', () => {
  const dir = genericCrate(`mod nested {
    mod __gdp_harness {}
    type Instant = std::time::Instant;
    pub struct Clock {stamp:std::time::Instant, value:u32}
    impl Clock {
      pub fn new()->Self {Self {stamp:Instant::now(), value:0}}
      pub fn take(&mut self) {self.stamp = Instant::now(); self.value = std::process::id();}
    }
  }`)
  expect(replaySite(dir, 'src/lib.rs', 'crate::nested').harness_name).toBe('__gdp_harness_1')
  ok(extractRust(dir, {entry:'Clock', check:budget, strict:true, failures:'kept', answers:{'std::process::id':'u32'}}))
}, 300_000)

t('Rust helper module: uncertain namespaces refuse collision repair only', () => {
  for (const [name, extra] of [
    ['import', 'use std::mem;'],
    ['cfg', '#[cfg(any())] mod disabled {}'],
    ['macro', 'macro_rules! unused {() => {}}'],
  ]) {
    helperRefusal(name!, genericCrate(`mod nested {mod __gdp_harness {} ${helperMeter} ${extra}}`))
  }
  helperRefusal('renamed-module-import', genericCrate(`mod supplier {pub mod supplied {}} use supplier::supplied as __gdp_harness; ${helperMeter}`))
  helperRefusal('glob-module-import', genericCrate(`mod supplier {pub mod __gdp_harness {}} use supplier::*; ${helperMeter}`))
  const clear = genericCrate(`mod nested {use std::mem; ${helperMeter}}`)
  expect(replaySite(clear, 'src/lib.rs', 'crate::nested').harness_name).toBe('__gdp_harness')
  ok(extractRust(clear, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
}, 300_000)

t('Rust helper module: unexpanded external declarations prevent a freshness claim', () => {
  const dir = genericCrate(`mod nested {mod __gdp_harness {} mod extra; ${helperMeter}}`)
  mkdirSync(`${dir}/src/nested`)
  writeFileSync(`${dir}/src/nested/extra.rs`, 'pub fn unused() {}')
  helperRefusal('unexpanded-external', dir)
}, 300_000)

t('Rust helper module: renaming does not widen closed-callee reader admission', () => {
  helperRefusal('D3-module-limit', genericCrate(`mod nested {mod __gdp_harness {} ${d3Source()}}`), 'closed callee: source namespace is not closed')
}, 300_000)

const replayBridges = (dir: string, file = 'src/lib.rs'): {now?: string, answer?: string, error?: string} => JSON.parse(execFileSync(rsReader(), [JSON.stringify({root:dir, harness_bridges:{file}})], {encoding:'utf8'}))
const bridgeRefusal = (name: string, dir: string, why = 'fresh root bridge: namespace is not closed') => {
  execFileSync('cargo', ['check', '--quiet', '--manifest-path', `${dir}/Cargo.toml`], {stdio:'pipe'})
  const x = extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'})
  expect({name, ok:x.ok}).toEqual({name, ok:false})
  expect(x.refusals[0]!.what).toContain(why)
  console.log(JSON.stringify({bridgeControl:name, native:'cargo-check-pass', refusal:x.refusals[0]!.what}))
}

t('Rust root bridge: original now and answer collisions are source-valid and replay', () => {
  for (const name of ['now', 'answer']) {
    const dir = genericCrate(`pub fn __gdp_${name}()->u32 {0}` + helperMeter)
    execFileSync('cargo', ['check', '--quiet', '--manifest-path', `${dir}/Cargo.toml`], {stdio:'pipe'})
    expect(replayBridges(dir)).toEqual({now:`__gdp_now${name === 'now' ? '_1' : ''}`, answer:`__gdp_answer${name === 'answer' ? '_1' : ''}`})
    const x = ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
    const r = x.rule!, rt = r.interpreter(), p = r.encodeParams({})
    expect(r.decode(rt.step(p, rt.init(p), r.encodeInput({}))).value).toBe(1)
  }
}, 300_000)

t('Rust root bridge: suffixes and raw identity are deterministic across declaration order', () => {
  const a = 'fn r#__gdp_now()->u32 {0} fn __gdp_now_1()->u32 {0} fn unused(__gdp_now_2:u32) {}'
  const b = 'const r#__gdp_answer:u32=0; const __gdp_answer_1:u32=0;'
  for (const declarations of [a + b, b + a]) {
    const dir = genericCrate(declarations + helperMeter)
    expect(replayBridges(dir)).toEqual({now:'__gdp_now_3', answer:'__gdp_answer_2'})
    ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
  }
}, 300_000)

t('Rust root bridge: constants, statics and tuple or unit constructors occupy values', () => {
  for (const declarations of [
    'const __gdp_now:u32=0; static __gdp_answer:u32=0;',
    'struct __gdp_now; struct __gdp_answer(u32);',
  ]) {
    const dir = genericCrate(declarations + helperMeter)
    expect(replayBridges(dir)).toEqual({now:'__gdp_now_1', answer:'__gdp_answer_1'})
    ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
  }
}, 300_000)

t('Rust root bridge: types, named-field structs, fields and other scopes keep defaults', () => {
  for (const source of [
    `use std::mem; type __gdp_now = u32; mod __gdp_answer {} mod other {pub fn __gdp_now() {} pub fn __gdp_answer() {}} ${helperMeter}`,
    `use std::mem; struct __gdp_now {n:u32} struct __gdp_answer {n:u32} ${helperMeter}`,
    `use std::mem; ${helperMeter.replaceAll('value', '__gdp_now')}`,
    `use std::mem; ${helperMeter.replaceAll('value', '__gdp_answer')}`,
  ]) {
    const dir = genericCrate(source)
    expect(replayBridges(dir)).toEqual({now:'__gdp_now', answer:'__gdp_answer'})
    ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
  }
}, 300_000)

t('Rust root bridge: original calls to user functions are not rewritten', () => {
  const dir = genericCrate('fn __gdp_now()->u32 {7} fn __gdp_answer()->u32 {9}' + helperMeter.replace('self.value = 1', 'self.value = __gdp_now() + __gdp_answer()'))
  const x = ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
  const r = x.rule!, rt = r.interpreter(), p = r.encodeParams({})
  expect(r.decode(rt.step(p, rt.init(p), r.encodeInput({}))).value).toBe(16)
}, 300_000)

const bridgeClock = `mod __gdp_harness {}
  type Instant = std::time::Instant;
  pub struct Clock {stamp:std::time::Instant, value:u32}
  impl Clock {
    pub fn new()->Self {Self {stamp:Instant::now(), value:0}}
    pub fn take(&mut self) {self.stamp = Instant::now(); self.value = std::process::id();}
  }`
t('Rust root bridge: both rewrites and declarations share chosen names in inline and file modules', () => {
  const root = 'fn __gdp_now()->u32 {7} fn __gdp_now_1()->u32 {0} fn __gdp_answer()->u32 {9}'
  for (const inline of [true, false]) {
    const dir = genericCrate(root + (inline ? `mod nested { // café }\n ${bridgeClock} }` : 'mod nested;'))
    if (!inline) writeFileSync(`${dir}/src/nested.rs`, bridgeClock)
    expect(replayBridges(dir)).toEqual({now:'__gdp_now_2', answer:'__gdp_answer_1'})
    expect(replaySite(dir, inline ? 'src/lib.rs' : 'src/nested.rs', 'crate::nested').harness_name).toBe('__gdp_harness_1')
    ok(extractRust(dir, {entry:'Clock', check:budget, strict:true, failures:'kept', answers:{'std::process::id':'u32'}}))
  }
}, 300_000)

// These cases add inventory sources not covered by the ordinary suffix/constructor tests.
const nameInventoryConformance = (name: string, declarations: string, expected: {harness: string, now: string, answer: string}) => {
  const source = bridgeClock.replace('mod __gdp_harness {}', declarations)
  const dir = genericCrate(source)
  execFileSync('cargo', ['check', '--quiet', '--manifest-path', `${dir}/Cargo.toml`], {stdio:'pipe'})
  const names = {...replayBridges(dir), harness:replaySite(dir, 'src/lib.rs', 'crate').harness_name}
  expect(names).toEqual(expected)
  const x = ok(extractRust(dir, {entry:'Clock', check:budget, strict:true, failures:'kept', answers:{'std::process::id':'u32'}}))
  // The configured run/depth bounds are not a guaranteed request count.
  // ok() already requires accepted conformance and positive native requests.
  console.log(JSON.stringify({nameInventory:name, source, sourceSha256:createHash('sha256').update(source).digest('hex'), native:'cargo-check-pass', names, ok:x.ok, requests:x.evidence?.requests, evidence:x.evidence}))
}

t('Rust name inventory: raw loaded module paths reserve suffixes for all helpers', () => {
  // The loader removes these declarations from root items. Empty module paths
  // must still reserve their names; raw spelling is the same Rust identity.
  nameInventoryConformance('loaded-module-paths', `
    mod r#__gdp_harness {}
    mod r#__gdp_harness_1 {}
    mod __gdp_harness_2 {}
    fn __gdp_now()->u32 {0}
    mod r#__gdp_now_1 {}
    mod __gdp_now_2 {}
    fn __gdp_answer()->u32 {0}
    mod r#__gdp_answer_1 {}
    mod __gdp_answer_2 {}
  `, {harness:'__gdp_harness_3', now:'__gdp_now_3', answer:'__gdp_answer_3'})
}, 300_000)

t('Rust name inventory: raw named-field and tuple structs distinguish helper namespaces', () => {
  // The same named-field shape collides with a module but not a function;
  // a tuple constructor occupies the value namespace as well as the type one.
  nameInventoryConformance('raw-struct-namespaces', `
    struct r#__gdp_harness {value:u32}
    struct r#__gdp_now {value:u32}
    struct r#__gdp_answer(u32);
  `, {harness:'__gdp_harness_1', now:'__gdp_now', answer:'__gdp_answer_1'})
}, 300_000)

t('Rust name inventory: doc and literal suffix text does not occupy identifiers', () => {
  // Doc attributes are permitted by the closed inventory. Their string values,
  // ordinary comments and literal text do not reserve the first free suffix.
  nameInventoryConformance('doc-and-literal-decoys', `
    #[doc = "__gdp_harness_1 __gdp_now_1 __gdp_answer_1"]
    type r#__gdp_harness = u32;
    /// __gdp_harness_1 __gdp_now_1 __gdp_answer_1
    struct r#__gdp_now;
    struct r#__gdp_answer(u32);
    const TEXT:&str = r#"__gdp_harness_1 __gdp_now_1 __gdp_answer_1"#;
    // __gdp_harness_1 __gdp_now_1 __gdp_answer_1
  `, {harness:'__gdp_harness_1', now:'__gdp_now_1', answer:'__gdp_answer_1'})
}, 300_000)

t('Rust root bridge: namespace uncertainty cannot become guessed freshness', () => {
  for (const [name, declarations] of [
    ['import', 'fn __gdp_now() {} use std::mem;'],
    ['cfg', '#[cfg(any())] fn __gdp_answer() {}'],
    ['macro', 'fn __gdp_now() {} macro_rules! unused {() => {}}'],
    ['renamed-import', 'mod supplier {pub fn value() {}} use supplier::value as __gdp_answer;'],
    ['glob-import', 'mod supplier {pub fn __gdp_answer() {}} use supplier::*;'],
    ['foreign-function', 'extern "C" {fn __gdp_answer();}'],
    ['foreign-static', 'extern "C" {static __gdp_now:u32;}'],
  ]) bridgeRefusal(name!, genericCrate(declarations + helperMeter))
  const dir = genericCrate('fn __gdp_now() {} mod nested {mod extra;}' + helperMeter)
  mkdirSync(`${dir}/src/nested`)
  writeFileSync(`${dir}/src/nested/extra.rs`, 'pub fn unused() {}')
  bridgeRefusal('unexpanded-external', dir)
}, 300_000)

t('Rust root bridge: naming does not widen D3 admission or accept an unknown root', () => {
  const dir = genericCrate(`fn __gdp_now() {} mod nested {mod excluded {} ${d3Source()}}`)
  bridgeRefusal('D3-module-limit', dir, 'closed callee: source namespace is not closed')
  expect(replayBridges(dir, 'src/missing.rs').error).toContain('one known crate-root bridge scope')
}, 300_000)

t('Rust raw identifiers: exact entry and distinct scalar encoding keys', () => {
  const source = `pub struct r#type {r#type:u32, r_type:u32}
    impl r#type {
      pub fn new()->Self {Self {r#type:0, r_type:1}}
      pub fn take(&mut self, r#match:u32, r_match:u32) {self.r#type = r#match; self.r_type = r_match;}
    }`
  const dir = genericCrate(source)
  execFileSync('cargo', ['check', '--quiet', '--manifest-path', `${dir}/Cargo.toml`], {stdio:'pipe'})
  const x = ok(extractRust(dir, {entry:'r#type', check:budget, strict:true, failures:'kept'}))
  expect(x.read!.leaves.map(l => ({name:l.name, path:l.path}))).toEqual([
    {name:'r_type', path:['r#type']}, {name:'r_type_', path:['r_type']},
  ])
  const r = x.rule!, rt = r.interpreter(), p = r.encodeParams({})
  expect(r.decode(rt.step(p, rt.init(p), r.encodeInput({r_match:7, r_match_:19})))).toMatchObject({r_type:7, r_type_:19, failed:false})
  const bare = extractRust(dir, {entry:'type', check:budget, strict:true, failures:'kept'})
  expect(bare.ok).toBe(false)
  expect(bare.refusals[0]!.what).toContain('no class or function type')
  expect(bare.evidence).toBeUndefined()
  console.log(JSON.stringify({rawBoundary:'entry-and-state', source, sourceSha256:createHash('sha256').update(source).digest('hex'), native:'cargo-check-pass', entry:'r#type', ok:x.ok, evidence:x.evidence, refusal:bare.refusals[0]!.what}))
}, 300_000)

t('Rust raw identifiers: inline module keeps exact scope and native selector', () => {
  const source = `mod r#type {${helperMeter}}`
  const dir = genericCrate(source)
  execFileSync('cargo', ['check', '--quiet', '--manifest-path', `${dir}/Cargo.toml`], {stdio:'pipe'})
  expect(replaySite(dir, 'src/lib.rs', 'crate::r#type').inline_end).toBe(source.lastIndexOf('}'))
  const bare = replaySite(dir, 'src/lib.rs', 'crate::type')
  expect(bare.error).toContain('one known file/module scope')
  const x = ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
  const r = x.rule!, rt = r.interpreter(), p = r.encodeParams({})
  expect(r.decode(rt.step(p, rt.init(p), r.encodeInput({}))).value).toBe(1)
  console.log(JSON.stringify({rawBoundary:'inline-selector', source, sourceSha256:createHash('sha256').update(source).digest('hex'), native:'cargo-check-pass', entry:'Meter', ok:x.ok, evidence:x.evidence, refusal:bare.error}))
}, 300_000)

t('Rust external modules: raw default filenames and redirected paths are not inferred', () => {
  for (const [name, root, file] of [
    ['raw-default-file', 'mod r#type;', 'src/type.rs'],
    ['path-redirect', '#[path="actual.rs"] mod renamed;', 'src/actual.rs'],
  ] as const) {
    const dir = genericCrate(root), files = {'src/lib.rs':root, [file]:helperMeter}
    writeFileSync(`${dir}/${file}`, helperMeter)
    execFileSync('cargo', ['check', '--quiet', '--manifest-path', `${dir}/Cargo.toml`], {stdio:'pipe'})
    expect(readRust(dir, ['Meter']).entries).toEqual([{k:'missing', name:'Meter'}])
    const x = extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'})
    expect(x.ok).toBe(false)
    expect(x.refusals[0]!.what).toContain('no class or function Meter')
    expect(x.evidence).toBeUndefined()
    console.log(JSON.stringify({externalBoundary:name, files, native:'cargo-check-pass', ok:x.ok, refusal:x.refusals[0]!.what}))
  }
}, 300_000)

t('Rust external modules: literal filename agreement selects and replays a raw module', () => {
  // This is filename agreement, not general #[path] interpretation or raw filename loading.
  const root = '#[path="r#type.rs"] mod r#type;', file = 'src/r#type.rs'
  const dir = genericCrate(root), files = {'src/lib.rs':root, [file]:helperMeter}
  writeFileSync(`${dir}/${file}`, helperMeter)
  execFileSync('cargo', ['check', '--quiet', '--manifest-path', `${dir}/Cargo.toml`], {stdio:'pipe'})
  expect(readRust(dir, ['Meter']).recs.Meter).toMatchObject({file, module:'crate::r#type'})
  expect(replaySite(dir, file, 'crate::r#type').inline_end).toBeNull()
  const x = ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
  const r = x.rule!, rt = r.interpreter(), p = r.encodeParams({})
  expect(r.decode(rt.step(p, rt.init(p), r.encodeInput({}))).value).toBe(1)
  console.log(JSON.stringify({externalBoundary:'raw-path-agreement', files, native:'cargo-check-pass', ok:x.ok, evidence:x.evidence}))
}, 300_000)

t('Rust inline replay: ambiguous or unknown placement is refused', () => {
  const dir = genericCrate('#[cfg(any())] mod nested {} #[cfg(not(any()))] mod nested {}')
  execFileSync('cargo', ['check', '--quiet', '--manifest-path', `${dir}/Cargo.toml`], {stdio:'pipe'})
  expect(replaySite(dir, 'src/lib.rs', 'crate::nested').error).toContain('one known file/module scope')
  expect(replaySite(dir, 'src/lib.rs', 'crate::absent').error).toContain('one known file/module scope')
}, 300_000)

t('Rust inline replay: fixed free functions cannot be shadowed by harness locals', () => {
  const functions = 'pub fn a(x:u32)->u32 {x} pub fn o(x:u32)->u32 {x} pub fn m(x:u32)->u32 {x}'
  for (const source of [functions, `mod nested {${functions}}`]) {
    ok(extractRust(genericCrate(source), {entry:['a','o','m'], check:budget, strict:true, failures:'kept'}))
  }
}, 300_000)

t('Rust inline replay: free-function entries must share a known module', () => {
  const dir = genericCrate('mod left {pub fn a(x:u32)->u32 {x.saturating_add(x)}} mod right {pub fn b(x:u32)->u32 {x}}')
  ok(extractRust(dir, {entry:'a', check:budget, strict:true, failures:'kept'}))
  const x = extractRust(dir, {entry:['a','b'], check:budget, strict:true, failures:'kept'})
  expect(x.ok).toBe(false)
  expect(x.refusals[0]!.what).toContain('function entries in one known file/module')
}, 300_000)

t('Rust D3: each argument value is captured before the next argument prelude', () => {
  const dir = genericCrate(d3Source(`self.value = ({${d3Prefix} first})(self.seen, {self.seen = self.seen.wrapping_add(1); 0});`))
  const x = ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
  const r = x.rule!, rt = r.interpreter(), p = r.encodeParams({})
  expect(r.decode(rt.step(p, rt.init(p), r.encodeInput({})))).toMatchObject({value:1, seen:2})
}, 300_000)

t('Rust D3: callee assignment failure prevents argument writes', () => {
  const dir = genericCrate(d3Source('self.value = ({self.seen = self.seen + 1; first})({self.value = 99; 0}, 0);', d3First, 4_294_967_295))
  const x = ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
  const r = x.rule!, rt = r.interpreter(), p = r.encodeParams({})
  expect(r.decode(rt.step(p, rt.init(p), r.encodeInput({})))).toMatchObject({value:7, seen:4_294_967_295, failed:true})
}, 300_000)

t('Rust D3: actual global declaration collisions refuse in either order', () => {
  const other = 'pub mod other {pub fn first(_a:u32, b:u32)->u32 {b}}'
  for (const before of [false, true]) {
    d3Refused(`collision-${before}`, before ? other + d3Source() : d3Source() + other, 'exactly one loaded function declaration')
  }
}, 300_000)

t('Rust D3: local and actual value namespace competitors refuse', () => {
  d3Refused('local-shadow', d3Source(`let first = |a:u32, _b:u32| a; ${d3Call}`), 'value-name ambiguity')
  d3Refused('alias', d3Source(`let chosen = first; ${d3Call.replace(' first })', ' chosen })')}`), 'exactly one loaded function declaration')
  d3Refused('nonliteral-constant', d3Source() + 'mod other {pub const first:u32 = 1 + 1;}', 'value-name ambiguity')
  d3Refused('static-name', d3Source() + 'mod other {pub static first:u32 = 1;}', 'value-name ambiguity')
  d3Refused('local-item-after-call', d3Source(`${d3Call} fn first(a:u32, _b:u32)->u32 {a}`), 'value-name ambiguity')
  d3Refused('different-caller-module', `${d3First} pub mod nested {const first:fn(u32,u32)->u32 = crate::first; ${d3Source(d3Call, '')}}`, 'caller file/module')
}, 300_000)

t('Rust D3: imports and macro/cfg uncertainty refuse conservatively', () => {
  const module = 'mod helper {pub fn first(a:u32, _b:u32)->u32 {a}}'
  for (const binding of ['use helper::first;', 'use helper::*;']) {
    d3Refused(binding, d3Source(d3Call, module + binding), 'source namespace is not closed')
  }
  d3Refused('renamed-import', d3Source(d3Call.replace(' first })', ' chosen })'), module + 'use helper::first as chosen;'), 'exactly one loaded function declaration')
  d3Refused('disabled-module', d3Source() + '#[cfg(any())] mod absent;', 'source namespace is not closed')
  d3Refused('macro', d3Source() + 'macro_rules! extra {() => {fn unrelated(){}}} extra!();', 'source namespace is not closed')
  d3Refused('attribute', d3Source(d3Call, '#[inline] ' + d3First), 'source namespace is not closed')
}, 300_000)

t('Rust D3: generic and noninteger signatures do not gain admission', () => {
  const generic = 'fn first<T>(a:T, _b:T)->T {a}'
  d3Refused('inferred-generic', d3Source(d3Call, generic), 'ordinary nongeneric integer signature')
  d3Refused('explicit-generic', d3Source(d3Call.replace(' first })', ' first::<u32> })'), generic), 'bare function-item tail')
  d3Refused('reference-signature', d3Source(d3Call.replace(' self.seen }, 0)', ' &self.seen }, 0)'), 'fn first(a:&u32, _b:u32)->u32 {*a}'), 'ordinary nongeneric integer signature')
  d3Refused('const-function', d3Source(d3Call, 'const ' + d3First), 'ordinary nongeneric integer signature')
}, 300_000)

t('Rust D3: out-of-contract callees retain refusals without expanding block support', () => {
  d3Refused('aliased-field', 'type Count = u32;' + d3Source().replace('seen:u32', 'seen:Count'), 'one primitive assignment')
  d3Refused('nested-arithmetic', d3Source(d3Call.replace(d3Prefix, 'self.seen = (self.seen + 1) + 0;')), 'one primitive assignment')
  d3Refused('extra-assignment', d3Source(d3Call.replace(d3Prefix, d3Prefix + d3Prefix)), 'the rule and the code differ')
  d3Refused('block-binding', d3Source(d3Call.replace(d3Prefix, `let chosen = first; ${d3Prefix}`).replace(' first })', ' chosen })')), 'the rule and the code differ')
  d3Refused('pointer-cast', d3Source(d3Call.replace(' first })', ' first as fn(u32,u32)->u32 })')), 'a fn cast')
  d3Refused('return-prefix', d3Source('self.value = ({return; first})({self.value = 99; 0}, 0);'), 'the rule and the code differ')
  d3Refused('panic-prefix', d3Source('self.value = ({panic!("callee"); first})({self.value = 99; 0}, 0);'), 'the rule and the code differ')
}, 300_000)

t('Rust D3: an independently supported pure function-item block is not banned', () => {
  const dir = genericCrate(d3Source('self.value = ({first})(3, 0);'))
  const x = ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
  const r = x.rule!, rt = r.interpreter(), p = r.encodeParams({})
  expect(r.decode(rt.step(p, rt.init(p), r.encodeInput({})))).toMatchObject({value:3, seen:0})
}, 300_000)

t('Rust method sequencing: unlisted computed receivers keep native mismatch refusals', () => {
  for (const [initial, body] of [
    [4_294_967_295, 'self.value = ((self.value + 1u32) + 0u32).max({ self.seen = self.seen.wrapping_add(1); 0 });'],
    [7, 'self.value = ({ self.seen = self.seen.wrapping_add(1); self.seen.wrapping_add(0) }).max({ self.seen = self.seen.wrapping_add(1); 0 });'],
  ] as const) {
    const dir = genericCrate(`fn first(a:u32, _b:u32)->u32 { a }
      pub struct Meter {value:u32, seen:u32}
      impl Meter {
        pub fn new()->Self { Self {value:${initial}, seen:0} }
        pub fn take(&mut self) { ${body} }
      }`)
    const x = extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'})
    expect(x.ok).toBe(false)
    expect(x.evidence?.mismatch).toContain('the code')
  }
}, 300_000)

t('Rust method sequencing: trait and generic helper dispatch do not enter the shortcut', () => {
  for (const generic of [false, true]) {
    const dir = genericCrate(`pub struct Helper {bias:u32}
      ${generic ? '' : 'trait Choose { fn first(&self, a:u32, b:u32)->u32; }'}
      impl ${generic ? '' : 'Choose for '}Helper {
        fn first${generic ? '<T>' : ''}(&self, a:u32, _b:u32)->u32 { a.wrapping_add(self.bias) }
      }
      pub struct Meter {value:u32, seen:u32, helper:Helper}
      impl Meter {
        pub fn new()->Self { Self {value:7, seen:0, helper:Helper {bias:0}} }
        pub fn take(&mut self) {
          self.value = self.helper.first${generic ? '::<u32>' : ''}(self.seen, { self.seen = self.seen.wrapping_add(1); 0 });
        }
      }`)
    const x = extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'})
    expect(x.ok).toBe(false)
    if (generic) expect(x.refusals.map(r => r.what).join('; ')).toContain('generic')
    else expect(x.evidence?.mismatch).toContain('the code')
  }
}, 300_000)

t('Rust identity: duplicate record names refuse in either module order', () => {
  const a = 'pub mod a {pub struct Helper {pub bias:u32} impl Helper {pub fn pick(&self)->u32 {11}}}'
  const b = 'pub mod b {pub struct Helper {pub bias:u32} impl Helper {pub fn pick(&self)->u32 {22}}}'
  for (const defs of [a+b, b+a]) {
    const dir = genericCrate(`${defs}
      pub struct Meter {value:u32, helper:a::Helper}
      impl Meter {
        pub fn new()->Self {Self {value:0, helper:a::Helper {bias:0}}}
        pub fn take(&mut self) {self.value=self.helper.pick();}
      }`)
    execFileSync('cargo', ['check', '--quiet'], {cwd:dir, stdio:'pipe'})
    const x = extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'})
    expect(x.ok).toBe(false)
    expect(x.refusals.map(r => r.what).join('; ')).toContain('multiple source record declarations')
    expect(x.evidence?.mismatch).toBeUndefined()
  }
}, 300_000)

t('Rust identity: trait and inherent collisions refuse in either declaration order', () => {
  const inherent = 'impl Helper {pub fn pick(&self)->u32 {11}}'
  const trait = 'trait Alternative {fn pick(&self)->u32;} impl Alternative for Helper {fn pick(&self)->u32 {22}}'
  for (const defs of [inherent+trait, trait+inherent]) {
    const dir = genericCrate(`pub struct Helper {bias:u32} ${defs}
      pub struct Meter {value:u32, helper:Helper}
      impl Meter {
        pub fn new()->Self {Self {value:0, helper:Helper {bias:0}}}
        pub fn take(&mut self) {self.value=self.helper.pick();}
      }`)
    execFileSync('cargo', ['check', '--quiet'], {cwd:dir, stdio:'pipe'})
    const x = extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'})
    expect(x.ok).toBe(false)
    expect(x.refusals.map(r => r.what).join('; ')).toContain('multiple source method candidates')
    expect(x.evidence?.mismatch).toBeUndefined()
  }
}, 300_000)

t('Rust identity: unique methods and unrelated collisions retain native-backed behavior', () => {
  for (const [defs, field, init, expression, expected] of [
    ['pub mod a {pub struct Left {pub bias:u32} impl Left {pub fn pick(&self)->u32 {11}}} pub mod b {pub struct Right {pub bias:u32} impl Right {pub fn pick(&self)->u32 {22}}}', ', helper:a::Left', ', helper:a::Left {bias:0}', 'self.helper.pick()', 11],
    ['pub mod a {pub struct Helper {pub bias:u32}} pub mod b {pub struct Helper {pub bias:u32}}', '', '', '7', 7],
    ['pub struct Helper {bias:u32} trait Alternative {fn pick(&self)->u32;} impl Alternative for Helper {fn pick(&self)->u32 {22}}', ', helper:Helper', ', helper:Helper {bias:0}', 'self.helper.pick()', 22],
    ['pub struct Helper {bias:u32} impl Helper {pub fn pick(&self)->u32 {11}} trait Alternative {fn pick(&self)->u32;} impl Alternative for Helper {fn pick(&self)->u32 {22}}', ', helper:Helper', ', helper:Helper {bias:7}', 'self.helper.bias', 7],
  ] as const) {
    const dir = genericCrate(`${defs}
      pub struct Meter {value:u32 ${field}}
      impl Meter {
        pub fn new()->Self {Self {value:0 ${init}}}
        pub fn take(&mut self) {self.value=${expression};}
      }`)
    const x = ok(extractRust(dir, {entry:'Meter', check:budget, strict:true, failures:'kept'}))
    const r = x.rule!, rt = r.interpreter(), p = r.encodeParams({})
    expect(r.decode(rt.step(p, rt.init(p), r.encodeInput({})))).toMatchObject({value:expected})
  }
}, 300_000)

type X = ReturnType<typeof extractRust>
const ok = (x: X) => {
  if (!x.ok) throw new Error(`refused: ${JSON.stringify(x.refusals)}\n${x.source ?? ''}\n${JSON.stringify(x.evidence)}`)
  expect(x.evidence!.requests).toBeGreaterThan(0)
  return x
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
type A = any
const step = (x: X, name: string, then: (b: A, a: A) => A, when?: (b: A) => A) => proveSteps(x.rule as A, x.invariants ?? [], [(x.rule as A).stepLaw(name, then, when)])

t('integers of a width: + traps past it (the failure), wrapping_add wraps, checked_add is an Option', () => {
  const x = ok(extractRust(DIR, {entry: 'Budget', methods: ['spend', 'lap', 'try_spend', 'mark'], failures: 'kept', check: budget}))
  expect(x.notes.join('\n')).toMatch(/past u8's range \(a panic/)
  expect(proveRule(x.rule!, [...x.invariants!, x.rule!.law('spent within the limit', ({spent, limit}: A) => spent.atMost(limit))]).proven).toBe(true)
  expect(step(x, 'a lap wraps at 256', (b, a) => a.laps.eq(0), b => b.method.is('lap').and(b.laps.eq(255))).proven).toBe(true)
  expect(step(x, 'mark keeps the phase', (b, a) => a.phase.eq(b.mark_p).and(a.phase_none.not()), b => b.method.is('mark')).proven).toBe(true)
}, 120_000)

t('a C-like enum, its discriminant, an Err returned, an atomic counter', () => {
  const x = ok(extractRust(DIR, {entry: 'Job', methods: ['start', 'finish'], failures: 'kept', check: budget}))
  expect(x.source).toContain("phase: oneOf('Idle', 'Running', 'Done')")
  expect(step(x, 'finish only from running', (b, a) => a.failed.not().implies(b.phase.is('Running').and(a.finish_result.eq(2))), b => b.method.is('finish')).proven).toBe(true)
  expect(step(x, 'a start counts one', (b, a) => a.start_result.implies(a.hits.eq(b.hits.plus(1))), b => b.method.is('start').and(b.hits.lt(1000))).proven).toBe(true)
}, 120_000)

t('refusals, each where it is with why', () => {
  const loop = extractRust(DIR, {entry: 'Tally', methods: ['add_all']})
  expect(loop.ok).toBe(false)
  expect(loop.refusals[0]!.what).toMatch(/a loop/)
  const map = extractRust(DIR, {entry: 'Ledger', methods: []})
  expect(map.ok).toBe(false)
}, 120_000)

t('the boundary inferred: other crates\' calls left out or answered (tagged: their types aren\'t read), the entry', () => {
  const dir = mkdtempSync(`${tmpdir()}/gdp-rscase-`)
  mkdirSync(`${dir}/src`)
  writeFileSync(`${dir}/Cargo.toml`, '[package]\nname = "meter"\nversion = "0.1.0"\nedition = "2021"\n\n[lib]\npath = "src/lib.rs"\n')
  writeFileSync(`${dir}/src/lib.rs`, `pub struct Meter { used: u32, cap: u32 }
impl Meter {
    pub fn new(cap: u32) -> Self { Meter { used: 0, cap } }
    pub fn take(&mut self, n: u32) -> bool {
        std::thread::yield_now();
        let extra: u32 = std::process::id(); // gdp: answer u32
        if n > self.cap || extra > self.cap - n || self.used > self.cap - n - extra { return false; }
        self.used += n + extra;
        true
    }
}
`)
  const x = ok(extractRust(dir, {check: budget}))
  const notes = x.notes.join('\n')
  expect(notes).toMatch(/the entry inferred: Meter/)
  expect(notes).toMatch(/std::thread::yield_now .*left out \(inferred/)
  expect(notes).toMatch(/std::process::id .*answered by the request \(tagged/)
  expect(step(x, 'never past its cap', (_b, a) => a.used.atMost(a.cap), b => b.used.atMost(b.cap)).proven).toBe(true)
}, 300_000)

// The check's build (the code with the harness): a compiler failing with nothing to say of the code (killed, past
// GDP_COMPILE_S) is retried once, then the check's harness failure; its errors about the code, the source refused with
// its message. Never "the rule and the code differ".
const killedBuild = <X>(make: () => X): X => { const old = process.env.GDP_COMPILE_S; process.env.GDP_COMPILE_S = '0.001'; try { return make() } finally { if (old === undefined) delete process.env.GDP_COMPILE_S; else process.env.GDP_COMPILE_S = old } }
t('the check\'s build: a crate rustc rejects refused with its message; cargo killed is the harness\'s failure, retried once', () => {
  const crate = (code: string) => { const d = mkdtempSync(`${tmpdir()}/gdp-rscase-`); mkdirSync(`${d}/src`); writeFileSync(`${d}/Cargo.toml`, '[package]\nname = "meter"\nversion = "0.1.0"\nedition = "2021"\n\n[lib]\npath = "src/lib.rs"\n'); writeFileSync(`${d}/src/lib.rs`, code); return d }
  const src = 'pub struct Meter { used: u32 }\nimpl Meter {\n    pub fn new() -> Self { Meter { used: 0 } }\n    pub fn take(&mut self, n: u32) -> bool { if n > 10 { return false; } self.used = self.used.wrapping_add(n); true }\n}\n'
  const bad = extractRust(crate(src.replace('if n > 10', 'let s: u32 = "x"; if n > 10')), {entry: 'Meter', check: {runs: 6, depth: 4, states: 6}})
  expect(bad.refusals[0]!.what).toMatch(/^the source doesn't compile \(cargo\): error\[E0308\]: mismatched types/)
  const killed = killedBuild(() => extractRust(crate(src), {entry: 'Meter', check: {runs: 6, depth: 4, states: 6}}))
  expect(killed.refusals[0]!.what).toMatch(/^the check's harness failed, twice .*cargo failed twice with nothing to say of the code/)
}, 600_000)

// The reader fuzz's crash (treadmill rust seed 675942: a span cut from src/lib.rs): the reader's own error, the source
// not parsing, was read as a module and threw; refused with it, and any front end's reader that gives no module too.
t('a crate that doesn\'t parse: refused with the reader\'s error, never a crash', () => {
  const d = mkdtempSync(`${tmpdir()}/gdp-rscase-`)
  mkdirSync(`${d}/src`)
  writeFileSync(`${d}/Cargo.toml`, '[package]\nname = "meter"\nversion = "0.1.0"\nedition = "2021"\n\n[lib]\npath = "src/lib.rs"\n')
  writeFileSync(`${d}/src/lib.rs`, 'pub struct Meter { used: u32 }\nimpl Meter {\n    pub fn take(&mut self, n: u32) -> bool { if n > 10 { return false; } self.used = \n')
  const x = extractRust(d, {entry: 'Meter'})
  expect(x.ok).toBe(false)
  expect(x.refusals[0]!.what).toMatch(/^the crate doesn't parse: /)
  const y = extractStep({error: 'src/lib.rs: expected an expression'} as never, () => ({cmd: 'false', args: [], hello: {}}), {})
  expect(y.refusals[0]!.what).toMatch(/^the reader read nothing: src\/lib.rs: expected an expression/)
}, 120_000)
