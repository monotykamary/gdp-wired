// Rules read from the code that ships (`gdp-wired/extract`): `extract(code, {entry})` reads a TypeScript or JavaScript
// step function (a reducer `(state, action) => state`, `useReducer`'s, functions over one record), a class whose
// methods write its fields (a rate limiter's `tryRemove(n)`, a wallet's `debit(x)`), with the classes it extends, or
// the object of functions a factory returns (its state what they close over), and returns the rule that steps the
// same way, as a builder value and as the source that makes it (`toSource`), for a user to read and keep:
//
//   const x = extract('./bucket.ts')        // a path or a URL; the entry inferred (or {entry: 'TokenBucket'})
//   if (!x.ok) console.log(x.refusals)     // where and why
//   proveRule(x.rule!, [x.rule!.law('within capacity', ({tokens, capacity}) => tokens.atMost(capacity))])
//   writeFileSync('bucket.rule.ts', toSource(x))
//
// Code in memory is read as {code, file}; the code-first form, extract(code, {file, entry}), stays.
// The extractor is untrusted. The rule is checked against the original code by running both (core/extract-check.ts):
// requests from the start, steps from drawn states, and steps from the prover's counterexamples, every state, map cell,
// list, result and refusal compared, and the code's branches counted. Any difference refuses the extraction with the
// difference; nothing is adopted that the check didn't run. What the subset doesn't read is refused where it is, with
// the reason, never approximated. XState machines go through `fromXState` (core/xstate.ts), their guards and actions
// read the same way (`extractXState`, a machine or a function that makes one, its actors, timers and eventless
// transitions included).
//
// The subset: numbers (integers: a literal that isn't one is refused; division only as Math.floor, ceil or trunc of
// x / k for a constant k, a fraction being a binary float the code rounds; % by a constant of a natural), booleans,
// string-literal unions, strings (set, compared, truthy where not empty), null and undefined where a value may be
// missing, records and nested records (spreads, shorthand), Map and Record state keyed by numbers or strings (get,
// set, has, delete, [k], ?? a default; a Map given to a constructor starts empty), arrays of numbers, booleans and
// string unions as lists (length, [i], push, pop, [i] = x within the array, [...xs], [...xs, x]), Dates as their time
// (new Date(), getTime(), setTime() where the Date is held), conditionals, ternaries, && || ?? (their right side's
// effects on its own path), early returns, switch on a tag (fall-through, default), Math.min, Math.max, Math.abs,
// Boolean(x), Date.now() (an input; once a step), throws (the rule's refusals: its assumption, or its precondition
// for a constructor), helper functions and methods of the same files (inlined), getters, single inheritance (each
// member resolved statically: this.m() the nearest the object has, super.m() the nearest above the class it is in),
// mixins of the same files (`(B) => class extends B {...}`, its class between the entry and the class it is given),
// a field holding a function (an injected clock, random or id source: each call's answer an input, one a step, for
// every such function that leaves the object alone), results kept (a value, a record of values, a value that may be
// missing). Refused: loops, strings beyond keys and
// literals, floats, async, try/catch, writes to the state a reducer is given, a throw after a method wrote a field, two
// keys of one map or two writes of one list in one step, a map or a list replaced whole, a reference into a map held
// across a set, one object (an array, a Map, a Date) in two places, aliasing that depends on the path, mixins of other
// modules, other modules' code.
import * as dsl from './dsl.ts'
import {compileFunction, walk} from './machine.ts'
import type {Rule} from './dsl.ts'
import type {Law} from './machine.ts'
import * as I from './extract-ir.ts'
import {type B, type K, type N, PASS} from './extract-ir.ts'
import {type Arg, type Layout, type MapDecl, type MapWrite, type Model, Refusal, type Source, type Term, type Var, placed, sourceOf, syntaxError, tooDeep} from './extract-read.ts'
import {type ReadOptions, isFactory, isSlice, readClass, readFactory, readFunctions, readSlice, readStandalone} from './extract-shapes.ts'
import {type Ctx, type Printer, type Sorts, kindOf, mapEmpty, mapKind, natOK, pb, pidx, pk, pnum, pterm, sortsOf} from './extract-print.ts'
import {type CheckOptions, type Evidence, check} from './extract-check.ts'
import {extractOrm, type OrmOptions} from './extract-orm.ts'
export type {OrmOptions} from './extract-orm.ts'
// (a rule read is proven from the same import: proveRule(x.rule!, [x.rule!.law(...)]))
export {proveRule, proveSteps} from './dsl.ts'

export type ExtractOptions = Omit<ReadOptions, 'entry' | 'functions'> & {
  // The class, reducer, slice or factory read (by default the one the file's exports have that reads), or several
  // functions over one record, each a request.
  entry?: string | string[],
  /** @deprecated entry: [...] (the same: several functions over one record, the entry the first) */
  functions?: string[],
  // The file's name, for code given as a string (for locations, and to read it as JavaScript when it ends in .js).
  file?: string,
  // Explicit injected ORM boundary; schema is relative to the handler's file.
  orm?: OrmOptions,
  // 'class' or 'functions' (a reducer is functions of one); by default, a class if the entry names one.
  shape?: 'class' | 'functions',
  // Explicit opt-in: one closed, pure scalar function (not a state reducer).
  // Safe integers only; numeric literal unions restrict its request domain.
  mode?: 'standalone',
  // Numbers given as naturals or integers (by the rule's variable name, or `map.field` for a map's numbers).
  domains?: Record<string, 'nat' | 'int'>,
  // The check's budget (runs, depth, states, probes, seed).
  check?: CheckOptions,
}
export type Extraction = {
  ok: boolean,
  // All initializers of the selected class. A single extraction remains refused until one is selected;
  // the CLI may check every selector separately, never choosing an arbitrary constructor.
  initializers?: {entry: string, name: string, selectors: string[]},
  // (a state variable that is 0 where the state is between two of the code's calls: a law about the state is about
  // those states; Solidity's pending calls into other code)
  quiet?: string,
  // (a run that breaks a law, replayed on the code: a front end whose rule has runs the code may not, Solidity's at a
  // narrower width; ok false where the code doesn't run it so)
  replay?: (run: {params: Record<string, number>, trace: Record<string, unknown>[]}, law?: unknown) => {ok: boolean, what: string},
  // The rule (when ok), and its source, also printed when the check refused it (to read why).
  rule?: Rule,
  // What every state of the code is in the rule's terms (a map's key the code doesn't hold holds the defaults): the
  // rule has states no object of the code is in, and a law about every state is about the code's with these beside it
  // (proveRule(rule, [...invariants, law])). Each is inductive: proveRule(rule, invariants) proves them.
  invariants?: Law[],
  source?: string,
  model?: Model,
  sorts?: Sorts,
  refusals: {where: string, what: string}[],
  evidence?: Evidence,
  // How the code's values sit in the rule, what each number's sort is and why, what was left out.
  notes: string[],
  // Where each of the rule's variables is in the code (core/laws.ts reads laws written in the code's names through it).
  names?: Name[],
  // (core/effect.ts) The schedule an entry is, read into its rule; the policies a service's methods retry or repeat
  // with, each read into its own; the methods read as several steps of each fiber (their steps, where each fiber's
  // place numbers them from).
  schedule?: unknown, schedules?: unknown[], fibers?: {name: string, steps: number, base: number}[],
  // The module's constants bound to literals (a law reads them as the code does: `n <= LIMIT`).
  consts?: Record<string, number | string | boolean>,
}
// A variable of the rule by the code's own path to it: a field (`cfg.limit`), a constructor's or a request's argument
// (`team_object.max_budget`, an object's field the caller gives), a call of other code answered by the request (its
// qualified name), a method's result, whether the step failed. `none`: the rule's flag for the code's value being
// None, nil or null; `map`: a map's cell fields (`value` for a map of scalars) and, for a store, its key's template.
export type Name = {code: string, rule: string, role: 'state' | 'param' | 'input' | 'answer' | 'result' | 'failed' | 'method' | 'clock' | 'const',
  method?: string, none?: string, value?: number, map?: {fields: string[], store?: string, tpl?: string, ordered?: boolean}}
// The names of a model read from TypeScript (the state's layout, each request's arguments, each method's result).
export function namesOf(m: Model): Name[] {
  const out: Name[] = [], fields = (n: string) => m.maps.find(d => d.name === n)?.fields.map(f => f.name) ?? []
  const lay = (l: Layout, at: string) => {
    if (l.k === 'scalar') out.push({code: at, rule: l.name, role: 'state'})
    else if (l.k === 'map') out.push({code: at, rule: l.name, role: 'state', map: {fields: fields(l.name)}})
    else if (l.k === 'const') { const e = l.value.e as N; if (e.op === 'var') out.push({code: at, rule: e.name, role: 'param'}); else if (e.op === 'const') out.push({code: at, rule: '', role: 'const', value: e.v}) }
    else if (l.k === 'rec') for (const [f, x] of l.fields) if (!f.endsWith('()')) lay(x, at ? `${at}.${f}` : f)
  }
  lay(m.layout, '')
  const arg = (a: Arg, at: string, method: string) => {
    if (a.k === 'input') out.push({code: at, rule: a.name, role: 'input', method})
    else if (a.k === 'maybe-bool') out.push({code: at, rule: a.name, none: a.missing, role: 'input', method})
    else if (a.k === 'rec') for (const [f, x] of a.fields) arg(x, `${at}.${f}`, method)
  }
  for (const e of m.events) e.args.forEach((a, i) => { const n = e.names?.[i]; if (n) arg(a, n, e.call) })
  for (const [method, r] of Object.entries(m.results ?? {})) {
    if (r.k === 'scalar') out.push({code: 'result', rule: r.name, role: 'result', method})
    else if (r.k === 'maybe') out.push({code: 'result', rule: r.name, role: 'result', method, none: r.missing})
    else for (const [f, n] of r.fields) out.push(f === 'failed' ? {code: 'failed', rule: n, role: 'failed'} : {code: f === 'value' ? 'result' : `result.${f}`, rule: n, role: 'result', method})
  }
  if (m.event) out.push({code: 'method', rule: m.event, role: 'method'})
  return out
}

export function extract(at: Source, opts: ExtractOptions = {}): Extraction {
  const notes: string[] = []
  let model: Model, code: string, file: string
  try {
    ;({code, file} = sourceOf(at, opts.file, 'input.ts'))
    if (opts.mode !== undefined && opts.mode !== 'standalone') throw new Refusal(file, `unsupported extraction mode: ${String(opts.mode)}`)
    const bad = syntaxError(code, file)
    if (bad) throw new Refusal(file, bad)
    if (opts.orm) {
      if (opts.mode === 'standalone') throw new Refusal(file, 'standalone mode cannot use ORM')
      if (typeof at !== 'string' || at.includes('\n') || !/\.[cm]?[jt]sx?$/.test(at)) throw new Refusal(file, 'ORM checking requires the original module on disk')
      return extractOrm(file, code, {...opts, orm: opts.orm})
    }
    const fns = Array.isArray(opts.entry) ? opts.entry : opts.functions
    const o: ReadOptions = {...opts, entry: (Array.isArray(opts.entry) ? opts.entry[0] : opts.entry) ?? fns?.[0] ?? '', ...(fns ? {functions: fns} : {})}
    if (opts.mode === 'standalone') {
      if (!o.entry || Array.isArray(opts.entry) || opts.functions || opts.shape || opts.orm) throw new Refusal(file, 'standalone mode needs exactly one named function and no other shape')
      model = readStandalone(code, placed(file), o)
    } else model = o.entry ? readModel(code, file, o, opts.shape) : inferred(code, file, o, opts.shape)
    model.file = file
  } catch (e) {
    if (e instanceof Refusal) return {ok: false, refusals: [{where: e.where, what: e.what}], notes}
    if (tooDeep(e)) return {ok: false, refusals: [{where: opts.file ?? (typeof at === 'string' && !at.includes('\n') ? at : 'input.ts'), what: 'the source nests too deeply to read'}], notes}
    throw e
  }
  if (model.standalone && Object.entries(model.standaloneDomains ?? {}).some(([n, xs]) => opts.domains?.[n] === 'nat' && xs.some(x => x < 0)))
    return {ok: false, refusals: [{where: file, what: 'standalone: a natural domain contradicts the declared negative numeric literals'}], notes, model}
  return {...fromModel(model, file, opts.domains, notes, (rule, sorts) => check(code, file, model, rule, sorts, {...opts.check, ...(opts.files ? {files: opts.files} : {}), ...(opts.domains ? {given: opts.domains} : {})})), names: namesOf(model)}
}
function readModel(code: string, file: string, opts: ReadOptions, shape?: 'class' | 'functions'): Model {
  const isClass = shape ? shape === 'class' : new RegExp(`\\bclass\\s+${opts.entry}\\b|\\b${opts.entry}\\s*=\\s*class\\b`).test(code), at = placed(file)
  return isClass ? readClass(code, at, opts) : isSlice(code, opts.entry) ? readSlice(code, at, opts) : isFactory(code, file, opts.entry) ? readFactory(code, at, opts) : readFunctions(code, at, opts)
}
// No entry named: each exported class and function tried, the one that reads taken.
function inferred(code: string, file: string, opts: ReadOptions, shape?: 'class' | 'functions'): Model {
  const names = [...new Set([...code.matchAll(/export\s+(?:default\s+)?(?:abstract\s+)?class\s+(\w+)|export\s+(?:const|function)\s+(\w+)/g)].map(m => (m[1] ?? m[2])!))]
  const read: Model[] = [], why: Refusal[] = []
  for (const entry of names) { try { read.push(readModel(code, file, {...opts, entry}, shape)) } catch (e) { if (e instanceof Refusal) why.push(e); else throw e } }
  if (read.length > 1) throw new Refusal(file, `several rules in the file (${read.map(m => m.entry).join(', ')}): name one (entry)`)
  if (!read.length) throw names.length === 1 ? why[0]! : new Refusal(file, names.length ? `no exported class or function reads as a rule (${why.map(r => `${r.where}: ${r.what}`).join('; ')}): name the entry` : 'no exported class or function: name the entry')
  read[0]!.notes.unshift(`the entry inferred: ${read[0]!.entry}, the one of the file's exports that reads as a rule`)
  return read[0]!
}
// A model read by a front end (this file's TypeScript, or core/extract-go.ts's Go) printed as the rule, built, and
// checked against the code by the front end's own check: what both front ends share.
export function fromModel(model: Model, file: string, domains: Record<string, 'nat' | 'int'> | undefined, notes: string[], run: (rule: Rule, sorts: Sorts) => Evidence): Extraction {
  let source: string, body: string, sorts: Sorts
  try {
    const s = sortsOf(model, domains)
    sorts = s.sorts
    datesInRange(model, sorts)
    notes.push(...model.notes, ...s.notes)
    body = builderOf(model, sorts)
    source = moduleOf(model, body, file)
  } catch (e) {
    if (e instanceof Refusal) return {ok: false, refusals: [{where: e.where, what: e.what}], notes, model}
    throw e
  }
  let rule: Rule, invariants: Law[]
  try { rule = evaluate(body); invariants = evaluateLaws(rule, invariantsOf(model, sorts)) } catch (e) { return {ok: false, source, model, sorts, refusals: [{where: file, what: `the rule printed doesn't build: ${(e as Error).message}`}], notes} }
  if (invariants.length) source = `${source}\n// What every state of the code is: a law about every state is about the code's with these beside it.\nexport const ${identOf(model)}Invariants = [${invariantsOf(model, sorts).map(x => x.replace(/^r\./, `${identOf(model)}Rule.`)).join(', ')}]\n`
  const evidence = run(rule, sorts)
  if (evidence.source) return {ok: false, source, model, sorts, evidence, refusals: [{where: file, what: evidence.source}], notes}
  if (evidence.harness) return {ok: false, source, model, sorts, evidence, refusals: [{where: file, what: `${HARNESS_FAILED}${evidence.harness}`}], notes}
  if (evidence.mismatch) return {ok: false, source, model, sorts, evidence, refusals: [{where: file, what: `the rule and the code differ: ${evidence.mismatch}`}], notes}
  return {ok: true, rule, ...(invariants.length ? {invariants} : {}), source, model, sorts, evidence, refusals: [], notes}
}
// The check's own failure (twice): no verdict on the code, neither a difference nor a pass.
export const HARNESS_FAILED = 'the check\'s harness failed, twice (a request past its time or its transport, not the code): '
// A Date holds a time within ±8.64e15 ms; past it the code's Date is invalid (NaN). The rule refuses a step that would
// set one there (as it refuses a sum past 2^53), and a start there: its claim stops at the Date's range.
const DATE_MAX = 8_640_000_000_000_000
function datesInRange(m: Model, sorts: Sorts) {
  const out = (e: N, at: string) => (sorts.get(at) === 'nat' ? I.cmp('<', I.num(DATE_MAX), e) : I.or(I.cmp('<', I.num(DATE_MAX), e), I.cmp('<', e, I.num(-DATE_MAX))))
  const dated = m.state.filter(v => v.sort.k === 'num' && v.sort.date)
  const over: B[] = []
  for (const v of dated) { const w = m.writes[v.name]; if (w?.s === 'num') over.push(out(w.e, v.name)) }
  for (const d of m.maps) for (const f of d.fields) if (f.sort.k === 'num' && f.sort.date) { const w = m.mapWrites[d.name]; const t = w?.vals[f.name]; if (t?.s === 'num') over.push(I.and(w!.has, out(t.e, `${d.name}.${f.name}`))) }
  if (over.length) m.refuse = I.or(m.refuse, ...over)
  const starts = dated.filter(v => m.init[v.name]?.s === 'num').map(v => I.not(out((m.init[v.name] as Term & {s: 'num'}).e, v.name)))
  if (starts.length) m.pre = I.and(m.pre, ...starts)
  if (over.length || starts.length) m.notes.push('a Date holds a time within ±8.64e15 ms: a step that would set one past it is refused (the code\'s Date would be invalid)')
}
// The module a user keeps: the rule, with what it was read from and how it was checked.
export const toSource = (x: Extraction): string => x.source ?? ''

// The source is the rule: it is evaluated with the builders, so what is checked is what is printed.
const NAMES = ['rule', 'nat', 'int', 'bool', 'oneOf', 'str', 'record', 'when', 'min', 'max', 'all', 'any', 'not', 'yes', 'no', 'lit', 'intern', 'Int', 'desc', 'everyKey'] as const
function evaluate(body: string): Rule {
  const f = compileFunction<(...xs: unknown[]) => Rule>([...NAMES], `return ${body}`)
  const r = f(...NAMES.map(n => (dsl as Record<string, unknown>)[n]))
  void r.machine
  return r
}
// A map's representation: each key it doesn't hold holds the defaults (as no object of the code holds a value there).
function invariantsOf(m: Model, sorts: Sorts): string[] {
  const empty = (d: MapDecl, f: Var) => (f.sort.k === 'num' ? `.eq(0)` : f.sort.k === 'bool' ? `.not()` : f.sort.k === 'choice' ? `.is(${JSON.stringify(f.sort.values[0])})` : `.eq('')`)
  // (a signed field the printer reads as a natural keeps its range's top: a natural is at least 0 already)
  const nat = (l: string) => { const r = /^r\.law\(("\w+ within its type's range"), \(\{(\w+)\}\) => \2\.atMost\((\d+)\)\.and\(\2\.atLeast\(-\d+\)\)\)$/.exec(l); return r && sorts.get(r[2]!) === 'nat' ? `r.law(${r[1]}, ({${r[2]}}) => ${r[2]}.atMost(${r[3]}))` : l }
  return [...(m.laws ?? []).map(nat), ...m.maps.filter(d => d.fields.length && !d.ordered).map(d => `r.law(${JSON.stringify(`${d.name}: a key it doesn't hold holds the defaults`)}, ({${d.name}}) => forall(k => any(${d.name}.at(k).has, all(${d.fields.map(f => `${d.name}.at(k).${f.name}${empty(d, f)}`).join(', ')}))))`),
    ...(m.lists ?? []).map(d => `r.law(${JSON.stringify(`${d.name}: nothing past its end`)}, ({${d.name}}) => ${d.name}.within())`),
    ...(m.lists ?? []).filter(d => d.len !== undefined).map(d => `r.law(${JSON.stringify(`${d.name}: ${d.len} items, always`)}, ({${d.name}_len}) => ${d.name}_len.eq(${d.len}))`)]
}
function evaluateLaws(r: Rule, xs: string[]): Law[] {
  if (!xs.length) return []
  const f = compileFunction<(...xs: unknown[]) => Law[]>(['r', 'forall', 'any', 'all'], `return [${xs.join(', ')}]`)
  return f(r, dsl.forall, dsl.any, dsl.all)
}
const identOf = (m: Model) => (/^[A-Za-z_$][\w$]*$/.test(m.name) ? m.name.charAt(0).toLowerCase() + m.name.slice(1) : 'extracted')
function moduleOf(m: Model, body: string, file: string): string {
  const used = NAMES.filter(n => new RegExp(`(^|[^.\\w$])${n}\\(|(^|[^.\\w$])${n}\\b(?!\\s*:)`).test(body.replace(/'[^']*'/g, "''")) || (n === 'rule'))
  const ident = identOf(m)
  return [
    `// Extracted by gdp-wired/extract from ${file} (${m.entry}, ${m.kind ?? (m.factory?.calls ? 'an Effect service' : m.factory ? 'a factory of an object of functions' : m.shape === 'class' ? (/\.go$/.test(file) ? 'a struct and its methods' : 'a class') : m.shape === 'reducer' ? 'a step function' : 'functions over one record')}).`,
    `// Checked against the code it was read from; read again with extract() after the code changes.`,
    `import {${[...new Set([...used, ...(m.maps.length ? ['all', 'any', 'forall'] : []), ...['all', 'any', 'forall'].filter(n => (m.laws ?? []).some(l => l.includes(`${n}(`)))])].sort((a, b) => a.localeCompare(b)).join(', ')}} from 'gdp-wired'`,
    '',
    `export const ${ident}Rule = ${body}`,
    '',
  ].join('\n')
}

// --- the builder calls ----------------------------------------------------------------------------------------------
function builderOf(m: Model, sorts: Sorts): string {
  const P: Printer = {sorts, m, hoisted: new Map(), choiceVars: new Map()}
  for (const v of [...m.state, ...m.inputs, ...m.params]) if (v.sort.k === 'choice' && !P.choiceVars.has(v.sort.values.join('\u0000'))) P.choiceVars.set(v.sort.values.join('\u0000'), v.name)
  // (a choice only a map's records hold: named through a cell of the map, its value unread, `m.at(0).f.of('x')`)
  for (const d of m.maps) for (const f of d.fields) if (f.sort.k === 'choice' && !P.choiceVars.has(f.sort.values.join('\u0000'))) P.choiceVars.set(f.sort.values.join('\u0000'), `${d.name}.at(${d.key === 'str' ? "intern('')" : '0'}).${f.name}`)
  const ctx = (): Ctx => ({m, sorts, atoms: []})
  const lines = [`rule(${JSON.stringify(m.name)})`]
  const kinds = (vs: Var[]) => vs.map(v => `${v.name}: ${kindOf(v, sorts)}`).join(', ')
  if (m.params.length) lines.push(`  .params({${kinds(m.params)}})`)
  if (m.inputs.length) lines.push(`  .inputs({${kinds(m.inputs)}})`)
  // The state: each variable from its start (a term over the params where the constructor makes it one).
  const params = (t: object) => [...I.varsOf(t as N).vars].filter(n => m.params.some(p => p.name === n))
  const start = (v: Var) => {
    const t = m.init[v.name]!, ps = params(t.e), fn = (x: string) => (ps.length ? `({${ps.join(', ')}}) => ${x}` : x)
    // The kernel's start expressions read parameters only, not functions (including div/mod).
    // A narrowing cast can introduce one even when the source spells no division.
    walk(t.e, o => { if (o.op === 'divk' || o.op === 'modk') throw new Refusal(m.file ?? m.entry, `${v.name}: division or remainder in an initializer (including a wrapping conversion) is outside the reader's start-expression subset`) })
    const at = pterm(t, P, ctx(), v.name)
    if (v.sort.k === 'num') return sorts.get(v.name) === 'nat' ? (ps.length ? fn(at) : at) : `int.from(${ps.length ? fn(at) : at})`
    if (v.sort.k === 'bool') return `bool.from(${ps.length ? fn(at) : at === 'yes' ? 'true' : at === 'no' ? 'false' : at})`
    if (v.sort.k === 'str') return `str().from(${ps.length ? fn(at) : at})`
    return `${kindOf(v, sorts)}.from(${ps.length ? fn(at) : at})`
  }
  if (m.state.length) lines.push(`  .state({${m.state.map(v => `${v.name}: ${start(v)}`).join(', ')}})`)
  if (m.maps.length) lines.push(`  .maps({${m.maps.map((d: MapDecl) => `${d.name}: ${mapKind(d, sorts)}.from(${mapEmpty(d)})`).join(', ')}})`)
  if (m.lists?.length) lines.push(`  .items({${m.lists.map(d => `${d.name}: ${kindOf(d.fields[0]!, sorts, `${d.name}.$item`)}`).join(', ')}}${m.lists.some(d => d.len !== undefined) ? `, {${m.lists.filter(d => d.len !== undefined).map(d => `${d.name}: ${d.len}`).join(', ')}}` : ''})`)
  // (a least key's two names are its one Maybe; the key its order is read at is bound by its own function)
  const leastOf = (n: string) => m.leasts?.find(l => l.some === n)?.name ?? n
  const envOf = (...xs: object[]) => {
    const vars = new Set<string>(), maps = new Set<string>()
    for (const x of xs) I.varsOf(x as N, vars, maps)
    return `{${[...new Set([...vars].filter(n => !m.leasts?.some(l => l.key === n)).map(leastOf)), ...maps].filter(n => n !== PASS && n !== 'kl$' && n !== 'k$' && n !== 'j$').join(', ')}}`
  }
  // The least keys: each where it holds, by what, read at the state before the step.
  if (m.leasts?.length) {
    const c = ctx()
    lines.push(`  .least({${m.leasts.map(l => `${l.name}: (${envOf(l.where, ...l.by.map(b => b.e))}) => ({where: ${l.key} => ${pb(l.where, P, c)}, by: ${l.key} => [${l.by.map(b => (b.desc ? `desc(${pnum(b.e, P, c)})` : pnum(b.e, P, c))).join(', ')}]})`).join(', ')}})`)
  }
  // The lists a request carries, the folds' running values, and what every request is assumed to carry in them: each
  // fold's start at 0 and its step at every pass below the list's length (printed over the pass, i$).
  const rec = (name: string, fs: Var[]) => `record({${fs.map(f => `${f.name}: ${kindOf(f, sorts, `${name}.${f.name}`)}`).join(', ')}})`
  for (const q of [...(m.seqs ?? []), ...(m.folds ?? []).map(d => ({name: d.run, fields: d.fields}))]) lines.push(`  .carriesList(${JSON.stringify(q.name)}, ${rec(q.name, q.fields)})`)
  // (a while loop's lists taken by an order: each one's held keys in it, and each key's place there)
  for (const g of (m.folds ?? []).flatMap(d => d.loop?.drains ?? [])) lines.push(`  .carriesList(${JSON.stringify(g.ord)}, record({k: nat}))`, `  .carries(${JSON.stringify(g.rk)})`)
  for (const d of m.folds ?? []) {
    const cell = (i: N, f: Var) => ({op: 'cell', map: d.run, key: {op: 'num', e: i}, field: f.name, ...(f.sort.k === 'choice' ? {values: f.sort.values} : {})}) as never
    const eq = (i: N, f: Var, t: Term): B => (t.s === 'num' ? I.cmp('=', cell(i, f), t.e) : t.s === 'bool' ? I.and(I.or(I.not(cell(i, f)), t.e), I.or(cell(i, f), I.not(t.e))) : t.s === 'str' ? I.keq(cell(i, f), t.e) : I.leq(cell(i, f), t.e as I.L))
    const start = I.and(...d.fields.filter(f => d.init[f.name]).map(f => eq(I.num(0), f, d.init[f.name]!))), step = I.and(...d.fields.filter(f => d.step[f.name]).map(f => eq(I.add(I.nvar(PASS), I.num(1)), f, d.step[f.name]!)))
    if (d.loop?.cond && d.loop.drains) {
      // A while loop's over lists by an order: its passes, each where its condition holds and none ended the loop, then
      // the first where not; each list's held keys in the order (increasing, each held, every held one at its place,
      // tying it), and no two that tie where the loop runs.
      const l = d.loop, cond = l.cond!, len = d.len, endC = I.substN(cond, PASS, len)
      const text = `all(${d.run}_len.eq(${pnum(I.add(len, I.num(1)), P, ctx())}), ${pb(start, P, ctx())}, ${d.run}.every((_x, ${PASS}) => ${PASS}.lt(${pnum(len, P, ctx())}).implies(${pb(I.and(step, cond), P, ctx())})), ${pb(I.not(endC), P, ctx())})`
      const env = envOf(start, step, cond, endC).slice(1, -1).split(', ').filter(Boolean)
      lines.push(`  .assume((${withChoices(`{${[...new Set([...env, d.run, `${d.run}_len`])].join(', ')}}`, text, P)}) => ${text})`)
      for (const g of l.drains!) {
        const ordAt = (x: N): N => ({op: 'cell', map: g.ord, key: {op: 'num', e: x}, field: 'k'}), byAt = (x: N) => g.by.map(b => ({...b, e: I.substN(b.e, 'kl$', x)}))
        const lt = (a: {e: N, desc?: boolean}[], b: {e: N, desc?: boolean}[]): B => a.reduceRight<B>((acc, x, j) => { const y = b[j]!; return I.or(x.desc ? I.cmp('<', y.e, x.e) : I.cmp('<', x.e, y.e), I.and(I.cmp('=', x.e, y.e), acc)) }, I.F)
        const same = (a: {e: N}[], b: {e: N}[]): B => I.and(...a.map((x, j) => I.cmp('=', x.e, b[j]!.e)))
        const iv = I.nvar('i$'), jv = I.nvar('j$'), kv = I.nvar('kl$'), cnt = I.nvar(`${g.ord}_len`), place: N = {op: 'cell', map: g.rk, key: {op: 'num', e: kv}, field: '$item'}
        const heldAt = (x: N) => I.substN(g.held, 'kl$', x)
        const inc = I.or(I.not(I.and(I.cmp('<', iv, jv), I.cmp('<', jv, cnt))), lt(byAt(ordAt(iv)), byAt(ordAt(jv))))
        const held = I.or(I.not(I.cmp('<', iv, cnt)), heldAt(ordAt(iv)))
        const all = I.or(I.not(g.held), I.and(I.cmp('<', place, cnt), same(byAt(ordAt(place)), g.by)))
        sorts.set('j$', 'nat')
        // (two held keys at one place are one: with the list increasing, every held key is at the place of its own, and
        // two items that tie under the order have no list, so the rule refuses there, an edge the check counts apart)
        const rkAt = (x: N): N => ({op: 'cell', map: g.rk, key: {op: 'num', e: x}, field: '$item'})
        const one = I.or(I.not(I.and(g.held, heldAt(jv), I.cmp('=', rkAt(kv), rkAt(jv)))), I.cmp('=', kv, jv))
        // (all of it only where the loop runs: the request its method's, on its branch)
        const gate = l.entry && !(l.entry.op === 'const' && l.entry.v) ? l.entry : undefined
        for (const [vs, c] of [['i$, j$', inc], ['i$', held], ['kl$', all], ['kl$, j$', one]] as const) {
          const t0 = `everyKey((${vs}) => ${pb(c, P, ctx())})`, t = gate ? `any(${pb(I.not(gate), P, ctx())}, ${t0})` : t0
          const e = envOf(c, ...(gate ? [gate] : [])).slice(1, -1).split(', ').filter(n => Boolean(n) && n !== 'j$')
          lines.push(`  .assume((${withChoices(`{${[...new Set([...e, g.ord, `${g.ord}_len`])].join(', ')}}`, t, P)}) => ${t})`)
        }
      }
      continue
    }
    if (d.back) {
      // (from the last place down: the start at the length, each pass's output at its own place)
      const step2 = I.and(...d.fields.filter(f => d.step[f.name]).map(f => eq(I.nvar(PASS), f, d.step[f.name]!))), start2 = I.and(...d.fields.filter(f => d.init[f.name]).map(f => eq(d.len, f, d.init[f.name]!)))
      const text = `all(${d.run}_len.eq(${pnum(I.add(d.len, I.num(1)), P, ctx())}), ${pb(start2, P, ctx())}, ${d.run}.every((_x, ${PASS}) => ${PASS}.lt(${pnum(d.len, P, ctx())}).implies(${pb(step2, P, ctx())})))`
      const env = envOf(start2, step2, d.len).slice(1, -1).split(', ').filter(Boolean)
      lines.push(`  .assume((${withChoices(`{${[...new Set([...env, d.run, `${d.run}_len`])].join(', ')}}`, text, P)}) => ${text})`)
      continue
    }
    // (the passes over the run's places: one past the list's length, a carried list's or one of the state's)
    const len = I.add(d.len, I.num(1)), text = `all(${d.run}_len.eq(${pnum(len, P, ctx())}), ${pb(start, P, ctx())}, ${d.run}.every((_x, ${PASS}) => ${PASS}.lt(${pnum(d.len, P, ctx())}).implies(${pb(step, P, ctx())})))`
    const env = envOf(start, step, d.len).slice(1, -1).split(', ').filter(Boolean)
    lines.push(`  .assume((${withChoices(`{${[...new Set([...env, d.run, `${d.run}_len`])].join(', ')}}`, text, P)}) => ${text})`)
  }
  if (!(m.pre.op === 'const' && m.pre.v)) lines.push(`  .pre((${envOf(m.pre)}) => ${pb(m.pre, P, ctx())})`)
  const allowed = I.not(m.refuse)
  if (!(allowed.op === 'const' && allowed.v)) {
    // The choices a printed literal is named by are read in the callback too.
    const text = pb(allowed, P, ctx())
    lines.push(`  .assume((${withChoices(envOf(allowed), text, P)}) => ${text})`)
  }
  // The step: a const for each term written more than once (by the code's own local's name where it has one).
  const outs: [string, string][] = []
  const writes = Object.entries(m.writes), mw = Object.entries(m.mapWrites)
  const allW = (w: MapWrite) => [...(w.pre ?? []), w]
  hoist(m, P, [...writes.map(([, t]) => t.e), ...mw.flatMap(([, w0]) => allW(w0).flatMap(w => [w.has, ...Object.values(w.vals).map(t => t.e), w.key, ...(w.when ? [w.when] : [])]))])
  const consts = [...P.hoisted.entries()]
  P.hoisted = new Map()
  const defs: string[] = []
  for (const [key, name] of consts) {
    const node = hoistNodes.get(key)!
    defs.push(`const ${name} = ${'rel' in node || isBool(node, m) ? pb(node as B, P, ctx()) : pterm({s: 'num', e: node as N}, P, ctx())}`)
    P.hoisted.set(key, name)
  }
  for (const [n, t] of writes) outs.push([n, pterm(t, P, ctx(), n)])
  for (const [n, w] of mw) {
    const d = m.maps.find(x => x.name === n)!
    if (w.pre) {
      // Several keys written: every key at once, each cell the last write at it (k$, the key, a natural).
      const k: K = {op: 'num', e: I.nvar('k$')}, ws = allW(w)
      sorts.set('k$', 'nat')
      const at = (x: MapWrite) => I.and(x.when ?? I.T, x.each ? I.T : I.keq(k, x.key))
      const has = ws.reduce<B>((acc, x) => I.bite(at(x), x.has, acc), {op: 'cell', map: n, key: k, field: 'has'})
      const vals = d.fields.map(f => {
        const base: Term = f.sort.k === 'num' ? {s: 'num', e: {op: 'cell', map: n, key: k, field: f.name}} : f.sort.k === 'choice' ? {s: 'choice', e: {op: 'cell', map: n, key: k, field: f.name, values: f.sort.values}} : {s: 'bool', e: {op: 'cell', map: n, key: k, field: f.name}}
        const t = ws.reduce<Term>((acc, x) => { const c = at(x), v = x.vals[f.name]!; return acc.s === 'num' && v.s === 'num' ? {s: 'num', e: I.nite(c, v.e, acc.e)} : acc.s === 'bool' && v.s === 'bool' ? {s: 'bool', e: I.bite(c, v.e, acc.e)} : acc.s === 'choice' && v.s === 'choice' ? {s: 'choice', e: I.lite(c, v.e, acc.e)} : acc }, base)
        return `${f.name}: ${pterm(t, P, ctx(), `${n}.${f.name}`)}`
      })
      outs.push([n, `${n}.each(k$ => ({${[`has: ${pb(has, P, ctx())}`, ...vals].join(', ')}}))`])
      sorts.delete('k$')
      continue
    }
    // (a field printed where the key is held; where that reading differs from the term itself, by cases, so a key the
    // step leaves unheld holds what it writes there: a delete's defaults)
    const vals = d.fields.map(f => {
      const t = w.vals[f.name]!, at = `${n}.${f.name}`, yes = pterm(t, P, {m, sorts, atoms: [w.has]}, at)
      if (w.has.op === 'const' || yes === pterm(t, P, ctx(), at)) return `${f.name}: ${yes}`
      let no: string
      try { no = pterm(t, P, {m, sorts, atoms: [I.not(w.has)]}, at) } catch { return `${f.name}: ${pterm(t, P, ctx(), at)}` }
      return `${f.name}: when(${pb(w.has, P, ctx())}, ${yes}, ${no})`
    })
    outs.push([n, `${n}.set(${pk(w.key, P, ctx())}, {${[`has: ${pb(w.has, P, ctx())}`, ...vals].join(', ')}})`])
  }
  // A list's write: its apply over the operations by cases (each under its condition).
  const lw = Object.entries(m.listWrites ?? {})
  for (const [n, ops] of lw) {
    const one = (o: (typeof ops)[number]) => {
      const at = {m, sorts, atoms: [o.when]}, when = pb(o.when, P, ctx())
      return o.op === 'push' ? `${n}.push(${pterm(o.x, P, at, `${n}.$item`)}, ${when})` : o.op === 'pop' ? `${n}.pop(${when})` : `${n}.set(when(${when}, ${pidx(o.i, P, at)}, 0), ${pterm(o.x, P, at, `${n}.$item`)}, ${when})`
    }
    outs.push([`...${n}`, `${n}.apply(${ops.map(one).join(', ')})`])
  }
  const all = [...defs, ...outs.map(([, x]) => x)].join('\n')
  const lterms = lw.flatMap(([, ops]) => ops.flatMap(o => [o.when, ...(o.op === 'pop' ? [] : [o.x.e]), ...(o.op === 'set' ? [o.i] : [])]))
  const env = withChoices(envOf(...writes.map(([, t]) => t.e), ...mw.flatMap(([, w0]) => allW(w0).flatMap(w => [w.has, w.key, ...(w.when ? [w.when] : []), ...Object.values(w.vals).map(t => t.e)])), ...lterms), all, P, [...mw.map(([n]) => n), ...lw.map(([n]) => n)])
  const ret = `{${outs.map(([n, x]) => (n.startsWith('...') ? `...${x}` : `${n}: ${x}`)).join(', ')}}`
  lines.push(defs.length ? `  .step((${env}) => {\n${defs.map(d => `    ${d}`).join('\n')}\n    return ${ret}\n  })` : `  .step((${env}) => (${ret}))`)
  return lines.join('\n')
}
// (a condition by cases is one where a branch is: an ite of conditions, or of a boolean variable or cell)
const isBool = (x: object, m?: Model): boolean => {
  const o = x as {op: string, v?: unknown, a?: object, b?: object, name?: string, map?: string, field?: string}
  if (['cmp', 'and', 'or', 'not', 'is', 'leq', 'keq'].includes(o.op) || (o.op === 'const' && typeof o.v === 'boolean')) return true
  if (o.op === 'ite') return isBool(o.a!, m) || isBool(o.b!, m)
  if (o.op === 'var' && m) return [...m.params, ...m.inputs, ...m.state].some(v => v.name === o.name && v.sort.k === 'bool') || !!m.leasts?.some(l => l.some === o.name)
  if (o.op === 'cell' && m) return o.field === 'has' || [...m.maps, ...(m.seqs ?? []), ...(m.folds ?? []).map(d => ({name: d.run, fields: d.fields}))].some(d => d.name === o.map && d.fields.some(f => f.name === o.field && f.sort.k === 'bool'))
  return false
}
// (a choice by cases, `when(c, 'a', 'b')`: printed where it is read, through its variable, never hoisted as a number)
const isChoice = (x: object): boolean => {
  const o = x as {op: string, values?: unknown, a?: object, b?: object}
  return o.op === 'lit' || (o.op === 'var' && Array.isArray(o.values)) || (o.op === 'ite' && (isChoice(o.a!) || isChoice(o.b!)))
}
// The env's names: those the terms read, the choices a literal is printed through, and the maps written.
function withChoices(env: string, text: string, P: Printer, extra: string[] = []): string {
  const names = new Set(env.slice(1, -1).split(', ').filter(Boolean))
  for (const w of P.choiceVars.values()) if (/^\w+$/.test(w) ? new RegExp(`\\b${w}\\.of\\(`).test(text) : text.includes(`${w}.of(`)) names.add(w.replace(/\.at\(.*$/, ''))
  for (const n of P.hoisted.values()) names.delete(n)
  for (const n of extra) names.add(n)
  return `{${[...names].join(', ')}}`
}
// Terms written more than once, hoisted as consts (inner ones first). A number is hoisted only where its printing
// doesn't depend on the branch it is read under (a natural everywhere, or an integer everywhere).
const hoistNodes = new Map<string, object>()
function hoist(m: Model, P: Printer, roots: object[]) {
  const count = new Map<string, number>(), order: string[] = []
  const visit = (x: unknown): void => {
    if (!x || typeof x !== 'object') return
    const o = x as {op?: string}
    if (o.op && !['var', 'const', 'lit', 'svar', 'slit', 'num'].includes(o.op)) {
      const k = I.keyOf(o)
      count.set(k, (count.get(k) ?? 0) + 1)
      if (!hoistNodes.has(k)) hoistNodes.set(k, o)
      if ((count.get(k) ?? 0) > 1) return
      Object.values(o).forEach(visit)
      if (!order.includes(k)) order.push(k)
      return
    }
    if (Array.isArray(x)) x.forEach(visit)
    else Object.values(o).forEach(visit)
  }
  roots.forEach(visit)
  let i = 0
  const names = new Set([...m.params, ...m.inputs, ...m.state].map(v => v.name).concat(m.maps.map(d => d.name)))
  for (const k of order) {
    const node = hoistNodes.get(k)!, size = k.length
    if ((count.get(k) ?? 0) < 2 || size < 60 || isChoice(node)) continue
    // (a term over a bound name (a key every key is written at, a pass) is printed where that name is bound)
    if (/"name":"(k\$|kl\$|i\$)"/.test(k)) continue
    // (a product of integers kept at 0 or above only by the conditions the path is under: printed where it is read,
    // under them, never hoisted out of them)
    let guarded = false
    walk(node, o => { if (o.op === 'mul' && !(natOK(o.a as N, {m, sorts: P.sorts, atoms: []}) && natOK(o.b as N, {m, sorts: P.sorts, atoms: []}))) guarded = true })
    if (guarded) continue
    if (!isBool(node, m)) {
      const ctx: Ctx = {m, sorts: P.sorts, atoms: []}, free = natOK(node as N, ctx)
      const cells: string[] = []
      walk(node, o => { if (o.op === 'cell') cells.push(`${o.map as string}.${o.field as string}`) })
      const hasInt = [...I.varsOf(node as N).vars].some(n => P.sorts.get(n) === 'int') || cells.some(c => P.sorts.get(c) === 'int')
      if (!free && !hasInt) continue
    }
    let name = m.hints.get(node) ?? `t${++i}`
    while (names.has(name)) name = `${name}_`
    names.add(name)
    P.hoisted.set(k, name)
  }
}
export type {Evidence, Model, Term}
export {Refusal}
export {extractXState, type XStateExtraction, type XStateOptions} from './extract-xstate.ts'
