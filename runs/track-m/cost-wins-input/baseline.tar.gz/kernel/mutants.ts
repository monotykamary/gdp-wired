// Mutation testing for the trusted base (kernel.ts and its tuple sites, core/check.ts, cyclic.ts, core/solver.ts's rows): each mutant changes
// one operator, constant or quantifier at one place; the battery (fast tests first, the kernel fuzz last) must fail on
// it. A mutant that survives is a change nothing notices: a blind spot in the tests (or an equivalent mutant, which the
// report lets a reader judge).
//   bun mutants.ts list                 the mutants, numbered
//   bun mutants.ts run <from> <to>      runs the battery on mutants from..to-1 (in this checkout: run it in a container)
//   bun mutants.ts ids <a,b,...>        runs the battery on those mutants
//   bun mutants.ts baseline             the battery on the unmutated code, which must pass
//   bun mutants.ts equivalent           the mutants MUTANTS.md lists as equivalent, and its entries that match none
// supercomputer/mutants.json fans the run out on Modal, one container per batch.
import {readFileSync, writeFileSync} from 'node:fs'
import {resolve} from 'node:path'

const root = resolve(import.meta.dir, '..')
// Each target a whole file, or (`only`) the top-level declarations named: core/data.ts's admission of a definition
// (its recursion structural, or well-founded: the calls' paths, each call's obligation and the measure it reads, a nested
// call read as a value under its invariant and the bodies keeping it, and only kernel-checked proofs taken), the rest of
// that file being the search, which a mutant would change in speed alone.
const targets: {file: string, only?: string[]}[] = [{file: 'kernel/kernel.ts'}, {file: 'core/check.ts'}, {file: 'core/data.ts', only: [
  'callsIn', 'recursion', 'measurable', 'sized', 'measureOf', 'sizeX', 'measureX', 'readsInt', 'iMax0', 'measureI', 'lexY', 'isIntX', 'padded',
  'callSites', 'sitesOf', 'shapedBy', 'ownArgs', 'lowerY', 'obligation', 'valueVar', 'invAt', 'checkInv', 'lifted', 'keeps', 'directly', 'proveMeasures',
  'proveMeasuresIn', 'ringSites', 'checkMeasures', 'termination']},
  {file: 'kernel/cyclic.ts'}, {file: 'core/solver.ts', only: ['v', 'k', 'add', 'scale', 'sub']}]
// [pattern, replacement]: binary operators keep their spaces, so generics and arrows aren't touched.
const operators: [RegExp, string][] = [
  [/ <= /g, ' < '], [/ < /g, ' <= '], [/ >= /g, ' > '], [/ > /g, ' >= '],
  [/ === /g, ' !== '], [/ !== /g, ' === '], [/ && /g, ' || '], [/ \|\| /g, ' && '],
  [/\.every\(/g, '.some('], [/\.some\(/g, '.every('], [/\btrue\b/g, 'false'], [/\bfalse\b/g, 'true'],
  [/ \+ 1\b/g, ''], [/ - 1\b/g, ''], [/\bk\(1\)/g, 'k(0)'], [/\bk\(0\)/g, 'k(1)'], [/ > 0\b/g, ' >= 0'],
  [/Math\.ceil/g, 'Math.floor'], [/!\(/g, '('], [/\.\.\.pre, /g, ''], [/\.slice\(0, -1\)/g, ''],
]
// cyclic.ts builds its goals as object literals, which the operators above barely reach: its own, after them (so the
// other files' mutants keep their numbers). A comparison's kind, a negation made true, a part of a goal's hypotheses
// dropped, a guard or a tree check skipped, a fact's keys past its terms, a language check widened.
const own: Record<string, [RegExp, string][]> = {
  'kernel/cyclic.ts': [
    [/op: '<'/g, "op: '<='"], [/op: '='/g, "op: '<='"], [/op: 'not', x: /g, "op: 'and', xs: [], x: "], [/if \(/g, 'if (false && '],
    [/!check\(/g, 'check('], [/!plain\(/g, 'plain('], [/!factsAvoid\(/g, 'factsAvoid('], [/\.slice\(0, at\.length\)/g, ''],
    [/\.\.\.n\.hyps, /g, ''], [/\.\.\.instHyps\(facts, n\.insts\)/g, ''], [/\.\.\.baseHyps\(facts, n\), /g, ''],
    [/\.\.\.useHyps\(nodes, n\.uses\), /g, ''], [/u\.guard, /g, ''], [/\|all/g, ''], [/\.slice\(1\)/g, ''],
  ],
}
// A record read or built through the object prototype, in every target: an own entry read as any property (a name like
// constructor or toString then reads Object's), a row built on {} (a variable __proto__, assigned, is dropped).
const named: [RegExp, string][] = [[/Object\.hasOwn\(/g, 'Reflect.has('], [/Object\.create\(null\)/g, '{}']]
// Tuple keys (gen/laneRL): kernel.ts's tuple sites, mutated past the operators above, numbered after every other mutant
// (so theirs keep their numbers): a part read for another (ps[0] and ps[1], parts[0] and parts[1], proj's a.a and a.b, a
// tuple equality's right side read on its left), a tuple's rest whole (.slice(1)), the parts' lengths left unchecked,
// a cell name's brackets not counted when its key is split, the names ⟨ ⟩ | no longer reserved, a pair claimed where the
// keys differ, a tuple key's part read as a key term where it isn't.
const tupleSites = {file: 'kernel/kernel.ts', only: ['linearOp', 'keyParts', 'keyArity', 'truthOf', 'tupleEq', 'tupleAnd', 'facts', 'leafRows', 'cellParts', 'splitOuter', 'linOf', 'sameKey',
  'plainName', 'mapArities', 'eachParts', 'projected', 'projectedC', 'tupleSides', 'keyOnly', 'apart', 'plainKey', 'tuple', 'tupleParts', 'part']}
const tupleOps: [RegExp, string][] = [
  [/ps\[0\]/g, 'ps[1]'], [/ps\[1\]/g, 'ps[0]'], [/parts\[0\]/g, 'parts[1]'], [/parts\[1\]/g, 'parts[0]'], [/a\.a : a\.b/g, 'a.b : a.a'],
  [/b: c\.b\.a/g, 'b: c.a.a'], [/b: c\.b\.b/g, 'b: c.a.b'], [/\.slice\(1\)/g, ''], [/p\.keys\.length === q\.keys\.length && /g, ''],
  [/ \|\| ch === '⟨'/g, ''], [/ \|\| ch === '⟩'/g, ''], [/⟨⟩\|\]/g, ']'], [/!sameKey\(/g, 'sameKey('], [/!keyTerm\(part, key\)/g, 'keyTerm(part, key)'],
  [/keyTerm\(p, key\) && other\(p\)/g, 'keyTerm(p, key)'], [/e\.b\.op !== 'tup'/g, "e.b.op === 'proj'"], [/keyParts\(key, new Map\(\)\)\?\.length \?\? /g, ''],
]
type Mutant = {id: number, file: string, line: number, from: string, to: string, at: number, length: number}

export function mutants(): Mutant[] {
  const out: Mutant[] = []
  const scan = (file: string, only: string[] | undefined, ops: (file: string) => [RegExp, string][]) => {
    const text = readFileSync(resolve(root, file), 'utf8')
    let offset = 0, inside: string | undefined
    for (const [i, line] of text.split('\n').entries()) {
      const code = line.replace(/\/\/.*$/, '') // comments aren't code
      inside = declared.exec(line)?.[1] ?? (/^\S/.test(line) && !line.startsWith('//') && !line.startsWith('}') ? undefined : inside)
      if (!code.trim().startsWith('import ') && (!only || (inside && only.includes(inside)))) for (const [pattern, to] of ops(file)) {
        for (const m of code.matchAll(pattern)) out.push({id: out.length, file, line: i + 1, from: m[0], to, at: offset + m.index, length: m[0].length})
      }
      offset += line.length + 1
    }
  }
  for (const {file, only} of targets) scan(file, only, f => [...operators, ...own[f] ?? [], ...named])
  scan(tupleSites.file, tupleSites.only, () => tupleOps)
  return out
}

// The equivalent mutants, as MUTANTS.md lists them (its ```equivalent block): `file | function | snippet | from -> to |
// why`, one per line. A mutant is listed when its file is the entry's, the top-level declaration it sits in is the
// function, and its operator lies inside the snippet where the snippet occurs on its line; a run's row carries the why
// (`equivalent`), so a report can set it apart. Anchored by name and text, the list survives edits that move lines.
type Equivalent = {file: string, fn: string, snippet: string, from: string, to: string, why: string}
export function equivalents(): Equivalent[] {
  const block = /```equivalent\n([\s\S]*?)```/.exec(readFileSync(resolve(root, 'kernel/MUTANTS.md'), 'utf8'))?.[1] ?? ''
  return block.split('\n').filter(l => l.trim()).map(l => {
    const [file, fn, snippet, change, why] = l.split(' | ').map(x => x.trim()), [from, to] = change!.split(' -> ').map(x => JSON.parse(x) as string)
    return {file: file!, fn: fn!, snippet: JSON.parse(snippet!) as string, from: from!, to: to!, why: why!}
  })
}
const declared = /^(?:export )?(?:async )?(?:function|const|let|type) ([A-Za-z_$][\w$]*)/
export function equivalentOf(m: Mutant, list = equivalents()): Equivalent | undefined {
  const text = readFileSync(resolve(root, m.file), 'utf8'), lines = text.split('\n'), start = text.lastIndexOf('\n', m.at - 1) + 1, line = lines[m.line - 1]!
  let fn: string | undefined
  for (let i = m.line - 1; i >= 0 && !fn; i--) fn = declared.exec(lines[i]!)?.[1]
  return list.find(e => e.file === m.file && e.fn === fn && e.from === m.from && e.to === m.to && [...line.matchAll(new RegExp(e.snippet.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'))]
    .some(x => x.index <= m.at - start && m.at - start + m.length <= x.index + e.snippet.length))
}

// Fast and pointed first; the kernel fuzz last. Each is a bun test (exit 0 = pass) with a time limit; a mutant that makes
// a test hang is caught too.
const battery: {name: string, cwd: string, cmd: string[], env?: Record<string, string>, ms: number}[] = [
  {name: 'counts', cwd: 'kernel', cmd: ['bun', 'test', 'count.test.ts'], ms: 120_000},
  {name: 'countmachine', cwd: 'kernel', cmd: ['bun', 'test', 'countmachine.test.ts'], ms: 180_000},
  {name: 'tuples', cwd: 'kernel', cmd: ['bun', 'test', 'tuples.test.ts'], ms: 180_000},
  {name: 'refusals', cwd: 'kernel', cmd: ['bun', 'test', 'refusals.test.ts'], ms: 60_000},
  {name: 'tamper', cwd: 'kernel', cmd: ['bun', 'test', 'tamper.test.ts'], ms: 120_000},
  {name: 'cyclic', cwd: 'core', cmd: ['bun', 'test', 'cyclic.test.ts'], ms: 120_000},
  {name: 'dsl', cwd: 'core', cmd: ['bun', 'test', 'dsl.test.ts'], ms: 120_000},
  {name: 'conformance', cwd: 'core', cmd: ['bun', 'test', 'conformance.test.ts'], env: {FUZZ_SEED: '1'}, ms: 180_000},
  {name: 'examples', cwd: 'examples', cmd: ['bun', 'test', 'examples.test.ts'], env: {DOMAIN: 'finance'}, ms: 180_000},
  {name: 'runtime', cwd: 'core', cmd: ['bun', 'test', 'runtime.test.ts'], ms: 180_000},
  {name: 'history', cwd: 'kernel', cmd: ['bun', 'test', 'history.test.ts'], ms: 240_000},
  {name: 'steplaw', cwd: 'kernel', cmd: ['bun', 'test', 'steplaw.test.ts'], ms: 240_000},
  {name: 'compose', cwd: 'core', cmd: ['bun', 'test', 'compose.test.ts'], ms: 120_000},
  {name: 'sets', cwd: 'kernel', cmd: ['bun', 'test', 'sets.test.ts'], ms: 240_000},
  {name: 'functions', cwd: 'core', cmd: ['bun', 'test', 'functions.test.ts'], ms: 120_000},
  {name: 'quantifiers', cwd: 'core', cmd: ['bun', 'test', 'quantifiers.test.ts'], ms: 180_000},
  {name: 'keyterms', cwd: 'core', cmd: ['bun', 'test', 'keyterms.test.ts'], ms: 120_000},
  {name: 'liveness', cwd: 'core', cmd: ['bun', 'test', 'liveness.test.ts'], ms: 120_000},
  {name: 'lists', cwd: 'core', cmd: ['bun', 'test', 'lists.test.ts'], ms: 300_000},
  {name: 'sums', cwd: 'core', cmd: ['bun', 'test', 'sums.test.ts'], ms: 120_000},
  {name: 'rationals', cwd: 'core', cmd: ['bun', 'test', 'rationals.test.ts'], ms: 120_000},
  {name: 'pairs', cwd: 'core', cmd: ['bun', 'test', 'pairs.test.ts'], ms: 120_000},
  {name: 'nonterm', cwd: 'core', cmd: ['bun', 'test', 'nonterm.test.ts'], ms: 300_000},
  // (core/data.ts's admission: definitions taken or refused, the obligations checked; MUTANT_BATTERY=termination,conformance
  // for its mutants alone)
  {name: 'termination', cwd: 'core', cmd: ['bun', 'test', 'data.test.ts', '-t', 'terminat|structural|well-founded|ring|measure|weighted|paths'], ms: 400_000},
  {name: 'cycles', cwd: 'core', cmd: ['bun', 'test', 'cycles.test.ts'], ms: 400_000},
  {name: 'kernel fuzz', cwd: 'kernel', cmd: ['bun', 'test', 'kernel.test.ts'], env: {FUZZ_SCALE: '0.5'}, ms: 400_000},
]
// MUTANT_BATTERY=a,b: only those tests (by name), for a run over one check's mutants.
const only = process.env.MUTANT_BATTERY?.split(',')
function runBattery(): {killedBy?: string, ms: number} {
  const t0 = performance.now()
  for (const b of only ? battery.filter(x => only.includes(x.name)) : battery) {
    const p = Bun.spawnSync(b.cmd, {cwd: resolve(root, b.cwd), env: {...process.env, ...b.env}, timeout: b.ms, stdout: 'ignore', stderr: 'ignore'})
    if (p.exitCode !== 0) return {killedBy: p.exitCode === null ? `${b.name} (timeout)` : b.name, ms: Math.round(performance.now() - t0)}
  }
  return {ms: Math.round(performance.now() - t0)}
}

const [cmd, a, b] = process.argv.slice(2)
if (cmd === 'list') for (const m of mutants()) console.log(`${m.id}\t${m.file}:${m.line}\t${JSON.stringify(m.from)} -> ${JSON.stringify(m.to)}`)
else if (cmd === 'baseline') console.log(JSON.stringify({baseline: runBattery()}))
else if (cmd === 'ids') {
  const all = mutants(), ids = new Set((a ?? '').split(',').map(Number))
  for (const m of all.filter(mm => ids.has(mm.id))) {
    const path = resolve(root, m.file), original = readFileSync(path, 'utf8'), eq = equivalentOf(m)
    writeFileSync(path, original.slice(0, m.at) + m.to + original.slice(m.at + m.length))
    try { console.log(JSON.stringify({...m, ...runBattery(), ...(eq ? {equivalent: eq.why} : {})})) } finally { writeFileSync(path, original) }
  }
} else if (cmd === 'run') {
  const all = mutants(), from = Number(a), to = Math.min(Number(b), all.length)
  for (const m of all.slice(from, to)) {
    const path = resolve(root, m.file), original = readFileSync(path, 'utf8'), eq = equivalentOf(m)
    writeFileSync(path, original.slice(0, m.at) + m.to + original.slice(m.at + m.length))
    try { console.log(JSON.stringify({...m, ...runBattery(), ...(eq ? {equivalent: eq.why} : {})})) } finally { writeFileSync(path, original) }
  }
} else if (cmd === 'equivalent') {
  const list = equivalents(), hit = new Set<Equivalent>()
  for (const m of mutants()) { const e = equivalentOf(m, list); if (e) { hit.add(e); console.log(`${m.id}\t${m.file}:${m.line}\t${JSON.stringify(m.from)} -> ${JSON.stringify(m.to)}\t${e.why}`) } }
  for (const e of list.filter(x => !hit.has(x))) console.log(`unmatched: ${e.file} | ${e.fn} | ${JSON.stringify(e.snippet)}`)
} else console.log('usage: bun mutants.ts list | run <from> <to> | ids <a,b,...> | baseline | equivalent')
