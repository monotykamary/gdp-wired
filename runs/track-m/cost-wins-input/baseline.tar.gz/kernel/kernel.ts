// The kernel: the only part of a machine proof that is trusted, besides check.ts. Provers (prove.ts, or anything else)
// are untrusted; they hand the kernel a proof tree and the kernel either accepts it or doesn't.
//
// A goal is a list of hypotheses over naturals (quantifier-free: +, ∸, × by a constant, min, max, if, map reads) that
// can't all hold. A proof is a tree of splits on linear atoms (lin <= 0, or lin >= 1), with a derivation at each leaf.
// At a leaf, the kernel takes the path's atoms, every linear fact the hypotheses give under the path (a comparison whose
// ifs, mins and truncations the path decides; the parts of a conjunction; the one disjunct left when the path refutes
// the others), each variable >= 0, and, for two reads of one map at keys the path proves equal, their equality; the
// leaf's derivation must refute them (check.ts). Splits are trivially exhaustive, so a tree whose leaves all check
// means the hypotheses never hold together.
//
// Machines: `obligations` turns a machine and a set of laws into goals, the induction rule spelled out: each law holds
// at the start, and one step from a state where every law in the set holds keeps it. A law that holds at every key is
// assumed at whatever keys the proof names (instantiating ∀ is sound at any term) and is proven at a fresh key. The
// whole set is checked, so nothing is assumed that isn't proven.
//
// Two kinds of assumption: `pre`, about the params alone, is a precondition (the law is claimed only for params that
// meet it), so it holds at the start and at every step; `assume`, about each request, holds only at a step, since no
// request has come at the start.
import {checkRefutation} from '../core/check.ts'
import type {C, Counted, E, Law, Machine, MapUpdate} from '../core/machine.ts'
import {type Constraint, type Lin, type Step, add, k, scale, sub, v} from '../core/solver.ts'

// An exhaustive switch's default: TypeScript proves it unreachable, and if it is reached anyway (a value from outside
// the types), it fails loudly instead of returning undefined.
export function unreachable(value: never): never { throw new Error(`unhandled case: ${JSON.stringify(value)}`) }

// Tuple keys (core/machine.ts's tup and proj): an n-tuple nests to the right, tup(x1, tup(x2, … xn)); one part is the
// part itself. `tupleParts` reads one back ([x1, …, xn]; anything else one part); `part` is the i-th of n parts of a
// natural read as an n-tuple (proj 0, proj 0 ∘ proj 1, …, the last proj 1 ∘ … ∘ proj 1).
export const tuple = (parts: E[]): E => parts.slice(0, -1).reduceRight<E>((b, a) => ({op: 'tup', a, b}), parts.at(-1)!)
export const tupleParts = (e: E): E[] => (e.op === 'tup' ? [e.a, ...tupleParts(e.b)] : [e])
export const part = (key: E, i: number, n: number): E => { let e = key; for (let j = 0; j < i; j++) e = {op: 'proj', k: 1, a: e}; return i < n - 1 ? {op: 'proj', k: 0, a: e} : e }

export type Tree = {split: Lin, yes: Tree, no: Tree} | {leaf: Step[], products?: [number, number][], squares?: Lin[]}
export type Goal = {name: string, hyps: C[]}

// The path: atoms decided so far, by their canonical text. yes: lin <= 0; no: lin >= 1.
export type Path = Map<string, {lin: Lin, holds: boolean}>
// (Remembered per linear form: a form is never changed once built, and the same forms are looked up at every node.)
const canonMemo = new WeakMap<Lin, string>(), flipMemo = new WeakMap<Lin, string>()
export const canon = (lin: Lin): string => {
  let out = canonMemo.get(lin)
  if (out === undefined) canonMemo.set(lin, (out = Object.keys(lin).sort().map(key => `${key}:${lin[key]}`).join(',')))
  return out
}
// canon(1 − lin), the atom that decides lin <= 0 the other way, without building it.
export const canonFlip = (lin: Lin): string => {
  let out = flipMemo.get(lin)
  if (out !== undefined) return out
  const keys = Object.keys(lin)
  if (!('1' in lin)) keys.push('1')
  const parts: string[] = []
  for (const key of keys.sort()) { const c = key === '1' ? 1 - (lin['1'] ?? 0) : -lin[key]!; if (c !== 0) parts.push(`${key}:${c}`) }
  flipMemo.set(lin, (out = parts.join(',')))
  return out
}
export const atomOf = (lin: Lin, holds: boolean): Constraint => ({lin: holds ? lin : add(k(1), scale(lin, -1)), label: ''})

// Is lin <= 0 decided by the path? A constant atom decides itself.
// Over the integers lin <= 0 fails exactly when 1 - lin <= 0 holds, so either atom decides the other.
// A form with a coefficient past a safe integer decides nothing: it may be a rounded difference, and its flip is
// rounded again (1 - (2^53 + 1) reads as the safe 1 - 2^53), so an atom about another form would decide it.
function decide(lin: Lin, path: Path): boolean | undefined {
  let constant = true
  for (const key in lin) { if (!Number.isSafeInteger(lin[key])) return undefined; if (key !== '1') constant = false }
  if (constant) return (lin['1'] ?? 0) <= 0
  const direct = look(path, canon(lin))
  if (direct !== undefined) return direct
  const flipped = look(path, canonFlip(lin))
  return flipped === undefined ? undefined : !flipped
}
// Every decision a hypothesis' facts read, found or not, while they are recorded (leafConstraintsReusing).
let recording: Map<string, boolean | undefined> | undefined
const look = (path: Path, key: string): boolean | undefined => { const out = path.get(key)?.holds; if (recording) recording.set(key, out); return out }

// A term's linear form under the path. Reads become cells, named by map and key: `M[key]`; a choice the path leaves
// open (∸, min, max, if) becomes a column of its own, `⟦n⟧`, standing for the term's value (see termRows).
// Remembered per path and term (a path is never changed once built; a new decision is a new path), so a term shared
// across hypotheses, or nested in a k-step run's later states, is read once per path.
// A term without a choice (no ∸, min, max or if inside, its keys' too) reads alike on every path: remembered once.
const linearMemo = new WeakMap<Path, WeakMap<E, Lin | undefined>>()
const freeMemo = new WeakMap<E, boolean>(), freeLinear = new WeakMap<E, Lin | undefined>()
const choiceFree = (e: E): boolean => {
  let out = freeMemo.get(e)
  if (out !== undefined) return out
  switch (e.op) {
    case 'var': case 'const': out = true; break
    case 'mul': out = choiceFree(e.a); break
    case 'get': out = choiceFree(e.key); break
    case 'add': case 'prod': case 'tup': out = choiceFree(e.a) && choiceFree(e.b); break
    case 'proj': out = choiceFree(e.a); break
    case 'sub': case 'min': case 'max': case 'if': out = false; break
  }
  freeMemo.set(e, out)
  return out
}
export function linear(e: E, path: Path): Lin | undefined {
  if (choiceFree(e)) {
    if (freeLinear.has(e)) return freeLinear.get(e)
    const out = linearOf(e, path)
    freeLinear.set(e, out)
    return out
  }
  if (reuse) return reusing(seenOf(linearSeen, e), path, p => linearOf(e, p))
  let memo = linearMemo.get(path)
  if (!memo) linearMemo.set(path, (memo = new WeakMap()))
  if (memo.has(e)) return memo.get(e)
  const out = linearOf(e, path)
  memo.set(e, out)
  return out
}
// A form with a coefficient past a safe integer is no form: its float may be rounded, and every part is read through
// here, so no rounding inside a term goes unseen (core/check.ts refuses such rows too).
function linearOf(e: E, path: Path): Lin | undefined {
  const out = linearOp(e, path)
  return out && safe(out) ? out : undefined
}
const safe = (lin: Lin) => Object.values(lin).every(c => Number.isSafeInteger(c))
function linearOp(e: E, path: Path): Lin | undefined {
  switch (e.op) {
    case 'var': return e.name === '1' || /[*[\],:⟦⟨⟩|]/.test(e.name) ? undefined : v(e.name) // those characters build cells, monomials, term columns and tuple keys
    case 'const': return k(e.value)
    case 'mul': { const a = linear(e.a, path); return a && Number.isSafeInteger(e.k) ? scale(a, e.k) : undefined } // (10 · 0.1 is a float 1)
    case 'prod': { const a = linear(e.a, path), b = linear(e.b, path); return a && b && times(a, b) }
    case 'add': { const a = linear(e.a, path), b = linear(e.b, path); return a && b && add(a, b) }
    case 'sub': case 'min': case 'max': {
      const a = linear(e.a, path), b = linear(e.b, path)
      if (!a || !b) return undefined
      const aLeB = decide(sub(a, b), path), bLeA = decide(sub(b, a), path)
      if (e.op === 'sub') return bLeA === true ? sub(a, b) : bLeA === false ? k(0) : v(termColumn(e))
      if (aLeB === undefined) return v(termColumn(e))
      return (e.op === 'min') === aLeB ? a : b
    }
    case 'if': { const c = truth(e.c, path); return c === undefined ? v(termColumn(e)) : linear(c ? e.then : e.else, path) }
    case 'get': {
      // (a map's name builds its cells' columns: one with the characters of a column could spell another read's)
      if (!plainMap(e.map)) return undefined
      if (e.key.op === 'tup' || e.key.op === 'proj') { const keys = keyParts(e.key, path); if (keys) return v(`${e.map}[⟨${keys.map(canon).join('|')}⟩]`); if (e.key.op === 'tup') return undefined }
      const key = linear(e.key, path); return key && v(`${e.map}[${canon(key)}]`)
    }
    // A tuple is no linear form (its pairing is not linear); a part of one read back is the part (Lean's linear).
    case 'tup': return undefined
    case 'proj': { const ps = keyParts(e.a, path); return !ps ? undefined : e.k === 0 ? ps[0] : ps.length === 2 ? ps[1] : undefined }
  }
}
// A map's name that builds no other column (kept per name: read at every cell of every path).
const plainMaps = new Map<string, boolean>()
export const plainMap = (name: string): boolean => { let ok = plainMaps.get(name); if (ok === undefined) plainMaps.set(name, (ok = name !== '1' && !/[*[\],:⟦⟧⟨⟩|]/.test(name))); return ok }
// A tuple key's parts as linear forms (Lean's `parts`): tup(a, b) is a's form, then b's parts if b is a tuple, else b's
// form; so tup(tup(a, b), c) has none (its first part is a tuple). A read at it is the cell M[⟨k1|k2|…⟩].
// A tuple's rest (proj 1 of it) is its parts after the first, while two or more are left (Lean's `parts`).
function keyParts(e: E, path: Path): Lin[] | undefined {
  if (e.op === 'proj') { const ps = e.k === 0 ? undefined : keyParts(e.a, path); return ps && ps.length >= 3 ? ps.slice(1) : undefined }
  if (e.op !== 'tup') return undefined
  const a = linear(e.a, path)
  if (!a) return undefined
  if (e.b.op !== 'tup') { const b = linear(e.b, path); return b && [a, b] }
  const rest = keyParts(e.b, path)
  return rest && [a, ...rest]
}

// --- term columns -------------------------------------------------------------------------------------------------------
// A choice the path leaves open is a column ⟦n⟧ for the n-th term met (one table per process: the name only has to be
// the same for the same term). A leaf reads it through rows that hold whichever way the choice goes (termRows), so a
// fact about the choice's value can be split on, and proven, before the choice is decided.
// Terms are hash-consed: a term's id comes from its operator, its fields and its parts' ids, remembered per object, so a
// deep term (a k-step run nests k steps) is read once, not once per lookup.
const termIds = new Map<string, number>(), termTable: (E | C)[] = [], memo = new WeakMap<object, number>()
function termId(t: E | C): number {
  const had = memo.get(t)
  if (had !== undefined) return had
  const parts = Object.entries(t).sort(([x], [y]) => (x < y ? -1 : x > y ? 1 : 0)).map(([key, val]) => (Array.isArray(val) ? `${key}=[${val.map(x => termId(x as E | C)).join(',')}]` : typeof val === 'object' && val !== null ? `${key}=#${termId(val as E | C)}` : `${key}=${JSON.stringify(val)}`))
  const key = parts.join(';')
  let id = termIds.get(key)
  if (id === undefined) { id = termTable.length; termIds.set(key, id); termTable.push(t) }
  memo.set(t, id)
  return id
}
export const termColumn = (e: E): string => `⟦${termId(e)}⟧`
export const columnTerm = (name: string): E | undefined => { const m = /^⟦(\d+)⟧$/.exec(name); return m ? termTable[Number(m[1])] as E : undefined }
// Whether the path decides a choice's top (an if's condition, which side of min, max or ∸).
export function decided(e: E, path: Path): boolean {
  if (e.op === 'if') return truth(e.c, path) !== undefined
  if (e.op !== 'sub' && e.op !== 'min' && e.op !== 'max') return true
  const a = linear(e.a, path), b = linear(e.b, path)
  return !!a && !!b && decide(e.op === 'sub' ? sub(b, a) : sub(a, b), path) !== undefined
}
// The rows a term column brings: its bounds, true whichever way the choice goes (min(a, b) ≤ a and ≤ b; max(a, b) ≥ a
// and ≥ b; a ∸ b ≥ a − b and ≤ a), and, once the path decides it, its equality to the branch taken.
export function termRows(name: string, path: Path): Lin[] {
  const e = columnTerm(name)!, col = v(name), out: Lin[] = []
  if (e.op === 'min' || e.op === 'max' || e.op === 'sub') {
    const a = linear(e.a, path), b = linear(e.b, path)
    if (a && b) {
      if (e.op === 'min') out.push(sub(col, a), sub(col, b))
      if (e.op === 'max') out.push(sub(a, col), sub(b, col))
      if (e.op === 'sub') out.push(sub(sub(a, b), col), sub(col, a))
    }
  }
  // An if is one of its two naturals, so at most their sum, whichever way its condition goes (a yes/no's if(c, 1, 0)
  // is at most 1 without deciding c). Only over constant branches: over a variable one (a map's if(c, Given[k], 0)),
  // each such row is one more in every leaf and slows the solve more than it saves.
  if (e.op === 'if') {
    const a = linear(e.then, path), b = linear(e.else, path), constant = (l: Lin) => Object.entries(l).every(([key, c]) => key === '1' || c === 0)
    if (a && b && constant(a) && constant(b)) out.push(sub(col, add(a, b)))
  }
  if (decided(e, path)) { const r = linear(e, path); if (r) out.push(sub(col, r), sub(r, col)) }
  return out
}

// Products: multiply out, each monomial (its factors joined by '*', sorted) one more natural variable. A factor is a
// variable or a map's cell (used ≤ per·Seats[k] reads one); an open choice isn't (the path decides it first, and the
// product is of its branch). Forgetting how monomials relate (x*x to x, say, or two monomials over cells the path
// proves equal) only weakens what a leaf may use, so it stays sound; distributing is what proves spend <= m·count over
// a node from the same law at its children.
// Every coefficient, product and partial sum a safe integer, else no product: a rounded product is past 2^53, but a
// monomial's other products could bring its sum back under it (and a square's form is the prover's, any float).
function times(a: Lin, b: Lin): Lin | undefined {
  const out: Lin = Object.create(null)
  for (const [p, cp] of Object.entries(a)) for (const [q, cq] of Object.entries(b)) {
    if (p.includes('⟦') || q.includes('⟦')) return undefined
    const fs = [...(p === '1' ? [] : factorsOf(p)), ...(q === '1' ? [] : factorsOf(q))].sort(), key = fs.length ? fs.join('*') : '1', c = (out[key] ?? 0) + cp * cq
    if (!(Number.isSafeInteger(cp) && Number.isSafeInteger(cq) && Number.isSafeInteger(cp * cq) && Number.isSafeInteger(c))) return undefined
    out[key] = c
  }
  for (const key in out) if (out[key] === 0) delete out[key]
  return out
}
// A name's factors: split at each '*' outside a cell's brackets (a cell's key may itself read a monomial).
const factorMemo = new Map<string, string[]>()
export function factorsOf(name: string): string[] {
  let out = factorMemo.get(name)
  if (out) return out
  out = []
  let depth = 0, start = 0
  for (let i = 0; i <= name.length; i++) {
    const ch = name[i]
    if (ch === '[') depth++
    else if (ch === ']') depth--
    else if ((ch === '*' && depth === 0) || i === name.length) { out.push(name.slice(start, i)); start = i + 1 }
  }
  factorMemo.set(name, out)
  return out
}
export const isMonomial = (name: string) => factorsOf(name).length > 1
export const isCell = (name: string) => name.includes('[') && !isMonomial(name)

// The atoms (lin <= 0 each) that make a comparison true, and those that make it false (one of which holds).
// Remembered per path and comparison (as linear is), and once for a comparison of terms without choices.
type Comparison = {when: Lin[], unless: Lin[][]} | undefined
const comparisonMemo = new WeakMap<Path, WeakMap<C, Comparison>>(), freeComparison = new WeakMap<C, Comparison>()
function comparison(c: Extract<C, {a: E}>, path: Path): Comparison {
  const free = choiceFree(c.a) && choiceFree(c.b)
  if (free && freeComparison.has(c)) return freeComparison.get(c)
  if (!free && reuse) return reusing(seenOf(comparisonSeen, c), path, p => comparisonOf(c, p))
  let memo = comparisonMemo.get(path)
  if (!free) {
    if (!memo) comparisonMemo.set(path, (memo = new WeakMap()))
    if (memo.has(c)) return memo.get(c)
  }
  const out = comparisonOf(c, path)
  if (free) freeComparison.set(c, out); else memo!.set(c, out)
  return out
}
function comparisonOf(c: Extract<C, {a: E}>, path: Path): Comparison {
  const a = linear(c.a, path), b = linear(c.b, path)
  if (!a || !b) return undefined
  // A rounded difference gives no fact: one past 2^53 is refused as a row, but plus 1 it may be safe again.
  const ab = sub(a, b), ba = sub(b, a)
  if (!safe(ab)) return undefined
  if (c.op === '<=') return {when: [ab], unless: [[add(ba, k(1))]]}
  if (c.op === '<') return {when: [add(ab, k(1))], unless: [[ba]]}
  return {when: [ab, ba], unless: [[add(ab, k(1))], [add(ba, k(1))]]}
}

// Kleene truth under the path: true, false, or undefined when open (remembered per path and condition).
const truthMemo = new WeakMap<Path, WeakMap<C, boolean | undefined>>()
export function truth(c: C, path: Path): boolean | undefined {
  if (reuse) return reusing(seenOf(truthSeen, c), path, p => truthOf(c, p))
  let memo = truthMemo.get(path)
  if (!memo) truthMemo.set(path, (memo = new WeakMap()))
  if (memo.has(c)) return memo.get(c)
  const out = truthOf(c, path)
  memo.set(c, out)
  return out
}
function truthOf(c: C, path: Path): boolean | undefined {
  switch (c.op) {
    case 'flag': throw new Error('flags are inlined before the kernel sees them')
    case 'all': return undefined // closed before a goal is checked; opaque here, so it gives a leaf nothing
    case 'not': { const t = truth(c.x, path); return t === undefined ? undefined : !t }
    case 'and': case 'or': {
      const ts = c.xs.map(y => truth(y, path)), dominant = c.op === 'or'
      return ts.includes(dominant) ? dominant : ts.every(t => t === !dominant) ? !dominant : undefined
    }
    case '<': case '<=': case '=': {
      const parts = tupleEq(c)
      if (parts) { const a = truth(parts[0], path), b = truth(parts[1], path); return a === false || b === false ? false : a === true && b === true ? true : undefined }
      const cmp = comparison(c, path)
      if (!cmp) return undefined
      const ts = cmp.when.map(lin => decide(lin, path))
      return ts.includes(false) ? false : ts.every(t => t === true) ? true : undefined
    }
    default: return unreachable(c)
  }
}

// An equality of two tuples as its two parts' equalities (tup(a1, a2) = tup(b1, b2): a1 = b1, a2 = b2), kept per condition.
const tupleEqMemo = new WeakMap<C, [C, C] | null>(), tupleAndMemo = new WeakMap<C, C>()
// (the same as one condition, `and` of the two: kernel/reader.ts reads it so)
export function tupleAnd(c: Extract<C, {a: E}>): C | undefined {
  const parts = tupleEq(c)
  if (!parts) return undefined
  let out = tupleAndMemo.get(c)
  if (!out) tupleAndMemo.set(c, (out = {op: 'and', xs: parts}))
  return out
}
export function tupleEq(c: Extract<C, {a: E}>): [C, C] | undefined {
  if (c.op !== '=' || c.a.op !== 'tup' || c.b.op !== 'tup') return undefined
  let out = tupleEqMemo.get(c)
  if (out === undefined) tupleEqMemo.set(c, (out = [{op: '=', a: c.a.a, b: c.b.a}, {op: '=', a: c.a.b, b: c.b.b}]))
  return out ?? undefined
}

// The linear facts a hypothesis gives under the path (each lin <= 0).
export function facts(c: C, path: Path, positive = true): Lin[] {
  switch (c.op) {
    case 'flag': throw new Error('flags are inlined before the kernel sees them')
    case 'all': return []
    case 'not': return facts(c.x, path, !positive)
    case 'and': case 'or': {
      if ((c.op === 'and') === positive) return c.xs.flatMap(y => facts(y, path, positive))
      const open = c.xs.filter(y => truth(y, path) !== !positive)
      return open.length === 0 ? [k(1)] : open.length === 1 ? facts(open[0]!, path, positive) : []
    }
    case '<': case '<=': case '=': {
      // Two tuples equal is their parts equal (the pairing is a bijection): Lean's facts of `and (eq a1 b1) (eq a2 b2)`.
      const parts = tupleEq(c)
      if (parts) {
        if (positive) return [...facts(parts[0], path, true), ...facts(parts[1], path, true)]
        const open = parts.filter(y => truth(y, path) !== true)
        return open.length === 0 ? [k(1)] : open.length === 1 ? facts(open[0]!, path, false) : []
      }
      const cmp = comparison(c, path)
      if (!cmp) return []
      if (positive) return cmp.when
      const open = cmp.unless.filter(atoms => !atoms.some(lin => decide(lin, path) === false))
      return open.length === 0 ? [k(1)] : open.length === 1 ? open[0]! : []
    }
    default: return unreachable(c)
  }
}

// What a leaf's derivation must refute.
export function leafConstraints(goal: Goal, path: Path): Constraint[] { return leafRows(goal, path, h => facts(h, path)) }
// The same rows, for the prover's search: each hypothesis' facts as they were at an earlier path of the goal's where
// every decision they read was the same (facts read the path only through those decisions), and found afresh, with
// what they read recorded, otherwise. The kernel's check never uses it: it rebuilds every row as leafConstraints does.
const factsSeen = new WeakMap<Goal, Map<C, Seen<Lin[]>>>()
export function leafConstraintsReusing(goal: Goal, path: Path): Constraint[] {
  let byHyp = factsSeen.get(goal)
  if (!byHyp) factsSeen.set(goal, (byHyp = new Map()))
  return leafRows(goal, path, h => {
    let seen = byHyp.get(h)
    if (!seen) byHyp.set(h, (seen = {}))
    return reusing(seen, path, p => facts(h, p))
  })
}
// A value of the path that reads it only through decisions (facts, truth, linear forms, and what is built of them): as
// it was at an earlier path where each decision it read is the same, else found afresh, on a copy of the path (so no
// memo made without recording answers it), with what it read recorded in `seen`. `seen` is a trie of the decisions
// read, in the order they were read: a value's next decision depends only on the answers to those before it, so
// following the path's answers from the root reaches the value found for the same answers, if there is one.
type Decisions = [string, boolean | undefined][]
// A leaf holds a value and every decision it read; a branch sits where two values' decisions first part (at index
// `at`, the decision's key), so a value's run of decisions shared with no other costs no nodes.
type Node<T> = {at: number, key: string, next: Map<boolean | undefined, Node<T>>} | {reads: Decisions, out: T}
export type Seen<T> = {root?: Node<T>, size?: number}
// Past `reuseKeep` values a trie starts afresh: a long search would otherwise keep every value it ever found.
const reuseKeep = 16
function remember<T>(seen: Seen<T>, reads: Decisions, out: T): void {
  if ((seen.size = (seen.size ?? 0) + 1) > reuseKeep) { seen.root = undefined; seen.size = 1 }
  const leaf: Node<T> = {reads, out}
  let node = seen.root, parent: {next: Map<boolean | undefined, Node<T>>} | undefined, via: boolean | undefined
  while (node && 'key' in node) {
    // A value that read otherwise than the trie says (none does: the decisions are deterministic) is not kept.
    if (reads[node.at]?.[0] !== node.key) return
    parent = node; via = reads[node.at]![1]
    node = node.next.get(via)
  }
  const put = (n: Node<T>) => { if (parent) parent.next.set(via, n); else seen.root = n }
  if (!node) { put(leaf); return }
  const i = node.reads.findIndex((d, j) => reads[j]?.[0] !== d[0] || reads[j]![1] !== d[1])
  if (i < 0 || reads[i]?.[0] !== node.reads[i]![0]) return
  put({at: i, key: node.reads[i]![0], next: new Map([[node.reads[i]![1], node], [reads[i]![1], leaf]])})
}
export function reusing<T>(seen: Seen<T>, path: Path, f: (path: Path) => T): T {
  let node = seen.root
  while (node && 'key' in node) node = node.next.get(path.get(node.key)?.holds)
  if (node && node.reads.every(([key, holds]) => path.get(key)?.holds === holds)) {
    if (recording) for (const [key, holds] of node.reads) recording.set(key, holds)
    return node.out
  }
  const outer = recording, mode = reuse
  recording = new Map()
  reuse = true
  try {
    const out = f(new Map(path))
    remember(seen, [...recording], out)
    return out
  } finally {
    // What was read inside is read by the outer value too.
    if (outer) for (const [key, holds] of recording) outer.set(key, holds)
    recording = outer
    reuse = mode
  }
}
// While the prover reuses (inside `reusing`), a term's linear form, a comparison and a condition's truth are reused the
// same way, each by the decisions it reads: only what a new decision touches is read again. The kernel's check never
// runs in this mode: it reads every term afresh on every path.
let reuse = false
const linearSeen = new WeakMap<E, Seen<Lin | undefined>>(), comparisonSeen = new WeakMap<C, Seen<Comparison>>(), truthSeen = new WeakMap<C, Seen<boolean | undefined>>()
const seenOf = <K extends object, T>(m: WeakMap<K, Seen<T>>, k: K): Seen<T> => { let s = m.get(k); if (!s) m.set(k, (s = {})); return s }
function leafRows(goal: Goal, path: Path, factsOf: (h: C) => Lin[]): Constraint[] {
  const rows: Constraint[] = [...path.values()].map((a, i) => ({...atomOf(a.lin, a.holds), src: {atom: i}}))
  for (const [i, h] of goal.hyps.entries()) for (const lin of factsOf(h)) rows.push({lin, label: '', src: {fact: i}})
  const names = new Set(rows.flatMap(r => Object.keys(r.lin).filter(key => key !== '1')))
  // Two reads of one map whose keys the path proves equal are equal.
  const cells = [...names].filter(isCell).map(name => ({name, ...cellParts(name)}))
  for (const [i, p] of cells.entries()) for (const q of cells.slice(i + 1)) {
    if (p.map !== q.map) continue
    if (!sameKey(p, q, path)) continue
    rows.push({lin: sub(v(p.name), v(q.name)), label: '', src: {pair: [p.name, q.name]}}, {lin: sub(v(q.name), v(p.name)), label: '', src: {pair: [p.name, q.name]}})
  }
  // Each term column's rows, and the columns those rows bring in turn.
  const seen = new Set<string>(), todo = [...names].filter(n => n.startsWith('⟦'))
  while (todo.length) {
    const name = todo.pop()!
    if (seen.has(name)) continue
    seen.add(name)
    for (const lin of termRows(name, path)) {
      rows.push({lin, label: '', src: {term: name}})
      for (const key of Object.keys(lin)) if (key !== '1') { names.add(key); if (key.startsWith('⟦') && !seen.has(key)) todo.push(key) }
    }
  }
  for (const name of names) rows.push({lin: {[name]: -1}, label: '', src: {nat: name}})
  return rows
}
// A cell's map and key: M[k] a key, M[⟨k1|k2|…⟩] a tuple's parts (each a canonical text). Split at the outer level only:
// a name in a key may itself be a cell, with brackets, commas and bars of its own.
// (kept per name: every leaf reads its cells' keys again; a form is never changed once built)
const cellMemo = new Map<string, {map: string, key?: Lin, keys?: Lin[]}>()
export function cellParts(cell: string): {map: string, key?: Lin, keys?: Lin[]} {
  let out = cellMemo.get(cell)
  if (!out) { if (cellMemo.size > 200_000) cellMemo.clear(); cellMemo.set(cell, (out = cellParts0(cell))) }
  return out
}
function cellParts0(cell: string): {map: string, key?: Lin, keys?: Lin[]} {
  const map = cell.slice(0, cell.indexOf('[')), inner = cell.slice(cell.indexOf('[') + 1, -1)
  if (inner.startsWith('⟨') && inner.endsWith('⟩')) return {map, keys: splitOuter(inner.slice(1, -1), '|').map(linOf)}
  return {map, key: linOf(inner)}
}
const splitOuter = (text: string, sep: string): string[] => {
  const parts: string[] = []
  let depth = 0, start = 0
  for (let i = 0; i <= text.length; i++) {
    const ch = text[i]
    if (ch === '[' || ch === '⟨') depth++
    else if (ch === ']' || ch === '⟩') depth--
    else if ((ch === sep && depth === 0) || i === text.length) { parts.push(text.slice(start, i)); start = i + 1 }
  }
  return parts
}
// A canonical text read back: `name:coef` joined by ',' at the outer level.
const linOf = (text: string): Lin => {
  const out: Lin = Object.create(null)
  for (const part of splitOuter(text, ',')) if (part) { const at = part.lastIndexOf(':'); out[part.slice(0, at)] = Number(part.slice(at + 1)) }
  return out
}
// Two keys the path proves equal: two plain keys whose difference it decides 0 both ways, or two tuples of as many parts,
// each pair of parts so (Lean's cellEq). A plain key and a tuple are never claimed equal.
function sameKey(p: {key?: Lin, keys?: Lin[]}, q: {key?: Lin, keys?: Lin[]}, path: Path): boolean {
  const zero = (a: Lin, b: Lin) => { const d = sub(a, b); return decide(d, path) === true && decide(scale(d, -1), path) === true }
  if (p.key && q.key) return zero(p.key, q.key)
  return !!p.keys && !!q.keys && p.keys.length === q.keys.length && p.keys.every((a, i) => zero(a, q.keys![i]!))
}

// A leaf may also use the product of two of its rows: p <= 0 and q <= 0 give p·q >= 0, as nlinarith does; and the
// square of any linear form t, which holds whatever t's sign: t·t >= 0 (a sum of squares, as a Positivstellensatz
// certificate has). The squares follow the leaf's rows, then the products; a pair may name a square or an earlier
// product (an index past the leaf's rows), each a row of the same kind, so degrees go higher.
export function withProducts(rows: Constraint[], pairs: [number, number][], squares: Lin[] = []): Constraint[] {
  const out = [...rows]
  for (const t of squares) { const tt = times(t, t); out.push(tt ? {lin: scale(tt, -1), label: ''} : {lin: {}, label: ''}) }
  for (const [i, j] of pairs) {
    const p = out[i], q = out[j], pq = p && q ? times(p.lin, q.lin) : undefined
    out.push(pq ? {lin: scale(pq, -1), label: ''} : {lin: {}, label: ''})
  }
  return out
}

export function check(goal: Goal, tree: Tree, path: Path = new Map()): boolean {
  if ('leaf' in tree) return checkRefutation(withProducts(leafConstraints(goal, path), tree.products ?? [], tree.squares), tree.leaf)
  const id = canon(tree.split)
  if (path.has(id) || Object.keys(tree.split).every(key => key === '1')) return false
  const yes = new Map(path).set(id, {lin: tree.split, holds: true}), no = new Map(path).set(id, {lin: tree.split, holds: false})
  return check(goal, tree.yes, yes) && check(goal, tree.no, no)
}

// Count.lean's conditional lemma rule. All rows use the containing goal's columns and witness namespace; a slice
// selects only that exact goal's hypotheses. A lemma tree is checked by the old checker, with no lemma list.
// TS acceptance is a strict subset of Lean's: legacy constant/repeated split refusals are intentionally retained.
export type LemmaCut = {when: Lin[], cut: Lin, tree: Tree, slice?: number[]}
const lemmaLin = (lin: Lin): boolean => !!lin && typeof lin === 'object' && !Array.isArray(lin)
  && (Object.getPrototypeOf(lin) === Object.prototype || Object.getPrototypeOf(lin) === null)
  && Object.values(lin).every(Number.isSafeInteger)

// Lean's path is a list, so repeated atoms remain input rows, with the first deciding lookup. Keep that exact
// behavior in a Map: noncanonical duplicate keys contain no colon and cannot collide with a nonempty canon(lin).
function prependAtoms(front: {lin: Lin, holds: boolean}[], path: Path): Path {
  const out: Path = new Map()
  let duplicate = 0
  for (const atom of [...front, ...path.values()]) {
    const id = canon(atom.lin)
    out.set(out.has(id) ? `@${duplicate++}` : id, atom)
  }
  return out
}

// Eligibility uses only the original split path, never another cut. The returned path is for a leaf alone.
export function lemmaPath(lemmas: LemmaCut[], path: Path): Path {
  // Lean's dec treats all-zero variable coefficients as constant. Normalize only this
  // new-condition decision boundary: preserve the original proof rows and every legacy path.
  lemmas = lemmas.map(l => ({...l, when: l.when.map(w =>
    Object.keys(w).every(key => key === '1' || w[key] === 0) ? k(w['1'] ?? 0) : w)}))
  const active = lemmas.filter(l => l.when.every(w => decide(w, path) === true))
  return active.length ? prependAtoms(active.map(l => ({lin: l.cut, holds: true})), path) : path
}

export function checkGoalLemmas(goal: Goal, tree: Tree, lemmas: LemmaCut[] = []): boolean {
  if (!Array.isArray(lemmas)) return false
  if (!lemmas.length) return check(goal, tree) // Exact legacy path, including all old refusal checks.
  try {
    if (!Array.from(lemmas).every(l => !!l && typeof l === 'object' && Array.isArray(l.when)
      && Array.from(l.when).every(lemmaLin) && lemmaLin(l.cut) && !!l.tree && typeof l.tree === 'object'
      && (l.slice === undefined || Array.isArray(l.slice) && Array.from(l.slice).every(i => Number.isSafeInteger(i) && i >= 0 && i < goal.hyps.length)))) return false
    for (const l of lemmas) {
      const hyps = l.slice === undefined ? goal.hyps : l.slice.map(i => goal.hyps[i]!)
      const path = prependAtoms([{lin: l.cut, holds: false}, ...l.when.map(lin => ({lin, holds: true}))], new Map())
      if (!check({...goal, hyps}, l.tree, path)) return false
    }
    const visit = (t: Tree, path: Path): boolean => {
      if ('leaf' in t) return check(goal, t, lemmaPath(lemmas, path))
      const id = canon(t.split)
      if (path.has(id) || Object.keys(t.split).every(key => key === '1')) return false
      return visit(t.yes, new Map(path).set(id, {lin: t.split, holds: true}))
        && visit(t.no, new Map(path).set(id, {lin: t.split, holds: false}))
    }
    return visit(tree, new Map())
  } catch { return false } // Malformed new payloads, including non-tree lemma references, are refusals.
}

// --- machines ----------------------------------------------------------------------------------------------------------

// Every constant and factor is a natural, so every value a machine computes is one (∸ truncates).
function natural(e: E): boolean {
  switch (e.op) {
    case 'var': return true
    case 'const': return Number.isInteger(e.value) && e.value >= 0
    case 'mul': return Number.isInteger(e.k) && e.k >= 0 && natural(e.a)
    case 'prod': return natural(e.a) && natural(e.b)
    case 'if': return naturalC(e.c) && natural(e.then) && natural(e.else)
    case 'get': return natural(e.key)
    case 'add': case 'sub': case 'min': case 'max': case 'tup': return natural(e.a) && natural(e.b)
    case 'proj': return (e.k === 0 || e.k === 1) && natural(e.a)
    default: return unreachable(e)
  }
}
const naturalC = (c: C): boolean => c.op === 'flag' ? true : c.op === 'all' ? naturalC(c.c) : c.op === 'not' ? naturalC(c.x) : c.op === 'and' || c.op === 'or' ? c.xs.every(naturalC) : natural(c.a) && natural(c.b)

// Substitution: variables by terms, and each map read by what the map holds (the start's constant, or a write over the
// map before the step).
export type Subst = {vars: Record<string, E>, maps: Record<string, (key: E) => E>, flags: Record<string, C>}
// (a substitution's own entries only: a name like `constructor` or `toString` is no entry of {}; terra's review. Every
// record the kernel reads by a name of the rule or the certificate reads it so, and every Lin is built on no prototype,
// where a name __proto__ is a key like any other.)
export const own = <T>(r: Record<string, T>, k: string): T | undefined => (Object.hasOwn(r, k) ? r[k] : undefined)
export function substE(e: E, s: Subst): E {
  switch (e.op) {
    case 'var': return own(s.vars, e.name) ?? e
    case 'const': return e
    case 'mul': return {...e, a: substE(e.a, s)}
    case 'prod': return {...e, a: substE(e.a, s), b: substE(e.b, s)}
    case 'if': return {op: 'if', c: substC(e.c, s), then: substE(e.then, s), else: substE(e.else, s)}
    case 'get': { const key = substE(e.key, s), f = own(s.maps, e.map); return f ? f(key) : {op: 'get', map: e.map, key} }
    case 'add': case 'sub': case 'min': case 'max': case 'tup': return {...e, a: substE(e.a, s), b: substE(e.b, s)}
    case 'proj': return {...e, a: substE(e.a, s)}
    default: return unreachable(e)
  }
}
export function substC(c: C, s: Subst): C {
  if (c.op === 'flag') { const f = own(s.flags, c.name); if (!f) throw new Error(`unknown flag ${c.name}`); return f }
  if (c.op === 'not') return {op: 'not', x: substC(c.x, s)}
  if (c.op === 'all') { const keys = boundOf(c), vars = Object.fromEntries(Object.entries(s.vars).filter(([n]) => !keys.includes(n))); return {...c, c: substC(c.c, {...s, vars})} }
  if (c.op === 'and' || c.op === 'or') return {op: c.op, xs: c.xs.map(y => substC(y, s))}
  return {...c, a: substE(c.a, s), b: substE(c.b, s)}
}
const mentions = (c: C, names: string[]): boolean => JSON.stringify(c).match(/"name":"([^"]+)"/g)?.some(m => names.includes(m.slice(8, -1))) ?? false
// A precondition reads the params and nothing else: no state, no request, no map.
const aboutParams = (c: C, params: string[]): boolean => !JSON.stringify(c).includes('"op":"get"') && (JSON.stringify(c).match(/"name":"([^"]+)"/g) ?? []).every(m => params.includes(m.slice(8, -1)))
const preOf = (o: {params: string[], pre?: C}): C[] => {
  if (o.pre && !(aboutParams(o.pre, o.params) && naturalC(o.pre))) throw new Error('a precondition reads only the params')
  return o.pre ? [o.pre] : []
}

// Instances: for each law that holds at every key, the keys (over the state before the step) the proof assumes it at;
// for a law about every two keys or more, the tuples, flattened (a tuple's keys in a row, `forall` first).
export type Instances = Record<string, E[]>

// --- runs: the one algebra under every obligation ----------------------------------------------------------------------

// Every obligation below is one inclusion: the runs a sequence of tests and steps allows, from a first frame (a copy of
// the state), are contained in a conclusion. A run is kept symbolically: the hypotheses met along it, each read at the
// frame it was met at, and the frame it ends at, every name a term over the first frame (and the inputs read on the
// way). Its goal is the hypotheses with the conclusion refuted. The induction rule, step laws, progress, loops, folds
// and k-step laws are each a few of these moves; nothing else turns a machine into goals.
type Run = {hyps: C[], at: Subst}
type Update = {vars: Record<string, E>, maps: Record<string, MapUpdate>}
const identity: Subst = {vars: {}, maps: {}, flags: {}}
const from = (at: Subst = identity): Run => ({hyps: [], at})
// Conditions that hold where the run is.
const holds = (r: Run, cs: C[]): Run => ({hyps: [...r.hyps, ...cs.map(c => substC(c, r.at))], at: r.at})
// Names read where the run is: inputs named for this step (a request's terms, or fresh names for a later step), and the
// maps a request carries, renamed for a later step.
const reading = (r: Run, vars: Record<string, E>, maps: Record<string, string> = {}): Run => ({hyps: r.hyps, at: {...r.at, vars: {...r.at.vars, ...vars},
  maps: {...r.at.maps, ...Object.fromEntries(Object.entries(maps).map(([map, name]) => [map, (key: E): E => ({op: 'get', map: name, key})]))}}})
// One step: each name the update sets is its term read where the run is; a map read after it is the written value at
// the written key, and what the map held before elsewhere (or, written at every key, its value at the key read).
const step = (r: Run, u: Update): Run => {
  const at = r.at, before = (map: string, key: E): E => { const f = own(at.maps, map); return f ? f(key) : {op: 'get', map, key} }
  return {hyps: r.hyps, at: {
    vars: {...at.vars, ...Object.fromEntries(Object.entries(u.vars).map(([n, e]) => [n, substE(e, at)]))},
    maps: {...at.maps, ...Object.fromEntries(Object.entries(u.maps).map(([map, w]) => [map, 'each' in w
      ? (key: E): E => substE(w.value, {...at, vars: {...at.vars, [w.each]: key}})
      : (key: E): E => ({op: 'if', c: {op: '=', a: key, b: substE(w.key, at)}, then: substE(w.value, at), else: before(map, key)})]))},
    flags: at.flags,
  }}
}
// The state after a step, named: each state variable a fresh name n~j equal to its term there, which later frames read,
// so a run of k steps is k small frames rather than a term nesting each state in the next (which grows as 3^k when a
// step reads its state thrice). The names are new to the goal; each equation holds of the run that took the steps.
const nameState = (r: Run, state: string[], j: number): Run => ({
  hyps: [...r.hyps, ...state.map(n => ({op: '=', a: {op: 'var', name: stateName(n, j)}, b: own(r.at.vars, n) ?? {op: 'var', name: n}}) as C)],
  at: {...r.at, vars: {...r.at.vars, ...Object.fromEntries(state.map(n => [n, {op: 'var', name: stateName(n, j)} as E]))}},
})
export const stateName = (n: string, j: number) => `${n}~${j}`
// The conclusion read at the run's end: plain names at the last frame.
const atEnd = (r: Run, c: C): C => substC(c, r.at)
// The conclusion read across the run: plain names at the first frame, primed names (s', and M'[k] as a read of the map
// named M') at the last; the first step's inputs as it read them, and its flags, decided where it was taken.
const across = (r: Run, c: C, state: string[], maps: string[], first: {inputs: Record<string, E>, flags: Record<string, C>}): C => substC(c, {
  vars: {...first.inputs, ...Object.fromEntries(state.map(n => [`${n}'`, own(r.at.vars, n) ?? {op: 'var', name: n}]))},
  maps: Object.fromEntries(maps.map(map => [`${map}'`, (key: E): E => { const f = own(r.at.maps, map); return f ? f(key) : {op: 'get', map, key} }])),
  flags: first.flags,
})
const goal = (name: string, r: Run, conclusion: C): Goal => ({name, hyps: [...r.hyps, {op: 'not', x: conclusion}]})
// A machine's flags as its terms read them (decided before the step, over the frame it starts from): a plain flag its
// condition (through the flags before it), a quantified flag (one whose condition holds at every key) its 0/1 variable
// ?f, which `closing` ties to the condition.
const flagsOf = (m: Machine): Record<string, C> => {
  const out: Record<string, C> = Object.create(null)
  for (const [f, c] of Object.entries(m.step.flags ?? {})) out[f] = c.op === 'all' ? {op: '=', a: {op: 'var', name: `?${f}`}, b: {op: 'const', value: 1}} : substC(c, {vars: {}, maps: {}, flags: out})
  return out
}
const quantified = (m: Machine) => Object.entries(m.step.flags ?? {}).filter((e): e is [string, Extract<C, {op: 'all'}>] => e[1].op === 'all')
// The keys a quantifier binds: its key, and a quantified flag's further keys (a condition at every tuple of keys).
export const boundOf = (c: Extract<C, {op: 'all'}>): string[] => [c.key, ...(c.keys ?? [])]
// A quantified flag's witnesses, one per key: w?f, then w2?f, w3?f.
export const witnessesOf = (f: string, q: Extract<C, {op: 'all'}>): string[] => boundOf(q).map((_, i) => (i ? `w${i + 1}?${f}` : `w?${f}`))
// A comparison between two of a flag's keys, plainly (i < j, i ≤ j, i = j).
const crossing = (c: C, keys: string[]): boolean => (c.op === '<' || c.op === '<=' || c.op === '=') && c.a.op === 'var' && c.b.op === 'var' && c.a.name !== c.b.name && keys.includes(c.a.name) && keys.includes(c.b.name)
// A condition over several keys with each comparison between two of them set aside (as 0 ≤ 0): what reads each key on
// its own. (Kept per condition and keys: the runtimes ask at every step.)
const crossCache = new WeakMap<C, Map<string, C>>()
export const crossFree = (c: C, keys: string[]): C => {
  const id = keys.join(','), hit = crossCache.get(c)?.get(id)
  if (hit) return hit
  const zero: E = {op: 'const', value: 0}
  const e = (t: E): E => (t.op === 'if' ? {...t, c: crossFree(t.c, keys), then: e(t.then), else: e(t.else)} : t.op === 'get' ? {...t, key: e(t.key)} : t.op === 'mul' || t.op === 'proj' ? {...t, a: e(t.a)}
    : t.op === 'add' || t.op === 'sub' || t.op === 'min' || t.op === 'max' || t.op === 'prod' || t.op === 'tup' ? {...t, a: e(t.a), b: e(t.b)} : t)
  const out: C = crossing(c, keys) ? {op: '<=', a: zero, b: zero} : c.op === 'not' ? {op: 'not', x: crossFree(c.x, keys)} : c.op === 'and' || c.op === 'or' ? {op: c.op, xs: c.xs.map(y => crossFree(y, keys))}
    : c.op === 'all' ? {...c, c: crossFree(c.c, keys)} : c.op === 'flag' ? c : {...c, a: e(c.a), b: e(c.b)}
  if (!crossCache.has(c)) crossCache.set(c, new Map())
  crossCache.get(c)!.set(id, out)
  return out
}
// A machine's step as an update, its flags inlined.
const updateOf = (m: Machine): Update => {
  const flags: Subst = {vars: {}, maps: {}, flags: flagsOf(m)}
  return {
    vars: Object.fromEntries(Object.entries(m.step.state ?? {}).map(([n, e]) => [n, substE(e, flags)])),
    maps: Object.fromEntries(Object.entries(m.step.maps ?? {}).map(([map, w]) => [map, 'each' in w ? {each: w.each, value: substE(w.value, flags)} : {key: substE(w.key, flags), value: substE(w.value, flags)}])),
  }
}
const inlineFlags = (m: Machine, c: C): C => substC(c, {vars: {}, maps: {}, flags: flagsOf(m)})
// A quantified flag ?f, closed: it is 0 or 1; where it is 1, its condition holds at each key the proof names (instances
// under ?f); where it is 0, the condition fails at a fresh witness w?f. A real step decides ?f by the condition, and if
// that fails some key fails it, so these hold of every real step: a goal that refutes them refutes the machine.
// Over several keys, the instances are tuples (flattened, as Instances keeps them) and there is a witness per key.
const closing = (m: Machine, instances: Instances): C[] => quantified(m).flatMap(([f, q]): C[] => {
  const v: E = {op: 'var', name: `?${f}`}, zero: E = {op: 'const', value: 0}, one: E = {op: 'const', value: 1}, names = boundOf(q), n = names.length
  const body = (keys: E[]): C => substC(q.c, {vars: Object.fromEntries(names.map((key, i) => [key, keys[i]!])), maps: {}, flags: flagsOf(m)})
  const inst = instances[`?${f}`] ?? []
  return [{op: '<=', a: v, b: one}, ...Array.from({length: Math.floor(inst.length / n)}, (_, t): C => ({op: 'or', xs: [{op: '=', a: v, b: zero}, body(inst.slice(t * n, (t + 1) * n))]})),
    {op: 'or', xs: [{op: '=', a: v, b: one}, {op: 'not', x: body(witnessesOf(f, q).map((name): E => ({op: 'var', name})))}]}]
})
// The names a later step (j >= 2) reads its request by: inputs, quantified flags and their witnesses, and carried maps.
const laterNames = (m: Machine, j: number) => ({
  vars: Object.fromEntries([...m.inputs, ...quantified(m).flatMap(([f, q]) => [`?${f}`, ...witnessesOf(f, q)])].map(name => [name, {op: 'var', name: `${name}@${j}`} as E])),
  maps: Object.fromEntries((m.inputMaps ?? []).map(map => [map, `${map}@${j}`])),
})
// The laws assumed where the run is: each plain law, and each every-key law at the keys the proof names.
export const assumed = (laws: Law[], instances: Instances): C[] => laws.flatMap(l => {
  const keys = own(instances, l.name) ?? []
  if (l.keys?.length) {
    const names = [l.forall!, ...l.keys], n = names.length
    return Array.from({length: Math.floor(keys.length / n)}, (_, t) => substC(l.holds, {vars: Object.fromEntries(names.map((name, i) => [name, keys[t * n + i]!])), maps: {}, flags: {}}))
  }
  return l.forall ? keys.map(key => substC(l.holds, {vars: {[l.forall!]: key}, maps: {}, flags: {}})) : [l.holds]
})
// The facts about the functions, at the keys the proof names: as they are (they read the params and functions alone, so
// any frame reads them alike).
const given = (m: Machine, r: Run, instances: Instances): Run => ({hyps: [...r.hyps, ...assumed(m.facts ?? [], instances)], at: r.at})
// The start: the state's start values over the params, every map cell its constant.
const startOf = (m: Machine): Subst => ({vars: {...m.state}, maps: Object.fromEntries(Object.entries(m.maps ?? {}).map(([map, c]) => [map, () => ({op: 'const', value: c})])), flags: {}})

// --- scope -----------------------------------------------------------------------------------------------------------

// Every name a machine reads is one it declares. A goal reads an undeclared name as one more free natural, so a proof
// would still be sound about the machine as written; but the runtimes have no value for it, so the proof would be about
// a machine that never runs. Refused here, before any goal is made.
type Reads = {vars: Set<string>, maps: Set<string>, flags: Set<string>}
function reads(t: E | C, out: Reads = {vars: new Set(), maps: new Set(), flags: new Set()}): Reads {
  switch (t.op) {
    case 'var': out.vars.add(t.name); break
    case 'const': break
    case 'get': out.maps.add(t.map); reads(t.key, out); break
    case 'flag': out.flags.add(t.name); break
    case 'all': { const inner = reads(t.c); for (const key of boundOf(t)) inner.vars.delete(key); for (const k of ['vars', 'maps', 'flags'] as const) for (const name of inner[k]) out[k].add(name); break }
    case 'not': reads(t.x, out); break
    case 'and': case 'or': for (const y of t.xs) reads(y, out); break
    case 'mul': case 'proj': reads(t.a, out); break
    case 'if': reads(t.c, out); reads(t.then, out); reads(t.else, out); break
    case 'add': case 'sub': case 'min': case 'max': case 'prod': case 'tup': case '<': case '<=': case '=': reads(t.a, out); reads(t.b, out); break
    default: unreachable(t)
  }
  return out
}
function inScope(what: string, ts: (E | C)[], vars: string[], maps: string[] = [], flags: string[] = []) {
  for (const t of ts) {
    const r = reads(t)
    for (const name of r.vars) if (!vars.includes(name)) throw new Error(`${what} reads ${name}, which it doesn't declare`)
    for (const map of r.maps) if (!maps.includes(map)) throw new Error(`${what} reads the map ${map}, which it doesn't declare`)
    for (const flag of r.flags) if (!flags.includes(flag)) throw new Error(`${what} reads the flag ${flag}, which it doesn't declare`)
  }
}
// A name the kernel's linear forms would read as something else: '1' is the constant, and '*', '[', ']', ',' and ':'
// build monomials and cells; '#' marks the fresh name a law is proven at (k#, its key's), which a name of the machine or
// another key of the law would capture. Such a name could never be proven about; refused instead, with its name.
// The names the kernel makes are kept apart the same way: '?' a flag's variable ?f and its witnesses w?f, w2?f; '~' a
// state named after a step (s~1); ''' the state and maps after the step (s', M'); '⟦' and '⟧' a term's column (⟦n⟧).
// ('@', a later step's a@2, ?f@2, I@2, is not reserved: compose's steps names its inputs x@s1; stepLawObligations
// keeps a later step's names apart from every name of the machine instead.) A name of the machine, a law's or step
// law's key with one of them would be read as the kernel's own (a param ?f as the flag f's 0/1 variable: "s <= ?f" was
// accepted, false at ?f = 0; Lean refuses it).
const plainName = (what: string, name: string) => { if (name === '1' || /[*[\],:#?~'⟦⟧⟨⟩|]/.test(name)) throw new Error(`${what}: the name ${name} is reserved (1, or * [ ] , : # ? ~ ' ⟦ ⟧ ⟨ ⟩ |)`) }
const distinct = (what: string, names: string[]) => { const seen = new Set<string>(); for (const name of names) { if (seen.has(name)) throw new Error(`${what} declares ${name} twice`); seen.add(name) } }

// A machine (without its history: historyMachine checks that and scopes the plain machine it makes) and its laws. The
// step reads params, inputs and the state before it; a flag reads the flags declared before it; a start value reads the
// params; a law reads the params, the state, the maps and its own key.
export function scope(m: Machine, laws: Law[] = []) {
  const state = Object.keys(m.state), maps = Object.keys(m.maps ?? {}), flags = Object.keys(m.step.flags ?? {}), fns = Object.keys(m.fns ?? {})
  // (a count map is read as a map the request carries; a law reads the counts of the state, countsScope says which)
  const counts = Object.keys(m.counts ?? {}), carried = [...(m.inputMaps ?? []), ...counts]
  const names = [...m.params, ...m.inputs, ...state]
  distinct(m.name, [...names, ...maps, ...carried, ...fns])
  for (const name of [...names, ...maps, ...carried, ...fns, ...flags]) plainName(m.name, name)
  for (const name of Object.keys(m.step.state ?? {})) if (!state.includes(name)) throw new Error(`${m.name}'s step sets ${name}, which isn't in its state`)
  for (const map of Object.keys(m.step.maps ?? {})) if (!maps.includes(map)) throw new Error(`${m.name}'s step writes the map ${map}, which it doesn't declare`)
  // The step reads the maps a request carries too. A key bound by a quantified flag or a write at every key is new and
  // read only as a map's key (so every key the maps hold nothing at reads alike); a quantifier is a whole flag, nowhere
  // else.
  const readable = [...maps, ...carried, ...fns]
  const bound = (what: string, key: string, t: E | C) => {
    plainName(what, key)
    if ([...names, ...readable, ...flags].includes(key)) throw new Error(`${what}: the key ${key} is already a name of ${m.name}`)
    // (a count map, like a function, has a value at every key, not cells a runtime can list: read at no key term)
    keyOnly(what, t, key, [...fns, ...counts])
  }
  inScope(`${m.name}'s start`, Object.values(m.state), m.params)
  flags.forEach((f, i) => {
    const c = m.step.flags![f]!, what = `${m.name}'s flag ${f}`
    // A quantified flag's body reads no flag (the twin decides quantified flags before the plain ones).
    if (c.op === 'all') {
      const keys = boundOf(c), body = crossFree(c.c, keys)
      distinct(what, keys)
      for (const key of keys) { bound(what, key, body); apart(what, body, key, keys) }
      unquantified(what, c.c); inScope(what, [c.c], [...names, ...keys], readable, [])
    }
    else { unquantified(what, c); inScope(what, [c], names, readable, flags.slice(0, i)) }
  })
  const arity = mapArities(m, laws)
  for (const [map, w] of Object.entries(m.step.maps ?? {})) {
    const what = `${m.name}'s write to ${map}`
    // At every key of a tuple-keyed map, the key is read as its parts (proj k, or the key whole at a read of the map):
    // the runtimes compute the write at every tuple of parts, each part read as a bound key is.
    if ('each' in w && (own(arity, map) ?? 1) > 1) {
      const t = eachParts(w, arity[map]!)
      plainName(what, w.each)
      if (readsKey(t.value, w.each)) throw new Error(`${what}: the key ${w.each} is read as its ${arity[map]} parts (or whole, as the key of a map of ${arity[map]}), nothing else`)
      for (const key of t.names) { bound(what, key, t.value); apart(what, crossFree({op: '=', a: t.value, b: {op: 'const', value: 0}}, t.names), key, t.names) }
      unquantified(what, w.value); inScope(what, [t.value], [...names, ...t.names], readable, flags)
    }
    else if ('each' in w) { bound(what, w.each, w.value); unquantified(what, w.value); inScope(what, [w.value], [...names, w.each], readable, flags) }
    else { unquantified(what, w.key); unquantified(what, w.value); inScope(what, [w.key, w.value], names, readable, flags) }
  }
  for (const e of Object.values(m.step.state ?? {})) unquantified(`${m.name}'s step`, e)
  inScope(`${m.name}'s step`, Object.values(m.step.state ?? {}), names, readable, flags)
  if (m.assume) { unquantified(`${m.name}'s assumption`, m.assume); inScope(`${m.name}'s assumption`, [m.assume], names, readable, flags) }
  if (m.pre) inScope(`${m.name}'s precondition`, [m.pre], m.params)
  const facts = m.facts ?? []
  distinct(`${m.name}'s laws and facts`, [...laws, ...facts].map(l => l.name))
  for (const law of [...laws, ...facts]) {
    const what = facts.includes(law) ? `fact ${law.name}` : `law ${law.name}`
    for (const key of [law.forall, ...(law.keys ?? [])]) if (key) { plainName(what, key); if ([...names, ...maps, ...carried, ...fns].includes(key)) throw new Error(`${what}'s key ${key} is already a name of ${m.name}`) }
    if (law.keys?.length && (!law.forall || new Set([law.forall, ...law.keys]).size !== law.keys.length + 1)) throw new Error(`${what}: further keys come with a first, each a different name`)
    if (law.name.startsWith('?')) throw new Error(`${what}: a name starting with ? is a flag's (its instances)`)
    unquantified(what, law.holds)
  }
  const keysOf = (l: Law) => [...(l.forall ? [l.forall] : []), ...(l.keys ?? [])]
  for (const law of laws) inScope(`law ${law.name}`, [law.holds], [...m.params, ...state, ...keysOf(law)], [...maps, ...fns, ...stateCounts(m)])
  countsScope(m, laws)
  // A fact reads the params and the functions alone: what holds of them holds at every state.
  for (const fact of facts) inScope(`fact ${fact.name}`, [fact.holds], [...m.params, ...keysOf(fact)], fns)
}

// Each map's number of parts (1 a plain key): every read and every write of a map is at keys of one shape, so a tuple
// map's cells are its tuples alone (the runtimes keep them apart from a plain key's). A function, a count and a carried
// map take plain keys.
// Lean keyArity at an empty path: projected tuple tails have the arity of their linear parts.
const keyArity = (key: E): number => keyParts(key, new Map())?.length ?? tupleParts(key).length
export function mapArities(m: Machine, laws: Law[] = []): Record<string, number> {
  const out: Record<string, number> = Object.create(null)
  const plainOnly = new Set([...Object.keys(m.fns ?? {}), ...Object.keys(m.counts ?? {}), ...(m.inputMaps ?? [])])
  const note = (map: string, key: E) => {
    const n = keyArity(key), had = own(out, map)
    if (had !== undefined && had !== n) throw new Error(`${m.name}: the map ${map} is read at keys of ${had} and of ${n} parts`)
    if (n > 1 && plainOnly.has(map)) throw new Error(`${m.name}: ${map} is a function, a count or a carried map, read at plain keys only`)
    out[map] = n
  }
  walkTerms([...machineTermsOf(m), ...laws.map(l => l.holds)], o => { if (o.op === 'get' && typeof o.map === 'string' && o.key) note(o.map, o.key as E) })
  for (const [map, w] of Object.entries(m.step.maps ?? {})) if (!('each' in w)) note(map, w.key)
  return out
}
const walkTerms = (ts: unknown[], f: (o: Record<string, unknown>) => void): void => {
  const go = (t: unknown): void => { if (Array.isArray(t)) { t.forEach(go); return } if (!t || typeof t !== 'object') return; f(t as Record<string, unknown>); for (const x of Object.values(t)) go(x) }
  ts.forEach(go)
}
const machineTermsOf = (m: Machine): unknown[] => [m.state, m.step, m.pre, m.assume, m.facts, m.history, m.sums, m.counts, m.leasts]
// A write at every key of an n-part map, read at its parts: the key named each, at k.1 … k.n (each$1 …), the value with
// the key the tuple of them and each part read back (proj of a tuple its part), so it reads the parts as bound keys.
export function eachParts(w: {each: string, value: E}, n: number): {names: string[], value: E} {
  const names = Array.from({length: n}, (_, i) => `${w.each}$${i + 1}`)
  // (the flags it reads left as they are)
  const flags: Record<string, C> = Object.fromEntries([...JSON.stringify(w.value).matchAll(/"op":"flag","name":"((?:[^"\\]|\\.)*)"/g)].map(m => [JSON.parse(`"${m[1]}"`), {op: 'flag', name: JSON.parse(`"${m[1]}"`)} as C]))
  const at = substE(w.value, {vars: {[w.each]: tuple(names.map((name): E => ({op: 'var', name})))}, maps: {}, flags})
  return {names, value: projected(at)}
}
// proj of a tuple read as its part, throughout.
export function projected(e: E): E {
  switch (e.op) {
    case 'var': case 'const': return e
    case 'proj': { const a = projected(e.a); return a.op === 'tup' ? (e.k === 0 ? a.a : a.b) : {op: 'proj', k: e.k, a} }
    case 'mul': return {...e, a: projected(e.a)}
    case 'get': return {...e, key: projected(e.key)}
    case 'if': return {op: 'if', c: projectedC(e.c), then: projected(e.then), else: projected(e.else)}
    case 'add': case 'sub': case 'min': case 'max': case 'prod': case 'tup': return {...e, a: projected(e.a), b: projected(e.b)}
    default: return unreachable(e)
  }
}
export const projectedC = (c: C): C => c.op === 'not' ? {op: 'not', x: projectedC(c.x)} : c.op === 'and' || c.op === 'or' ? {op: c.op, xs: c.xs.map(projectedC)}
  : c.op === 'all' ? {...c, c: projectedC(c.c)} : c.op === 'flag' ? c : {...c, a: projected(c.a), b: projected(c.b)}

// A key bound in t is read in key terms only: the key, or the key plus or less a term that doesn't read it (k + e, e + k,
// k ∸ e), each a map's key (no function's or count's: their values don't stop where a map's cells do) or a side of a
// comparison whose other side doesn't read the key. Then t is constant between finitely many keys (the runtimes'
// breakpoints: each map's cells and each compared value, shifted by the offsets), so a runtime decides it on those.
const readsKey = (t: E | C, key: string) => JSON.stringify(t).includes(`"op":"var","name":${JSON.stringify(key)}`)
// A tuple key's parts each read the same way: the key alone in a part, or plus or less a term that doesn't read it; a
// comparison of two tuples of as many parts compares them part by part.
const tupleSides = (u: Extract<C, {a: E}>): [E, E][] | undefined => {
  if (u.op !== '=' || u.a.op !== 'tup' || u.b.op !== 'tup') return undefined
  const as = tupleParts(u.a), bs = tupleParts(u.b)
  return as.length === bs.length ? as.map((a, i) => [a, bs[i]!]) : undefined
}
export const keyTerm = (e: E, key: string): boolean => e.op === 'var' ? e.name === key
  : e.op === 'add' ? (e.a.op === 'var' && e.a.name === key && !readsKey(e.b, key)) || (e.b.op === 'var' && e.b.name === key && !readsKey(e.a, key))
  : e.op === 'sub' && e.a.op === 'var' && e.a.name === key && !readsKey(e.b, key)
function keyOnly(what: string, t: E | C, key: string, fns: string[] = []): void {
  const bad = () => { throw new Error(`${what}: the key ${key} is read only in a map's key or a comparison, alone or plus or less a term that doesn't read it`) }
  const walk = (u: E | C): void => {
    switch (u.op) {
      case 'var': if (u.name === key) bad(); break
      case 'get':
        if (u.key.op === 'tup' && !fns.includes(u.map)) { for (const part of tupleParts(u.key)) if (!keyTerm(part, key)) walk(part) }
        else if (!(keyTerm(u.key, key) && !fns.includes(u.map))) walk(u.key)
        break
      case 'const': case 'flag': break
      case 'not': walk(u.x); break
      case 'all': walk(u.c); break
      case 'and': case 'or': u.xs.forEach(walk); break
      case 'mul': case 'proj': walk(u.a); break
      case 'if': walk(u.c); walk(u.then); walk(u.else); break
      case '<': case '<=': case '=': {
        const side = (a: E, b: E) => { if (keyTerm(a, key) && !readsKey(b, key)) walk(b); else if (keyTerm(b, key) && !readsKey(a, key)) walk(a); else { walk(a); walk(b) } }
        const pairs = tupleSides(u)
        if (pairs) for (const [a, b] of pairs) side(a, b); else side(u.a, u.b)
        break
      }
      case 'add': case 'sub': case 'min': case 'max': case 'prod': case 'tup': walk(u.a); walk(u.b); break
      default: unreachable(u)
    }
  }
  walk(t)
}
// Over several keys, each read apart from the others: no offset of its key terms, and no value it is compared with, reads
// another (the comparisons between two of them, plainly, are set aside before: crossFree).
function apart(what: string, t: C, key: string, keys: string[]): void {
  const others = keys.filter(k => k !== key), other = (e: E) => others.some(k => readsKey(e, k))
  const cmp = (a: E, b: E) => (keyTerm(a, key) && (other(a) || other(b))) || (keyTerm(b, key) && (other(a) || other(b)))
  const walk = (u: E | C): void => {
    if ((u.op === 'get' && (u.key.op === 'tup' ? tupleParts(u.key).some(p => keyTerm(p, key) && other(p)) : keyTerm(u.key, key) && other(u.key)))
      || ((u.op === '<' || u.op === '<=' || u.op === '=') && (tupleSides(u)?.some(([a, b]) => cmp(a, b)) ?? cmp(u.a, u.b))))
      throw new Error(`${what}: the keys ${keys.join(', ')} are each read on their own, and compared with one another only plainly (i < j, i <= j, i = j)`)
    for (const x of Object.values(u)) if (x && typeof x === 'object') (Array.isArray(x) ? x : [x]).forEach(y => walk(y as E | C))
  }
  walk(t)
}
// Whether the key is read only as a map's key, plainly (what the GPU searches decide: every cell, and one past them).
export const plainKey = (t: E | C, key: string): boolean => {
  const walk = (u: E | C): boolean => {
    switch (u.op) {
      case 'var': return u.name !== key
      case 'get': return (u.key.op === 'var' && u.key.name === key) || walk(u.key)
      case 'const': case 'flag': return true
      case 'not': return walk(u.x)
      case 'all': return walk(u.c)
      case 'and': case 'or': return u.xs.every(walk)
      case 'mul': case 'proj': return walk(u.a)
      case 'if': return walk(u.c) && walk(u.then) && walk(u.else)
      case 'add': case 'sub': case 'min': case 'max': case 'prod': case 'tup': case '<': case '<=': case '=': return walk(u.a) && walk(u.b)
      default: return unreachable(u)
    }
  }
  return walk(t)
}
// No quantifier inside t: a quantifier is a whole flag.
function unquantified(what: string, t: E | C): void {
  if (JSON.stringify(t).includes('"op":"all"')) throw new Error(`${what}: a condition at every key is a flag of its own (flags: {name: all(...)})`)
}

// --- histories ---------------------------------------------------------------------------------------------------------

// A term or condition that reads only these names, and no map.
const readsOnly = (t: E | C, names: string[]): boolean => !JSON.stringify(t).includes('"op":"get"') && !JSON.stringify(t).includes('"op":"flag"') && (JSON.stringify(t).match(/"name":"([^"]+)"/g) ?? []).every(m => names.includes(m.slice(8, -1)))
const homogeneous = (e: E, names: string[]): boolean => e.op === 'var' ? names.includes(e.name) : e.op === 'add' ? homogeneous(e.a, names) && homogeneous(e.b, names) : e.op === 'mul' ? Number.isInteger(e.k) && e.k >= 0 && homogeneous(e.a, names) : false

// A machine with a history as a plain one: each sum a state variable from 0, plus its term at the request whenever the
// step keeps the request; each query an input; each relation part of the step's assumption. Sound because, at every
// step, a sum is the sum of its term over the history so far and a query the sum of its term over the same records:
// a relation that holds record by record (the goals returned, one per relation, over a record's fields as free
// naturals) holds of the sums, since a and b are linear without a constant and `when` doesn't read the record.
export function historyMachine(m: Machine): {machine: Machine, goals: Goal[]} {
  const h = m.history
  if (!h) return {machine: m, goals: []}
  const queries = Object.keys(h.queries), sums = Object.keys(h.sums), plainInputs = m.inputs.filter(i => !queries.includes(i))
  const fields = h.record.map(f => `r.${f}`)
  const taken = [...m.params, ...m.inputs, ...Object.keys(m.state), ...Object.keys(m.step.state ?? {})]
  // r.<field> names a record's field and nothing else: a param, input or state variable of that name would be read as
  // the field in the per-record goal and as itself in `pre` and `when`.
  const ok = [...taken, ...sums].every(name => !name.startsWith('r.'))
    && queries.every(q => m.inputs.includes(q)) && h.record.every(f => plainInputs.includes(f)) && sums.every(s => !taken.includes(s))
    && Object.values(h.sums).every(g => natural(g) && readsOnly(g, [...fields, ...m.params]))
    && Object.values(h.queries).every(g => natural(g) && readsOnly(g, [...fields, ...m.params, ...plainInputs])) && naturalC(h.keep)
    && (h.relations ?? []).every(r => naturalC(r.when) && readsOnly(r.when, [...m.params, ...plainInputs]) && r.holds.op === '<=' && homogeneous(r.holds.a, [...sums, ...queries]) && homogeneous(r.holds.b, [...sums, ...queries]))
  if (!ok) throw new Error('a history: sums read the record and params, queries also the request\'s other inputs, relations are homogeneous a <= b under a condition on the params and the request')
  inScope(`${m.name}'s keep`, [h.keep], [...m.params, ...m.inputs, ...Object.keys(m.state), ...sums], Object.keys(m.maps ?? {}), Object.keys(m.step.flags ?? {}))
  if (h.prune && !(h.record.includes(h.prune.order) && natural(h.prune.after) && readsOnly(h.prune.after, m.params))) throw new Error('a history is pruned by a recorded input and a term over the params')
  const atRequest: Subst = {vars: Object.fromEntries(h.record.map(f => [`r.${f}`, {op: 'var', name: f} as E])), maps: {}, flags: {}}
  // The relations conjoined to the assumption as the Lean twin builds them (History.lean's HMachine.plain: assume ∧
  // r₁ ∧ … ∧ true), so the two read the same assumption.
  const TRUE: C = {op: '<=', a: {op: 'const', value: 0}, b: {op: 'const', value: 0}}
  const relations = (h.relations ?? []).map(r => ({op: 'or', xs: [{op: 'not', x: r.when}, r.holds]}) as C).reduceRight<C>((acc, r) => ({op: 'and', xs: [r, acc]}), TRUE)
  const machine: Machine = {
    ...m, history: undefined,
    state: {...m.state, ...Object.fromEntries(sums.map(s => [s, {op: 'const', value: 0} as E]))},
    step: {...m.step, state: {...m.step.state, ...Object.fromEntries(sums.map(s => [s, {op: 'add', a: {op: 'var', name: s}, b: {op: 'if', c: h.keep, then: substE(h.sums[s]!, atRequest), else: {op: 'const', value: 0}}} as E]))}},
    assume: {op: 'and', xs: [m.assume ?? TRUE, relations]},
  }
  const perRecord: Subst = {vars: {...h.sums, ...h.queries}, maps: {}, flags: {}}
  const goals = (h.relations ?? []).map((r, i) => ({name: `relation ${i + 1} @record`, hyps: [...preOf(m), r.when, {op: 'not', x: substC(r.holds, perRecord)} as C]}))
  // Pruning: a record whose order plus `after` is at most the request's adds nothing to any query. With requests in
  // nondecreasing order (the runtimes refuse one that goes back), such a record adds nothing to any later query either,
  // so dropping it changes no query: these goals are about the runtimes, the laws are proven over the whole history.
  if (h.prune) {
    const {order, after} = h.prune
    const gone: C = {op: '<=', a: {op: 'add', a: {op: 'var', name: `r.${order}`}, b: after}, b: {op: 'var', name: order}}
    for (const [q, g] of Object.entries(h.queries)) goals.push({name: `prune @query ${q}`, hyps: [...preOf(m), gone, {op: 'not', x: {op: '<=', a: g, b: {op: 'const', value: 0}}}]})
  }
  return {machine, goals}
}

// --- sums over a map's keys (Sums.lean) ---------------------------------------------------------------------------

// A machine with sums as a plain one, as Sums.lean's SumMachine.plain builds it: each sum S a state variable from 0, after
// each step (S + new) ∸ old, where old and new are the term's values at the cover keys (each key once: a key equal to an
// earlier one adds 0) before and after the step; conjoined to the assumption, old ≤ S and a quantified flag that holds
// at every key k: the term at k and at the cover keys, each once, is at most S. Sound because every sum is exact in every
// reachable state (Sums.lean's sum_holds): the term starts 0 at every key, a step changes it at the cover keys alone
// (a map it reads written at one key: that key; written at every key: the keys its value compares the bound key with,
// each other key kept, the cover goals returned), so the facts hold of every request there (sum_allowed). The cover keys
// read no flag (a quantified flag reads none; Lean inlines the rest, here nothing to inline).
const ZERO: E = {op: 'const', value: 0}
const TRUE_C: C = {op: '<=', a: ZERO, b: ZERO}
// Sums.lean's dTermE: G at each listed key, a key equal to an earlier one read as 0.
const dTerm = (G: (t: E) => E, cs: E[]): E => (cs.length ? {op: 'add', a: G(cs[0]!), b: dTerm(t => ({op: 'if', c: {op: '=', a: t, b: cs[0]!}, then: ZERO, else: G(t)}), cs.slice(1))} : ZERO)
// A term over the maps at the key alone (Sums.lean's gOkE): no variable but in a map's key, and that key the variable.
const sumTermOk = (e: E, key: string): boolean => {
  switch (e.op) {
    case 'var': return false
    case 'const': return true
    case 'get': return e.key.op === 'var' && e.key.name === key
    case 'mul': return sumTermOk(e.a, key)
    case 'if': return sumCondOk(e.c, key) && sumTermOk(e.then, key) && sumTermOk(e.else, key)
    case 'add': case 'sub': case 'min': case 'max': case 'prod': return sumTermOk(e.a, key) && sumTermOk(e.b, key)
    case 'tup': case 'proj': return false
    default: return unreachable(e)
  }
}
const sumCondOk = (c: C, key: string): boolean => c.op === 'flag' || c.op === 'all' ? false : c.op === 'not' ? sumCondOk(c.x, key)
  : c.op === 'and' || c.op === 'or' ? c.xs.every(y => sumCondOk(y, key)) : sumTermOk(c.a, key) && sumTermOk(c.b, key)
// The names a sum's parts go by: its quantified flag, the cover goals' key.
export const sumParts = (s: string) => ({flag: `cells$${s}`, x: `x$${s}`})
// The keys a write at every key compares its bound key with (k = t, t not reading k): where else it keeps every cell.
function comparedKeys(t: E | C, key: string, out: Map<string, E>): void {
  if (t.op === '=' && t.a.op === 'var' && t.a.name === key && !readsKey(t.b, key)) out.set(JSON.stringify(t.b), t.b)
  else if (t.op === '=' && t.b.op === 'var' && t.b.name === key && !readsKey(t.a, key)) out.set(JSON.stringify(t.a), t.a)
  for (const x of Object.values(t)) if (x && typeof x === 'object') (Array.isArray(x) ? x : [x]).forEach(y => comparedKeys(y as E | C, key, out))
}
// Each sum's cover keys, in the order of the maps its term reads (first read first).
export function sumCovers(m: Machine): Record<string, E[]> {
  return Object.fromEntries(Object.entries(m.sums ?? {}).map(([s, sum]) => {
    const out = new Map<string, E>()
    for (const map of [...new Set([...JSON.stringify(sum.term).matchAll(/"op":"get","map":"([^"]+)"/g)].map(x2 => x2[1]!))]) {
      const w = own(m.step.maps ?? {}, map)
      if (!w) continue
      if ('each' in w) comparedKeys(w.value, w.each, out)
      else out.set(JSON.stringify(w.key), w.key)
    }
    return [s, [...out.values()]]
  }))
}
// The cells' laws at a cover goal's key x (Sums.lean's cellLaws): each law about one key (no further key) that reads
// nothing but cells of the maps the term reads, at its key, read at x. A cell's kind is one (a yes/no at most 1, a
// choice below its count): the cover goal may lean on it because the laws are proven with it (Sums.lean's sum_cells).
const cellLaws = (laws: Law[], read: string[], x: E): C[] => laws.flatMap(l => (l.forall && !l.keys?.length && sumCondOk(l.holds, l.forall)
  && [...JSON.stringify(l.holds).matchAll(/"op":"get","map":"([^"]+)"/g)].every(y => read.includes(y[1]!)) ? [substC(l.holds, {vars: {[l.forall]: x}, maps: {}, flags: {}})] : []))
// `given`: each sum's cover keys (core/conformance.ts's tampered twins), else sumCovers'. `laws`: the laws proven with
// the cover goals, whose cells' laws they assume.
export function sumMachine(m: Machine, given?: Record<string, E[]>, laws: Law[] = []): {machine: Machine, goals: Goal[]} {
  const sums = Object.entries(m.sums ?? {})
  if (!sums.length) return {machine: m, goals: []}
  if (m.history) throw new Error(`${m.name}: sums over a map's keys go on a machine without a history`)
  const covers = given ?? sumCovers(m), flags = m.step.flags ?? {}
  // (substitutions that leave each flag as it is: Lean reads a flag as its variable in the step's view)
  const same: Record<string, C> = Object.fromEntries(Object.keys(flags).map(f => [f, {op: 'flag', name: f} as C]))
  // (a sum may be declared in the state, at 0, which no step sets: a state variable the plain machine moves)
  for (const [s] of sums) if (Object.hasOwn(m.state, s) && JSON.stringify(m.state[s]) !== JSON.stringify(ZERO) || Object.hasOwn(m.step.state ?? {}, s)) throw new Error(`${m.name}: the sum ${s} starts at 0 and no step sets it`)
  // (every name the machine has, as the Lean twin numbers them: a flag f's variable ?f, a quantified flag's witnesses,
  // the keys writes at every key and quantified flags bind)
  const names = [...m.params, ...m.inputs, ...Object.keys(m.state).filter(n => !Object.hasOwn(m.sums!, n)), ...Object.keys(m.maps ?? {}), ...(m.inputMaps ?? []), ...Object.keys(m.fns ?? {}),
    ...Object.keys(flags), ...Object.keys(flags).map(f => `?${f}`), ...Object.entries(flags).flatMap(([f, c]) => (c.op === 'all' ? [...witnessesOf(f, c), ...boundOf(c)] : [])),
    ...Object.values(m.step.maps ?? {}).flatMap(w => ('each' in w ? [w.each] : []))]
  const steps: Record<string, E> = Object.create(null), qflags: Record<string, C> = Object.create(null), facts: C[] = [], goals: Goal[] = []
  for (const [s, sum] of sums) {
    const {term, key} = sum, {flag, x} = sumParts(s), cs = own(covers, s)!
    const read = [...new Set([...JSON.stringify(term).matchAll(/"op":"get","map":"([^"]+)"/g)].map(x2 => x2[1]!))]
    const bad = (why: string) => { throw new Error(`${m.name}: the sum ${s}: ${why}`) }
    for (const name of [s, key, flag, x]) { plainName(m.name, name); if (names.includes(name) || Object.hasOwn(m.sums ?? {}, name) && name !== s) bad(`${name} is already a name of the machine`) }
    if (new Set([s, key, flag, x, `?${flag}`, `w?${flag}`]).size !== 6 || names.includes(`?${flag}`) || names.includes(`w?${flag}`)) bad('its names collide')
    if (!natural(term) || !sumTermOk(term, key)) bad(`its term reads the maps at ${key} alone, and no other name`)
    for (const map of read) {
      if ((m.inputMaps ?? []).includes(map) || Object.hasOwn(m.fns ?? {}, map) || !Object.hasOwn(m.maps ?? {}, map)) bad(`${map} is not a map of the machine's state`)
    }
    // 0 where every map holds its start value (Sums.lean's startVal: the term with each read its map's start).
    const atStart = substE(term, {vars: {}, maps: Object.fromEntries(read.map(map => [map, () => ({op: 'const', value: m.maps![map]!} as E)])), flags: same})
    if (natE(atStart, {}) !== 0n) bad('its term is not 0 at the start')
    for (const c of cs) if (JSON.stringify(c).includes('"op":"flag"') || readsKey(c, key) || readsKey(c, x)) bad('a key a step writes it at reads a flag')
    // (Sums.lean's sumOk1: a map the term reads written at one key has that key among the cover keys)
    for (const map of read) { const w = own(m.step.maps ?? {}, map); if (w && !('each' in w) && !cs.some(c => JSON.stringify(c) === JSON.stringify(w.key))) bad(`the key ${map} is written at is no cover key`) }
    const here = (t: E): E => substE(term, {vars: {[key]: t}, maps: {}, flags: same})
    // A map read after the step, over the step's view (Sums.lean's postRd).
    const post = (map: string) => (k2: E): E => {
      const w = own(m.step.maps ?? {}, map)
      if (!w) return {op: 'get', map, key: k2}
      if ('each' in w) return substE(w.value, {vars: {[w.each]: k2}, maps: {}, flags: same})
      return {op: 'if', c: {op: '=', a: k2, b: w.key}, then: w.value, else: {op: 'get', map, key: k2}}
    }
    const after = (t: E): E => substE(term, {vars: {[key]: t}, maps: Object.fromEntries(read.map(map => [map, post(map)])), flags: same})
    const S: E = {op: 'var', name: s}
    steps[s] = {op: 'sub', a: {op: 'add', a: S, b: dTerm(after, cs)}, b: dTerm(here, cs)}
    qflags[flag] = {op: 'all', key, c: {op: '<=', a: dTerm(here, [{op: 'var', name: key}, ...cs]), b: S}}
    facts.push({op: 'and', xs: [{op: '<=', a: dTerm(here, cs), b: S}, {op: 'flag', name: flag}]})
    // A map it reads written at every key: at a key none of the cover keys is, the write keeps the cell. Built as
    // Sums.lean's sumCoverGoal builds it (each write at every key in the machine's order, its flags inlined as Lean
    // inlines them: a flag f read as (if f's condition then 1 else 0) = 1), so the Lean export reads these goals as they are.
    const lean: Subst = {vars: {}, maps: {}, flags: Object.fromEntries(Object.entries(flagsOf(m)).map(([f, c]): [string, C] => [f, flags[f]!.op === 'all' ? c
      : {op: '=', a: {op: 'if', c, then: {op: 'const', value: 1}, else: ZERO}, b: {op: 'const', value: 1}}]))}
    for (const [map, w] of Object.entries(m.step.maps ?? {})) {
      if (!('each' in w) || !read.includes(map)) continue
      const X: E = {op: 'var', name: x}
      goals.push({name: `${s} @cover ${map}`, hyps: [substC(m.assume ?? TRUE_C, lean), ...cellLaws(laws, read, X), ...cs.map((c): C => ({op: 'not', x: {op: '=', a: X, b: c}})),
        {op: 'not', x: {op: '=', a: substE(substE(w.value, lean), {vars: {[w.each]: X}, maps: {}, flags: {}}), b: {op: 'get', map, key: X}}}]})
    }
  }
  // (Sums.lean's sumsC: each sum's facts, then the rest, ending in 0 ≤ 0)
  const assumed = facts.reduceRight<C>((acc, f) => ({op: 'and', xs: [f, acc]}), TRUE_C)
  const machine: Machine = {
    ...m, sums: undefined,
    state: {...m.state, ...Object.fromEntries(sums.map(([s]) => [s, ZERO]))},
    step: {...m.step, flags: {...flags, ...qflags}, state: {...m.step.state, ...steps}},
    assume: {op: 'and', xs: [m.assume ?? TRUE_C, assumed]},
  }
  return {machine, goals}
}
// The machine the runtimes step: each sum a state variable kept exact by its step, the rule's own assumption.
export function sumRuntime(m: Machine): Machine {
  if (!m.sums || !Object.keys(m.sums).length) return m
  const {machine} = sumMachine(m)
  const flags = Object.fromEntries(Object.entries(machine.step.flags ?? {}).filter(([f]) => !Object.keys(m.sums!).some(s => sumParts(s).flag === f)))
  return {...machine, step: {...machine.step, flags}, assume: m.assume}
}
// The plain machine any claim is proven of: with a history kernel.ts's historyMachine's, with sums sumMachine's.
export const plainOf = (m: Machine): Machine => (m.history ? historyMachine(m).machine : m.sums && Object.keys(m.sums).length ? sumMachine(m).machine : m)
// The goals beside a plain machine's own: a history's record goals, the sums' cover goals (over the laws proven with them).
export const sideGoals = (m: Machine, laws: Law[] = []): Goal[] => (m.history ? historyMachine(m).goals : m.sums && Object.keys(m.sums).length ? sumMachine(m, undefined, laws).goals : [])

// `only`: the goals of that law alone (the prover's instance search asks for one law's at a time).
export function obligations(m: Machine, laws: Law[], instances: Record<string, Instances> = {}, only?: number): Goal[] {
  if (m.history || (m.sums && Object.keys(m.sums).length)) { const goals = only === undefined ? sideGoals(m, laws) : []; return [...obligations(plainOf(m), laws, instances, only), ...goals] }
  // (a count changes with the state: a law reading one is read after the step at its post name, countedObligations')
  if (m.counts && Object.keys(m.counts).length) throw new Error(`${m.name} counts: its goals are countedObligations'`)
  scope(m, laws)
  const ok = [...Object.values(m.state), ...Object.values(m.step.state ?? {}), ...Object.values(m.step.maps ?? {}).flatMap(w => ('each' in w ? [w.value] : [w.key, w.value]))].every(natural)
    && Object.values(m.step.flags ?? {}).every(naturalC) && laws.every(l => naturalC(l.holds)) && Object.values(m.maps ?? {}).every(c => Number.isInteger(c) && c >= 0)
  if (!ok || !(m.facts ?? []).every(l => naturalC(l.holds)) || laws.some(l => mentions(l.holds, m.inputs))) throw new Error('a negative constant or factor, or a law about a request, is outside the kernel')
  // A law that holds at every key is proven at a fresh one.
  // A law about every two keys keeps its second key as it is: a fresh name nothing else reads, so the goal is about every
  // value of it too (the Lean twin reads it so).
  const proven = (law: Law) => (law.forall ? substC(law.holds, {vars: {[law.forall]: {op: 'var', name: `${law.forall}#`}}, maps: {}, flags: {}}) : law.holds)
  const pre = preOf(m), u = updateOf(m), assume = m.assume ? [inlineFlags(m, m.assume)] : []
  return laws.flatMap((law, i) => {
    if (only !== undefined && i !== only) return []
    // At the start: the precondition, and no request. One step: from a state where the laws hold, a request allowed.
    // The facts hold throughout, read where the run begins (they read no state).
    const inst = own(instances, law.name) ?? {}
    const start = given(m, holds(from(startOf(m)), pre), inst)
    const turn = step(holds(given(m, from(), inst), [...pre, ...assume, ...assumed(laws, inst), ...closing(m, inst)]), u)
    return [goal(`${law.name} @start`, start, atEnd(start, proven(law))), goal(`${law.name} @step`, turn, atEnd(turn, proven(law)))]
  })
}

// The whole set at once: every goal has a tree, and every tree checks.
export function checkLaws(m: Machine, laws: Law[], proof: {instances: Record<string, Instances>, trees: Record<string, Tree>}): boolean {
  return obligations(m, laws, proof.instances).every(g => { const t = own(proof.trees, g.name); return t !== undefined && check(g, t) })
}

// --- loops: termination ------------------------------------------------------------------------------------------------

// A loop runs `body` while `while` holds; each turn may read fresh inputs (a server's delay, a page's size). It halts if a
// natural-valued rank, over the state and params, drops on every turn the invariants allow: naturals can't drop forever.
export type Loop = {name: string, params: string[], inputs: string[], state: Record<string, E>, while: C, body: Record<string, E>, pre?: C, assume?: C}

// A loop is a machine: its state, a turn's inputs as a request, its body taken where `while` holds and the state kept
// where it fails. Its invariants are the machine's laws, and that it halts is a liveness: from anywhere, `while` fails
// later, every request helpful, the rank the loop's (Live.lean's Loop.machine and loop_halts_of: then no run of turns is
// infinite). `while` and the rank read the state and params, not the turn's input.
// A rank may be a tuple, compared in order (lexicographically): the first part drops, or it stays and the rest drops.
// Tuples of naturals can't drop forever either; nested loops need them (an outer count, then an inner one).
// A rank reads the state and params only: one that reads the turn's input drops against this turn's input, but the next
// turn measures it with a fresh one, so nothing need decrease (while x < w, x := x + 1, rank w ∸ x, w = x + 1 each turn).
export const loopMachine = (l: Loop): Machine => ({
  name: l.name, params: l.params, inputs: l.inputs, state: l.state,
  step: {state: Object.fromEntries(Object.entries(l.body).map(([v, e]) => [v, {op: 'if', c: l.while, then: e, else: {op: 'var', name: v}} as E]))},
  ...(l.pre ? {pre: l.pre} : {}), ...(l.assume ? {assume: l.assume} : {}),
})
export const loopLiveness = (l: Loop, rank: E | E[]): Liveness => ({name: `${l.name} halts`, from: trueC, to: {op: 'not', x: l.while}, rank, request: {}})
export function loopObligations(l: Loop, laws: Law[], rank: E | E[]): Goal[] {
  const ranks = Array.isArray(rank) ? rank : [rank]
  const parts = [...Object.values(l.state), ...Object.values(l.body), ...ranks]
  const names = [...l.params, ...l.inputs, ...Object.keys(l.state)]
  distinct(l.name, names)
  for (const name of Object.keys(l.body)) if (!Object.hasOwn(l.state, name)) throw new Error(`${l.name}'s body sets ${name}, which isn't in its state`)
  inScope(`${l.name}'s start`, Object.values(l.state), l.params)
  inScope(l.name, [...Object.values(l.body), ...(l.assume ? [l.assume] : [])], names)
  inScope(`${l.name}'s while`, [l.while], [...l.params, ...Object.keys(l.state)])
  inScope(`${l.name}'s precondition`, l.pre ? [l.pre] : [], l.params)
  inScope(`${l.name}'s rank and laws`, [...ranks, ...laws.map(law => law.holds)], [...l.params, ...Object.keys(l.state)])
  if (ranks.some(r => mentions({op: '=', a: r, b: r}, l.inputs))) throw new Error('a rank reads the state and params, not the turn\'s input')
  if (!parts.every(natural) || !naturalC(l.while) || !laws.every(law => !law.forall && !law.keys?.length && naturalC(law.holds) && !mentions(law.holds, l.inputs))) throw new Error('outside the kernel')
  const m = loopMachine(l), {stay, cover, helps} = livenessParts(m, loopLiveness(l, rank))
  return [...obligations(m, laws, {}), ...[stay, cover, ...helps].map(sl => stepLawObligations(m, laws, {}, sl)[0]!)]
}

// --- loops: a run that never ends ----------------------------------------------------------------------------------------

// The claim (Lean: NonTerm.lean's `NeverEnds`): for some params meeting the precondition, a run of turns from the start
// goes on forever. The certificate is a closed recurrent set with its successor given (`never_ends_of`): `set`, a
// condition over the state and params; `wit`, a term per input over the state and params, the turn taken from a state of
// the set; `start`, the params' values (every other name 0); `stem`, each turn's inputs (an input not named is 0) from the
// start into the set. The start and the stem are evaluated exactly, as Lean's naturals (bigint, ∸ truncating); the
// closure goal is a kernel goal: a state of the set whose witnessed turn fails `while` or the assumption, or ends outside
// the set. Refuted, the witnessed turn from the set's states, again and again, is a run that never ends. A loop's
// halting (loopObligations) and this claim contradict each other (`halts_not_never_ends`).
export type Recur = {start: Record<string, number>, stem: Record<string, number>[], set: C, wit: Record<string, E>, tree: Tree}
// The closure goal, built as Lean's recurGoal builds it: [set, ¬(while ∧ (assume ∧ set after the body)), each read at the
// witnessed request].
export function recurGoal(l: Loop, r: Pick<Recur, 'set' | 'wit'>): Goal {
  const w: Subst = {vars: r.wit, maps: {}, flags: {}}
  return {name: `${l.name} never ends: the set is closed`, hyps: [r.set, {op: 'not', x: {op: 'and', xs: [substC(l.while, w), substC(l.assume ?? trueC, w),
    substC(substC(r.set, {vars: l.body, maps: {}, flags: {}}), w)]}}]}
}
// Lean's evalE and evalC over naturals with every map cell 0 (NonTerm.lean's noMaps): exact, never rounded.
const natE = (e: E, env: Record<string, bigint>): bigint => {
  switch (e.op) {
    case 'var': return own(env, e.name) ?? 0n
    case 'const': return BigInt(e.value)
    case 'add': return natE(e.a, env) + natE(e.b, env)
    case 'sub': { const d = natE(e.a, env) - natE(e.b, env); return d > 0n ? d : 0n }
    case 'mul': return BigInt(e.k) * natE(e.a, env)
    case 'prod': return natE(e.a, env) * natE(e.b, env)
    case 'min': { const a = natE(e.a, env), b = natE(e.b, env); return a < b ? a : b }
    case 'max': { const a = natE(e.a, env), b = natE(e.b, env); return a > b ? a : b }
    case 'if': return natC(e.c, env) ? natE(e.then, env) : natE(e.else, env)
    case 'get': return 0n
    case 'tup': case 'proj': throw new Error('a loop\'s run is read over no tuple')
    default: return unreachable(e)
  }
}
const natC = (c: C, env: Record<string, bigint>): boolean => {
  switch (c.op) {
    case '<=': return natE(c.a, env) <= natE(c.b, env)
    case '<': return natE(c.a, env) < natE(c.b, env)
    case '=': return natE(c.a, env) === natE(c.b, env)
    case 'and': return c.xs.every(x => natC(x, env))
    case 'or': return c.xs.some(x => natC(x, env))
    case 'not': return !natC(c.x, env)
    case 'flag': case 'all': throw new Error('a loop reads no flag')
    default: return unreachable(c)
  }
}
// Lean's checkRecur: the witness sets only inputs; the start meets the precondition; the stem's turns meet `while` and
// the assumption, and the state after them is in the set; the closure goal's tree checks. A certificate outside the
// language (names the loop doesn't declare, values that aren't naturals, a set reading a turn's input) is refused.
export function checkRecur(l: Loop, r: Recur | RecurCases): boolean { return 'cases' in r ? checkRecurCases(l, r) : stemOk(l, r) && check(recurGoal(l, r), r.tree) }
// Everything but the closure: the language, the witness's names, the start and the stem.
function stemOk(l: Loop, r: Omit<Recur, 'tree'>): boolean {
  const names = [...l.params, ...l.inputs, ...Object.keys(l.state)], values = (o: Record<string, number>) => Object.values(o).every(x => Number.isSafeInteger(x) && x >= 0)
  distinct(l.name, names)
  for (const name of Object.keys(l.body)) if (!Object.hasOwn(l.state, name)) throw new Error(`${l.name}'s body sets ${name}, which isn't in its state`)
  inScope(`${l.name}'s start`, Object.values(l.state), l.params)
  inScope(l.name, [...Object.values(l.body), ...(l.assume ? [l.assume] : [])], names)
  inScope(`${l.name}'s while`, [l.while], [...l.params, ...Object.keys(l.state)])
  inScope(`${l.name}'s precondition`, l.pre ? [l.pre] : [], l.params)
  inScope(`${l.name}'s recurrent set and witness`, [r.set, ...Object.values(r.wit)], [...l.params, ...Object.keys(l.state)])
  if (![...Object.values(l.state), ...Object.values(l.body), ...Object.values(r.wit)].every(natural) || ![l.while, r.set, ...(l.pre ? [l.pre] : []), ...(l.assume ? [l.assume] : [])].every(naturalC)) throw new Error('outside the kernel')
  if (!Object.keys(r.start).every(n => l.params.includes(n)) || !values(r.start) || !r.stem.every(t => Object.keys(t).every(n => l.inputs.includes(n)) && values(t))) throw new Error(`${l.name}: a start names params and a stem's turn inputs, each a natural`)
  if (!Object.keys(r.wit).every(n => l.inputs.includes(n))) return false
  let env: Record<string, bigint> = Object.fromEntries(names.map(n => [n, BigInt(own(r.start, n) ?? 0)]))
  if (!natC(l.pre ?? trueC, env)) return false
  const apply = (body: Record<string, E>, at: Record<string, bigint>) => ({...at, ...Object.fromEntries(Object.entries(body).map(([n, e]) => [n, natE(e, at)]))})
  env = apply(l.state, env)
  for (const turn of r.stem) {
    const at = {...env, ...Object.fromEntries(l.inputs.map(n => [n, BigInt(own(turn, n) ?? 0)]))}
    if (!natC(l.while, at) || !natC(l.assume ?? trueC, at)) return false
    env = apply(l.body, at)
  }
  return natC(r.set, env)
}

// The closure by cases (NonTerm.lean's `never_ends_of_cases`), for a large program's closure goal, which reads every
// rule's body: each case pins some variables to values (a location) and names a condition (the set's part there);
// `cover` refutes the set with no case's pins and condition holding, and each case's goal is [its condition, the
// witnessed turn failing], built at the pins with the constants folded (caseGoals, Lean's caseGoal: the witness and the
// body read at the pins first, so only the location's rules are left). Where the pins hold, substituting them keeps
// every value; folding keeps every value.
export type RecurCases = Omit<Recur, 'tree'> & {cover: Tree, cases: {pins: [string, number][], cond: C, tree: Tree}[]}
const isTC = (c: C) => c.op === '<=' && c.a.op === 'const' && c.b.op === 'const' && c.a.value <= c.b.value
const isFC = (c: C) => c.op === '<' && c.a.op === 'const' && c.b.op === 'const' ? c.b.value <= c.a.value : c.op === '<=' && c.a.op === 'const' && c.b.op === 'const' && c.b.value < c.a.value
const kE = (value: number): E => ({op: 'const', value})
// Lean's folds, on kernel.ts's terms: an and of several (Lean: each and of two, nested to the right) is false if one is,
// else the rest that aren't true, and so for or; read through the Lean text, the two give the same terms.
// A constant folded past a safe integer is left unfolded (`kF`): its float may be rounded (2 + (2^53 - 1) is 2^53), and
// the term unfolded has its value exactly, which the kernel's linear forms then refuse (Lean's Nat folds it exactly).
const kF = (value: number, e: E): E => (Number.isSafeInteger(value) ? kE(value) : e)
const foldMul = (k0: number, a: E): E => (k0 === 0 ? kE(0) : k0 === 1 ? a : a.op === 'const' ? kF(k0 * a.value, {op: 'mul', k: k0, a}) : {op: 'mul', k: k0, a})
function foldTerm(e: E, f: (e: E) => E, fc: (c: C) => C): E {
  switch (e.op) {
    case 'var': case 'const': return e
    case 'add': { const a = f(e.a), b = f(e.b); return a.op === 'const' && a.value === 0 ? b : b.op === 'const' && b.value === 0 ? a : a.op === 'const' && b.op === 'const' ? kF(a.value + b.value, {op: 'add', a, b}) : {op: 'add', a, b} }
    case 'sub': { const a = f(e.a), b = f(e.b); return b.op === 'const' && b.value === 0 ? a : a.op === 'const' && b.op === 'const' ? kF(Math.max(0, a.value - b.value), {op: 'sub', a, b}) : {op: 'sub', a, b} }
    case 'mul': return foldMul(e.k, f(e.a))
    case 'min': case 'max': { const a = f(e.a), b = f(e.b); return a.op === 'const' && b.op === 'const' ? kE(Math[e.op](a.value, b.value)) : {op: e.op, a, b} }
    case 'prod': { const a = f(e.a), b = f(e.b); return a.op === 'const' ? foldMul(a.value, b) : b.op === 'const' ? foldMul(b.value, a) : {op: 'prod', a, b} }
    case 'if': { const c = fc(e.c); return isTC(c) ? f(e.then) : isFC(c) ? f(e.else) : {op: 'if', c, then: f(e.then), else: f(e.else)} }
    case 'get': return {op: 'get', map: e.map, key: f(e.key)}
    case 'tup': return {op: 'tup', a: f(e.a), b: f(e.b)}
    case 'proj': return {op: 'proj', k: e.k, a: f(e.a)}
    default: return unreachable(e)
  }
}
function foldCond(c: C, f: (e: E) => E, fc: (c: C) => C): C {
  switch (c.op) {
    case '<=': case '<': case '=': {
      const a = f(c.a), b = f(c.b)
      if (a.op !== 'const' || b.op !== 'const') return {op: c.op, a, b}
      return (c.op === '<=' ? a.value <= b.value : c.op === '<' ? a.value < b.value : a.value === b.value) ? trueC : falseC
    }
    case 'and': case 'or': {
      const ys = c.xs.map(fc), stop = c.op === 'and' ? isFC : isTC, unit = c.op === 'and' ? isTC : isFC
      if (ys.some(stop)) return c.op === 'and' ? falseC : trueC
      const zs = ys.filter(y => !unit(y))
      return zs.length === 0 ? (c.op === 'and' ? trueC : falseC) : zs.length === 1 ? zs[0]! : {op: c.op, xs: zs}
    }
    case 'not': { const x = fc(c.x); return isTC(x) ? falseC : isFC(x) ? trueC : {op: 'not', x} }
    case 'flag': case 'all': throw new Error('a loop reads no flag')
    default: return unreachable(c)
  }
}
// Lean's simpC ∘ substC: the variables substituted, then the constants folded, each shared part once (a folder keeps
// what it folded, so its terms are folded once for every use).
const folder = () => {
  const me = new WeakMap<E, E>(), mc = new WeakMap<C, C>()
  const f = (e: E): E => { let o = me.get(e); if (!o) { o = foldTerm(e, f, fc); me.set(e, o) } return o }
  const fc = (x: C): C => { let o = mc.get(x); if (!o) { o = foldCond(x, f, fc); mc.set(x, o) } return o }
  return {f, fc}
}
const substituter = (vars: Record<string, E>) => {
  const me = new WeakMap<E, E>(), mc = new WeakMap<C, C>()
  const se = (e: E): E => {
    const had = me.get(e)
    if (had) return had
    let o: E
    switch (e.op) {
      case 'var': o = own(vars, e.name) ?? e; break
      case 'const': o = e; break
      case 'mul': o = {op: 'mul', k: e.k, a: se(e.a)}; break
      case 'if': o = {op: 'if', c: sc(e.c), then: se(e.then), else: se(e.else)}; break
      case 'get': o = {op: 'get', map: e.map, key: se(e.key)}; break
      case 'add': case 'sub': case 'min': case 'max': case 'prod': case 'tup': o = {op: e.op, a: se(e.a), b: se(e.b)}; break
      case 'proj': o = {op: 'proj', k: e.k, a: se(e.a)}; break
      default: return unreachable(e)
    }
    me.set(e, o)
    return o
  }
  const sc = (c: C): C => {
    const had = mc.get(c)
    if (had) return had
    if (c.op === 'flag' || c.op === 'all') throw new Error('a loop reads no flag')
    const o: C = c.op === 'not' ? {op: 'not', x: sc(c.x)} : c.op === 'and' || c.op === 'or' ? {op: c.op, xs: c.xs.map(sc)} : {op: c.op, a: se(c.a), b: se(c.b)}
    mc.set(c, o)
    return o
  }
  return {se, sc}
}
export const foldPinned = (c: C, pins: [string, number][]): C => folder().fc(substituter(Object.fromEntries(pins.map(([n, x]) => [n, kE(x)]))).sc(c))
// The pins as a condition, as Lean's pinC: each variable equal to its value, nested to the right; none: true.
export const pinC = (pins: [string, number][]): C => (pins.length === 0 ? trueC : pins.length === 1 ? {op: '=', a: {op: 'var', name: pins[0]![0]}, b: kE(pins[0]![1])}
  : {op: 'and', xs: [{op: '=', a: {op: 'var', name: pins[0]![0]}, b: kE(pins[0]![1])}, pinC(pins.slice(1))]})
export const coverGoal = (r: {set: C, cases: Pick<RecurCases['cases'][number], 'pins' | 'cond'>[]}): Goal => ({name: 'the set is covered by its cases', hyps: [r.set, ...r.cases.map((c): C => ({op: 'not', x: {op: 'and', xs: [pinC(c.pins), c.cond]}}))]})
// Each case's goal, as Lean's caseGoal: its condition at the pins, then the witnessed turn failing, built at the pins
// (caseNeg): the witness's terms at the pins and the pins (`w`), the body's terms read there and folded, then `w` (a
// state variable's term first); the guard and the assumption read at `w`, the set at those terms, each folded.
export function caseGoals(l: Loop, r: Pick<Recur, 'set' | 'wit'>, cases: Pick<RecurCases['cases'][number], 'pins' | 'cond'>[]): Goal[] {
  return cases.map(({pins, cond}) => {
    const {f, fc} = folder(), at = substituter(Object.fromEntries(pins.map(([n, x]) => [n, kE(x)])))
    const w: Record<string, E> = {...Object.fromEntries(Object.entries(r.wit).map(([n, t]) => [n, f(at.se(t))])), ...Object.fromEntries(pins.map(([n, x]) => [n, kE(x)]))}
    const sw = substituter(w), b: Record<string, E> = {...w, ...Object.fromEntries(Object.entries(l.body).map(([n, t]) => [n, f(sw.se(t))]))}
    const neg: C = {op: 'not', x: {op: 'and', xs: [fc(sw.sc(l.while)), fc(sw.sc(l.assume ?? trueC)), fc(substituter(b).sc(r.set))]}}
    return {name: `${l.name} never ends: the set is closed where ${pins.map(([n, x]) => `${n} = ${x}`).join(', ')}`, hyps: [foldPinned(cond, pins), neg]}
  })
}
// Lean's checkRecurCases: as checkRecur, the closure by its cases.
export function checkRecurCases(l: Loop, r: RecurCases): boolean {
  const scope = [...l.params, ...Object.keys(l.state)]
  for (const c of r.cases) {
    inScope(`${l.name}'s case`, [c.cond], scope)
    if (!naturalC(c.cond) || !c.pins.every(([n, x]) => scope.includes(n) && Number.isSafeInteger(x) && x >= 0) || new Set(c.pins.map(([n]) => n)).size < c.pins.length) throw new Error('outside the kernel')
  }
  if (!stemOk(l, r) || !check(coverGoal(r), r.cover)) return false
  const goals = caseGoals(l, r, r.cases)
  return r.cases.every((c, j) => check(goals[j]!, c.tree))
}

// --- progress: laws with "there is a request" ----------------------------------------------------------------------

// "In every reachable state where `when` holds, some request makes `then` true of the step": proven by naming the
// request (a term per input over the state and params) and proving it allowed (the machine's assumption holds of it)
// and that the step it causes makes `then` hold. `then` reads the state before the step by plain names and after it by
// primed names (s', and M'[k] as a read of the map named M'). The laws assumed must be proven inductive on their own.
// A machine with sums: the request is allowed by the rule's own assumption (the facts its plain machine assumes besides
// hold of every request where the sums are exact: Sums.lean's sum_allowed).
export function progressObligations(m0: Machine, laws: Law[], instances: Instances, p: {name: string, when: C, then: C, request: Record<string, E>}): Goal[] {
  const m = plainOf(m0), own = m0.sums && Object.keys(m0.sums).length ? m0.assume : m.assume
  scope(m, laws) // (as obligations scopes it: a param ?f would be read as the flag f's variable here too)
  if (!m.inputs.every(i => Object.hasOwn(p.request, i)) || !Object.values(p.request).every(natural) || mentions(p.when, m.inputs)) throw new Error('outside the kernel')
  for (const e of Object.values(p.request)) if (mentions({op: '=', a: e, b: e}, m.inputs)) throw new Error('a request is named from the state and params')
  const req: Subst = {vars: p.request, maps: {}, flags: {}}
  const flags = Object.fromEntries(Object.entries(flagsOf(m)).map(([f, c]) => [f, substC(c, req)]))
  // The run: a state where the laws and `when` hold, the named request (its quantified flags closed), then the step it
  // causes. Maps a request carries are left as any maps: the step is shown for all of them.
  const before = holds(given(m, from(), instances), [...preOf(m), ...assumed(laws, instances), p.when])
  const asked = holds(reading(before, p.request), closing(m, instances))
  const caused = step(asked, updateOf(m))
  return [
    ...(own ? [goal(`${p.name}: the request is allowed`, asked, substC(inlineFlags(m, own), req))] : []),
    goal(`${p.name}: the step it causes`, caused, across(caused, p.then, Object.keys(m.state), Object.keys(m.maps ?? {}), {inputs: p.request, flags})),
  ]
}

// --- liveness: "from leads to to", under fairness ----------------------------------------------------------------------

// "Whenever `from` holds, `to` holds later", in every run that takes each helpful request infinitely often. The rank is
// naturals over the state and params compared in order (one term, or several: the first that differs decides). A
// helpful request names some inputs by terms over the state and params (the others, and the maps it carries, stay
// free: any value helps) and the region where it helps (everywhere, if none). Every goal is a step law, while `from`
// holds and `to` doesn't: each request allowed keeps `from` or reaches `to`, and reaches `to`, lowers the rank, or keeps
// it with every region it is in kept (stay); some region holds (cover); and each helpful request taken in its region
// reaches `to` or lowers the rank (helps). Then along such a run the rank can't drop forever; once it stops, the region
// it is in stays and its request comes (the Lean twin's `leads_sound`, `sleads_sound`). The conditions are built
// exactly as Live.lean builds them, two parts per and/or.
export type Helpful = {when?: C, request: Record<string, E>}
// `fairness: 'strong'` (Live.lean's sleads_sf_soundA): each helpful request taken in its region infinitely often wherever,
// infinitely often, it is allowed there; the regions need not stay, and a helpful request may reach, instead of `to` or
// a lower rank, the region of one of a higher level (`levels`, one per helpful request in order; the order itself where
// left out).
export type Liveness = {name: string, from: C, to: C, rank: E | E[], request?: Record<string, E>, helpful?: Helpful[], fairness?: 'weak' | 'strong', levels?: number[]}
export const strongly = (l: Liveness): boolean => l.fairness === 'strong'
export const livenessLevels = (l: Liveness): number[] => l.levels ?? livenessHelpful(l).map((_, i) => i)
const zero: E = {op: 'const', value: 0}
export const trueC: C = {op: '<=', a: zero, b: zero}, falseC: C = {op: '<', a: zero, b: zero}
const and2 = (a: C, b: C): C => ({op: 'and', xs: [a, b]}), or2 = (a: C, b: C): C => ({op: 'or', xs: [a, b]})
const lexLt = (after: E[], before: E[]): C => (after.length && before.length ? or2({op: '<', a: after[0]!, b: before[0]!}, and2({op: '=', a: after[0]!, b: before[0]!}, lexLt(after.slice(1), before.slice(1)))) : falseC)
const eqs = (after: E[], before: E[]): C => (after.length && before.length ? and2({op: '=', a: after[0]!, b: before[0]!}, eqs(after.slice(1), before.slice(1))) : trueC)
const keep = (ws: C[], prime: (c: C) => C): C => (ws.length ? and2(or2({op: 'not', x: ws[0]!}, prime(ws[0]!)), keep(ws.slice(1), prime)) : trueC)
const anyOf = (ws: C[]): C => (ws.length ? or2(ws[0]!, anyOf(ws.slice(1))) : falseC)
const named = (req: [string, E][]): C => (req.length ? and2({op: '=', a: {op: 'var', name: req[0]![0]}, b: req[0]![1]}, named(req.slice(1))) : trueC)
export const livenessRanks = (l: Liveness): E[] => (Array.isArray(l.rank) ? l.rank : [l.rank])
export const livenessHelpful = (l: Liveness): {when: C, request: Record<string, E>}[] => {
  if ((l.request === undefined) === (l.helpful === undefined)) throw new Error(`liveness ${l.name}: a helpful request, or helpful requests with their regions`)
  return (l.helpful ?? [{request: l.request!}]).map(h => ({when: h.when ?? trueC, request: h.request}))
}
export function livenessParts(m: Machine, l: Liveness): {stay: StepLaw, cover: StepLaw, helps: StepLaw[]} {
  // A machine with a history as its plain machine (its sums are state, its queries inputs no request names).
  const plain = plainOf(m)
  const queries = Object.keys(m.history?.queries ?? {}), client = plain.inputs.filter(i => !queries.includes(i))
  const ranks = livenessRanks(l), helpful = livenessHelpful(l)
  if (!ranks.length || !helpful.length) throw new Error(`liveness ${l.name}: a rank of one natural or more, and a helpful request or more`)
  for (const [what, t] of [['from', l.from], ['to', l.to], ...ranks.map((r, i) => [`rank ${i + 1}`, {op: '=', a: r, b: r}] as const), ...helpful.map((h, i) => [`region ${i + 1}`, h.when] as const)] as const) {
    if (mentions(t as C, plain.inputs)) throw new Error(`liveness ${l.name}: ${what} reads the state and params, not a request`)
  }
  for (const h of helpful) for (const [input, t] of Object.entries(h.request)) {
    if (!client.includes(input)) throw new Error(`liveness ${l.name}: a helpful request names inputs a client sends (${input} is ${queries.includes(input) ? 'a query, computed from the log' : 'none'})`)
    if (mentions({op: '=', a: t, b: t}, plain.inputs)) throw new Error(`liveness ${l.name}: the request's ${input} is a term over the state and params`)
  }
  const after: Subst = {vars: Object.fromEntries(Object.keys(plain.state).map(n => [n, {op: 'var', name: `${n}'`} as E])), maps: Object.fromEntries(Object.keys(plain.maps ?? {}).map(map => [map, (key: E): E => ({op: 'get', map: `${map}'`, key})])), flags: {}}
  const prime = (c: C) => substC(c, after), ranks2 = ranks.map(r => substE(r, after)), to2 = prime(l.to)
  const pending = and2(l.from, {op: 'not', x: l.to}), lower = lexLt(ranks2, ranks), regions = helpful.map(h => h.when)
  if (strongly(l)) {
    // (Live.lean's liveStaySC and liveHelpThenS: the regions of a higher level, in order)
    const levels = livenessLevels(l)
    if (levels.length !== helpful.length || !levels.every(n => Number.isInteger(n) && n >= 0)) throw new Error(`liveness ${l.name}: a level, a natural, per helpful request`)
    return {
      stay: {name: `${l.name}: each step stays or gets there, the rank never rising`, when: pending, then: and2(or2(prime(l.from), to2), or2(to2, or2(lower, eqs(ranks2, ranks))))},
      cover: {name: `${l.name}: some helpful request applies`, when: pending, then: anyOf(regions)},
      helps: helpful.map((h, i) => ({name: `${l.name}: helpful request ${i + 1}`, when: and2(pending, and2(h.when, named(Object.entries(h.request)))),
        then: or2(to2, or2(lower, anyOf(regions.filter((_, j) => levels[i]! < levels[j]!).map(prime))))})),
    }
  }
  return {
    stay: {name: `${l.name}: each step stays or gets there, the rank kept only with its region`, when: pending,
      then: and2(or2(prime(l.from), to2), or2(to2, or2(lower, and2(eqs(ranks2, ranks), keep(regions, prime)))))},
    cover: {name: `${l.name}: some helpful request applies`, when: pending, then: anyOf(regions)},
    helps: helpful.map((h, i) => ({name: `${l.name}: helpful request ${i + 1}`, when: and2(pending, and2(h.when, named(Object.entries(h.request)))), then: or2(to2, lower)})),
  }
}

// --- step laws: what one step does ------------------------------------------------------------------------------------

// "In every reachable state, every request the machine allows takes a step where `then` holds": `then` reads the state,
// maps, params and the request as they are before the step by plain names, and the state and maps after it by primed
// names (s', and M'[k] as a read of the map named M'); flags (decided before the step) may be read too. `when` narrows
// the requests the law is about; `forall` names a key the law holds at every value of (a free variable of the goal). One
// goal per law: the precondition, the laws (proven inductive on their own, assumed at
// the keys the proof names), the request's assumption and `when` as hypotheses, `then` refuted with the primed names read
// through the step. A machine with a history is its plain machine (sums are state, queries are inputs).
//
// With `steps: k`, the law is about k steps in a row: `then` reads the state before the first by plain names and after
// the last by primed ones, the first request by plain names and the j-th (j >= 2) as input@j; `when` is one condition
// for the first step, or one per step, each read at the state that step starts from with its request by plain names.
// The laws hold at every state on the way (each is reachable), so each is assumed before each step.
export type StepLaw = {name: string, when?: C | C[], then: C, forall?: string, keys?: string[], steps?: number}
export function stepLawObligations(machine: Machine, laws: Law[], instances: Instances, sl: StepLaw): Goal[] {
  const m = plainOf(machine)
  scope(m, laws)
  const k = sl.steps ?? 1
  // Past 64 the cost is the bound (proving grows about as k³: 64 steps in about 5 s on Modal; Lean checks 32 in about 14 s, 64 in about 47 s).
  if (!Number.isInteger(k) || k < 1 || k > 64) throw new Error(`step law ${sl.name}: steps is a whole number from 1 to 64`)
  const whens = sl.when === undefined ? [] : Array.isArray(sl.when) ? sl.when : [sl.when]
  if (whens.length > k) throw new Error(`step law ${sl.name}: one when per step at most`)
  const state = Object.keys(m.state), maps = Object.keys(m.maps ?? {}), carried = m.inputMaps ?? [], flagNames = Object.keys(m.step.flags ?? {})
  const primes = [...state, ...maps].map(n => `${n}'`)
  const laters = Array.from({length: k - 1}, (_, i) => laterNames(m, i + 2))
  const later = laters.flatMap(l => Object.values(l.vars).map(e => (e as {name: string}).name)), laterMaps = laters.flatMap(l => Object.values(l.maps))
  const names = Array.from({length: k - 1}, (_, i) => state.map(n => stateName(n, i + 1))).flat()
  const taken = [...m.params, ...m.inputs, ...state, ...maps, ...carried]
  // (and every name the run reads besides: the functions, each flag's variable ?f and its witnesses, which a later
  // step's names, a@2, I@2, ?f@2, must not be: a function I@2 was read as the second request's carried map)
  const own = [...taken, ...Object.keys(m.fns ?? {}), ...flagNames.map(f => `?${f}`), ...quantified(m).flatMap(([f, q]) => witnessesOf(f, q))]
  for (const p of [...primes, ...later, ...laterMaps, ...names]) if (own.includes(p)) throw new Error(`${m.name}: ${p} is a name of the machine and a name a step law reads`)
  for (const key of [sl.forall, ...(sl.keys ?? [])]) if (key) plainName(`step law ${sl.name}'s key`, key)
  for (const key of [sl.forall, ...(sl.keys ?? [])]) if (key && [...own, ...primes, ...later, ...names].includes(key)) throw new Error(`step law ${sl.name}'s key ${key} is already a name of ${m.name}`)
  if (sl.keys?.length && (!sl.forall || new Set([sl.forall, ...sl.keys]).size !== sl.keys.length + 1)) throw new Error(`step law ${sl.name}: further keys come with a first, each a different name`)
  unquantified(`step law ${sl.name}`, sl.then)
  inScope(`step law ${sl.name}`, [sl.then], [...taken, ...state.map(n => `${n}'`), ...later, ...(sl.forall ? [sl.forall] : []), ...(sl.keys ?? [])], [...maps, ...carried, ...maps.map(n => `${n}'`), ...laterMaps], flagNames)
  for (const w of whens) { unquantified(`step law ${sl.name}'s when`, w); inScope(`step law ${sl.name}'s when`, [w], taken, [...maps, ...carried], flagNames) }
  if (!naturalC(sl.then) || !whens.every(naturalC)) throw new Error(`step law ${sl.name}: a negative constant or factor is outside the kernel`)
  const u = updateOf(m), assume = m.assume ? [inlineFlags(m, m.assume)] : []
  let run = given(m, holds(from(), preOf(m)), instances)
  for (let j = 1; j <= k; j++) {
    if (j > 1) run = reading(run, laters[j - 2]!.vars, laters[j - 2]!.maps)
    run = step(holds(run, [...assumed(laws, instances), ...assume, ...(whens[j - 1] ? [inlineFlags(m, whens[j - 1]!)] : []), ...closing(m, instances)]), u)
    if (j < k) run = nameState(run, state, j)
  }
  return [goal(k === 1 ? `${sl.name} @step law` : `${sl.name} @${k} steps`, run, across(run, sl.then, state, maps, {inputs: {}, flags: flagsOf(m)}))]
}

// The laws' proof and every step law's tree: all must check.
// `perStep`: a step law's own instances, where it has them (else `instances`).
// Each frame's hypotheses read no name a later step's request is read by: the condition the Lean twin's proof needs
// (Sets.lean's checkSKStep, `avoids (szone s sl)`; plain flags are inlined here, so their names never occur), checked
// here alike. A quantified flag's keys are free of it: where the flag is 1 its condition holds at every key, so at a
// key a later step names too (and the flag, its witness and its condition read none).
const lawsOnly = (inst: Instances): Instances => Object.fromEntries(Object.entries(inst).filter(([n]) => !n.startsWith('?')))
export function checkStepLaws(m: Machine, laws: Law[], stepLaws: StepLaw[], proof: {laws: {instances: Record<string, Instances>, trees: Record<string, Tree>}, instances: Instances, perStep?: Record<string, Instances>, trees: Record<string, Tree>}): boolean {
  return checkLaws(m, laws, proof.laws) && stepLaws.every(sl => {
    const inst = own(proof.perStep ?? {}, sl.name) ?? proof.instances, plain = plainOf(m)
    const zone = stepZone(plain, sl.steps ?? 1)
    return [...assumed(laws, inst), ...assumed(plain.facts ?? [], inst), ...closing(plain, lawsOnly(inst))].every(c => !mentions(c, zone))
      && stepLawObligations(m, laws, inst, sl).every(g => { const t = own(proof.trees, g.name); return t !== undefined && check(g, t) })
  })
}
// The names a k-step law's run introduces past its first frame: each later step's inputs, quantified flags and their
// witnesses, and the state after each step but the last (stateName).
export const stepZone = (m: Machine, k: number): string[] => [
  ...Array.from({length: k - 1}, (_, i) => Object.values(laterNames(m, i + 2).vars).map(e => (e as {name: string}).name)).flat(),
  ...Array.from({length: k - 1}, (_, i) => Object.keys(m.state).map(n => stateName(n, i + 1))).flat(),
]

// --- k-induction: a law k steps in a row keep -------------------------------------------------------------------------

// A plain law (no key) holds in every reachable state if it holds at the start, after every run of j steps from the
// start for 1 ≤ j < k (the base), and after any k steps in a row from a reachable state, each step starting where it
// holds (the step). Every goal but the start's (the law's own @start goal) is a k-step law's, its `when`s and `then`
// built here from the law alone: the base of depth j reads its first state as the start (each state variable its start
// term) with the law there, and the law before each later step; the step reads the law before each of its k steps; `then`
// is the law with primed names. The Lean twin (KInd.lean's checkKInd) builds the same goals, and `kind_sound` proves
// that a checked certificate makes the law hold in every reachable state. The proof is a step laws' proof (the laws
// assumed, proven inductive as ever; each goal's tree by name), its start goal's instances `perStep[<law> @start]`.
export type KInduction = {law: Law, k: number}
export function kInductionSteps(machine: Machine, kl: KInduction): StepLaw[] {
  const m = plainOf(machine), L = kl.law, k = kl.k
  if (L.forall || L.keys?.length || L.some?.length || L.ex) throw new Error(`k-induction of ${L.name}: a law with no key`)
  if (!Number.isInteger(k) || k < 1 || k > 64) throw new Error(`k-induction of ${L.name}: k is a whole number from 1 to 64`)
  // (as the twin's checkKInd: the law reads no request's name, flag or witness; the start reads none, nor a state
  // variable, nor a map; scope below asks the rest)
  const ext = [...m.inputs, ...quantified(m).flatMap(([f, q]) => [`?${f}`, ...witnessesOf(f, q)]), ...Object.keys(m.step.flags ?? {}).map(f => `?${f}`)]
  if (mentions(L.holds, ext) || Object.keys(m.state).some(n => ext.includes(n))) throw new Error(`k-induction of ${L.name}: reads a request's name or a flag`)
  for (const e of Object.values(m.state)) if (mentions({op: '=', a: e, b: e}, [...ext, ...Object.keys(m.state)]) || JSON.stringify(e).includes('"op":"get"')) throw new Error(`k-induction of ${L.name}: a start reads the params alone`)
  const start: C = {op: 'and', xs: Object.entries(m.state).map(([n, e]): C => ({op: '=', a: {op: 'var', name: n}, b: e}))}
  const after: Subst = {vars: Object.fromEntries(Object.keys(m.state).map(n => [n, {op: 'var', name: `${n}'`} as E])), maps: Object.fromEntries(Object.keys(m.maps ?? {}).map(map => [map, (key: E): E => ({op: 'get', map: `${map}'`, key})])), flags: {}}
  const then = substC(L.holds, after)
  return [
    ...Array.from({length: k - 1}, (_, i): StepLaw => ({name: `${L.name} @base ${i + 1}`, when: [{op: 'and', xs: [start, L.holds]}, ...Array.from({length: i}, () => L.holds)], then, steps: i + 1})),
    {name: `${L.name} @k-step`, when: Array.from({length: k}, () => L.holds), then, steps: k},
  ]
}
export const kInductionStart = (machine: Machine, kl: KInduction, instances: Instances): Goal => {
  const m = plainOf(machine)
  return obligations(m, [kl.law], {[kl.law.name]: instances})[0]!
}
export function checkKInduction(m: Machine, laws: Law[], kl: KInduction, proof: {laws: {instances: Record<string, Instances>, trees: Record<string, Tree>}, instances: Instances, perStep?: Record<string, Instances>, trees: Record<string, Tree>}): boolean {
  const steps = kInductionSteps(m, kl), plain = plainOf(m)
  scope(plain, [...laws, kl.law])
  const start = kInductionStart(m, kl, own(proof.perStep ?? {}, `${kl.law.name} @start`) ?? proof.instances)
  const t = own(proof.trees, start.name)
  return t !== undefined && check(start, t) && checkStepLaws(m, laws, steps, proof)
}

// --- trees: structural induction ---------------------------------------------------------------------------------------

// A fold over binary trees whose leaves and nodes carry inputs: a leaf's state from its inputs, a node's from its
// children's (l_name, r_name) and its own inputs. A law holds of every tree if it holds at every leaf, and at a node
// whenever it holds at both children.
export type Fold = {name: string, params: string[], inputs: string[], leaf: Record<string, E>, node: Record<string, E>, pre?: C, assume?: C}

export function foldObligations(f: Fold, laws: Law[]): Goal[] {
  if (![...Object.values(f.leaf), ...Object.values(f.node)].every(natural) || !laws.every(law => !law.forall && !law.keys?.length && naturalC(law.holds) && !mentions(law.holds, f.inputs))) throw new Error('outside the kernel')
  const names = Object.keys(f.leaf)
  distinct(f.name, [...f.params, ...f.inputs, ...names])
  // The children's copies (l_n, r_n) are names of their own (Lean's copiesOk): a param l_size would be read as the left
  // child's size at a node.
  const copies = names.flatMap(n => [`l_${n}`, `r_${n}`])
  for (const name of [...f.params, ...f.inputs, ...names]) if (copies.includes(name)) throw new Error(`${f.name}: ${name} is a name of the fold and a child's copy (l_<name>, r_<name>)`)
  if (Object.keys(f.node).sort().join() !== [...names].sort().join()) throw new Error(`${f.name}'s leaf and node set the same names`)
  inScope(`${f.name}'s leaf`, [...Object.values(f.leaf), ...(f.assume ? [f.assume] : [])], [...f.params, ...f.inputs])
  inScope(`${f.name}'s node`, Object.values(f.node), [...f.params, ...f.inputs, ...names.flatMap(n => [`l_${n}`, `r_${n}`])])
  inScope(`${f.name}'s precondition`, f.pre ? [f.pre] : [], f.params)
  inScope(`${f.name}'s laws`, laws.map(law => law.holds), [...f.params, ...names])
  const side = (p: string): Subst => ({vars: Object.fromEntries(names.map(n => [n, {op: 'var', name: `${p}${n}`} as E])), maps: {}, flags: {}})
  // A fold's inputs are each leaf's and node's own, so its assumption holds at every leaf and node it reads them at.
  // A leaf is a start from its inputs; a node, a step from the frame of its two children, the laws holding at each.
  const assume = [...preOf(f), ...(f.assume ? [f.assume] : [])]
  const leaf = holds(from({vars: {...f.leaf}, maps: {}, flags: {}}), assume)
  const node = step(holds(from(), [...assume, ...laws.flatMap(h => [substC(h.holds, side('l_')), substC(h.holds, side('r_'))])]), {vars: f.node, maps: {}})
  return laws.flatMap(law => [goal(`${law.name} @leaf`, leaf, atEnd(leaf, law.holds)), goal(`${law.name} @node`, node, atEnd(node, law.holds))])
}

// --- rationals: Rationals.lean's twin --------------------------------------------------------------------------------
// A goal over the rationals: hypotheses over terms whose values are rationals (variables, rational constants, +, −
// not truncated, × by a rational constant, min, max, if; ≤, <, =, and, or, not), with no naturality row and no term
// column. A term's linear form is a row with integer coefficients over a positive denominator, computed exactly
// (bigint), as Lean's `linear`; a split's no side is the strict row −lin < 0; a leaf's derivation is checked by
// check.ts with no cut (Rationals.lean's checkQ). Each function below is the Lean definition of the same name in
// namespace Q; the exporter writes each leaf's inputs as the rows Lean finds among its own (`claimOk`).
export type Rat = {num: bigint, den: bigint}
export type QE =
  | {op: 'var', name: string}
  | {op: 'const', q: Rat}
  | {op: 'add' | 'sub' | 'min' | 'max', a: QE, b: QE}
  | {op: 'mul', k: Rat, a: QE}
  | {op: 'if', c: QC, then: QE, else: QE}
export type QC = {op: '<=' | '<' | '=', a: QE, b: QE} | {op: 'and' | 'or', a: QC, b: QC} | {op: 'not', x: QC}
export type QGoal = {name: string, hyps: QC[]}
// A row: coefficients by variable (none zero) and a constant; a form is a row over a positive denominator.
export type QRow = {cs: Map<string, bigint>, c: bigint}
export type LF = {row: QRow, den: bigint}
const bgcd = (a: bigint, b: bigint): bigint => { a = a < 0n ? -a : a; b = b < 0n ? -b : b; while (b) [a, b] = [b, a % b]; return a }
// Lean's q.num and q.den: the reduced fraction (a denominator <= 0 is no rational).
export const ratNorm = (q: Rat): Rat => {
  if (q.den <= 0n) throw new Error('a rational has a positive denominator')
  const g = bgcd(q.num, q.den) || 1n
  return {num: q.num / g, den: q.den / g}
}
const rscale = (m: bigint, r: QRow): QRow => ({cs: new Map(m === 0n ? [] : [...r.cs].map(([x, c]) => [x, m * c])), c: m * r.c})
const radd = (a: QRow, b: QRow): QRow => {
  const cs = new Map(a.cs)
  for (const [x, c] of b.cs) { const s = (cs.get(x) ?? 0n) + c; if (s === 0n) cs.delete(x); else cs.set(x, s) }
  return {cs, c: a.c + b.c}
}
export const qdif = (a: LF, b: LF): QRow => radd(rscale(b.den, a.row), rscale(-a.den, b.row))
// A row as a Lin, its coefficients safe integers (else undefined: a row past 2^53 is not read, so the check is weaker,
// never wrong); and its key, as `canon` writes a Lin (zero coefficients dropped: Lean's `same` compares by value).
export const qLin = (r: QRow): Lin | undefined => {
  const out: Lin = Object.create(null)
  for (const [x, c] of r.cs) { if (c < -(2n ** 53n) + 1n || c > 2n ** 53n - 1n) return undefined; out[x] = Number(c) }
  if (r.c !== 0n) { if (r.c < -(2n ** 53n) + 1n || r.c > 2n ** 53n - 1n) return undefined; out['1'] = Number(r.c) }
  return out
}
const linRow = (lin: Lin): QRow | undefined => {
  if (!Object.values(lin).every(c => Number.isSafeInteger(c))) return undefined
  const cs = new Map<string, bigint>()
  for (const [x, c] of Object.entries(lin)) if (x !== '1' && c !== 0) cs.set(x, BigInt(c))
  return {cs, c: BigInt(lin['1'] ?? 0)}
}
const rowKey = (r: QRow): string | undefined => { const lin = qLin(r); return lin && canon(lin) }
export function qdec(path: Path, r: QRow): boolean | undefined {
  if (r.cs.size === 0) return r.c <= 0n
  const key = rowKey(r)
  return key === undefined ? undefined : path.get(key)?.holds
}
export function qlinear(e: QE, path: Path): LF | undefined {
  switch (e.op) {
    case 'var': return e.name === '1' || /[*[\],:⟦]/.test(e.name) ? undefined : {row: {cs: new Map([[e.name, 1n]]), c: 0n}, den: 1n} // (a row's key is its canonical text: a variable x:1,y read as x + y's)
    case 'const': { const q = ratNorm(e.q); return {row: {cs: new Map(), c: q.num}, den: q.den} }
    case 'add': case 'sub': {
      const a = qlinear(e.a, path), b = qlinear(e.b, path)
      if (!a || !b) return undefined
      return {row: e.op === 'add' ? radd(rscale(b.den, a.row), rscale(a.den, b.row)) : qdif(a, b), den: a.den * b.den}
    }
    case 'mul': { const k = ratNorm(e.k), a = qlinear(e.a, path); return a && {row: rscale(k.num, a.row), den: k.den * a.den} }
    case 'min': case 'max': {
      const a = qlinear(e.a, path), b = qlinear(e.b, path)
      if (!a || !b) return undefined
      const d = qdec(path, qdif(a, b))
      return d === undefined ? undefined : (d === (e.op === 'min')) ? a : b
    }
    case 'if': { const t = qtruth(e.c, path); return t === undefined ? undefined : qlinear(t ? e.then : e.else, path) }
    default: return unreachable(e)
  }
}
export function qtruth(c: QC, path: Path): boolean | undefined {
  switch (c.op) {
    case '<=': case '<': case '=': {
      const a = qlinear(c.a, path), b = qlinear(c.b, path)
      if (!a || !b) return undefined
      if (c.op === '<=') return qdec(path, qdif(a, b))
      if (c.op === '<') { const d = qdec(path, qdif(b, a)); return d === undefined ? undefined : !d }
      const d1 = qdec(path, qdif(a, b)), d2 = qdec(path, qdif(b, a))
      return d1 === false || d2 === false ? false : d1 === true && d2 === true ? true : undefined
    }
    case 'and': case 'or': {
      const ta = qtruth(c.a, path), tb = qtruth(c.b, path), dominant = c.op === 'or'
      return ta === dominant || tb === dominant ? dominant : ta === !dominant && tb === !dominant ? !dominant : undefined
    }
    case 'not': { const t = qtruth(c.x, path); return t === undefined ? undefined : !t }
    default: return unreachable(c)
  }
}
// The rows (each with its strictness) a hypothesis gives under the path when it has the truth value `pos`.
export function qfacts(c: QC, path: Path, pos = true): [QRow, boolean][] {
  switch (c.op) {
    case 'not': return qfacts(c.x, path, !pos)
    case 'and': case 'or': {
      // and when true, or when false: both parts; otherwise the part the other one's truth leaves.
      if ((c.op === 'and') === pos) return [...qfacts(c.a, path, pos), ...qfacts(c.b, path, pos)]
      if (qtruth(c.a, path) === !pos) return qfacts(c.b, path, pos)
      if (qtruth(c.b, path) === !pos) return qfacts(c.a, path, pos)
      return []
    }
    case '<=': case '<': case '=': {
      const a = qlinear(c.a, path), b = qlinear(c.b, path)
      if (!a || !b) return []
      if (c.op === '<=') return pos ? [[qdif(a, b), false]] : [[qdif(b, a), true]]
      if (c.op === '<') return pos ? [[qdif(a, b), true]] : [[qdif(b, a), false]]
      if (pos) return [[qdif(a, b), false], [qdif(b, a), false]]
      if (qdec(path, qdif(a, b)) === true) return [[qdif(a, b), true]]
      if (qdec(path, qdif(b, a)) === true) return [[qdif(b, a), true]]
      return []
    }
    default: return unreachable(c)
  }
}
// A leaf's rows: the path's atoms (l <= 0, or −l < 0), then each hypothesis' facts; a row past 2^53 is left out.
export function qLeafRows(goal: QGoal, path: Path): Constraint[] {
  const rows: [QRow, boolean][] = [...[...path.values()].map(a => (a.holds ? [linRow(a.lin)!, false] : [rscale(-1n, linRow(a.lin)!), true]) as [QRow, boolean]),
    ...goal.hyps.flatMap(h => qfacts(h, path))]
  return rows.flatMap(([r, strict]) => { const lin = qLin(r); return lin ? [{lin, label: '', strict}] : [] })
}
// A split on a row the path decides already (or a constant one) is refused, as Lean's checkT refuses it.
export function checkQTree(goal: QGoal, tree: Tree, path: Path = new Map()): boolean {
  if ('leaf' in tree) return !tree.products?.length && !tree.squares?.length && checkRefutation(qLeafRows(goal, path), tree.leaf, false)
  const row = linRow(tree.split), lin = row && qLin(row)
  if (!row || !lin || qdec(path, row) !== undefined) return false
  const key = canon(lin)
  return checkQTree(goal, tree.yes, new Map(path).set(key, {lin, holds: true})) && checkQTree(goal, tree.no, new Map(path).set(key, {lin, holds: false}))
}

// Step machines over the rationals (Rationals.lean's Machine): params, inputs and state are rationals; `state` is each
// state variable's start over the params, `step` its value after a request (a variable it leaves out keeps its value).
export type QMachine = {name: string, params: string[], inputs: string[], state: Record<string, QE>, step: Record<string, QE>, pre?: QC, assume?: QC}
export type QLaw = {name: string, holds: QC}
export const qTrue: QC = {op: '<=', a: {op: 'const', q: {num: 0n, den: 1n}}, b: {op: 'const', q: {num: 0n, den: 1n}}}
export function qSubstE(e: QE, s: Record<string, QE>): QE {
  switch (e.op) {
    case 'var': return Object.hasOwn(s, e.name) ? s[e.name]! : e
    case 'const': return e
    case 'mul': return {...e, a: qSubstE(e.a, s)}
    case 'if': return {op: 'if', c: qSubstC(e.c, s), then: qSubstE(e.then, s), else: qSubstE(e.else, s)}
    case 'add': case 'sub': case 'min': case 'max': return {...e, a: qSubstE(e.a, s), b: qSubstE(e.b, s)}
    default: return unreachable(e)
  }
}
export function qSubstC(c: QC, s: Record<string, QE>): QC {
  switch (c.op) {
    case 'not': return {op: 'not', x: qSubstC(c.x, s)}
    case 'and': case 'or': return {op: c.op, a: qSubstC(c.a, s), b: qSubstC(c.b, s)}
    case '<=': case '<': case '=': return {op: c.op, a: qSubstE(c.a, s), b: qSubstE(c.b, s)}
    default: return unreachable(c)
  }
}
export function qOccurs(t: QE | QC, names: string[]): boolean {
  switch (t.op) {
    case 'var': return names.includes(t.name)
    case 'const': return false
    case 'mul': return qOccurs(t.a, names)
    case 'not': return qOccurs(t.x, names)
    case 'if': return qOccurs(t.c, names) || qOccurs(t.then, names) || qOccurs(t.else, names)
    case 'and': case 'or': return qOccurs(t.a, names) || qOccurs(t.b, names)
    case 'add': case 'sub': case 'min': case 'max': case '<=': case '<': case '=': return qOccurs(t.a, names) || qOccurs(t.b, names)
    default: return unreachable(t)
  }
}
// startGoal and stepGoal: the law refuted at the start, and after a step from where every law and the request's
// assumption hold.
export function qObligations(m: QMachine, laws: QLaw[], law: QLaw): {start: QGoal, step: QGoal} {
  const pre = m.pre ?? qTrue, assume = m.assume ?? qTrue
  return {
    start: {name: `${law.name} @start`, hyps: [pre, {op: 'not', x: qSubstC(law.holds, m.state)}]},
    step: {name: `${law.name} @step`, hyps: [pre, assume, ...laws.map(l => l.holds), {op: 'not', x: qSubstC(law.holds, m.step)}]},
  }
}
// checkMachine: the precondition reads no input and no state variable, no law reads an input, and each law's start
// and step goals are refuted by its trees.
export function checkQMachine(m: QMachine, laws: QLaw[], trees: Record<string, {start: Tree, step: Tree}>): boolean {
  const assigned = [...m.inputs, ...Object.keys(m.state), ...Object.keys(m.step)]
  if (m.pre && qOccurs(m.pre, assigned)) return false
  return laws.every(law => {
    const t = own(trees, law.name), goals = qObligations(m, laws, law)
    return !!t && !qOccurs(law.holds, m.inputs) && checkQTree(goals.start, t.start) && checkQTree(goals.step, t.step)
  })
}

// --- counts: quorum facts (Lean twin: ../lean-kernel/Count.lean, counted_sound) ------------------------------------------
// A counted goal is a goal and the counts its hypotheses read: a count's variable v names Σ body(k) over the keys k below
// `below`, the body read with its variable `key` at k (a 0/1 body counts a set). Its certificate is instances of
// Count.lean's lemma and a tree. An instance names a fresh witness, the bound its counts share, an integer coefficient per
// count (by variable) and one on the constant 1, and stands for its hypothesis (countHyp, P the positive parts and N
// the negative parts of the coefficients):
//   (P·counts + P(unit)·below ≤ N·counts + N(unit)·below) ∨ (wit < below ∧ N·bodies(wit) + N(unit) < P·bodies(wit) + P(unit))
// The tree refutes the goal's hypotheses followed by the instances', in order. Each function below is Count.lean's of the
// same name, built the same way (DESIGN.md, gen/laneK, has the table); Lean builds the hypotheses itself.
export type Count = {v: string, key: string, below: E, body: E}
export type CountInst = {wit: string, below: E, terms: [number, string][], unit: number}
export type CountedGoal = {name: string, hyps: C[], counts: Count[]}

// Lean's beqE: equal by structure (every field, keys in order).
const stable = (t: E): string => JSON.stringify(t, (_, x: unknown) => (x && typeof x === 'object' && !Array.isArray(x) ? Object.fromEntries(Object.keys(x).sort().map(key => [key, (x as Record<string, unknown>)[key]])) : x))
const sameE = (a: E, b: E): boolean => stable(a) === stable(b)
// findCount: the first count with the variable.
const findCount = (cs: Count[], v: string): Count | undefined => cs.find(c => c.v === v)
// resolve: each term's count, if every term names one whose bound is the instance's.
function resolve(cs: Count[], B: E, ts: [number, string][]): [number, Count][] | undefined {
  const out: [number, Count][] = []
  for (const [z, v] of ts) {
    const c = findCount(cs, v)
    if (!c || !sameE(c.below, B)) return undefined
    out.push([z, c])
  }
  return out
}
// sumE: a sum, right-nested from 0. posP, negP: Int.toNat z and Int.toNat (−z).
const sumE = (es: E[]): E => es.reduceRight<E>((acc, e) => ({op: 'add', a: e, b: acc}), {op: 'const', value: 0})
const posP = (z: number) => Math.max(z, 0), negP = (z: number) => Math.max(-z, 0)
// side: each count read by rd times its coefficient's part, then the unit's part times `one`.
const side = (part: (z: number) => number, rd: (c: Count) => E, one: E, u: number, rs: [number, Count][]): E =>
  ({op: 'add', a: sumE(rs.map(([z, c]): E => ({op: 'mul', k: part(z), a: rd(c)}))), b: {op: 'mul', k: part(u), a: one}})
// atCount: the count's variable; atWit: its body at the witness (substE [(key, var w)] body).
const atCount = (c: Count): E => ({op: 'var', name: c.v})
const atWit = (w: string) => (c: Count): E => substE(c.body, {vars: {[c.key]: {op: 'var', name: w}}, maps: {}, flags: {}})
// countHyp: the instance's hypothesis (and/or binary, as Lean's .and/.or).
export function countHyp(cs: Count[], i: CountInst): C | undefined {
  const rs = resolve(cs, i.below, i.terms)
  if (!rs) return undefined
  const one: E = {op: 'const', value: 1}, w = atWit(i.wit)
  return {op: 'or', xs: [
    {op: '<=', a: side(posP, atCount, i.below, i.unit, rs), b: side(negP, atCount, i.below, i.unit, rs)},
    {op: 'and', xs: [{op: '<', a: {op: 'var', name: i.wit}, b: i.below}, {op: '<', a: side(negP, w, one, i.unit, rs), b: side(posP, w, one, i.unit, rs)}]}]}
}
// countHyps: every instance's, in order, or none if one isn't built.
export function countHyps(cs: Count[], is: CountInst[]): C[] | undefined {
  const out: C[] = []
  for (const i of is) {
    const h = countHyp(cs, i)
    if (!h) return undefined
    out.push(h)
  }
  return out
}
// witFresh: no hypothesis reads w, no count names it or reads it (in its bound or body), no instance's bound reads it.
const readsVar = (t: E | C, w: string): boolean => reads(t).vars.has(w)
export const witFresh = (hyps: C[], cs: Count[], is: CountInst[], w: string): boolean =>
  hyps.every(h => !readsVar(h, w)) && cs.every(c => c.v !== w && !readsVar(c.below, w) && !readsVar(c.body, w)) && is.every(j => !readsVar(j.below, w))
// countedOk: the witnesses distinct (cDistinct), each fresh.
export function countedOk(hyps: C[], cs: Count[], is: CountInst[]): boolean {
  const ws = is.map(i => i.wit)
  return new Set(ws).size === ws.length && is.every(i => witFresh(hyps, cs, is, i.wit))
}
// checkCounted, and TypeScript's own condition on the certificate, an input from outside: every witness a name (Lean's
// is a variable; a number 5 would pass `reads` yet be read as the variable "5") and every coefficient a safe integer
// (Lean's are Int).
const typed = (is: CountInst[]): boolean => is.every(i => typeof i.wit === 'string' && Number.isSafeInteger(i.unit) && i.terms.every(([z]) => Number.isSafeInteger(z)))
export function checkCounted(g: CountedGoal, cert: {insts: CountInst[], tree: Tree, lemmas?: LemmaCut[]}): boolean {
  if (!(countedOk(g.hyps, g.counts, cert.insts) && typed(cert.insts))) return false
  const goal = countedGoal(g, cert.insts)
  return goal !== undefined && checkGoalLemmas(goal, cert.tree, cert.lemmas)
}
// The goal a certificate's tree refutes: the goal's hypotheses, then the instances' (also what the search and the
// exporter read), or none.
export function countedGoal(g: CountedGoal, insts: CountInst[]): Goal | undefined {
  const hs = countHyps(g.counts, insts)
  return hs && {name: g.name, hyps: [...g.hyps, ...hs]}
}

// --- counts in a machine (Lean twin: ../lean-kernel/CountMachine.lean, cmachine_sound) ---------------------------------
// A machine's count map C (Machine.counts): at x, Σ_{k < below} body(k), j at x and key at k. Lean reads C as a map the
// request carries (CReach: each request carries it at its count at the request's view, as the runtimes compute it); a
// guard reads it there, a law a count of the state (`stateOnly`: its bound and body read no input and no carried map).
// The goals are obligations', the law proven read with each count map renamed to its post name C# (Lean's renLaw); a
// goal declares the counts it reads (Lean's cStartDecls, cStepDecls): after the start, each state count read across
// it; at a step, every count as the request carries it, then each state count read across the step (afterDecl). A
// goal's certificate names the cells it reads (a fresh variable, a count map, a key term) and Count.lean's instances
// and tree. checkMC follows Lean's counted rule, but TS accepts a strict subset: the legacy constant/repeated
// split refusals remain intentional (lean-kernel/README.md has the counted-certificate mirror contract).
export type CountDecl = {map: string, j: string, key: string, below: E, body: E, lo?: string, base?: number}
export type MapRead = [string, string, E]
export type CountCert = {reads: MapRead[], insts: CountInst[], tree: Tree, picks?: [string, E[]][], lemmas?: LemmaCut[]}
export const postName = (map: string) => `${map}#`
const declsOf = (m: Machine): CountDecl[] => Object.entries(m.counts ?? {}).map(([map, c]) => ({map, j: c.j, key: c.key, below: c.below, body: c.body, ...(c.base ? {lo: c.lo, base: c.base} : {})}))
// A declaration's second parameter (Lean's CDecl.lo, base): one parameter is lo = j, base 0.
const loOf = (d: CountDecl): string => d.lo ?? d.j, baseOf = (d: CountDecl): number => d.base ?? 0
// stateOnly: the bound and body read no input and no map a request carries (Lean: avoidsE (extVars ++ flagVars) and
// avoidsMapsE carried; a count reads no flag, quantified flag or witness here, countsScope's).
const stateOnly = (m: Machine, d: Counted): boolean => [d.below, d.body].every(t => {
  const r = reads(t)
  return m.inputs.every(i => !r.vars.has(i)) && [...(m.inputMaps ?? []), ...Object.keys(m.counts ?? {})].every(mp => !r.maps.has(mp))
})
export const stateCounts = (m: Machine): string[] => Object.entries(m.counts ?? {}).filter(([, d]) => stateOnly(m, d)).map(([c]) => c)
// Each count, as Lean's cDeclOk and cApart: its post name none of the machine's; j and key distinct plain names that are
// none of its names, bound keys, quantified flags or witnesses, nor a law's key or skolem (k, k#); the bound reading
// the params, inputs, state and j, the body those and key, each of the maps, carried maps and functions (no count, no
// post name, no flag); naturals only.
function countsScope(m: Machine, laws: Law[]): void {
  const counts = m.counts ?? {}
  if (!Object.keys(counts).length) return
  const state = Object.keys(m.state), maps = Object.keys(m.maps ?? {}), carried = m.inputMaps ?? [], fns = Object.keys(m.fns ?? {})
  const names = [...m.params, ...m.inputs, ...state], declared = [...names, ...maps, ...carried, ...fns, ...Object.keys(counts), ...Object.keys(m.step.flags ?? {})]
  const bound = [...quantified(m).flatMap(([f, q]) => [`?${f}`, ...witnessesOf(f, q), ...boundOf(q)]), ...Object.values(m.step.maps ?? {}).flatMap(w => ('each' in w ? [w.each] : []))]
  const lawNames = [...laws, ...(m.facts ?? [])].flatMap(l => [l.forall, ...(l.keys ?? [])].flatMap(k => (k ? [k, `${k}#`] : [])))
  for (const [c, d] of Object.entries(counts)) {
    const what = `${m.name}'s count ${c}`
    if (declared.includes(postName(c))) throw new Error(`${what}: its post name ${postName(c)} is already a name of ${m.name}`)
    // (two parameters: lo a plain name apart from j and key, base a positive integer; one: neither)
    if ((d.lo === undefined) !== (d.base === undefined) || (d.base !== undefined && !(Number.isSafeInteger(d.base) && d.base > 0))) throw new Error(`${what}: lo and base go together, base a positive integer`)
    const ps = d.lo === undefined ? [d.j] : [d.j, d.lo]
    for (const x of [...ps, d.key]) plainName(what, x)
    if (new Set([...ps, d.key]).size !== ps.length + 1) throw new Error(`${what}: j, lo and key are one name`)
    for (const x of [...ps, d.key]) if ([...declared, ...bound, ...lawNames].includes(x)) throw new Error(`${what}: ${x} is already a name of ${m.name} or a law`)
    unquantified(what, d.below); unquantified(what, d.body)
    inScope(`${what}'s bound`, [d.below], [...names, ...ps], [...maps, ...carried, ...fns])
    inScope(`${what}'s body`, [d.body], [...names, ...ps, d.key], [...maps, ...carried, ...fns])
    if (!natural(d.below) || !natural(d.body)) throw new Error(`${what}: a negative constant or factor is outside the kernel`)
  }
}
// countKeyParts (CountMachine.lean): the terms a key term gives the parameters: one, the term (j a constant 0); two, the term written base·a + b
// (j at a, lo at b). toCount: a read cell as Count.lean's count (its variable, the declaration with its parameters at
// the parts); toCounts: each.
const countKeyParts = (d: CountDecl, e: E): [E, E] | undefined =>
  (!baseOf(d) ? [{op: 'const', value: 0}, e] : e.op === 'add' && e.a.op === 'mul' && e.a.k === baseOf(d) ? [e.a.a, e.b] : undefined)
const toCount = (ds: CountDecl[], r: MapRead): Count | undefined => {
  const d = ds.find(x => x.map === r[1]), p = d && countKeyParts(d, r[2])
  if (!d || !p) return undefined
  const at: Subst = {vars: {[d.j]: p[0], [loOf(d)]: p[1]}, maps: {}, flags: {}}
  return {v: r[0], key: d.key, below: substE(d.below, at), body: substE(d.body, at)}
}
function toCounts(ds: CountDecl[], rs: MapRead[]): Count[] | undefined {
  const out: Count[] = []
  for (const r of rs) {
    const c = toCount(ds, r)
    if (!c) return undefined
    out.push(c)
  }
  return out
}
// readHyp: the read's variable is its cell; for two parameters, where the second part is below the base.
const readHyp = (ds: CountDecl[], r: MapRead): C => {
  const eq: C = {op: '=', a: {op: 'var', name: r[0]}, b: {op: 'get', map: r[1], key: r[2]}}, d = ds.find(x => x.map === r[1]), p = d && baseOf(d) ? countKeyParts(d, r[2]) : undefined
  return p ? {op: 'or', xs: [{op: '<=', a: {op: 'const', value: baseOf(d!)}, b: p[1]}, eq]} : eq
}
// A count at least its body at distinct keys (Lean's pickHyp, pickHyps): a pick names a read and key terms; where the
// terms are distinct and below the count's bound, the count is at least the sum of its body at them. It holds wherever
// the count is its sum, so a certificate may name any terms; a pick of no read adds nothing.
const allNe = (k: E, ks: E[]): C => (ks.length ? {op: 'and', xs: [{op: 'not', x: {op: '=', a: k, b: ks[0]!}}, allNe(k, ks.slice(1))]} : trueC)
const distinctBelow = (b: E, ks: E[]): C => (ks.length ? {op: 'and', xs: [{op: '<', a: ks[0]!, b}, {op: 'and', xs: [allNe(ks[0]!, ks.slice(1)), distinctBelow(b, ks.slice(1))]}]} : trueC)
const pickHyp = (c: Count, ks: E[]): C => ({op: 'or', xs: [{op: 'not', x: distinctBelow(c.below, ks)},
  {op: '<=', a: sumE(ks.map(k => substE(c.body, {vars: {[c.key]: k}, maps: {}, flags: {}}))), b: {op: 'var', name: c.v}}]})
const pickHyps = (ds: CountDecl[], rs: MapRead[], ps: [string, E[]][]): C[] => ps.flatMap(([v, ks]) => {
  const r = rs.find(x => x[0] === v), c = r && toCount(ds, r)
  return c ? [pickHyp(c, ks)] : []
})
const picksTyped = (ps: unknown): boolean => ps === undefined || (Array.isArray(ps) && ps.every(p => Array.isArray(p) && p.length === 2 && typeof p[0] === 'string' && Array.isArray(p[1]) && p[1].every(safeTerm)))
// readFresh: no hypothesis, declaration or key term reads v, and v is no declaration's j, lo or key.
const readFresh = (hyps: C[], ds: CountDecl[], rs: MapRead[], v: string): boolean =>
  hyps.every(h => !readsVar(h, v)) && ds.every(d => !readsVar(d.below, v) && !readsVar(d.body, v) && d.j !== v && loOf(d) !== v && d.key !== v) && rs.every(r => !readsVar(r[2], v))
// readsOk: the variables distinct (cDistinct), each fresh, each key term reading no declaration's key.
const readsOk = (hyps: C[], ds: CountDecl[], rs: MapRead[]): boolean =>
  new Set(rs.map(r => r[0])).size === rs.length && rs.every(r => readFresh(hyps, ds, rs, r[0]) && ds.every(d => !readsVar(r[2], d.key)))
// TypeScript's own condition on the certificate, an input from outside: each read a name, a map's name and a term over
// the naturals (Lean's E: every constant and factor a safe integer, which `safeTerm` checks), each instance's bound too.
const safeTerm = (t: unknown): boolean => {
  if (!t || typeof t !== 'object') return false
  const e = t as E
  switch (e.op) {
    case 'var': return typeof e.name === 'string'
    case 'const': return Number.isSafeInteger(e.value) && e.value >= 0
    case 'mul': return Number.isSafeInteger(e.k) && e.k >= 0 && safeTerm(e.a)
    case 'get': return typeof e.map === 'string' && safeTerm(e.key)
    case 'add': case 'sub': case 'min': case 'max': case 'prod': return safeTerm(e.a) && safeTerm(e.b)
    case 'if': return safeCond(e.c) && safeTerm(e.then) && safeTerm(e.else)
    // Count certificates still use the scalar/packed-key language, not native tuple terms.
    // These were refused by the default too; make that unchanged boundary explicit.
    case 'tup': case 'proj': return false
    default: return false
  }
}
const safeCond = (c: C): boolean => !!c && typeof c === 'object' && (c.op === '<' || c.op === '<=' || c.op === '=' ? safeTerm(c.a) && safeTerm(c.b)
  : c.op === 'not' ? safeCond(c.x) : (c.op === 'and' || c.op === 'or') && Array.isArray(c.xs) && c.xs.every(safeCond))
const readsTyped = (rs: MapRead[]): boolean => Array.isArray(rs) && rs.every(r => Array.isArray(r) && r.length === 3 && typeof r[0] === 'string' && typeof r[1] === 'string' && safeTerm(r[2]))
// witFreshW, countedOkW, checkCountedW: Count.lean's checkCounted with each witness fresh for the counts and the
// instances' bounds only. A machine's goal may read a witness in its instances of laws, facts and quantified flags,
// which hold at every value of a variable the machine never reads (witsOk): CountMachine.lean's countedW_sound asks the
// hypotheses at every value of the witnesses.
const witFreshW = (cs: Count[], is: CountInst[], w: string): boolean =>
  cs.every(c => c.v !== w && !readsVar(c.below, w) && !readsVar(c.body, w)) && is.every(j => !readsVar(j.below, w))
const countedOkW = (cs: Count[], is: CountInst[]): boolean => { const ws = is.map(i => i.wit); return new Set(ws).size === ws.length && is.every(i => witFreshW(cs, is, i.wit)) }
function checkCountedW(hyps: C[], cs: Count[], cert: {insts: CountInst[], tree: Tree, lemmas?: LemmaCut[]}): boolean {
  if (!(countedOkW(cs, cert.insts) && typed(cert.insts))) return false
  const hs = countHyps(cs, cert.insts)
  return hs !== undefined && checkGoalLemmas({name: 'counted', hyps: [...hyps, ...hs]}, cert.tree, cert.lemmas)
}
// checkMC: each declaration's j and lo differ from its key, the reads are fresh, no read is a witness or reads one in
// its key term, and checkCountedW accepts the counted goal they make (the goal's hypotheses, each read variable equal to
// its cell; Lean's names the hypotheses it uses, each the goal's).
export function checkMC(hyps: C[], ds: CountDecl[], k: CountCert): boolean {
  if (!(ds.every(d => d.j !== d.key && loOf(d) !== d.key) && picksTyped(k.picks) && readsTyped(k.reads) && Array.isArray(k.insts) && k.insts.every(i => !!i && safeTerm(i.below)) && readsOk(hyps, ds, k.reads))) return false
  if (!k.reads.every(r => k.insts.every(i => i.wit !== r[0] && !readsVar(r[2], i.wit)))) return false
  const cs = toCounts(ds, k.reads)
  return cs !== undefined && checkCountedW([...hyps, ...k.reads.map(r => readHyp(ds, r)), ...pickHyps(ds, k.reads, k.picks ?? [])], cs, {insts: k.insts, tree: k.tree, lemmas: k.lemmas})
}
// The goal a certificate's tree refutes (what the search and the exporter read), or none.
export function mcGoal(hyps: C[], ds: CountDecl[], k: Pick<CountCert, 'reads' | 'insts' | 'picks'>): Goal | undefined {
  const cs = toCounts(ds, k.reads)
  return cs && countedGoal({name: 'counted', hyps: [...hyps, ...k.reads.map(r => readHyp(ds, r)), ...pickHyps(ds, k.reads, k.picks ?? [])], counts: cs}, k.insts)
}
// The goals of a machine with counts: obligations', each law proven renamed (renLaw), with the counts each declares.
export function countedObligations(m: Machine, laws: Law[], instances: Record<string, Instances> = {}, only?: number): {goal: Goal, decls: CountDecl[]}[] {
  if (m.history || (m.sums && Object.keys(m.sums).length)) throw new Error(`${m.name}: counts go with no history and no sums`)
  scope(m, laws)
  const ok = [...Object.values(m.state), ...Object.values(m.step.state ?? {}), ...Object.values(m.step.maps ?? {}).flatMap(w => ('each' in w ? [w.value] : [w.key, w.value]))].every(natural)
    && Object.values(m.step.flags ?? {}).every(naturalC) && laws.every(l => naturalC(l.holds)) && Object.values(m.maps ?? {}).every(c => Number.isInteger(c) && c >= 0)
  if (!ok || !(m.facts ?? []).every(l => naturalC(l.holds)) || laws.some(l => mentions(l.holds, m.inputs))) throw new Error('a negative constant or factor, or a law about a request, is outside the kernel')
  const ren: Subst = {vars: {}, maps: Object.fromEntries(Object.keys(m.counts ?? {}).map(c => [c, (key: E): E => ({op: 'get', map: postName(c), key})])), flags: {}}
  const proven = (law: Law) => { const h = substC(law.holds, ren); return law.forall ? substC(h, {vars: {[law.forall]: {op: 'var', name: `${law.forall}#`}}, maps: {}, flags: {}}) : h }
  const all = declsOf(m), st = all.filter(d => stateOnly(m, d))
  const after = (at: Subst): CountDecl[] => st.map(d => ({...d, map: postName(d.map), below: substE(d.below, at), body: substE(d.body, at)}))
  const pre = preOf(m), u = updateOf(m), assume = m.assume ? [inlineFlags(m, m.assume)] : []
  return laws.flatMap((law, i) => {
    if (only !== undefined && i !== only) return []
    const inst = own(instances, law.name) ?? {}
    const start = given(m, holds(from(startOf(m)), pre), inst)
    const turn = step(holds(given(m, from(), inst), [...pre, ...assume, ...assumed(laws, inst), ...closing(m, inst)]), u)
    return [{goal: goal(`${law.name} @start`, start, atEnd(start, proven(law))), decls: after(start.at)},
      {goal: goal(`${law.name} @step`, turn, atEnd(turn, proven(law))), decls: [...all, ...after(turn.at)]}]
  })
}
// witsOk: a certificate's witnesses are names nothing of the machine or its laws reads or binds: none of its names, bound
// keys, quantified flags or witnesses, nor a law's key or skolem (Lean's witsOk: fresh for the machine, the precondition
// and the laws, no entry's skolem or further key).
function witsOk(m: Machine, laws: Law[], k: CountCert): boolean {
  const flags = Object.keys(m.step.flags ?? {})
  const taken = new Set([...m.params, ...m.inputs, ...Object.keys(m.state), ...Object.keys(m.maps ?? {}), ...(m.inputMaps ?? []), ...Object.keys(m.fns ?? {}), ...Object.keys(m.counts ?? {}), ...flags,
    ...flags.map(f => `?${f}`), ...quantified(m).flatMap(([f, q]) => [...witnessesOf(f, q), ...boundOf(q)]), ...Object.values(m.step.maps ?? {}).flatMap(w => ('each' in w ? [w.each] : [])),
    ...[...laws, ...(m.facts ?? [])].flatMap(l => [l.forall, ...(l.keys ?? [])].flatMap(x => (x ? [x, `${x}#`] : [])))])
  return Array.isArray(k.insts) && k.insts.every(i => !!i && typeof i.wit === 'string' && !taken.has(i.wit))
}
// Lean's checkCMachine: every goal has a certificate, its witnesses fresh, and every certificate checks.
export function checkCountedLaws(m: Machine, laws: Law[], proof: {instances: Record<string, Instances>, certs: Record<string, CountCert>}): boolean {
  return countedObligations(m, laws, proof.instances).every(({goal: g, decls}) => { const k = own(proof.certs, g.name); return k !== undefined && witsOk(m, laws, k) && checkMC(g.hyps, decls, k) })
}

// --- ghost maps (Lean twin: ../lean-kernel/GhostMap.lean) ----------------------------------------------------------------
// A ghosted machine: the original and its ghosts, ghost values (a start over the params, a step) and ghost maps (a start
// at every key and a write, at one key or at every key), new names no part of the original reads. A ghost map is a Skolem
// function the step keeps: a law of the ghosted machine about every key k that reads W at k says every k has a witness.
// GhostMap.lean: smghost_laws (a law that reads no ghost holds of the original), some_of_ghostmap and
// forall_some_of_ghostmap (a law over a ghost map gives, at every reachable state of the original, ∀ k ∃ x). The two
// functions below are Lean's SGhostedM.full and smghostOk, over the machine's literal (emit.ts's machineLit).
export type GhostMap = {start: number, write: MapUpdate}
export type Ghosted = {orig: Machine, vars: Record<string, {start: E, step: E}>, maps: Record<string, GhostMap>}
// SGhostedM.full: the original with each ghost's start and step after its own (Lean: lists appended; here records, whose
// names smghostOk keeps apart from the original's).
export function ghostedMachine(g: Ghosted): Machine {
  const o = g.orig, gv = Object.entries(g.vars), gm = Object.entries(g.maps)
  return {...o,
    state: {...o.state, ...Object.fromEntries(gv.map(([name, x]) => [name, x.start]))},
    maps: {...o.maps, ...Object.fromEntries(gm.map(([name, x]) => [name, x.start]))},
    step: {...o.step,
      state: {...o.step.state, ...Object.fromEntries(gv.map(([name, x]) => [name, x.step]))},
      maps: {...o.step.maps, ...Object.fromEntries(gm.map(([name, x]) => [name, x.write]))}}}
}
// smghostOk: the original takes no history and no sums (Lean's SGhostedM is over SMachine); the ghost variables are none of
// its variables (extVars: inputs, quantified flags and their witnesses; the state; the plain flags; the keys its writes
// and quantified flags bind); the ghost maps none of its maps (origMaps: started, written, carried); and none of its
// parts reads a ghost (pre, assume, flags, the start, the step, the writes, the facts; a flag f reads Lean's ?f). Lean's
// distinct ghosts and ghost writes of ghost maps only hold here by construction (record keys; a ghost map's write is its
// own).
export function ghostedOk(g: Ghosted): boolean {
  const o = g.orig, vs = Object.keys(g.vars), ms = Object.keys(g.maps)
  const fl = Object.entries(o.step.flags ?? {}), ws = Object.values(o.step.maps ?? {})
  const quant = fl.filter((e): e is [string, Extract<C, {op: 'all'}>] => e[1].op === 'all')
  const varNames = [...o.inputs, ...quant.flatMap(([f, q]) => [`?${f}`, ...witnessesOf(f, q)]), ...Object.keys(o.state), ...Object.keys(o.step.state ?? {}),
    ...fl.map(([f]) => `?${f}`), ...ws.flatMap(w => ('each' in w ? [w.each] : [])), ...quant.flatMap(([, q]) => boundOf(q))]
  const mapNames = [...Object.keys(o.maps ?? {}), ...Object.keys(o.step.maps ?? {}), ...(o.inputMaps ?? [])]
  const parts: (E | C)[] = [o.pre ?? trueC, o.assume ?? trueC, ...fl.map(([, c]) => c), ...Object.values(o.state), ...Object.values(o.step.state ?? {}),
    ...ws.flatMap(w => ('each' in w ? [w.value] : [w.key, w.value])), ...(o.facts ?? []).map(l => l.holds)]
  const apart = (t: E | C): boolean => { const r = reads(t); return vs.every(v => !r.vars.has(v) && !(v.startsWith('?') && r.flags.has(v.slice(1)))) && ms.every(mp => !r.maps.has(mp)) }
  return !o.history && !o.sums && vs.every(v => !varNames.includes(v)) && ms.every(mp => !mapNames.includes(mp)) && parts.every(apart)
}
// The laws of a ghosted machine, checked: the ghosts as smghostOk says, and the laws of the ghosted machine as checkLaws
// says (Lean: smghostOk and checkSMachine of SGhostedM.full).
export const checkGhostedLaws = (g: Ghosted, laws: Law[], proof: {instances: Record<string, Instances>, trees: Record<string, Tree>}): boolean =>
  ghostedOk(g) && checkLaws(ghostedMachine(g), laws, proof)
// GhostMap.lean's forall_some_of_ghostsubst, the ∃ reading: a law with "there exists" (`some`, its body c) holds of the
// original (Lean's ExHolds: for every value of its keys, some natural for each bound name where c holds) where the
// ghosted machine's law `plain` is c with each bound name x replaced by a term sub[x] (Lean's substC σ c: a term over
// anything of the ghosted machine, a ghost map at a key, several, the law's keys). The caller has the plain law proven
// of ghostedMachine(g) (checkLaws). What Lean takes: the ghosts smghostOk's (ghostedOk); the plain law exactly c with sub
// in place, about the law's keys (e.law.key, e.keys2); c reading no ghost variable and no ghost map (avoids, avoidsMaps);
// the bound names sub's (σ's names). And where the law's reading and Lean's statement would part: c in Lean's terms (no
// quantified condition, no flag), each bound name once, none a key of the law (ExHolds writes the bound names over the
// keys' values) nor a name of the original or of a ghost.
export function someOfGhostsOk(g: Ghosted, law: Law, plain: Law, sub: Record<string, E>): boolean {
  const xs = law.some ?? [], keys = [...(law.forall ? [law.forall] : []), ...(law.keys ?? [])], o = g.orig, r = reads(law.holds), text = JSON.stringify(law.holds)
  const vs = Object.keys(g.vars), ms = Object.keys(g.maps)
  const names = [...o.params, ...o.inputs, ...Object.keys(o.state), ...Object.keys(o.maps ?? {}), ...(o.inputMaps ?? []), ...Object.keys(o.fns ?? {}), ...vs, ...ms]
  return ghostedOk(g) && xs.length > 0 && new Set(xs).size === xs.length && Object.keys(sub).length === xs.length && xs.every(x => Object.hasOwn(sub, x))
    && !text.includes('"op":"all"') && !text.includes('"op":"flag"') && !plain.some?.length
    && plain.forall === law.forall && JSON.stringify(plain.keys ?? []) === JSON.stringify(law.keys ?? [])
    && JSON.stringify(plain.holds) === JSON.stringify(substC(law.holds, {vars: Object.assign(Object.create(null) as Record<string, E>, sub), maps: {}, flags: {}}))
    && vs.every(v => !r.vars.has(v)) && ms.every(mp => !r.maps.has(mp))
    && xs.every(x => !keys.includes(x) && !names.includes(x))
}
